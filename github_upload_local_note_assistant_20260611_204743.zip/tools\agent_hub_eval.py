import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN_MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
PLUGIN_MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
REPORT = ROOT / "tools" / "agent_hub_eval_report.md"


def file_contains(path, text):
    return text in path.read_text(encoding="utf-8")


def manifest_version():
    return json.loads(PLUGIN_MANIFEST.read_text(encoding="utf-8")).get("version")


def extract_target(text):
    wiki = re.search(r"\[\[([^\]\n]+)\]\]", text)
    if wiki:
        return wiki.group(1).strip()
    html = re.search(r"<!--\s*([^>]+?)\s*-->", text)
    if html:
        return html.group(1).strip()
    tag = re.search(r"#([A-Za-z0-9_\-/\u4e00-\u9fff]+)", text)
    if tag:
        return "#" + tag.group(1)
    bare = re.search(r"\b(tag[0-9A-Za-z_-]*)\b", text, re.I)
    if bare:
        return bare.group(1)
    around = re.search(r"(?:在|到|放到|放进|写进|写到|插入到|接在)\s*([A-Za-z0-9_\-\u4e00-\u9fff]{1,80})\s*(?:处|位置|后面|前面|下面|上面|后|前)?", text)
    return around.group(1).strip() if around else ""


def infer_hub(text, state=None):
    state = state or {}
    value = str(text or "").strip()
    lower = value.lower()
    target = extract_target(value)
    prior = re.search(r"刚才|刚刚|刚生成|上面|之前|上一轮|上一条|前面|那个回答|那个证明|那段|这段回答|这个证明|last|previous|above|earlier", value, re.I)
    transform = prior and re.search(r"改写|重写|润色|整理|总结|摘要|压缩|扩写|补全|改成|变成|转成|格式|命题-证明|定理-证明|rewrite|summarize|polish|convert", value, re.I)
    insert = re.search(r"插入|加入|添加|追加|放到|放进|写进|写到|塞到|接在|insert|append|add|put|place", value, re.I)

    if re.search(r"暂停\s*AI|暂停模型|关闭\s*AI|不要调用模型|pause\s*ai|pause", value, re.I):
        return "pause_ai", []
    if re.search(r"恢复\s*AI|继续\s*AI|开启\s*AI|启用\s*AI|resume\s*ai|resume", value, re.I):
        return "resume_ai", []
    if re.search(r"检查.*索引|索引.*变化|check.*index", value, re.I):
        return "check_index_changes", []
    if re.search(r"更新.*变更.*索引|更新.*改动.*索引|update.*changed.*index", value, re.I):
        return "update_changed_index", []
    if re.search(r"重建.*索引|完整.*重建.*索引|rebuild.*index|build.*index", value, re.I):
        return "build_index", []
    if re.search(r"记忆|对话记录|历史对话|conversation memory|memory", value, re.I) and re.search(r"打开|查看|进入|展开|管理|删除|回到|继续|open|show|view|manage", value, re.I):
        return "memory", []
    if re.search(r"知识索引|概念索引|知识图谱|knowledge index|knowledge", value, re.I) and re.search(r"打开|查看|进入|刷新|构建|建立|重建|open|show|view|build|refresh", value, re.I):
        return "knowledge", []
    if re.search(r"迁移|链接替换|符号替换|migration", value, re.I) and re.search(r"审阅|审核|表格|review", value, re.I):
        return "migration_review", []
    if re.search(r"迁移|链接替换|符号替换|migration", value, re.I) and re.search(r"工具|页面|面板|打开|进入|呼出|使用|open|tool|panel", value, re.I):
        return "migration_tool", []
    if re.search(r"chatgpt|gpt|prompt\s*包|prompt\s*package|handoff|交接", value, re.I) and re.search(r"打开|生成|创建|导入|粘贴|复制|模式|包|文件|open|generate|create|import|paste|copy", value, re.I):
        return "chatgpt_handoff", []
    if state.get("hasImage") and re.search(r"图片|截图|图像|图里|照片|识别|转\s*markdown|转成\s*md|pdf|证明|公式|image|screenshot|ocr", value, re.I):
        return "image_to_markdown", []
    if re.search(r"正式笔记|正式文档|原笔记|formal note|formal notes", value, re.I) and re.search(r"改掉|修改|删除|替换|直接改|覆盖|remove|delete|replace|modify", value, re.I):
        return "formal_note_proposal", []
    if re.search(r"空白|新建|创建|建立|打开|开一页|blank", value, re.I) and re.search(r"草稿|文档|笔记|draft|note|页面", value, re.I):
        return "create_blank_draft", []
    if state.get("hasDraftSelection") and re.search(r"选中|所选|这段|这一段|selected|selection", value, re.I) and re.search(r"改写|修改|润色|优化|替换|扩写|整理|证明|rewrite|edit|replace|polish", value, re.I):
        return "edit_selection", []
    if state.get("hasCurrentDraft") and re.search(r"当前草稿|当前文档|这篇草稿|整个草稿|这篇|全文|整篇|current draft|whole draft|draft", value, re.I) and re.search(r"改写|修改|重写|整理|优化|扩写|补全|润色|rewrite|edit|improve|polish", value, re.I):
        return "edit_current_draft", []
    if re.search(r"整理|梳理|总结|综述|汇总|生成|写一篇|做一个|做成|形成|synthesize|organize|summarize", value, re.I) and re.search(r"文件|文档|笔记|草稿|ai generated|draft|note|页面|资料", lower, re.I):
        return "generate_draft", []
    if insert and (target or re.search(r"草稿|draft|后面|前面|之前|之后|下面|上面|末尾|开头", value, re.I)):
        if prior:
            steps = ["use_artifact"]
            if transform:
                steps.append("generate_markdown")
            steps.append("insert_into_draft")
            return "agent_task", steps
        return "insert_into_draft", []
    if re.search(r"查找|搜索|找到|检索|解释|说明|讲讲|说说|回忆|忘了|看看|是什么|什么是|为什么|如何|怎么|证明|应用|关系|区别|联系|来源|引用|search|find|explain|what|why|how", value, re.I):
        return "search_answer", []
    return "search_answer", []


SCENARIOS = [
    ("检查索引有没有变化", {}, "check_index_changes", []),
    ("更新变更索引", {}, "update_changed_index", []),
    ("完整重建索引", {}, "build_index", []),
    ("打开记忆面板", {}, "memory", []),
    ("查看知识索引", {}, "knowledge", []),
    ("打开迁移工具", {}, "migration_tool", []),
    ("打开迁移审阅表格", {}, "migration_review", []),
    ("打开 ChatGPT 交接模式", {}, "chatgpt_handoff", []),
    ("把这张截图里的证明转成 Markdown", {"hasImage": True}, "image_to_markdown", []),
    ("创建一个空白草稿，主题是层", {}, "create_blank_draft", []),
    ("整理 C 星代数和表示的关系，生成一个文件", {}, "generate_draft", []),
    ("改写当前草稿，让它更像正式笔记", {"hasCurrentDraft": True}, "edit_current_draft", []),
    ("把选中段落润色一下", {"hasDraftSelection": True}, "edit_selection", []),
    ("在 #pp 后面插入一个定理", {"hasCurrentDraft": True}, "insert_into_draft", []),
    ("把刚才那段证明放到 #tag2 后面", {"hasCurrentDraft": True}, "agent_task", ["use_artifact", "insert_into_draft"]),
    ("将上一轮关于 NIP 的回答改成命题-证明格式，然后放到 tag1", {"hasCurrentDraft": True}, "agent_task", ["use_artifact", "generate_markdown", "insert_into_draft"]),
    ("直接修改正式笔记A，把旧记号替换掉", {}, "formal_note_proposal", []),
    ("C 星代数的表示有什么应用", {}, "search_answer", []),
]


TESTS = [
    ("manifest version", manifest_version, "0.4.85"),
    ("tool catalog static check", lambda: file_contains(PLUGIN_MAIN, "AGENT_TOOL_SPECS"), True),
    ("hub local intent static check", lambda: file_contains(PLUGIN_MAIN, "inferAgentHubLocalIntent"), True),
    ("hub normalizer static check", lambda: file_contains(PLUGIN_MAIN, "normalizeAgentHubRoute"), True),
    ("clean router prompt static check", lambda: file_contains(PLUGIN_MAIN, "Prefer the user's real goal over individual keywords"), True),
    ("clean planner prompt static check", lambda: file_contains(PLUGIN_MAIN, "You plan safe Obsidian draft tool steps"), True),
]


def main():
    passed = 0
    lines = ["# Agent Hub Evaluation", "", f"Static checks: `{len(TESTS)}`", ""]
    for name, fn, expected in TESTS:
        try:
            actual = fn()
            ok = actual == expected
        except Exception as error:
            actual = f"ERROR: {error}"
            ok = False
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        lines.append(f"  - actual: `{actual}`")
        lines.append(f"  - expected: `{expected}`")

    scenario_passed = 0
    lines.append("")
    lines.append(f"Routing scenarios: `{len(SCENARIOS)}`")
    lines.append("")
    for text, state, expected_action, expected_steps in SCENARIOS:
        actual_action, actual_steps = infer_hub(text, state)
        ok = actual_action == expected_action and (not expected_steps or actual_steps == expected_steps)
        scenario_passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} `{text}`")
        lines.append(f"  - actual: `{actual_action}` / `{actual_steps}`")
        lines.append(f"  - expected: `{expected_action}` / `{expected_steps}`")

    total = len(TESTS) + len(SCENARIOS)
    total_passed = passed + scenario_passed
    lines.insert(2, f"Summary: `{total_passed}/{total}` checks passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{total_passed}/{total} checks passed")
    print(REPORT)
    return 0 if total_passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
