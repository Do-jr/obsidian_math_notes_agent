from pathlib import Path
import re
import sys

from knowledge_index_experiment import extract_callouts, line_score, score_callout, tokenize


VAULT = Path(r"C:\Users\ddjr\Desktop\obsidian notes.valut")

TESTS = [
    {
        "query": "C星代数 是什么",
        "must": "泛函分析\\C星代数\\C星代数.md",
        "line": 4,
        "top": 3,
        "why": "basic definition should beat specialized CStar category or matrix C*-algebra blocks",
    },
    {
        "query": "C星代数 基本定义",
        "must": "泛函分析\\C星代数\\C星代数.md",
        "line": 4,
        "top": 3,
        "why": "basic definition intent",
    },
    {
        "query": "度量化定理",
        "must": "泛函分析\\拓扑向量空间\\拓扑向量空间的理论部分.md",
        "line": 174,
        "top": 1,
        "why": "exact theorem lookup",
    },
    {
        "query": "范畴性质 态射 表示论 C星代数",
        "must": "泛函分析\\C星代数\\C星代数的范畴性质.md",
        "line": 6,
        "top": 3,
        "why": "multi-aspect topic should retrieve category definition",
    },
    {
        "query": "C星代数 表示 态射",
        "must": "泛函分析\\C星代数\\C星代数的表示.md",
        "line": 15,
        "top": 5,
        "why": "representation morphism should be retrievable",
    },
]

TOPIC_BUNDLE_TESTS = [
    {
        "query": "C星代数",
        "must": "泛函分析\\C星代数\\C星代数的表示.md",
        "top": 8,
        "why": "broad C*-algebra synthesis should include the linked/same-folder representation note",
    },
    {
        "query": "C星代数",
        "must": "泛函分析\\C星代数\\C星代数的范畴性质.md",
        "top": 8,
        "why": "broad C*-algebra synthesis should include same-folder categorical properties",
    },
]


WIKI = re.compile(r"\[\[([^\]\n]+)\]\]")


def normalize_ref(value):
    return str(value or "").split("|")[0].split("#")[0].removesuffix(".md").replace("/", "\\").strip().lower()


def extract_links(text):
    links = []
    for match in WIKI.finditer(str(text or "")):
        ref = normalize_ref(match.group(1))
        if ref:
            links.append(ref)
    return list(dict.fromkeys(links))


def profile_matches(profile, ref):
    target = normalize_ref(ref)
    title = normalize_ref(profile["title"])
    path = normalize_ref(profile["path"])
    return bool(target and (target == title or target == path or path.endswith("\\" + target) or target.endswith("\\" + title)))


def load_callouts(vault):
    files = [path for path in vault.rglob("*.md") if ".obsidian" not in path.parts]
    callouts = []
    profiles = []
    for path in files:
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = path.read_text(encoding="utf-8-sig", errors="ignore")
        relative = path.relative_to(vault)
        extracted = extract_callouts(relative, text)
        callouts.extend(extracted)
        rel_parts = relative.parts
        profiles.append(
            {
                "path": str(relative),
                "title": path.stem,
                "folders": list(rel_parts[:-1]),
                "folder": str(Path(*rel_parts[:-1])) if len(rel_parts) > 1 else "",
                "links": extract_links(text),
                "callouts": extracted,
                "text": "\n".join([str(relative), path.stem, " ".join(rel_parts[:-1]), text[:5000]]),
            }
        )
    return files, callouts, profiles


def rank(callouts, query):
    terms = tokenize(query)
    return sorted(
        ((score_callout(item, query, terms), item) for item in callouts),
        key=lambda pair: pair[0],
        reverse=True,
    )


def topic_bundle(profiles, callouts, query, limit=12):
    terms = tokenize(query)
    ranked_callouts = rank(callouts, query)
    seed_paths = {item["path"] for _score, item in ranked_callouts[:12]}
    seed_profiles = [profile for profile in profiles if profile["path"] in seed_paths]
    seed_refs = set()
    seed_links = []
    seed_folders = set()
    for profile in seed_profiles:
        seed_refs.add(normalize_ref(profile["title"]))
        seed_refs.add(normalize_ref(profile["path"]))
        seed_folders.add(profile["folder"])
        seed_links.extend(profile["links"])
    compact_query = re.sub(r"\s+", "", query).lower()
    scored = []
    for profile in profiles:
        score = line_score(profile["text"], terms)
        if profile["path"] in seed_paths:
            score += 120
        if profile["folder"] and profile["folder"] in seed_folders:
            score += 75
        if any(normalize_ref(link) in seed_refs for link in profile["links"]):
            score += 70
        if any(profile_matches(profile, link) for link in seed_links):
            score += 70
        compact_profile = re.sub(r"\s+", "", f"{profile['path']} {profile['title']} {' '.join(profile['folders'])}").lower()
        compact_title = re.sub(r"\s+", "", profile["title"]).lower()
        compact_basename = re.sub(r"\.md$", "", Path(profile["path"]).name, flags=re.I)
        compact_basename = re.sub(r"\s+", "", compact_basename).lower()
        if compact_query and compact_query in {compact_title, compact_basename}:
            score += 160
        elif compact_query and compact_query in compact_profile:
            score += 45
        if profile["path"].replace("/", "\\").lower().startswith("ai drafts\\") and profile["path"] not in seed_paths:
            score -= 80
        if score > 0:
            scored.append((score, profile))
    return sorted(scored, key=lambda pair: pair[0], reverse=True)[:limit]


def main():
    files, callouts, profiles = load_callouts(VAULT)
    lines = [
        "# Knowledge Index Evaluation",
        "",
        f"- Vault: `{VAULT}`",
        f"- Markdown files: `{len(files)}`",
        f"- Callouts: `{len(callouts)}`",
        "",
    ]
    passed = 0
    for test in TESTS:
        ranked = rank(callouts, test["query"])
        top_items = ranked[: max(8, test["top"])]
        hit_position = None
        for index, (_score, item) in enumerate(ranked[: test["top"]], start=1):
            if item["path"] == test["must"] and int(item["line"]) == int(test["line"]):
                hit_position = index
                break
        ok = hit_position is not None
        if ok:
            passed += 1
        lines.append(f"## {'PASS' if ok else 'FAIL'}: {test['query']}")
        lines.append("")
        lines.append(f"- Expect: `{test['must']}:{test['line']}` in top {test['top']}")
        lines.append(f"- Reason: {test['why']}")
        if ok:
            lines.append(f"- Hit position: `{hit_position}`")
        lines.append("")
        lines.append("Top candidates:")
        for index, (score, item) in enumerate(top_items, start=1):
            lines.append(
                f"{index}. `{score:.1f}` `{item['path']}:{item['line']}` [{item['type']}] {item['title'] or '(untitled)'}"
            )
        lines.append("")
    for test in TOPIC_BUNDLE_TESTS:
        bundle = topic_bundle(profiles, callouts, test["query"], max(12, test["top"]))
        hit_position = None
        for index, (_score, profile) in enumerate(bundle[: test["top"]], start=1):
            if profile["path"] == test["must"]:
                hit_position = index
                break
        ok = hit_position is not None
        if ok:
            passed += 1
        lines.append(f"## {'PASS' if ok else 'FAIL'} topic coverage: {test['query']}")
        lines.append("")
        lines.append(f"- Expect: `{test['must']}` in topic bundle top {test['top']}")
        lines.append(f"- Reason: {test['why']}")
        if ok:
            lines.append(f"- Hit position: `{hit_position}`")
        lines.append("")
        lines.append("Top topic bundle notes:")
        for index, (score, profile) in enumerate(bundle[: max(8, test["top"])], start=1):
            lines.append(f"{index}. `{score:.1f}` `{profile['path']}`")
        lines.append("")
    total = len(TESTS) + len(TOPIC_BUNDLE_TESTS)
    lines.insert(1, f"\nSummary: `{passed}/{total}` tests passed.\n")
    report = Path("tools/knowledge_index_eval_report.md")
    report.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} tests passed")
    print(report)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
