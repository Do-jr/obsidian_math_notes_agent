const {
  ItemView,
  MarkdownView,
  Notice,
  MarkdownRenderer,
  Modal,
  Plugin,
  PluginSettingTab,
  Setting,
  TFile,
  requestUrl,
} = require("obsidian");

const VIEW_TYPE = "local-note-assistant-view";
const INDEX_VERSION = 3;
const KNOWLEDGE_INDEX_VERSION = 8;
const CONCEPT_CARD_INDEX_VERSION = 3;

const DEFAULT_SETTINGS = {
  language: "en",
  embeddingProvider: "ollama",
  ollamaBaseUrl: "http://localhost:11434",
  ollamaModel: "nomic-embed-text",
  openaiApiKey: "",
  openaiBaseUrl: "https://api.openai.com/v1",
  openaiModel: "text-embedding-3-small",
  geminiApiKey: "",
  geminiModel: "gemini-embedding-001",
  qwenApiKey: "",
  qwenBaseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
  qwenModel: "text-embedding-v4",
  qwenDimensions: 1024,
  customApiKey: "",
  customBaseUrl: "",
  customModel: "",
  chatProvider: "qwen",
  answerWithSources: true,
  answerSourceMode: "notes_only",
  ollamaChatModel: "qwen2.5:7b",
  openaiChatModel: "gpt-4o-mini",
  geminiChatModel: "gemini-1.5-flash",
  qwenChatModel: "qwen-plus",
  deepseekApiKey: "",
  deepseekBaseUrl: "https://api.deepseek.com",
  deepseekChatModel: "deepseek-chat",
  customChatModel: "",
  enableImageInput: true,
  visionProvider: "chat",
  imageOutputLanguage: "auto",
  ollamaVisionModel: "llava",
  openaiVisionModel: "gpt-4o-mini",
  geminiVisionModel: "gemini-1.5-flash",
  qwenVisionModel: "qwen-vl-plus",
  customVisionModel: "",
  maxImageBytes: 5242880,
  enableVoiceInput: true,
  voiceInputLanguage: "zh-CN",
  voiceInputMode: "append",
  chunkSize: 1200,
  chunkOverlap: 160,
  maxIncrementalIndexChunks: 250,
  resultLimit: 10,
  answerContextLimit: 6,
  maxAnswerContextChars: 5000,
  maxTotalAnswerContextChars: 30000,
  includeNeighborChunks: true,
  neighborChunksBefore: 1,
  neighborChunksAfter: 1,
  includeSameHeadingSection: true,
  useConversationMemory: true,
  conversationTurnsToKeep: 4,
  assistantArtifactsToKeep: 12,
  useLongTermMemory: true,
  longTermMemoryToKeep: 60,
  useNegativeFeedbackMemory: true,
  negativeFeedbackToKeep: 40,
  aiPaused: false,
  migrationScanLimit: 30,
  maxAgentSteps: 6,
  confirmAgentPlans: true,
  userWritingPreferences:
    "Mathematical notes should prefer definition-theorem-proof-example structure when appropriate. Preserve Obsidian-renderable LaTeX. Avoid unsupported source claims.",
  writeMode: "disabled",
  draftFolder: "AI Drafts",
  draftSourceMode: "notes_model",
  maxDraftEditChars: 50000,
  handoffFolder: "AI Handoffs",
  maxHandoffPromptChars: 18000,
};

const TOOL_KEYWORD_DEFS = [
  {
    keyword: "\u95ee\u7b54",
    aliases: ["\u641c\u7d22", "\u67e5\u627e", "\u89e3\u91ca", "search", "qa"],
    action: "search_answer",
    zhLabel: "\u7b14\u8bb0\u95ee\u7b54 / \u641c\u7d22",
    enLabel: "Search / Q&A",
    zhHint: "\u6309\u666e\u901a\u95ee\u7b54\u6216\u7b14\u8bb0\u641c\u7d22\u5904\u7406\u3002",
    enHint: "Answer normally with note search.",
  },
  {
    keyword: "\u4e3b\u9898\u6574\u7406",
    aliases: ["\u4e3b\u9898\u7b14\u8bb0", "\u6574\u7406\u6587\u4ef6", "\u751f\u6210\u6587\u4ef6", "topic"],
    action: "topic_synthesis",
    zhLabel: "\u751f\u6210 AI generated \u4e3b\u9898\u6587\u4ef6",
    enLabel: "Topic synthesis file",
    zhHint: "\u6839\u636e\u7b14\u8bb0\u6574\u7406\u4e00\u4e2a\u4e3b\u9898\u6587\u4ef6\u3002",
    enHint: "Create an AI generated synthesis file from your notes.",
  },
  {
    keyword: "\u751f\u6210\u8349\u7a3f",
    aliases: ["\u8349\u7a3f", "\u8349\u7a3f\u9884\u89c8", "draft"],
    action: "generate_draft",
    zhLabel: "\u751f\u6210\u8349\u7a3f\u9884\u89c8",
    enLabel: "Generate draft preview",
    zhHint: "\u751f\u6210\u8349\u7a3f\u9884\u89c8\uff0c\u518d\u7531\u4f60\u51b3\u5b9a\u662f\u5426\u521b\u5efa\u6587\u4ef6\u3002",
    enHint: "Generate a draft preview before creating a file.",
  },
  {
    keyword: "\u7a7a\u767d\u8349\u7a3f",
    aliases: ["\u65b0\u5efa\u8349\u7a3f", "\u7a7a\u767d\u6587\u6863", "blank"],
    action: "create_blank_draft",
    zhLabel: "\u521b\u5efa\u7a7a\u767d\u8349\u7a3f",
    enLabel: "Create blank draft",
    zhHint: "\u53ea\u521b\u5efa\u7a7a\u767d\u8349\u7a3f\uff0c\u4e0d\u81ea\u52a8\u5199\u5185\u5bb9\u3002",
    enHint: "Create an empty draft without generated content.",
  },
  {
    keyword: "\u63d2\u5165\u8349\u7a3f",
    aliases: ["\u8ffd\u52a0\u8349\u7a3f", "\u52a0\u5165\u8349\u7a3f", "insert"],
    action: "insert_into_draft",
    zhLabel: "\u63d2\u5165\u5f53\u524d\u8349\u7a3f",
    enLabel: "Insert into current draft",
    zhHint: "\u5728\u5f53\u524d\u8349\u7a3f\u7684\u6307\u5b9a\u4f4d\u7f6e\u63d2\u5165\u5185\u5bb9\u3002",
    enHint: "Insert content into the current draft at a target.",
  },
  {
    keyword: "\u6539\u5199\u8349\u7a3f",
    aliases: ["\u4fee\u6539\u8349\u7a3f", "\u7f16\u8f91\u8349\u7a3f", "edit draft"],
    action: "edit_current_draft",
    zhLabel: "\u76f4\u63a5\u6539\u5199\u5f53\u524d\u8349\u7a3f",
    enLabel: "Rewrite current draft",
    zhHint: "\u8ba9 AI \u76f4\u63a5\u6539\u5199\u5f53\u524d\u8349\u7a3f\u5168\u6587\u3002",
    enHint: "Let AI rewrite the whole current draft.",
  },
  {
    keyword: "\u6539\u5199\u9009\u4e2d",
    aliases: ["\u4fee\u6539\u9009\u4e2d", "\u9009\u4e2d\u6bb5\u843d", "edit selection"],
    action: "edit_selection",
    zhLabel: "\u6539\u5199\u9009\u4e2d\u6bb5\u843d",
    enLabel: "Rewrite selected text",
    zhHint: "\u53ea\u6539\u5199\u5f53\u524d\u8349\u7a3f\u91cc\u4f60\u9009\u4e2d\u7684\u6587\u5b57\u3002",
    enHint: "Rewrite only the selected text in the current draft.",
  },
  {
    keyword: "\u56fe\u7247\u8f6c\u5199",
    aliases: [
      "\u622a\u56fe\u8f6c\u5199",
      "\u622a\u56fe\u63d0\u95ee",
      "\u56fe\u7247\u8f6cmarkdown",
      "\u4ee3\u7801\u8f6c\u5199",
      "\u516c\u5f0f\u8f6c\u5199",
      "\u8bc1\u660e\u8f6c\u5199",
      "ocr",
      "image",
      "code screenshot",
    ],
    action: "image_to_markdown",
    zhLabel: "\u56fe\u7247 / \u622a\u56fe\u8f6c Markdown",
    enLabel: "Image to Markdown",
    zhHint: "\u628a\u5df2\u7c98\u8d34\u6216\u9009\u62e9\u7684\u56fe\u7247\u8f6c\u6210 Markdown\u3002",
    enHint: "Convert the attached image into Markdown.",
  },
  {
    keyword: "\u8fc1\u79fb\u5de5\u5177",
    aliases: ["\u8fc1\u79fb", "\u8fc1\u79fb\u9875\u9762", "migration"],
    action: "migration_tool",
    zhLabel: "\u6253\u5f00\u8fc1\u79fb\u5de5\u5177",
    enLabel: "Open migration tool",
    zhHint: "\u6253\u5f00\u94fe\u63a5\u3001\u6574\u9875\u548c\u7b26\u53f7\u8fc1\u79fb\u9875\u9762\u3002",
    enHint: "Open the link, page, and symbol migration tool.",
  },
  {
    keyword: "\u8fc1\u79fb\u5ba1\u9605",
    aliases: ["\u8fc1\u79fb\u8868\u683c", "\u8fc1\u79fb\u5ba1\u6838", "review"],
    action: "migration_review",
    zhLabel: "\u6253\u5f00\u8fc1\u79fb\u5ba1\u9605\u8868\u683c",
    enLabel: "Open migration review",
    zhHint: "\u6253\u5f00\u8fc1\u79fb\u5019\u9009\u7684\u5ba1\u9605\u548c\u5e94\u7528\u8868\u683c\u3002",
    enHint: "Open the migration candidate review table.",
  },
  {
    keyword: "\u77e5\u8bc6\u7d22\u5f15",
    aliases: ["\u77e5\u8bc6", "\u6982\u5ff5\u7d22\u5f15", "knowledge"],
    action: "knowledge",
    zhLabel: "\u6253\u5f00\u77e5\u8bc6\u7d22\u5f15",
    enLabel: "Open knowledge index",
    zhHint: "\u67e5\u770b\u548c\u5237\u65b0\u77e5\u8bc6\u7d22\u5f15\u3002",
    enHint: "Open the knowledge index panel.",
  },
  {
    keyword: "\u6982\u5ff5\u5361\u7247",
    aliases: ["\u6982\u5ff5\u5ba1\u7406", "\u5361\u7247\u5ba1\u7406", "concept card", "concept cards"],
    action: "concept_cards",
    zhLabel: "\u6253\u5f00\u6982\u5ff5\u5361\u7247\u5ba1\u7406",
    enLabel: "Open concept card review",
    zhHint: "\u751f\u6210\u3001\u5ba1\u7406\u548c\u786e\u8ba4\u6982\u5ff5\u5361\u7247\u3002",
    enHint: "Generate, review, accept, or reject concept cards.",
  },
  {
    keyword: "\u68c0\u67e5\u7d22\u5f15",
    aliases: ["\u7d22\u5f15\u53d8\u5316", "check index"],
    action: "check_index_changes",
    zhLabel: "\u68c0\u67e5\u7d22\u5f15\u53d8\u5316",
    enLabel: "Check index changes",
    zhHint: "\u53ea\u68c0\u67e5\u54ea\u4e9b\u7b14\u8bb0\u6539\u52a8\uff0c\u4e0d\u8c03\u7528 embedding\u3002",
    enHint: "Check changed notes without calling embeddings.",
  },
  {
    keyword: "\u66f4\u65b0\u7d22\u5f15",
    aliases: ["\u66f4\u65b0\u53d8\u66f4\u7d22\u5f15", "update index"],
    action: "update_changed_index",
    zhLabel: "\u66f4\u65b0\u53d8\u66f4\u7d22\u5f15",
    enLabel: "Update changed index",
    zhHint: "\u53ea\u66f4\u65b0\u6709\u53d8\u5316\u7684\u8bed\u4e49\u7d22\u5f15\u7247\u6bb5\u3002",
    enHint: "Update only changed semantic index chunks.",
  },
  {
    keyword: "\u91cd\u5efa\u7d22\u5f15",
    aliases: ["rebuild index", "build index"],
    action: "build_index",
    zhLabel: "\u5b8c\u6574\u91cd\u5efa\u8bed\u4e49\u7d22\u5f15",
    enLabel: "Rebuild semantic index",
    zhHint: "\u624b\u52a8\u5b8c\u6574\u91cd\u5efa\u8bed\u4e49\u7d22\u5f15\u3002",
    enHint: "Manually rebuild the full semantic index.",
  },
  {
    keyword: "\u8bb0\u5fc6",
    aliases: ["\u5bf9\u8bdd\u8bb0\u5fc6", "memory"],
    action: "memory",
    zhLabel: "\u6253\u5f00\u5bf9\u8bdd\u8bb0\u5fc6",
    enLabel: "Open conversation memory",
    zhHint: "\u67e5\u770b\u4ee5\u5bf9\u8bdd\u4e3a\u754c\u9650\u4fdd\u5b58\u7684\u8bb0\u5fc6\u3002",
    enHint: "Open saved conversation memory.",
  },
  {
    keyword: "ChatGPT\u4ea4\u63a5",
    aliases: ["GPT\u4ea4\u63a5", "prompt\u5305", "\u4ea4\u63a5\u5305", "handoff"],
    action: "chatgpt_handoff",
    zhLabel: "\u6253\u5f00 ChatGPT \u4ea4\u63a5\u6a21\u5f0f",
    enLabel: "Open ChatGPT handoff",
    zhHint: "\u751f\u6210\u7cbe\u7b80 prompt \u5305\uff0c\u7c98\u8d34\u5230 ChatGPT Pro \u540e\u518d\u5bfc\u56de\u8349\u7a3f\u3002",
    enHint: "Create a compact prompt package for ChatGPT, then import the answer back to drafts.",
  },
  {
    keyword: "\u6682\u505cAI",
    aliases: ["\u6682\u505c", "\u5173\u95edAI", "pause ai", "pause"],
    action: "pause_ai",
    zhLabel: "\u6682\u505c AI \u8f93\u51fa",
    enLabel: "Pause AI",
    zhHint: "\u6682\u505c\u5927\u6a21\u578b\u56de\u7b54\u3001Agent \u548c\u5199\u5165\u64cd\u4f5c\uff0c\u4ec5\u4fdd\u7559\u672c\u5730\u641c\u7d22\u3002",
    enHint: "Pause model answers, agents, and writing; keep local search available.",
  },
  {
    keyword: "\u6062\u590dAI",
    aliases: ["\u7ee7\u7eedAI", "\u5f00\u542fAI", "resume ai", "resume"],
    action: "resume_ai",
    zhLabel: "\u6062\u590d AI \u8f93\u51fa",
    enLabel: "Resume AI",
    zhHint: "\u91cd\u65b0\u542f\u7528\u5927\u6a21\u578b\u56de\u7b54\u3001Agent \u548c\u8349\u7a3f\u64cd\u4f5c\u3002",
    enHint: "Resume model answers, agents, and draft actions.",
  },
];

const AGENT_TOOL_SPECS = [
  {
    action: "search_answer",
    label: "Search / Q&A",
    writes: false,
    description: "Search local notes and answer from retrieved note evidence.",
  },
  {
    action: "topic_synthesis",
    label: "Topic synthesis file",
    writes: true,
    description: "Create an AI generated synthesis file from local notes. Generated files are excluded from indexing.",
  },
  {
    action: "agent_task",
    label: "Multi-step agent task",
    writes: true,
    description: "Use several safe draft tools in sequence, such as find earlier output, rewrite it, then insert it.",
  },
  {
    action: "create_blank_draft",
    label: "Blank draft",
    writes: true,
    description: "Create an empty AI draft without generated content.",
  },
  {
    action: "generate_draft",
    label: "Draft preview",
    writes: true,
    description: "Generate a draft preview before writing a file.",
  },
  {
    action: "insert_into_draft",
    label: "Insert into draft",
    writes: true,
    description: "Insert Markdown into the current AI draft at a marker, heading, wiki target, or remembered location.",
  },
  {
    action: "edit_current_draft",
    label: "Edit current draft",
    writes: true,
    description: "Rewrite the current AI draft only.",
  },
  {
    action: "edit_selection",
    label: "Edit selected draft text",
    writes: true,
    description: "Rewrite selected text inside the current AI draft only.",
  },
  {
    action: "image_to_markdown",
    label: "Image to Markdown",
    writes: false,
    description: "Convert an attached screenshot or image into mathematical Markdown.",
  },
  {
    action: "migration_tool",
    label: "Migration tool",
    writes: false,
    description: "Open the migration page for link, page, or symbol migration review.",
  },
  {
    action: "migration_review",
    label: "Migration review",
    writes: false,
    description: "Open the migration review table.",
  },
  {
    action: "knowledge",
    label: "Knowledge index",
    writes: false,
    description: "Open or inspect the knowledge index page.",
  },
  {
    action: "concept_cards",
    label: "Concept card review",
    writes: false,
    description: "Open the concept card review page for AI-assisted concept cards. Accept/reject only changes plugin data.",
  },
  {
    action: "memory",
    label: "Memory",
    writes: false,
    description: "Open conversation memory and saved chats.",
  },
  {
    action: "chatgpt_handoff",
    label: "ChatGPT handoff",
    writes: true,
    description: "Create or import a compact ChatGPT handoff prompt package.",
  },
  {
    action: "formal_note_proposal",
    label: "Formal note proposal",
    writes: false,
    description: "Read formal notes and produce a safe modification proposal without changing note files.",
  },
  {
    action: "check_index_changes",
    label: "Check index changes",
    writes: false,
    description: "Check which searchable notes changed. This does not call an embedding model.",
  },
  {
    action: "update_changed_index",
    label: "Update changed index",
    writes: false,
    description: "Update only changed semantic index chunks.",
  },
  {
    action: "build_index",
    label: "Build / rebuild index",
    writes: false,
    description: "Manually rebuild the semantic index.",
  },
  {
    action: "pause_ai",
    label: "Pause AI",
    writes: false,
    description: "Pause model calls and writing actions.",
  },
  {
    action: "resume_ai",
    label: "Resume AI",
    writes: false,
    description: "Resume model calls and writing actions.",
  },
];

const UI_TEXT = {
  en: {
    title: "Local Note Assistant",
    subtitle: "Semantic search for your local Markdown notes. It only writes plugin data, not notes.",
    buildIndex: "Build / Rebuild Index",
    checkIndexChanges: "Check index changes",
    updateChangedIndex: "Update changed index",
    indexChangeSummary: "Index changes",
    indexNoChanges: "Semantic index is up to date.",
    indexFullRebuildNeeded: "A full semantic rebuild is needed before incremental updates can be used.",
    indexIncrementalUpdated: "Changed semantic index updated.",
    indexUpdateBlockedByLimit: "Too many changed chunks for one incremental update. Use full rebuild, or raise the limit in settings.",
    indexAdded: "added",
    indexModified: "modified",
    indexDeleted: "deleted",
    indexUnchanged: "unchanged",
    indexEstimateChunks: "estimated changed chunks",
    indexReusedChunks: "reused chunks",
    indexEmbeddedChunks: "embedded chunks",
    indexDeletedChunks: "deleted chunks",
    newChat: "New Chat",
  memoryButton: "Memory",
    pauseAi: "Pause AI",
    resumeAi: "Resume AI",
    aiPaused: "AI paused",
    aiResumed: "AI resumed",
    aiPausedNotice: "AI is paused. I will not call the model or perform draft actions until you resume AI.",
    pausedSearchOnly: "AI is paused, so I only ran local note search.",
    pauseBlockedAction: "AI is paused. Resume AI before using this action.",
    knowledgeButton: "Knowledge",
    knowledgeTitle: "Knowledge index",
    knowledgeDesc: "A local map of note titles, headings, tags, links, and short note profiles. It helps retrieval, but it is not a replacement for source excerpts.",
    buildKnowledge: "Build / Refresh Knowledge Index",
    knowledgeBuilt: "Knowledge index built",
    knowledgeEmpty: "No knowledge index yet. Build it first.",
    knowledgeStats: "Knowledge stats",
    knowledgeTopNotes: "Central notes",
    knowledgeConcepts: "Concepts",
    knowledgeDomains: "Folders / domains",
    conceptCards: "Concept cards",
    conceptCardsDesc: "Auto-built concept cards from definitions, propositions, theorems, examples, links, and backlinks. Proofs are kept as proof entrances, not main content.",
    buildConceptCards: "Generate concept cards",
    conceptCardsBuilt: "Concept cards generated",
    conceptCardReviewButton: "Review concept cards",
    conceptCardReviewTitle: "Concept card review",
    conceptCardEmpty: "No concept cards yet. Generate them from the knowledge index first.",
    conceptCardStats: "Concept card stats",
    conceptCardAccepted: "Concept card accepted",
    conceptCardRejected: "Concept card rejected",
    conceptCardAccept: "Accept",
    conceptCardReject: "Reject",
    conceptCardAcceptedStatus: "accepted",
    conceptCardRejectedStatus: "rejected",
    conceptCardAutoStatus: "auto",
    conceptCardConfidence: "confidence",
    conceptCardRisk: "risk",
    conceptCardEvidence: "evidence",
    conceptCardRelations: "relations",
    conceptCardProofEntrances: "proof entrances",
    conceptCardReviewReasons: "review reasons",
    conceptCardInsufficient: "insufficient evidence",
    conceptCardFilterPlaceholder: "Search cards, sources, relations...",
    conceptCardQueue: "queue",
    conceptCardQueueAll: "All cards",
    conceptCardQueueReview: "Needs review",
    conceptCardQueueAuto: "Ready to trust",
    conceptCardQueueInsufficient: "Needs more evidence",
    conceptCardQueueConfirmed: "Confirmed",
    conceptCardQueueRejected: "Rejected",
    conceptCardQueueChanged: "Changed",
    conceptCardChangeStatus: "change",
    conceptCardChangeNew: "new",
    conceptCardChangeChanged: "changed",
    conceptCardChangeUnchanged: "unchanged",
    conceptCardBatchAcceptVisible: "Accept visible ready cards",
    conceptCardBatchRejectVisible: "Reject visible insufficient cards",
    conceptCardBatchDone: "Batch decision saved",
    conceptCardMergeSuggestions: "possible duplicates",
    conceptCardReviewQueueHint: "Default view shows cards that need human attention first.",
    conceptCardGeneratedName: "generated name",
    conceptCardEditDetails: "Edit title, aliases, and parent topic",
    conceptCardDisplayTitle: "Display title",
    conceptCardAliases: "Aliases / search words",
    conceptCardParentTopic: "Parent topic",
    conceptCardNote: "Card note",
    conceptCardSaveEdit: "Save card edit",
    conceptCardEditSaved: "Card edit saved",
    conceptCardResetEdit: "Reset edit",
    conceptCardEditReset: "Card edit reset",
    conceptCardHierarchy: "hierarchy",
    conceptCardChildren: "children",
    conceptCardTechnicalDetail: "technical detail",
    migrationToolButton: "Migration Tool",
    migrationReviewButton: "Migration Review",
    chatGptHandoffButton: "ChatGPT Handoff",
    chatGptHandoffTitle: "ChatGPT handoff",
    chatGptHandoffDesc: "Create a compact Markdown prompt package, paste it into ChatGPT Pro, then import the result back into drafts.",
    handoffTopic: "Topic or task",
    handoffMode: "Prompt mode",
    handoffNotesOnly: "Notes only",
    handoffNoteCompletion: "Note completion",
    handoffProofCompletion: "Proof completion",
    handoffTopicSynthesis: "Topic synthesis",
    handoffMultiFile: "Multi-file generation",
    handoffCheck: "Check / critique",
    generateHandoffPrompt: "Generate PROMPT.md",
    generatingHandoff: "Generating handoff prompt...",
    handoffCreated: "Handoff prompt created",
    handoffPrompt: "Prompt package",
    copyPrompt: "Copy prompt",
    promptCopied: "Prompt copied",
    openPromptFile: "Open prompt file",
    handoffQuality: "Prompt check",
    handoffGptOutput: "Paste ChatGPT output",
    handoffOutputPlaceholder: "Paste the Markdown returned by ChatGPT here. Multi-file output may use FILE: path.md blocks.",
    readClipboardOutput: "Read clipboard output",
    chooseMarkdownOutput: "Choose Markdown file",
    clipboardOutputRead: "Clipboard output read",
    clipboardTextMissing: "No text was found in the clipboard.",
    markdownOutputRead: "Markdown file loaded",
    markdownOutputReadFailed: "Could not read that Markdown file.",
    markdownOutputDropHint: "You can paste text, choose a .md file, or drag Markdown files into this box.",
    previewImport: "Preview import",
    importToDrafts: "Import to drafts",
    handoffImportPreview: "Import preview",
    handoffImported: "Imported ChatGPT output",
    handoffOutputRequired: "Paste ChatGPT output first.",
    handoffTopicRequired: "Type a topic or task first.",
    handoffFolder: "ChatGPT handoff folder",
    handoffFolderDesc: "Where generated PROMPT.md files are stored.",
    maxHandoffPromptChars: "Handoff prompt length",
    maxHandoffPromptCharsDesc: "Maximum characters kept in a ChatGPT handoff prompt.",
    oldTarget: "Old target",
    newTarget: "New target",
    migrationNotes: "Migration notes",
    migrationMode: "Migration mode",
    migrationToolDesc: "Enter Obsidian links, page targets, or symbols, then scan. No notes are modified during scanning.",
    linkMigrationMode: "Link / anchor",
    pageMigrationMode: "Whole page",
    symbolMigrationMode: "Symbol",
    oldSymbol: "Old symbol",
    oldSymbolContext: "Old expression / context",
    searchSymbol: "Search symbol",
    newSymbol: "New symbol",
    scanMigration: "Scan migration",
    openMigrationReview: "Open review table",
    applySelected: "Apply selected",
    selectedApplied: "Selected migration items applied",
    migrationFilterRisk: "Risk",
    migrationFilterFolder: "Folder filter",
    migrationFormulaOnly: "Formula only",
    migrationAiJudge: "AI judge visible",
    migrationAiAdvice: "AI advice",
    migrationHistory: "Migration history",
    preciseSymbolMatch: "Exact symbol boundary",
    migrationTarget: "Target link",
    migrationTargetPlaceholder: "[[Target note#heading]]",
    migrationTargetPreview: "Preview",
    migrationNotesPlaceholder: "Optional: describe notation changes or special rules.",
    migrationSymbolNotesPlaceholder: "Optional: describe which occurrences should be changed.",
    oldPage: "Old page",
    defaultNewPage: "Default new page",
    migrationCandidateSummary: "candidates",
    migrationCanApplySummary: "can be applied deterministically",
    migrationAlreadyAppliedSummary: "already applied",
    visibleCandidates: "visible candidates",
    allRisk: "All",
    lowRisk: "Low",
    mediumRisk: "Medium",
    highRisk: "High",
    folderFilterPlaceholder: "folder/name",
    migrationOriginal: "Original",
    migrationChange: "Change",
    noneText: "none",
    notJudged: "not judged",
    targetNotFoundYet: "Target not found yet.",
    selectedAppliedDetail: "Changes were written and an undo snapshot was saved.",
    close: "Close",
    targetLinkRequired: "Enter a target link to generate a diff.",
    noMigrationItemsSelected: "No migration items selected.",
    noteChangedAfterDiff: "The note changed after the diff was generated. Generate the diff again before applying.",
    noteChangedAfterReview: "The note changed after the review was generated",
    migrationUndoHint: "You can undo this operation by asking: undo last migration.",
    noMediumHighRisk: "No medium or high risk candidates remain.",
    previewMigrationItemHint: "To preview one item, ask: preview item N",
    applyMigrationItemHint: "To apply one reviewed item, ask: apply item N",
    memoryTitle: "Conversation memory",
    noMemory: "No saved memory yet.",
    olderMemory: "Older memory",
    restoreConversation: "Continue",
    deleteConversation: "Delete",
    deleteConversationConfirm: "Delete this saved conversation?",
    conversationRestored: "Conversation restored",
    conversationDeleted: "Conversation deleted",
    memoryConversation: "Conversation",
    memoryItems: "items",
    memorySearch: "Search conversations...",
    noMemoryMatches: "No matching conversations.",
    settings: "Settings",
    visionApiSettings: "Vision API",
    visionApiSettingsDesc: "Configure the provider used for screenshot and image understanding.",
    providerCredentials: "Provider credentials",
    providerModels: "Vision models",
    saveVisionApi: "Save Vision API",
    visionApiSaved: "Vision API settings saved",
    apiKeyStoredLocally: "API keys are stored locally in this plugin's data.json file.",
    welcome:
      "Ask a fuzzy question. If a semantic index exists, I will use it. Otherwise I will fall back to keyword search.",
    placeholder: "Type what you are trying to find...",
    ready: "Ready",
    searching: "Searching...",
    indexing: "Indexing...",
    search: "Search",
    send: "Send",
    tools: "Tools",
    toolKeywords: "Prompt shortcuts",
    chooseKeyword: "Choose a keyword...",
    commonKeywords: "Common",
    autoAction: "Auto action",
    toolRunning: "Running",
    toolDone: "Done",
    toolFailed: "Failed",
    toolWhy: "Why",
    toolRoute: "Choosing tool",
    toolSearch: "Searching notes",
    toolAnswer: "Writing answer",
    toolOpenPanel: "Opening panel",
    toolReasonRoute: "I am deciding which plugin tool best matches your request.",
    toolReasonSearch: "I am searching your local notes before answering.",
    toolReasonAnswer: "I am using the selected context to write the answer.",
    toolReasonPanel: "This request maps directly to a local plugin page.",
    toolReasonDraft: "This request changes or creates an AI draft, so it uses a draft tool.",
    toolReasonImage: "An image is attached or requested, so it uses the image-to-Markdown tool.",
    toolReasonMigration: "This request concerns note/link migration, so it uses the migration tool.",
    toolReasonPausedSearch: "AI is paused, so I only use local note search.",
    chooseImage: "Choose image",
    startScreenshot: "System screenshot",
    attachClipboardImage: "Read clipboard screenshot",
    screenshotQuestion: "Ask with screenshot",
    screenshotStarted: "System screenshot tool started. After selecting an area, use Read clipboard screenshot.",
    clipboardImageAttached: "Clipboard screenshot attached",
    noClipboardImage: "No image was found in the clipboard. Take a screenshot first, then try again.",
    clipboardReadFailed: "Could not read the clipboard screenshot",
    systemScreenshotWindowsOnly: "System screenshot launch is only available on Windows. Use your OS screenshot shortcut, then read the clipboard screenshot.",
    imageMode: "Image mode",
    imageModeAuto: "Auto",
    imageModeProof: "Proof",
    imageModeFormula: "Formula",
    imageModeCode: "Code",
    imageModeTable: "Table",
    imageModeQuestion: "Question",
    imageOutputLanguage: "Output language",
    imageLanguageAuto: "Auto",
    imageLanguageChinese: "Chinese",
    imageLanguageEnglish: "English",
    voiceInput: "Voice input",
    startVoiceInput: "Start voice",
    stopVoiceInput: "Stop voice",
    voiceListening: "Listening...",
    voiceReady: "Voice input ready",
    voiceUnsupported: "Voice input is not supported in this Obsidian environment.",
    voiceInputDisabled: "Voice input is disabled in settings.",
    voicePermissionHint: "Allow microphone permission if Obsidian asks.",
    voiceError: "Voice input failed",
    voiceMode: "Voice mode",
    voiceModeDesc: "Append to the current input, replace it, or treat the speech as a tool command.",
    voiceModeAppend: "Append",
    voiceModeReplace: "Replace",
    voiceModeCommand: "Command",
    enableVoiceInput: "Enable voice input",
    enableVoiceInputDesc: "Use the browser speech recognition engine to dictate into the chat input.",
    voiceInputLanguage: "Voice recognition language",
    voiceInputLanguageDesc: "Examples: zh-CN, en-US, ja-JP. Restart voice input after changing this.",
    clearImage: "Clear image",
    imageToMarkdown: "Image to Markdown",
    imageReady: "Image ready",
    imageRequired: "Paste or choose an image first.",
    imageTooLarge: "Image is too large. Use a smaller screenshot.",
    imageInputDisabled: "Image input is disabled in settings.",
    convertingImage: "Converting image...",
    draftNote: "Draft Note",
    blankDraft: "Blank Draft",
    creatingBlankDraft: "Creating blank draft...",
    drafting: "Drafting...",
    draftPreview: "Draft preview",
    createDraft: "Create Draft",
    topicSynthesis: "Topic synthesis",
    topicSynthesisCreated: "Topic synthesis created",
    draftCreated: "Draft created",
    creatingDraft: "Creating draft...",
    appendToDraft: "Append to Draft",
    appendSelectionToDraft: "Append selection to Draft",
    appendResultsToDraft: "Append results to Draft",
    rewriteForDraft: "Rewrite for Draft",
    rewritingForDraft: "Rewriting...",
    rewrittenPreview: "Rewritten draft preview",
    appendRewrittenToDraft: "Append rewritten to Draft",
    appendedToDraft: "Appended to draft",
    appendFailed: "Append failed",
    noSelection: "Select some text in this panel first.",
    noCurrentDraft: "No current draft. Create a Blank Draft first.",
    draftFileNotCreated: "Draft file was not created.",
    undoOutsideDraftFolder: "Undo target is outside the configured draft folder.",
    currentDraftOutsideFolder: "Current draft is outside the configured draft folder.",
    emptyDraftReturned: "The model returned an empty draft.",
    emptyInsertionReturned: "The model returned an empty insertion.",
    emptyReplacementReturned: "The model returned an empty replacement.",
    currentDraft: "Current draft",
    draftOutline: "Draft outline",
    noDraftHeadings: "No headings yet",
    editDraft: "Edit current draft",
    editingDraftDirectly: "Editing current draft...",
    draftEditedDirectly: "Current draft edited",
    insertedIntoDraft: "Inserted into current draft",
    insertTargetNotFound: "Could not find that insertion target in the current draft.",
    agentWorking: "Agent working...",
    agentFinished: "Agent task finished",
    draftInstructionRequired: "Type an instruction for editing the current draft.",
    draftTooLarge: "Current draft is too long for direct whole-draft editing. Select a section and use Edit selection instead.",
    editSelection: "Edit selection",
    editingSelection: "Editing selection...",
    selectionEdited: "Selection edited",
    activeDraftRequired: "Open the current draft before editing a selection.",
    draftSelectionRequired: "Select text inside the current draft first.",
    noDraftSelected: "No draft selected",
    openDraft: "Open draft",
    useActiveDraft: "Use active draft",
    clearDraft: "Clear draft",
    undoDraftEdit: "Undo last edit",
    draftEditUndone: "Last draft edit undone",
    noDraftUndo: "No draft edit to undo.",
    activeDraftSet: "Current draft set",
    activeNoteNotDraft: "The active note is not inside the configured draft folder.",
    answerSourceMode: "Answer mode",
    notesOnlyMode: "Notes",
    modelOnlyMode: "Model",
    notesModelMode: "Notes + model",
    writeDisabled: "Writing is disabled. Enable Draft only in settings first.",
    draftFailed: "Draft failed",
    answerWithSources: "Answer with sources",
    answering: "Answering...",
    answerFailed: "Answer failed",
    sources: "Sources",
    snippet: "Snippet",
    buildingIndex: "Building semantic index. This can take a while for the first run.",
    indexRebuilt: "Local Note Assistant index rebuilt.",
    indexFailed: "Index build failed. Check settings and provider connection.",
    noResults: "No clear matches found. Try a shorter or differently worded query.",
    semantic: "Semantic",
    keyword: "Keyword",
    found: "search found",
    matchesFor: "likely matches for",
    heading: "Heading",
    similarity: "Similarity",
    score: "Score",
    noIndex: "No semantic index yet. Click Build / Rebuild Index to enable semantic search.",
    indexReady: "Index ready",
    chunksFrom: "chunks from",
    notesUsing: "notes using",
    settingsChanged: "Settings changed, so rebuild the index.",
    readingProgress: "Reading",
    embeddingProgress: "Embedding",
    semanticSearchFallback: "Semantic search failed, so I used keyword search instead",
    semanticIndexStaleWarning: "The semantic index was built with different settings. Rebuild it to use semantic search.",
    noSemanticIndexWarning: "No semantic index exists yet. Click Build / Rebuild Index for smarter search.",
    noHeading: "(no heading)",
    settingIntro:
      "Choose the embedding provider used for semantic search. API keys are stored locally in this plugin's data.json file.",
    language: "Language",
    languageDesc: "Switch the plugin interface between English and Chinese.",
    provider: "Embedding provider",
    providerDesc: "Changing this requires rebuilding the index.",
    chatProvider: "Chat provider",
    chatProviderDesc: "Used for answering from retrieved note snippets.",
    enableImageInput: "Enable image input",
    enableImageInputDesc: "Allow screenshots or image files to be sent to a vision model.",
    visionProvider: "Vision provider",
    visionProviderDesc: "Used only when converting an attached image to Markdown.",
    maxImageBytes: "Maximum image size",
    maxImageBytesDesc: "Largest image upload allowed, in bytes. Default is 5242880, about 5 MB.",
    providerUseChat: "Use chat provider",
    providerOllama: "Ollama local",
    providerOpenAI: "OpenAI",
    providerGemini: "Gemini",
    providerQwen: "Qwen / DashScope",
    providerDeepSeek: "DeepSeek",
    providerCustom: "Custom OpenAI-compatible",
    settingsCore: "Core",
    settingsEmbeddingSection: "Embedding search",
    settingsEmbeddingDesc: "Choose one embedding provider. Only the matching setup template is shown below.",
    maxIncrementalIndexChunks: "Incremental index chunk limit",
    maxIncrementalIndexChunksDesc:
      "Maximum changed chunks to embed from the safer update button. Checking changes never calls an embedding model.",
    settingsChatSection: "Chat answer model",
    settingsChatDesc: "Choose the model provider used for answers, agents, draft rewrites, and routing.",
    settingsVisionSection: "Vision and input",
    settingsVisionDesc: "Configure screenshot/image understanding and voice input.",
    settingsRetrievalSection: "Retrieval context",
    settingsRetrievalDesc: "Controls how much local note context is sent to the model.",
    settingsMemorySection: "Memory and feedback",
    settingsMemoryDesc: "Conversation memory, longer output memory, and unsatisfied-answer feedback.",
    settingsDraftSection: "Drafts and handoff",
    settingsDraftDesc: "Controls safe draft writing and ChatGPT handoff files.",
    settingsMigrationSection: "Migration and agent",
    settingsMigrationDesc: "Controls migration review and agent planning behavior.",
    providerTemplate: "Current provider template",
    providerTemplateDesc: "Only fields needed for the selected provider are shown.",
    providerInheritedFromChat: "Uses the selected chat provider settings.",
    ollamaBaseUrl: "Ollama base URL",
    ollamaEmbeddingModel: "Ollama embedding model",
    openaiBaseUrl: "OpenAI base URL",
    openaiApiKey: "OpenAI API key",
    openaiEmbeddingModel: "OpenAI embedding model",
    geminiApiKey: "Gemini API key",
    geminiEmbeddingModel: "Gemini embedding model",
    qwenBaseUrl: "Qwen / DashScope base URL",
    qwenApiKey: "Qwen / DashScope API key",
    qwenEmbeddingModel: "Qwen embedding model",
    qwenEmbeddingDimensions: "Qwen embedding dimensions",
    customBaseUrl: "Custom base URL",
    customApiKey: "Custom API key",
    customEmbeddingModel: "Custom embedding model",
    ollamaChatModel: "Ollama chat model",
    openaiChatModel: "OpenAI chat model",
    geminiChatModel: "Gemini chat model",
    qwenChatModel: "Qwen chat model",
    deepseekBaseUrl: "DeepSeek base URL",
    deepseekApiKey: "DeepSeek API key",
    deepseekChatModel: "DeepSeek chat model",
    customChatModel: "Custom chat model",
    ollamaVisionModel: "Ollama vision model",
    openaiVisionModel: "OpenAI vision model",
    geminiVisionModel: "Gemini vision model",
    qwenVisionModel: "Qwen vision model",
    customVisionModel: "Custom vision model",
    answerContextLimit: "Answer context snippets",
    answerContextLimitDesc: "How many retrieved snippets to send to the chat model.",
    maxAnswerContextChars: "Answer context length",
    maxAnswerContextCharsDesc: "Maximum characters to send from each retrieved snippet.",
    maxTotalAnswerContextChars: "Total answer context length",
    maxTotalAnswerContextCharsDesc: "Maximum total characters sent to the chat model.",
    includeNeighborChunks: "Include neighbor chunks",
    includeNeighborChunksDesc: "Add chunks before and after each matched chunk when answering.",
    neighborChunksBefore: "Neighbor chunks before",
    neighborChunksAfter: "Neighbor chunks after",
    includeSameHeadingSection: "Include same heading section",
    includeSameHeadingSectionDesc: "Add other chunks under the same heading when answering.",
    useConversationMemory: "Use conversation memory",
    useConversationMemoryDesc: "Continue the current topic until you click New Chat.",
    conversationTurnsToKeep: "Conversation turns to keep",
    conversationTurnsToKeepDesc: "How many recent question-answer turns to use. Allowed range: 0-99.",
    writeMode: "Write mode",
    writeModeDesc: "Controls whether the plugin may create Markdown files.",
    writeModeDisabled: "Disabled",
    writeModeDraft: "Draft only",
    draftFolder: "Draft folder",
    draftFolderDesc: "New AI drafts are created in this folder.",
    draftSourceMode: "Draft source mode",
    draftSourceModeDesc: "Choose whether generated drafts use notes, model knowledge, or both.",
    draftSourceNotesOnly: "Notes only",
    draftSourceNotesModel: "Notes + model knowledge",
    draftSourceModelOnly: "Model knowledge only",
    maxDraftEditChars: "Whole-draft edit length",
    maxDraftEditCharsDesc: "Maximum characters allowed for direct whole-draft AI editing.",
    confirmAgentPlans: "Confirm agent plans",
    confirmAgentPlansDesc: "Show the agent plan before running multi-step draft tasks.",
    userWritingPreferences: "Writing preferences",
    userWritingPreferencesDesc: "Long-term style rules included in draft editing prompts.",
    agentPlan: "Agent plan",
    runAgentPlan: "Run plan",
    cancelAgentPlan: "Cancel",
    agentCancelled: "Agent plan cancelled",
    agentSelfCheck: "Agent self-check",
    draftChangeSummary: "Draft change summary",
    memory: "Memory",
    useLongTermMemory: "Use longer memory",
    useLongTermMemoryDesc: "Remember recent AI outputs across chats for later draft actions.",
    longTermMemoryToKeep: "Longer memory items",
    longTermMemoryToKeepDesc: "How many recent AI outputs to keep locally.",
    markUnsatisfied: "Unsatisfied",
    unsatisfiedFeedback: "Mark answer as unsatisfied",
    unsatisfiedFeedbackDesc: "Save a local failure tag so similar future answers can avoid the same mistake.",
    unsatisfiedReason: "What was wrong?",
    saveFeedback: "Save feedback",
    unsatisfiedReasonPlaceholder: "Example: the answer invented a source, missed the linked note, or used bad LaTeX.",
    unsatisfiedSaved: "Saved unsatisfied feedback. Future answers will try to avoid this pattern.",
    unsatisfiedMissingAnswer: "There is no recent assistant answer to tag.",
    negativeFeedbackTitle: "Unsatisfied answer feedback",
    negativeFeedbackDesc: "Local feedback tags used to reduce repeated answer mistakes.",
    negativeFeedbackItems: "feedback items",
    noNegativeFeedback: "No unsatisfied feedback yet.",
    deleteFeedback: "Delete feedback",
    deleteFeedbackConfirm: "Delete this unsatisfied-answer feedback item?",
    feedbackTags: "Tags",
    useNegativeFeedbackMemory: "Use unsatisfied feedback",
    useNegativeFeedbackMemoryDesc: "Include recent local feedback tags in future AI prompts.",
    negativeFeedbackToKeep: "Unsatisfied feedback items",
    negativeFeedbackToKeepDesc: "How many unsatisfied-answer feedback items to keep locally.",
    migrationScanLimit: "Migration scan limit",
    migrationScanLimitDesc: "Maximum related notes to send to the model when planning note migration.",
    noteMigration: "Note migration",
    noteMigrationScanning: "Scanning note migration...",
    noteMigrationNeedTwoLinks: "Please include the old note and new note as two wiki links, for example [[A]] -> [[B]].",
    noteMigrationNoCandidates: "No related notes were found for this migration.",
    noteMigrationNoPlan: "No migration plan is available. Run a migration scan first.",
    noteMigrationApplied: "Low-risk migration applied",
    noteMigrationUndone: "Last formal-note migration undone",
    migrationRiskCandidates: "Migration risk candidates",
    migrationReview: "Migration review",
    migrationReviewNoDiff: "No safe deterministic diff could be generated for this item.",
    migrationReviewApplied: "Reviewed migration applied",
    migrationAlreadyApplied: "Already applied",
    planEditor: "Editable plan",
    taskLog: "Task log",
    anchors: "Anchors",
    maxAgentSteps: "Max agent steps",
    formalProposal: "Formal note proposal",
    formalProposalNoWrite: "No formal notes were modified. This is a read-only proposal.",
    formalProposalCandidates: "Candidate notes",
    agentPlanSummary: "Plan summary",
    agentPlanGoal: "Goal",
    agentPlanWrites: "Writes",
    agentPlanReads: "Reads",
    agentPlanSafety: "Safety",
    agentPlanDraftOnly: "Draft-only write",
    agentPlanReadOnly: "Read-only",
    agentPlanFormalSafe: "Formal notes are protected; only a proposal will be generated.",
    agentPlanTarget: "Target",
    agentPlanSources: "Likely sources",
    agentPlanNoTarget: "No exact insertion target was provided.",
    insertionTargetFallback: "Insertion target fallback",
    topicCoverageReport: "Coverage check",
    resultsToShow: "Results to show",
    resultsToShowDesc: "How many search results to show in the chat panel.",
    openFailed: "Could not open",
    opened: "Opened",
  },
  zh: {
    title: "本地笔记助手",
    subtitle: "为你的本地 Markdown 笔记进行语义搜索。它只写入插件数据，不修改笔记。",
    buildIndex: "建立 / 重建索引",
    settings: "设置",
    welcome: "你可以用模糊的问题来搜索。如果已有语义索引，我会使用语义搜索；否则会退回关键词搜索。",
    placeholder: "输入你想寻找的内容...",
    ready: "就绪",
    searching: "搜索中...",
    indexing: "索引中...",
    search: "搜索",
    buildingIndex: "正在建立语义索引。第一次运行可能需要一些时间。",
    indexRebuilt: "本地笔记助手索引已重建。",
    indexFailed: "索引建立失败。请检查设置和模型连接。",
    noResults: "没有找到明显相关的结果。可以换一种说法，或输入更短的问题。",
    semantic: "语义",
    keyword: "关键词",
    found: "搜索找到了",
    matchesFor: "个可能相关结果，问题是",
    heading: "标题",
    similarity: "相似度",
    score: "分数",
    noIndex: "还没有语义索引。点击“建立 / 重建索引”来启用更聪明的搜索。",
    indexReady: "索引已就绪",
    chunksFrom: "个片段，来自",
    notesUsing: "篇笔记，使用",
    settingsChanged: "设置已经改变，请重建索引。",
    settingIntro: "选择语义搜索使用的 embedding 来源。API key 会保存在本插件本地的 data.json 文件中。",
    language: "界面语言",
    languageDesc: "在英文和中文界面之间切换。",
    provider: "Embedding 来源",
    providerDesc: "更改后需要重建索引。",
    resultsToShow: "显示结果数量",
    resultsToShowDesc: "聊天面板里显示多少条搜索结果。",
    openFailed: "无法打开",
    opened: "已打开",
  },
};

Object.assign(UI_TEXT.zh, {
  title: "\u672c\u5730\u7b14\u8bb0\u52a9\u624b",
  subtitle: "\u4e3a\u4f60\u7684\u672c\u5730 Markdown \u7b14\u8bb0\u8fdb\u884c\u8bed\u4e49\u641c\u7d22\u3002\u5b83\u53ea\u5199\u5165\u63d2\u4ef6\u6570\u636e\uff0c\u4e0d\u4fee\u6539\u7b14\u8bb0\u3002",
  buildIndex: "\u5efa\u7acb / \u91cd\u5efa\u7d22\u5f15",
  checkIndexChanges: "\u68c0\u67e5\u7d22\u5f15\u53d8\u5316",
  updateChangedIndex: "\u66f4\u65b0\u53d8\u66f4\u7d22\u5f15",
  indexChangeSummary: "\u7d22\u5f15\u53d8\u5316",
  indexNoChanges: "\u8bed\u4e49\u7d22\u5f15\u5df2\u662f\u6700\u65b0\u3002",
  indexFullRebuildNeeded: "\u9700\u8981\u5148\u624b\u52a8\u5b8c\u6574\u91cd\u5efa\u4e00\u6b21\u8bed\u4e49\u7d22\u5f15\uff0c\u4e4b\u540e\u624d\u80fd\u4f7f\u7528\u589e\u91cf\u66f4\u65b0\u3002",
  indexIncrementalUpdated: "\u53d8\u66f4\u7684\u8bed\u4e49\u7d22\u5f15\u5df2\u66f4\u65b0\u3002",
  indexUpdateBlockedByLimit: "\u672c\u6b21\u53d8\u66f4\u7247\u6bb5\u8d85\u8fc7\u5355\u6b21\u589e\u91cf\u4e0a\u9650\u3002\u8bf7\u4f7f\u7528\u5b8c\u6574\u91cd\u5efa\uff0c\u6216\u5728\u8bbe\u7f6e\u4e2d\u63d0\u9ad8\u4e0a\u9650\u3002",
  indexAdded: "\u65b0\u589e",
  indexModified: "\u4fee\u6539",
  indexDeleted: "\u5220\u9664",
  indexUnchanged: "\u672a\u53d8",
  indexEstimateChunks: "\u9884\u8ba1\u53d8\u66f4\u7247\u6bb5",
  indexReusedChunks: "\u590d\u7528\u7247\u6bb5",
  indexEmbeddedChunks: "\u65b0\u5efa embedding \u7247\u6bb5",
  indexDeletedChunks: "\u79fb\u9664\u7247\u6bb5",
  newChat: "\u65b0\u5bf9\u8bdd",
  memoryButton: "\u8bb0\u5fc6",
  pauseAi: "\u6682\u505c AI",
  resumeAi: "\u6062\u590d AI",
  aiPaused: "AI \u5df2\u6682\u505c",
  aiResumed: "AI \u5df2\u6062\u590d",
  aiPausedNotice: "AI \u5df2\u6682\u505c\u3002\u5728\u6062\u590d AI \u4e4b\u524d\uff0c\u6211\u4e0d\u4f1a\u8c03\u7528\u6a21\u578b\uff0c\u4e5f\u4e0d\u4f1a\u6267\u884c\u8349\u7a3f\u64cd\u4f5c\u3002",
  pausedSearchOnly: "AI \u5df2\u6682\u505c\uff0c\u56e0\u6b64\u53ea\u6267\u884c\u4e86\u672c\u5730\u7b14\u8bb0\u641c\u7d22\u3002",
  pauseBlockedAction: "AI \u5df2\u6682\u505c\u3002\u8bf7\u5148\u6062\u590d AI\uff0c\u518d\u4f7f\u7528\u8fd9\u4e2a\u529f\u80fd\u3002",
  knowledgeButton: "\u77e5\u8bc6\u7d22\u5f15",
  knowledgeTitle: "\u77e5\u8bc6\u7d22\u5f15",
  knowledgeDesc: "\u4ece\u7b14\u8bb0\u6807\u9898\u3001\u76ee\u5f55\u3001\u6807\u7b7e\u3001\u53cc\u94fe\u548c\u77ed\u6458\u8981\u4e2d\u5efa\u7acb\u7684\u672c\u5730\u5730\u56fe\u3002\u5b83\u7528\u4e8e\u5e2e\u52a9\u68c0\u7d22\uff0c\u4e0d\u4ee3\u66ff\u539f\u6587\u8bc1\u636e\u3002",
  buildKnowledge: "\u5efa\u7acb / \u5237\u65b0\u77e5\u8bc6\u7d22\u5f15",
  knowledgeBuilt: "\u77e5\u8bc6\u7d22\u5f15\u5df2\u5efa\u7acb",
  knowledgeEmpty: "\u8fd8\u6ca1\u6709\u77e5\u8bc6\u7d22\u5f15\u3002\u8bf7\u5148\u5efa\u7acb\u3002",
  knowledgeStats: "\u77e5\u8bc6\u7edf\u8ba1",
  knowledgeTopNotes: "\u6838\u5fc3\u7b14\u8bb0",
  knowledgeConcepts: "\u6982\u5ff5",
  knowledgeDomains: "\u6587\u4ef6\u5939 / \u9886\u57df",
  conceptCards: "\u6982\u5ff5\u5361\u7247",
  conceptCardsDesc: "\u4ece\u5b9a\u4e49\u3001\u547d\u9898\u3001\u5b9a\u7406\u3001\u4f8b\u5b50\u3001\u94fe\u63a5\u548c\u53cd\u94fe\u81ea\u52a8\u5efa\u7acb\u7684\u5019\u9009\u5361\u7247\u3002proof \u53ea\u4f5c\u4e3a\u8bc1\u660e\u5165\u53e3\uff0c\u4e0d\u4f5c\u4e3a\u4e3b\u5e72\u3002",
  buildConceptCards: "\u751f\u6210\u6982\u5ff5\u5361\u7247",
  conceptCardsBuilt: "\u6982\u5ff5\u5361\u7247\u5df2\u751f\u6210",
  conceptCardReviewButton: "\u5ba1\u7406\u6982\u5ff5\u5361\u7247",
  conceptCardReviewTitle: "\u6982\u5ff5\u5361\u7247\u5ba1\u7406",
  conceptCardEmpty: "\u8fd8\u6ca1\u6709\u6982\u5ff5\u5361\u7247\u3002\u8bf7\u5148\u4ece\u77e5\u8bc6\u7d22\u5f15\u751f\u6210\u3002",
  conceptCardStats: "\u6982\u5ff5\u5361\u7247\u7edf\u8ba1",
  conceptCardAccepted: "\u5df2\u63a5\u53d7\u6982\u5ff5\u5361\u7247",
  conceptCardRejected: "\u5df2\u62d2\u7edd\u6982\u5ff5\u5361\u7247",
  conceptCardAccept: "\u63a5\u53d7",
  conceptCardReject: "\u62d2\u7edd",
  conceptCardAcceptedStatus: "\u5df2\u786e\u8ba4",
  conceptCardRejectedStatus: "\u5df2\u62d2\u7edd",
  conceptCardAutoStatus: "\u81ea\u52a8\u5019\u9009",
  conceptCardConfidence: "\u7f6e\u4fe1\u5ea6",
  conceptCardRisk: "\u98ce\u9669",
  conceptCardEvidence: "\u8bc1\u636e",
  conceptCardRelations: "\u5173\u8054",
  conceptCardProofEntrances: "\u8bc1\u660e\u5165\u53e3",
  conceptCardReviewReasons: "\u5ba1\u7406\u7406\u7531",
  conceptCardInsufficient: "\u8bc1\u636e\u4e0d\u8db3",
  conceptCardFilterPlaceholder: "\u641c\u7d22\u5361\u7247\u3001\u6765\u6e90\u3001\u5173\u8054\u2026",
  conceptCardQueue: "队列",
  conceptCardQueueAll: "全部卡片",
  conceptCardQueueReview: "需要审理",
  conceptCardQueueAuto: "可先信任",
  conceptCardQueueInsufficient: "证据不足",
  conceptCardQueueConfirmed: "已确认",
  conceptCardQueueRejected: "已拒绝",
  conceptCardQueueChanged: "有变化",
  conceptCardChangeStatus: "变化",
  conceptCardChangeNew: "新增",
  conceptCardChangeChanged: "已变化",
  conceptCardChangeUnchanged: "未变化",
  conceptCardBatchAcceptVisible: "批量接受当前可靠项",
  conceptCardBatchRejectVisible: "批量拒绝当前不足项",
  conceptCardBatchDone: "批量审理已保存",
  conceptCardMergeSuggestions: "可能重复",
  conceptCardReviewQueueHint: "默认只显示值得人工注意的卡片。",
  conceptCardGeneratedName: "原始标题",
  conceptCardEditDetails: "编辑标题、别名和上位主题",
  conceptCardDisplayTitle: "显示标题",
  conceptCardAliases: "别名 / 搜索词",
  conceptCardParentTopic: "上位主题",
  conceptCardNote: "卡片备注",
  conceptCardSaveEdit: "保存卡片修改",
  conceptCardEditSaved: "卡片修改已保存",
  conceptCardResetEdit: "清除人工修改",
  conceptCardEditReset: "人工修改已清除",
  conceptCardHierarchy: "层级",
  conceptCardChildren: "子主题",
  conceptCardTechnicalDetail: "技术细节",
  migrationToolButton: "\u8fc1\u79fb\u5de5\u5177",
  migrationReviewButton: "\u8fc1\u79fb\u5ba1\u9605",
  chatGptHandoffButton: "ChatGPT \u4ea4\u63a5",
  chatGptHandoffTitle: "ChatGPT \u4ea4\u63a5\u6a21\u5f0f",
  chatGptHandoffDesc: "\u751f\u6210\u7cbe\u7b80 Markdown prompt \u5305\uff0c\u7c98\u8d34\u5230 ChatGPT Pro \u5904\u7406\uff0c\u518d\u628a\u7ed3\u679c\u5bfc\u56de\u8349\u7a3f\u3002",
  handoffTopic: "\u4e3b\u9898\u6216\u4efb\u52a1",
  handoffMode: "Prompt \u6a21\u5f0f",
  handoffNotesOnly: "\u4ec5\u7b14\u8bb0\u6574\u7406",
  handoffNoteCompletion: "\u7b14\u8bb0\u8865\u5168",
  handoffProofCompletion: "\u8bc1\u660e\u8865\u5168",
  handoffTopicSynthesis: "\u4e3b\u9898\u7efc\u8ff0",
  handoffMultiFile: "\u591a\u6587\u4ef6\u751f\u6210",
  handoffCheck: "\u68c0\u67e5 / \u6279\u6ce8",
  generateHandoffPrompt: "\u751f\u6210 PROMPT.md",
  generatingHandoff: "\u6b63\u5728\u751f\u6210\u4ea4\u63a5 prompt...",
  handoffCreated: "\u4ea4\u63a5 prompt \u5df2\u751f\u6210",
  handoffPrompt: "Prompt \u5305",
  copyPrompt: "\u590d\u5236 prompt",
  promptCopied: "Prompt \u5df2\u590d\u5236",
  openPromptFile: "\u6253\u5f00 prompt \u6587\u4ef6",
  handoffQuality: "Prompt \u81ea\u68c0",
  handoffGptOutput: "\u7c98\u8d34 ChatGPT \u8f93\u51fa",
  handoffOutputPlaceholder: "\u628a ChatGPT \u8fd4\u56de\u7684 Markdown \u7c98\u8d34\u5230\u8fd9\u91cc\u3002\u591a\u6587\u4ef6\u8f93\u51fa\u53ef\u4ee5\u4f7f\u7528 FILE: path.md \u5757\u3002",
  readClipboardOutput: "\u8bfb\u53d6\u526a\u8d34\u677f\u8f93\u51fa",
  chooseMarkdownOutput: "\u9009\u62e9 Markdown \u6587\u4ef6",
  clipboardOutputRead: "\u5df2\u8bfb\u53d6\u526a\u8d34\u677f\u8f93\u51fa",
  clipboardTextMissing: "\u526a\u8d34\u677f\u91cc\u6ca1\u6709\u627e\u5230\u6587\u672c\u3002",
  markdownOutputRead: "Markdown \u6587\u4ef6\u5df2\u8bfb\u53d6",
  markdownOutputReadFailed: "\u65e0\u6cd5\u8bfb\u53d6\u8fd9\u4e2a Markdown \u6587\u4ef6\u3002",
  markdownOutputDropHint: "\u53ef\u4ee5\u7c98\u8d34\u6587\u672c\uff0c\u9009\u62e9 .md \u6587\u4ef6\uff0c\u6216\u628a Markdown \u6587\u4ef6\u62d6\u5230\u8fd9\u4e2a\u6846\u91cc\u3002",
  previewImport: "\u9884\u89c8\u5bfc\u5165",
  importToDrafts: "\u5bfc\u5165\u5230\u8349\u7a3f",
  handoffImportPreview: "\u5bfc\u5165\u9884\u89c8",
  handoffImported: "\u5df2\u5bfc\u5165 ChatGPT \u8f93\u51fa",
  handoffOutputRequired: "\u8bf7\u5148\u7c98\u8d34 ChatGPT \u8f93\u51fa\u3002",
  handoffTopicRequired: "\u8bf7\u5148\u8f93\u5165\u4e3b\u9898\u6216\u4efb\u52a1\u3002",
  handoffFolder: "ChatGPT \u4ea4\u63a5\u6587\u4ef6\u5939",
  handoffFolderDesc: "\u751f\u6210\u7684 PROMPT.md \u4fdd\u5b58\u5728\u8fd9\u4e2a\u6587\u4ef6\u5939\u3002",
  maxHandoffPromptChars: "\u4ea4\u63a5 prompt \u957f\u5ea6",
  maxHandoffPromptCharsDesc: "\u4fdd\u7559\u5230 ChatGPT \u4ea4\u63a5 prompt \u4e2d\u7684\u6700\u5927\u5b57\u7b26\u6570\u3002",
  oldTarget: "\u65e7\u76ee\u6807",
  newTarget: "\u65b0\u76ee\u6807",
  migrationNotes: "\u8fc1\u79fb\u8865\u5145\u8bf4\u660e",
  migrationMode: "\u8fc1\u79fb\u6a21\u5f0f",
  migrationToolDesc: "\u8f93\u5165 Obsidian \u94fe\u63a5\u3001\u9875\u9762\u76ee\u6807\u6216\u7b26\u53f7\uff0c\u7136\u540e\u626b\u63cf\u3002\u626b\u63cf\u9636\u6bb5\u4e0d\u4f1a\u4fee\u6539\u7b14\u8bb0\u3002",
  linkMigrationMode: "\u94fe\u63a5 / \u951a\u70b9",
  pageMigrationMode: "\u6574\u9875",
  symbolMigrationMode: "\u7b26\u53f7",
  oldSymbol: "\u65e7\u7b26\u53f7",
  oldSymbolContext: "\u65e7\u8868\u8fbe\u5f0f / \u4e0a\u4e0b\u6587",
  searchSymbol: "\u641c\u7d22\u7b26\u53f7",
  newSymbol: "\u65b0\u7b26\u53f7",
  scanMigration: "\u626b\u63cf\u8fc1\u79fb",
  openMigrationReview: "\u6253\u5f00\u5ba1\u9605\u8868\u683c",
  applySelected: "\u5e94\u7528\u9009\u4e2d\u9879",
  selectedApplied: "\u5df2\u5e94\u7528\u9009\u4e2d\u8fc1\u79fb\u9879",
  migrationFilterRisk: "\u98ce\u9669",
  migrationFilterFolder: "\u6587\u4ef6\u5939\u8fc7\u6ee4",
  migrationFormulaOnly: "\u53ea\u770b\u516c\u5f0f",
  migrationAiJudge: "AI \u5224\u65ad\u53ef\u89c1\u9879",
  migrationAiAdvice: "AI \u5efa\u8bae",
  migrationHistory: "\u8fc1\u79fb\u8bb0\u5f55",
  preciseSymbolMatch: "\u7cbe\u786e\u7b26\u53f7\u8fb9\u754c",
  migrationTarget: "\u76ee\u6807\u94fe\u63a5",
  migrationTargetPlaceholder: "[[\u76ee\u6807\u7b14\u8bb0#\u6807\u9898]]",
  migrationTargetPreview: "\u9884\u89c8",
  migrationNotesPlaceholder: "\u53ef\u9009\uff1a\u8bf4\u660e\u8bb0\u53f7\u53d8\u66f4\u6216\u7279\u6b8a\u89c4\u5219\u3002",
  migrationSymbolNotesPlaceholder: "\u53ef\u9009\uff1a\u8bf4\u660e\u54ea\u4e9b\u51fa\u73b0\u4f4d\u7f6e\u5e94\u8be5\u4fee\u6539\u3002",
  oldPage: "\u65e7\u9875\u9762",
  defaultNewPage: "\u9ed8\u8ba4\u65b0\u9875\u9762",
  migrationCandidateSummary: "\u4e2a\u5019\u9009",
  migrationCanApplySummary: "\u4e2a\u53ef\u786e\u5b9a\u81ea\u52a8\u6267\u884c",
  migrationAlreadyAppliedSummary: "\u4e2a\u5df2\u5904\u7406",
  visibleCandidates: "\u4e2a\u53ef\u89c1\u5019\u9009",
  allRisk: "\u5168\u90e8",
  lowRisk: "\u4f4e\u98ce\u9669",
  mediumRisk: "\u4e2d\u98ce\u9669",
  highRisk: "\u9ad8\u98ce\u9669",
  folderFilterPlaceholder: "\u6587\u4ef6\u5939/\u540d\u79f0",
  migrationOriginal: "\u539f\u6587",
  migrationChange: "\u4fee\u6539",
  noneText: "\u65e0",
  notJudged: "\u672a\u5224\u65ad",
  targetNotFoundYet: "\u8fd8\u6ca1\u6709\u627e\u5230\u76ee\u6807\u3002",
  selectedAppliedDetail: "\u5df2\u5b8c\u6210\u5199\u5165\uff0c\u5e76\u5df2\u4fdd\u5b58\u64a4\u9500\u5feb\u7167\u3002",
  close: "\u5173\u95ed",
  targetLinkRequired: "\u8bf7\u8f93\u5165\u76ee\u6807\u94fe\u63a5\u4ee5\u751f\u6210 diff\u3002",
  noMigrationItemsSelected: "\u6ca1\u6709\u9009\u4e2d\u8fc1\u79fb\u9879\u3002",
  noteChangedAfterDiff: "\u7b14\u8bb0\u5728 diff \u751f\u6210\u540e\u5df2\u53d8\u5316\u3002\u8bf7\u91cd\u65b0\u751f\u6210 diff \u540e\u518d\u6267\u884c\u3002",
  noteChangedAfterReview: "\u7b14\u8bb0\u5728\u5ba1\u9605\u751f\u6210\u540e\u5df2\u53d8\u5316",
  migrationUndoHint: "\u53ef\u4ee5\u5728\u804a\u5929\u6846\u8f93\u5165\uff1a\u64a4\u9500\u4e0a\u6b21\u8fc1\u79fb\u3002",
  noMediumHighRisk: "\u6ca1\u6709\u5269\u4f59\u7684\u4e2d\u9ad8\u98ce\u9669\u5019\u9009\u3002",
  previewMigrationItemHint: "\u8981\u9884\u89c8\u67d0\u4e00\u9879\uff0c\u8bf7\u8f93\u5165\uff1a\u4e3a\u7b2c N \u6761\u751f\u6210 diff",
  applyMigrationItemHint: "\u8981\u6267\u884c\u67d0\u4e00\u5ba1\u9605\u9879\uff0c\u8bf7\u8f93\u5165\uff1a\u6267\u884c\u7b2c N \u6761",
  memoryTitle: "\u5bf9\u8bdd\u8bb0\u5fc6",
  noMemory: "\u8fd8\u6ca1\u6709\u4fdd\u5b58\u7684\u8bb0\u5fc6\u3002",
  olderMemory: "\u65e7\u7248\u672a\u5206\u7ec4\u8bb0\u5fc6",
  restoreConversation: "\u7ee7\u7eed",
  deleteConversation: "\u5220\u9664",
  deleteConversationConfirm: "\u786e\u5b9a\u5220\u9664\u8fd9\u4e2a\u5bf9\u8bdd\u5417\uff1f",
  conversationRestored: "\u5df2\u6062\u590d\u5bf9\u8bdd",
  conversationDeleted: "\u5df2\u5220\u9664\u5bf9\u8bdd",
  memoryConversation: "\u5bf9\u8bdd",
  memoryItems: "\u6761\u8bb0\u5fc6",
  memorySearch: "\u641c\u7d22\u5bf9\u8bdd...",
  noMemoryMatches: "\u6ca1\u6709\u5339\u914d\u7684\u5bf9\u8bdd\u3002",
  settings: "\u8bbe\u7f6e",
  visionApiSettings: "\u89c6\u89c9 API",
  visionApiSettingsDesc: "\u914d\u7f6e\u7528\u4e8e\u622a\u56fe\u548c\u56fe\u7247\u7406\u89e3\u7684\u6a21\u578b\u6765\u6e90\u3002",
  providerCredentials: "\u63a5\u53e3\u8fde\u63a5\u4fe1\u606f",
  providerModels: "\u89c6\u89c9\u6a21\u578b",
  saveVisionApi: "\u4fdd\u5b58\u89c6\u89c9 API",
  visionApiSaved: "\u89c6\u89c9 API \u8bbe\u7f6e\u5df2\u4fdd\u5b58",
  apiKeyStoredLocally: "API key \u4f1a\u4fdd\u5b58\u5728\u672c\u63d2\u4ef6\u672c\u5730\u7684 data.json \u6587\u4ef6\u4e2d\u3002",
  welcome: "\u4f60\u53ef\u4ee5\u7528\u6a21\u7cca\u7684\u95ee\u9898\u6765\u641c\u7d22\u3002\u5982\u679c\u5df2\u6709\u8bed\u4e49\u7d22\u5f15\uff0c\u6211\u4f1a\u4f7f\u7528\u8bed\u4e49\u641c\u7d22\uff1b\u5426\u5219\u4f1a\u9000\u56de\u5173\u952e\u8bcd\u641c\u7d22\u3002",
  placeholder: "\u8f93\u5165\u4f60\u60f3\u5bfb\u627e\u7684\u5185\u5bb9...",
  ready: "\u5c31\u7eea",
  searching: "\u641c\u7d22\u4e2d...",
  indexing: "\u7d22\u5f15\u4e2d...",
  search: "\u641c\u7d22",
  send: "\u53d1\u9001",
  tools: "\u5de5\u5177",
  toolKeywords: "\u63d0\u793a\u8bcd",
  chooseKeyword: "\u9009\u62e9\u5173\u952e\u8bcd...",
  commonKeywords: "\u5e38\u7528",
  autoAction: "\u81ea\u52a8\u64cd\u4f5c",
  toolRunning: "\u8fdb\u884c\u4e2d",
  toolDone: "\u5df2\u5b8c\u6210",
  toolFailed: "\u5931\u8d25",
  toolWhy: "\u539f\u56e0",
  toolRoute: "\u5224\u65ad\u5de5\u5177",
  toolSearch: "\u641c\u7d22\u7b14\u8bb0",
  toolAnswer: "\u751f\u6210\u56de\u7b54",
  toolOpenPanel: "\u6253\u5f00\u9875\u9762",
  toolReasonRoute: "\u6211\u6b63\u5728\u5224\u65ad\u8fd9\u4e2a\u8bf7\u6c42\u5e94\u8be5\u4f7f\u7528\u54ea\u4e2a\u63d2\u4ef6\u5de5\u5177\u3002",
  toolReasonSearch: "\u6211\u5148\u5728\u4f60\u7684\u672c\u5730\u7b14\u8bb0\u4e2d\u627e\u76f8\u5173\u7247\u6bb5\u3002",
  toolReasonAnswer: "\u6211\u6b63\u5728\u6839\u636e\u627e\u5230\u7684\u4e0a\u4e0b\u6587\u751f\u6210\u56de\u7b54\u3002",
  toolReasonPanel: "\u8fd9\u4e2a\u8bf7\u6c42\u76f4\u63a5\u5bf9\u5e94\u4e00\u4e2a\u672c\u5730\u63d2\u4ef6\u9875\u9762\u3002",
  toolReasonDraft: "\u8fd9\u4e2a\u8bf7\u6c42\u4f1a\u521b\u5efa\u6216\u4fee\u6539 AI \u8349\u7a3f\uff0c\u56e0\u6b64\u4f7f\u7528\u8349\u7a3f\u5de5\u5177\u3002",
  toolReasonImage: "\u8fd9\u4e2a\u8bf7\u6c42\u6d89\u53ca\u56fe\u7247\u6216\u622a\u56fe\uff0c\u56e0\u6b64\u4f7f\u7528\u56fe\u7247\u8f6c Markdown \u5de5\u5177\u3002",
  toolReasonMigration: "\u8fd9\u4e2a\u8bf7\u6c42\u6d89\u53ca\u7b14\u8bb0\u6216\u94fe\u63a5\u8fc1\u79fb\uff0c\u56e0\u6b64\u4f7f\u7528\u8fc1\u79fb\u5de5\u5177\u3002",
  toolReasonPausedSearch: "AI \u5df2\u6682\u505c\uff0c\u6240\u4ee5\u6211\u53ea\u8fdb\u884c\u672c\u5730\u7b14\u8bb0\u641c\u7d22\u3002",
  chooseImage: "\u9009\u62e9\u56fe\u7247",
  startScreenshot: "\u7cfb\u7edf\u622a\u56fe",
  attachClipboardImage: "\u8bfb\u53d6\u526a\u8d34\u677f\u622a\u56fe",
  screenshotQuestion: "\u7528\u622a\u56fe\u63d0\u95ee",
  screenshotStarted: "\u5df2\u542f\u52a8\u7cfb\u7edf\u622a\u56fe\u5de5\u5177\u3002\u9009\u62e9\u533a\u57df\u540e\uff0c\u70b9\u51fb\u201c\u8bfb\u53d6\u526a\u8d34\u677f\u622a\u56fe\u201d\u3002",
  clipboardImageAttached: "\u5df2\u6dfb\u52a0\u526a\u8d34\u677f\u622a\u56fe",
  noClipboardImage: "\u526a\u8d34\u677f\u91cc\u6ca1\u6709\u627e\u5230\u56fe\u7247\u3002\u8bf7\u5148\u622a\u56fe\uff0c\u518d\u91cd\u8bd5\u3002",
  clipboardReadFailed: "\u65e0\u6cd5\u8bfb\u53d6\u526a\u8d34\u677f\u622a\u56fe",
  systemScreenshotWindowsOnly: "\u7cfb\u7edf\u622a\u56fe\u542f\u52a8\u4ec5\u652f\u6301 Windows\u3002\u8bf7\u4f7f\u7528\u64cd\u4f5c\u7cfb\u7edf\u622a\u56fe\u5feb\u6377\u952e\uff0c\u7136\u540e\u8bfb\u53d6\u526a\u8d34\u677f\u622a\u56fe\u3002",
  imageMode: "\u622a\u56fe\u6a21\u5f0f",
  imageModeAuto: "\u81ea\u52a8",
  imageModeProof: "\u8bc1\u660e",
  imageModeFormula: "\u516c\u5f0f",
  imageModeCode: "\u4ee3\u7801",
  imageModeTable: "\u8868\u683c",
  imageModeQuestion: "\u95ee\u9898",
  imageOutputLanguage: "\u8f93\u51fa\u8bed\u8a00",
  imageLanguageAuto: "\u81ea\u52a8",
  imageLanguageChinese: "\u4e2d\u6587",
  imageLanguageEnglish: "\u82f1\u6587",
  voiceInput: "\u8bed\u97f3\u8f93\u5165",
  startVoiceInput: "\u5f00\u59cb\u8bed\u97f3",
  stopVoiceInput: "\u505c\u6b62\u8bed\u97f3",
  voiceListening: "\u6b63\u5728\u542c\u5199...",
  voiceReady: "\u8bed\u97f3\u8f93\u5165\u5df2\u5c31\u7eea",
  voiceUnsupported: "\u5f53\u524d Obsidian \u73af\u5883\u4e0d\u652f\u6301\u8bed\u97f3\u8f93\u5165\u3002",
  voiceInputDisabled: "\u8bed\u97f3\u8f93\u5165\u5df2\u5728\u8bbe\u7f6e\u4e2d\u5173\u95ed\u3002",
  voicePermissionHint: "\u5982\u679c Obsidian \u8bf7\u6c42\u9ea6\u514b\u98ce\u6743\u9650\uff0c\u8bf7\u5141\u8bb8\u3002",
  voiceError: "\u8bed\u97f3\u8f93\u5165\u5931\u8d25",
  voiceMode: "\u8bed\u97f3\u6a21\u5f0f",
  voiceModeDesc: "\u8ffd\u52a0\u5230\u5f53\u524d\u8f93\u5165\uff0c\u66ff\u6362\u5f53\u524d\u8f93\u5165\uff0c\u6216\u628a\u8bed\u97f3\u5f53\u4f5c\u5de5\u5177\u6307\u4ee4\u3002",
  voiceModeAppend: "\u8ffd\u52a0",
  voiceModeReplace: "\u66ff\u6362",
  voiceModeCommand: "\u6307\u4ee4",
  enableVoiceInput: "\u542f\u7528\u8bed\u97f3\u8f93\u5165",
  enableVoiceInputDesc: "\u4f7f\u7528\u6d4f\u89c8\u5668\u8bed\u97f3\u8bc6\u522b\u5f15\u64ce\u5c06\u8bed\u97f3\u5199\u5165\u804a\u5929\u8f93\u5165\u6846\u3002",
  voiceInputLanguage: "\u8bed\u97f3\u8bc6\u522b\u8bed\u8a00",
  voiceInputLanguageDesc: "\u4f8b\u5982 zh-CN\u3001en-US\u3001ja-JP\u3002\u66f4\u6539\u540e\u8bf7\u91cd\u65b0\u5f00\u59cb\u8bed\u97f3\u8f93\u5165\u3002",
  clearImage: "\u6e05\u9664\u56fe\u7247",
  imageToMarkdown: "\u56fe\u7247\u8f6c Markdown",
  imageReady: "\u56fe\u7247\u5df2\u51c6\u5907",
  imageRequired: "\u8bf7\u5148\u7c98\u8d34\u6216\u9009\u62e9\u4e00\u5f20\u56fe\u7247\u3002",
  imageTooLarge: "\u56fe\u7247\u592a\u5927\u3002\u8bf7\u7528\u66f4\u5c0f\u7684\u622a\u56fe\u3002",
  imageInputDisabled: "\u56fe\u7247\u8f93\u5165\u529f\u80fd\u5df2\u5728\u8bbe\u7f6e\u4e2d\u5173\u95ed\u3002",
  convertingImage: "\u6b63\u5728\u8f6c\u6362\u56fe\u7247...",
  draftNote: "\u751f\u6210\u8349\u7a3f",
  blankDraft: "\u7a7a\u767d\u8349\u7a3f",
  creatingBlankDraft: "\u6b63\u5728\u521b\u5efa\u7a7a\u767d\u8349\u7a3f...",
  drafting: "\u6b63\u5728\u751f\u6210\u8349\u7a3f...",
  draftPreview: "\u8349\u7a3f\u9884\u89c8",
  createDraft: "\u521b\u5efa\u8349\u7a3f",
  topicSynthesis: "\u4e3b\u9898\u6574\u7406",
  topicSynthesisCreated: "\u5df2\u751f\u6210\u4e3b\u9898\u6574\u7406\u6587\u4ef6",
  draftCreated: "\u8349\u7a3f\u5df2\u521b\u5efa",
  creatingDraft: "\u6b63\u5728\u521b\u5efa\u8349\u7a3f...",
  appendToDraft: "\u52a0\u5165\u8349\u7a3f",
  appendSelectionToDraft: "\u5c06\u9009\u4e2d\u5185\u5bb9\u52a0\u5165\u8349\u7a3f",
  appendResultsToDraft: "\u5c06\u7ed3\u679c\u52a0\u5165\u8349\u7a3f",
  rewriteForDraft: "\u6539\u5199\u4e3a\u7b14\u8bb0",
  rewritingForDraft: "\u6b63\u5728\u6539\u5199...",
  rewrittenPreview: "\u6539\u5199\u9884\u89c8",
  appendRewrittenToDraft: "\u5c06\u6539\u5199\u7248\u52a0\u5165\u8349\u7a3f",
  appendedToDraft: "\u5df2\u52a0\u5165\u8349\u7a3f",
  appendFailed: "\u52a0\u5165\u8349\u7a3f\u5931\u8d25",
  noSelection: "\u8bf7\u5148\u5728\u9762\u677f\u4e2d\u9009\u4e2d\u4e00\u6bb5\u6587\u5b57\u3002",
  noCurrentDraft: "\u8fd8\u6ca1\u6709\u5f53\u524d\u8349\u7a3f\u3002\u8bf7\u5148\u521b\u5efa\u7a7a\u767d\u8349\u7a3f\u3002",
  draftFileNotCreated: "\u8349\u7a3f\u6587\u4ef6\u672a\u80fd\u521b\u5efa\u3002",
  undoOutsideDraftFolder: "\u64a4\u9500\u76ee\u6807\u4e0d\u5728\u8bbe\u7f6e\u7684\u8349\u7a3f\u6587\u4ef6\u5939\u4e2d\u3002",
  currentDraftOutsideFolder: "\u5f53\u524d\u8349\u7a3f\u4e0d\u5728\u8bbe\u7f6e\u7684\u8349\u7a3f\u6587\u4ef6\u5939\u4e2d\u3002",
  emptyDraftReturned: "\u6a21\u578b\u8fd4\u56de\u4e86\u7a7a\u8349\u7a3f\u3002",
  emptyInsertionReturned: "\u6a21\u578b\u8fd4\u56de\u4e86\u7a7a\u63d2\u5165\u5185\u5bb9\u3002",
  emptyReplacementReturned: "\u6a21\u578b\u8fd4\u56de\u4e86\u7a7a\u66ff\u6362\u5185\u5bb9\u3002",
  currentDraft: "\u5f53\u524d\u8349\u7a3f",
  draftOutline: "\u8349\u7a3f\u76ee\u5f55",
  noDraftHeadings: "\u8fd8\u6ca1\u6709\u6807\u9898",
  editDraft: "\u4fee\u6539\u5f53\u524d\u8349\u7a3f",
  editingDraftDirectly: "\u6b63\u5728\u4fee\u6539\u5f53\u524d\u8349\u7a3f...",
  draftEditedDirectly: "\u5f53\u524d\u8349\u7a3f\u5df2\u4fee\u6539",
  insertedIntoDraft: "\u5df2\u63d2\u5165\u5f53\u524d\u8349\u7a3f",
  insertTargetNotFound: "\u5728\u5f53\u524d\u8349\u7a3f\u4e2d\u6ca1\u6709\u627e\u5230\u8fd9\u4e2a\u63d2\u5165\u4f4d\u7f6e\u3002",
  agentWorking: "Agent \u6b63\u5728\u5904\u7406...",
  agentFinished: "Agent \u4efb\u52a1\u5df2\u5b8c\u6210",
  draftInstructionRequired: "\u8bf7\u5148\u8f93\u5165\u4fee\u6539\u5f53\u524d\u8349\u7a3f\u7684\u6307\u4ee4\u3002",
  draftTooLarge: "\u5f53\u524d\u8349\u7a3f\u592a\u957f\uff0c\u4e0d\u9002\u5408\u6574\u7bc7\u76f4\u63a5\u4fee\u6539\u3002\u8bf7\u9009\u4e2d\u67d0\u4e00\u8282\u540e\u4f7f\u7528\u201c\u6539\u5199\u9009\u4e2d\u6bb5\u843d\u201d\u3002",
  editSelection: "\u6539\u5199\u9009\u4e2d\u6bb5\u843d",
  editingSelection: "\u6b63\u5728\u6539\u5199\u9009\u4e2d\u6bb5\u843d...",
  selectionEdited: "\u9009\u4e2d\u6bb5\u843d\u5df2\u6539\u5199",
  activeDraftRequired: "\u8bf7\u5148\u6253\u5f00\u5f53\u524d\u8349\u7a3f\uff0c\u518d\u6539\u5199\u9009\u4e2d\u5185\u5bb9\u3002",
  draftSelectionRequired: "\u8bf7\u5148\u5728\u5f53\u524d\u8349\u7a3f\u4e2d\u9009\u4e2d\u4e00\u6bb5\u6587\u5b57\u3002",
  noDraftSelected: "\u672a\u9009\u62e9\u8349\u7a3f",
  openDraft: "\u6253\u5f00\u8349\u7a3f",
  useActiveDraft: "\u4f7f\u7528\u5f53\u524d\u7b14\u8bb0",
  clearDraft: "\u6e05\u9664\u8349\u7a3f",
  undoDraftEdit: "\u64a4\u9500\u672c\u6b21\u4fee\u6539",
  draftEditUndone: "\u5df2\u64a4\u9500\u4e0a\u6b21\u8349\u7a3f\u4fee\u6539",
  noDraftUndo: "\u6ca1\u6709\u53ef\u64a4\u9500\u7684\u8349\u7a3f\u4fee\u6539\u3002",
  activeDraftSet: "\u5df2\u8bbe\u4e3a\u5f53\u524d\u8349\u7a3f",
  activeNoteNotDraft: "\u5f53\u524d\u7b14\u8bb0\u4e0d\u5728\u8bbe\u7f6e\u7684\u8349\u7a3f\u6587\u4ef6\u5939\u4e2d\u3002",
  answerSourceMode: "\u56de\u7b54\u6a21\u5f0f",
  notesOnlyMode: "\u7b14\u8bb0",
  modelOnlyMode: "\u6a21\u578b",
  notesModelMode: "\u7b14\u8bb0+\u6a21\u578b",
  writeDisabled: "\u5199\u5165\u529f\u80fd\u5df2\u5173\u95ed\u3002\u8bf7\u5148\u5728\u8bbe\u7f6e\u4e2d\u542f\u7528\u201c\u4ec5\u8349\u7a3f\u201d\u3002",
  draftFailed: "\u8349\u7a3f\u751f\u6210\u5931\u8d25",
  answerWithSources: "\u5e26\u6765\u6e90\u56de\u7b54",
  answering: "\u56de\u7b54\u4e2d...",
  answerFailed: "\u56de\u7b54\u5931\u8d25",
  sources: "\u6765\u6e90",
  snippet: "\u7247\u6bb5",
  buildingIndex: "\u6b63\u5728\u5efa\u7acb\u8bed\u4e49\u7d22\u5f15\u3002\u7b2c\u4e00\u6b21\u8fd0\u884c\u53ef\u80fd\u9700\u8981\u4e00\u4e9b\u65f6\u95f4\u3002",
  indexRebuilt: "\u672c\u5730\u7b14\u8bb0\u52a9\u624b\u7d22\u5f15\u5df2\u91cd\u5efa\u3002",
  indexFailed: "\u7d22\u5f15\u5efa\u7acb\u5931\u8d25\u3002\u8bf7\u68c0\u67e5\u8bbe\u7f6e\u548c\u6a21\u578b\u8fde\u63a5\u3002",
  noResults: "\u6ca1\u6709\u627e\u5230\u660e\u663e\u76f8\u5173\u7684\u7ed3\u679c\u3002\u53ef\u4ee5\u6362\u4e00\u79cd\u8bf4\u6cd5\uff0c\u6216\u8f93\u5165\u66f4\u77ed\u7684\u95ee\u9898\u3002",
  semantic: "\u8bed\u4e49",
  keyword: "\u5173\u952e\u8bcd",
  found: "\u641c\u7d22\u627e\u5230\u4e86",
  matchesFor: "\u4e2a\u53ef\u80fd\u76f8\u5173\u7ed3\u679c\uff0c\u95ee\u9898\u662f",
  heading: "\u6807\u9898",
  similarity: "\u76f8\u4f3c\u5ea6",
  score: "\u5206\u6570",
  noIndex: "\u8fd8\u6ca1\u6709\u8bed\u4e49\u7d22\u5f15\u3002\u70b9\u51fb\u201c\u5efa\u7acb / \u91cd\u5efa\u7d22\u5f15\u201d\u6765\u542f\u7528\u66f4\u806a\u660e\u7684\u641c\u7d22\u3002",
  indexReady: "\u7d22\u5f15\u5df2\u5c31\u7eea",
  chunksFrom: "\u4e2a\u7247\u6bb5\uff0c\u6765\u81ea",
  notesUsing: "\u7bc7\u7b14\u8bb0\uff0c\u4f7f\u7528",
  settingsChanged: "\u8bbe\u7f6e\u5df2\u7ecf\u6539\u53d8\uff0c\u8bf7\u91cd\u5efa\u7d22\u5f15\u3002",
  readingProgress: "\u8bfb\u53d6\u4e2d",
  embeddingProgress: "Embedding \u4e2d",
  semanticSearchFallback: "\u8bed\u4e49\u641c\u7d22\u5931\u8d25\uff0c\u56e0\u6b64\u6539\u7528\u5173\u952e\u8bcd\u641c\u7d22",
  semanticIndexStaleWarning: "\u8bed\u4e49\u7d22\u5f15\u662f\u7528\u4e0d\u540c\u8bbe\u7f6e\u5efa\u7acb\u7684\u3002\u8bf7\u91cd\u5efa\u7d22\u5f15\u540e\u518d\u4f7f\u7528\u8bed\u4e49\u641c\u7d22\u3002",
  noSemanticIndexWarning: "\u8fd8\u6ca1\u6709\u8bed\u4e49\u7d22\u5f15\u3002\u70b9\u51fb\u201c\u5efa\u7acb / \u91cd\u5efa\u7d22\u5f15\u201d\u53ef\u542f\u7528\u66f4\u806a\u660e\u7684\u641c\u7d22\u3002",
  noHeading: "\uff08\u65e0\u6807\u9898\uff09",
  settingIntro: "\u9009\u62e9\u8bed\u4e49\u641c\u7d22\u548c\u56de\u7b54\u751f\u6210\u4f7f\u7528\u7684\u6a21\u578b\u3002API key \u4f1a\u4fdd\u5b58\u5728\u672c\u63d2\u4ef6\u672c\u5730\u7684 data.json \u6587\u4ef6\u4e2d\u3002",
  language: "\u754c\u9762\u8bed\u8a00",
  languageDesc: "\u5728\u82f1\u6587\u548c\u4e2d\u6587\u754c\u9762\u4e4b\u95f4\u5207\u6362\u3002",
  provider: "Embedding \u6765\u6e90",
  providerDesc: "\u66f4\u6539\u540e\u9700\u8981\u91cd\u5efa\u7d22\u5f15\u3002",
  chatProvider: "\u804a\u5929\u6a21\u578b\u6765\u6e90",
  chatProviderDesc: "\u7528\u4e8e\u57fa\u4e8e\u68c0\u7d22\u5230\u7684\u7b14\u8bb0\u7247\u6bb5\u56de\u7b54\u95ee\u9898\u3002",
  enableImageInput: "\u542f\u7528\u56fe\u7247\u8f93\u5165",
  enableImageInputDesc: "\u5141\u8bb8\u5c06\u622a\u56fe\u6216\u56fe\u7247\u6587\u4ef6\u53d1\u9001\u7ed9\u89c6\u89c9\u6a21\u578b\u3002",
  visionProvider: "\u89c6\u89c9\u6a21\u578b\u6765\u6e90",
  visionProviderDesc: "\u53ea\u5728\u5c06\u56fe\u7247\u8f6c\u6210 Markdown \u65f6\u4f7f\u7528\u3002",
  maxImageBytes: "\u56fe\u7247\u6700\u5927\u5927\u5c0f",
  maxImageBytesDesc: "\u5141\u8bb8\u4e0a\u4f20\u7684\u6700\u5927\u56fe\u7247\u5b57\u8282\u6570\u3002\u9ed8\u8ba4 5242880\uff0c\u5927\u7ea6 5 MB\u3002",
  providerUseChat: "\u4f7f\u7528\u804a\u5929\u6a21\u578b\u6765\u6e90",
  providerOllama: "Ollama \u672c\u5730",
  providerOpenAI: "OpenAI",
  providerGemini: "Gemini",
  providerQwen: "Qwen / DashScope",
  providerDeepSeek: "DeepSeek",
  providerCustom: "\u81ea\u5b9a\u4e49 OpenAI-compatible",
  settingsCore: "\u57fa\u7840",
  settingsEmbeddingSection: "Embedding \u8bed\u4e49\u641c\u7d22",
  settingsEmbeddingDesc: "\u5148\u9009\u62e9\u4e00\u4e2a embedding \u6765\u6e90\uff0c\u4e0b\u65b9\u53ea\u663e\u793a\u5bf9\u5e94\u516c\u53f8\u7684\u8bbe\u7f6e\u6a21\u677f\u3002",
  maxIncrementalIndexChunks: "\u589e\u91cf\u7d22\u5f15\u5355\u6b21\u7247\u6bb5\u4e0a\u9650",
  maxIncrementalIndexChunksDesc: "\u201c\u66f4\u65b0\u53d8\u66f4\u7d22\u5f15\u201d\u6309\u94ae\u5355\u6b21\u6700\u591a\u65b0\u5efa\u591a\u5c11\u4e2a embedding\u3002\u201c\u68c0\u67e5\u7d22\u5f15\u53d8\u5316\u201d\u4e0d\u4f1a\u8c03\u7528 embedding \u6a21\u578b\u3002",
  settingsChatSection: "\u804a\u5929\u56de\u7b54\u6a21\u578b",
  settingsChatDesc: "\u7528\u4e8e\u56de\u7b54\u3001Agent\u3001\u8349\u7a3f\u6539\u5199\u548c\u610f\u56fe\u8def\u7531\u7684\u6a21\u578b\u6765\u6e90\u3002",
  settingsVisionSection: "\u89c6\u89c9\u4e0e\u8f93\u5165",
  settingsVisionDesc: "\u914d\u7f6e\u622a\u56fe/\u56fe\u7247\u7406\u89e3\u548c\u8bed\u97f3\u8f93\u5165\u3002",
  settingsRetrievalSection: "\u68c0\u7d22\u4e0a\u4e0b\u6587",
  settingsRetrievalDesc: "\u63a7\u5236\u6bcf\u6b21\u56de\u7b54\u53d1\u9001\u591a\u5c11\u672c\u5730\u7b14\u8bb0\u5185\u5bb9\u7ed9\u6a21\u578b\u3002",
  settingsMemorySection: "\u8bb0\u5fc6\u4e0e\u53cd\u9988",
  settingsMemoryDesc: "\u5bf9\u8bdd\u8bb0\u5fc6\u3001\u957f\u8bb0\u5fc6\u548c\u201c\u4e0d\u6ee1\u610f\u201d\u53cd\u9988\u8bb0\u5f55\u3002",
  settingsDraftSection: "\u8349\u7a3f\u4e0e ChatGPT \u4ea4\u63a5",
  settingsDraftDesc: "\u63a7\u5236\u5b89\u5168\u8349\u7a3f\u5199\u5165\u548c ChatGPT \u4ea4\u63a5\u6587\u4ef6\u3002",
  settingsMigrationSection: "\u8fc1\u79fb\u4e0e Agent",
  settingsMigrationDesc: "\u63a7\u5236\u8fc1\u79fb\u5ba1\u9605\u548c Agent \u8ba1\u5212\u884c\u4e3a\u3002",
  providerTemplate: "\u5f53\u524d\u4f9b\u5e94\u5546\u6a21\u677f",
  providerTemplateDesc: "\u53ea\u663e\u793a\u5f53\u524d\u9009\u4e2d\u4f9b\u5e94\u5546\u9700\u8981\u586b\u5199\u7684\u5b57\u6bb5\u3002",
  providerInheritedFromChat: "\u4f7f\u7528\u5f53\u524d\u804a\u5929\u6a21\u578b\u6765\u6e90\u7684\u8bbe\u7f6e\u3002",
  ollamaBaseUrl: "Ollama \u57fa\u7840 URL",
  ollamaEmbeddingModel: "Ollama embedding \u6a21\u578b",
  openaiBaseUrl: "OpenAI \u57fa\u7840 URL",
  openaiApiKey: "OpenAI API key",
  openaiEmbeddingModel: "OpenAI embedding \u6a21\u578b",
  geminiApiKey: "Gemini API key",
  geminiEmbeddingModel: "Gemini embedding \u6a21\u578b",
  qwenBaseUrl: "Qwen / DashScope \u57fa\u7840 URL",
  qwenApiKey: "Qwen / DashScope API key",
  qwenEmbeddingModel: "Qwen embedding \u6a21\u578b",
  qwenEmbeddingDimensions: "Qwen embedding \u7ef4\u5ea6",
  customBaseUrl: "\u81ea\u5b9a\u4e49\u57fa\u7840 URL",
  customApiKey: "\u81ea\u5b9a\u4e49 API key",
  customEmbeddingModel: "\u81ea\u5b9a\u4e49 embedding \u6a21\u578b",
  ollamaChatModel: "Ollama \u804a\u5929\u6a21\u578b",
  openaiChatModel: "OpenAI \u804a\u5929\u6a21\u578b",
  geminiChatModel: "Gemini \u804a\u5929\u6a21\u578b",
  qwenChatModel: "Qwen \u804a\u5929\u6a21\u578b",
  deepseekBaseUrl: "DeepSeek \u57fa\u7840 URL",
  deepseekApiKey: "DeepSeek API key",
  deepseekChatModel: "DeepSeek \u804a\u5929\u6a21\u578b",
  customChatModel: "\u81ea\u5b9a\u4e49\u804a\u5929\u6a21\u578b",
  ollamaVisionModel: "Ollama \u89c6\u89c9\u6a21\u578b",
  openaiVisionModel: "OpenAI \u89c6\u89c9\u6a21\u578b",
  geminiVisionModel: "Gemini \u89c6\u89c9\u6a21\u578b",
  qwenVisionModel: "Qwen \u89c6\u89c9\u6a21\u578b",
  customVisionModel: "\u81ea\u5b9a\u4e49\u89c6\u89c9\u6a21\u578b",
  answerContextLimit: "\u56de\u7b54\u4f7f\u7528\u7684\u7247\u6bb5\u6570",
  answerContextLimitDesc: "\u53d1\u9001\u7ed9\u804a\u5929\u6a21\u578b\u7684\u68c0\u7d22\u7247\u6bb5\u6570\u91cf\u3002",
  maxAnswerContextChars: "\u6bcf\u4e2a\u7247\u6bb5\u7684\u4e0a\u4e0b\u6587\u957f\u5ea6",
  maxAnswerContextCharsDesc: "\u6bcf\u4e2a\u68c0\u7d22\u7247\u6bb5\u6700\u591a\u53d1\u9001\u7ed9\u804a\u5929\u6a21\u578b\u7684\u5b57\u7b26\u6570\u3002",
  maxTotalAnswerContextChars: "\u56de\u7b54\u603b\u4e0a\u4e0b\u6587\u957f\u5ea6",
  maxTotalAnswerContextCharsDesc: "\u6bcf\u6b21\u56de\u7b54\u6700\u591a\u53d1\u9001\u7ed9\u804a\u5929\u6a21\u578b\u7684\u603b\u5b57\u7b26\u6570\u3002",
  includeNeighborChunks: "\u5305\u542b\u76f8\u90bb\u7247\u6bb5",
  includeNeighborChunksDesc: "\u56de\u7b54\u65f6\u52a0\u5165\u547d\u4e2d\u7247\u6bb5\u524d\u540e\u7684\u7247\u6bb5\u3002",
  neighborChunksBefore: "\u524d\u9762\u76f8\u90bb\u7247\u6bb5\u6570",
  neighborChunksAfter: "\u540e\u9762\u76f8\u90bb\u7247\u6bb5\u6570",
  includeSameHeadingSection: "\u5305\u542b\u540c\u6807\u9898\u5185\u5bb9",
  includeSameHeadingSectionDesc: "\u56de\u7b54\u65f6\u52a0\u5165\u540c\u4e00\u6807\u9898\u4e0b\u7684\u5176\u4ed6\u7247\u6bb5\u3002",
  useConversationMemory: "\u4f7f\u7528\u5bf9\u8bdd\u8bb0\u5fc6",
  useConversationMemoryDesc: "\u5728\u70b9\u51fb\u201c\u65b0\u5bf9\u8bdd\u201d\u4e4b\u524d\uff0c\u540e\u7eed\u95ee\u9898\u4f1a\u7ee7\u627f\u5f53\u524d\u4e3b\u9898\u3002",
  conversationTurnsToKeep: "\u4fdd\u7559\u5bf9\u8bdd\u8f6e\u6570",
  conversationTurnsToKeepDesc: "\u7528\u4e8e\u7406\u89e3\u540e\u7eed\u95ee\u9898\u7684\u6700\u8fd1\u95ee\u7b54\u8f6e\u6570\u3002\u5141\u8bb8\u8303\u56f4\uff1a0-99\u3002",
  writeMode: "\u5199\u5165\u6a21\u5f0f",
  writeModeDesc: "\u63a7\u5236\u63d2\u4ef6\u662f\u5426\u53ef\u4ee5\u521b\u5efa Markdown \u6587\u4ef6\u3002",
  writeModeDisabled: "\u5173\u95ed",
  writeModeDraft: "\u4ec5\u8349\u7a3f",
  draftFolder: "\u8349\u7a3f\u6587\u4ef6\u5939",
  draftFolderDesc: "AI \u8349\u7a3f\u4f1a\u521b\u5efa\u5230\u8fd9\u4e2a\u6587\u4ef6\u5939\u3002",
  draftSourceMode: "\u8349\u7a3f\u6765\u6e90\u6a21\u5f0f",
  draftSourceModeDesc: "\u9009\u62e9\u8349\u7a3f\u751f\u6210\u65f6\u4f7f\u7528\u7b14\u8bb0\u3001\u6a21\u578b\u77e5\u8bc6\u6216\u4e24\u8005\u3002",
  draftSourceNotesOnly: "\u4ec5\u7b14\u8bb0",
  draftSourceNotesModel: "\u7b14\u8bb0 + \u6a21\u578b\u77e5\u8bc6",
  draftSourceModelOnly: "\u4ec5\u6a21\u578b\u77e5\u8bc6",
  maxDraftEditChars: "\u6574\u7bc7\u8349\u7a3f\u4fee\u6539\u957f\u5ea6",
  maxDraftEditCharsDesc: "\u5141\u8bb8 AI \u76f4\u63a5\u4fee\u6539\u6574\u7bc7\u8349\u7a3f\u7684\u6700\u5927\u5b57\u7b26\u6570\u3002",
  confirmAgentPlans: "\u786e\u8ba4 Agent \u8ba1\u5212",
  confirmAgentPlansDesc: "\u591a\u6b65\u8349\u7a3f\u4efb\u52a1\u6267\u884c\u524d\u5148\u663e\u793a\u8ba1\u5212\u3002",
  userWritingPreferences: "\u5199\u4f5c\u504f\u597d",
  userWritingPreferencesDesc: "\u4f1a\u52a0\u5165\u8349\u7a3f\u5199\u4f5c\u548c\u6539\u5199 prompt \u7684\u957f\u671f\u98ce\u683c\u8981\u6c42\u3002",
  agentPlan: "Agent \u8ba1\u5212",
  runAgentPlan: "\u6267\u884c\u8ba1\u5212",
  cancelAgentPlan: "\u53d6\u6d88",
  agentCancelled: "Agent \u8ba1\u5212\u5df2\u53d6\u6d88",
  agentSelfCheck: "Agent \u81ea\u68c0",
  draftChangeSummary: "\u8349\u7a3f\u4fee\u6539\u6458\u8981",
  memory: "\u8bb0\u5fc6",
  useLongTermMemory: "\u4f7f\u7528\u66f4\u957f\u8bb0\u5fc6",
  useLongTermMemoryDesc: "\u8de8\u65b0\u5bf9\u8bdd\u4fdd\u7559\u6700\u8fd1 AI \u8f93\u51fa\uff0c\u4f9b\u540e\u7eed\u8349\u7a3f\u64cd\u4f5c\u8c03\u7528\u3002",
  longTermMemoryToKeep: "\u957f\u8bb0\u5fc6\u6761\u76ee\u6570",
  longTermMemoryToKeepDesc: "\u672c\u5730\u4fdd\u7559\u591a\u5c11\u6761\u6700\u8fd1 AI \u8f93\u51fa\u3002",
  markUnsatisfied: "\u4e0d\u6ee1\u610f",
  unsatisfiedFeedback: "\u6807\u8bb0\u8fd9\u6b21\u56de\u7b54\u4e0d\u6ee1\u610f",
  unsatisfiedFeedbackDesc: "\u5728\u672c\u5730\u4fdd\u5b58\u4e00\u6761\u5931\u8d25\u6807\u7b7e\uff0c\u5e2e\u52a9\u4ee5\u540e\u907f\u514d\u540c\u7c7b\u9519\u8bef\u3002",
  unsatisfiedReason: "\u54ea\u91cc\u4e0d\u597d\uff1f",
  saveFeedback: "\u4fdd\u5b58\u53cd\u9988",
  unsatisfiedReasonPlaceholder: "\u4f8b\u5982\uff1a\u5b83\u7f16\u9020\u4e86\u6765\u6e90\u3001\u6f0f\u6389\u76f8\u5173\u7b14\u8bb0\uff0c\u6216\u8005\u516c\u5f0f\u683c\u5f0f\u4e0d\u5bf9\u3002",
  unsatisfiedSaved: "\u5df2\u4fdd\u5b58\u4e0d\u6ee1\u610f\u53cd\u9988\u3002\u540e\u7eed\u56de\u7b54\u4f1a\u5c3d\u91cf\u907f\u514d\u8fd9\u7c7b\u95ee\u9898\u3002",
  unsatisfiedMissingAnswer: "\u8fd8\u6ca1\u6709\u53ef\u6807\u8bb0\u7684\u6700\u8fd1\u56de\u7b54\u3002",
  negativeFeedbackTitle: "\u4e0d\u6ee1\u610f\u56de\u7b54\u53cd\u9988",
  negativeFeedbackDesc: "\u672c\u5730\u4fdd\u5b58\u7684\u5931\u8d25\u6807\u7b7e\uff0c\u7528\u6765\u51cf\u5c11\u91cd\u590d\u72af\u9519\u3002",
  negativeFeedbackItems: "\u6761\u53cd\u9988",
  noNegativeFeedback: "\u8fd8\u6ca1\u6709\u4e0d\u6ee1\u610f\u53cd\u9988\u3002",
  deleteFeedback: "\u5220\u9664\u53cd\u9988",
  deleteFeedbackConfirm: "\u786e\u5b9a\u5220\u9664\u8fd9\u6761\u4e0d\u6ee1\u610f\u53cd\u9988\u5417\uff1f",
  feedbackTags: "\u6807\u7b7e",
  useNegativeFeedbackMemory: "\u4f7f\u7528\u4e0d\u6ee1\u610f\u53cd\u9988",
  useNegativeFeedbackMemoryDesc: "\u5c06\u6700\u8fd1\u7684\u672c\u5730\u53cd\u9988\u6807\u7b7e\u52a0\u5165\u540e\u7eed AI prompt\u3002",
  negativeFeedbackToKeep: "\u4e0d\u6ee1\u610f\u53cd\u9988\u6761\u76ee\u6570",
  negativeFeedbackToKeepDesc: "\u672c\u5730\u6700\u591a\u4fdd\u7559\u591a\u5c11\u6761\u4e0d\u6ee1\u610f\u56de\u7b54\u53cd\u9988\u3002",
  migrationScanLimit: "\u8fc1\u79fb\u626b\u63cf\u6570\u91cf",
  migrationScanLimitDesc: "\u751f\u6210\u6b63\u5f0f\u7b14\u8bb0\u8fc1\u79fb\u8ba1\u5212\u65f6\uff0c\u6700\u591a\u53d1\u9001\u591a\u5c11\u7bc7\u76f8\u5173\u7b14\u8bb0\u7ed9\u6a21\u578b\u3002",
  noteMigration: "\u7b14\u8bb0\u8fc1\u79fb",
  noteMigrationScanning: "\u6b63\u5728\u626b\u63cf\u7b14\u8bb0\u8fc1\u79fb...",
  noteMigrationNeedTwoLinks: "\u8bf7\u540c\u65f6\u5199\u51fa\u65e7\u7b14\u8bb0\u548c\u65b0\u7b14\u8bb0\uff0c\u4f8b\u5982 [[A]] -> [[B]]\u3002",
  noteMigrationNoCandidates: "\u6ca1\u627e\u5230\u9700\u8981\u8fc1\u79fb\u7684\u76f8\u5173\u7b14\u8bb0\u3002",
  noteMigrationNoPlan: "\u8fd8\u6ca1\u6709\u53ef\u6267\u884c\u7684\u8fc1\u79fb\u8ba1\u5212\u3002\u8bf7\u5148\u8fdb\u884c\u8fc1\u79fb\u626b\u63cf\u3002",
  noteMigrationApplied: "\u5df2\u6267\u884c\u4f4e\u98ce\u9669\u8fc1\u79fb",
  noteMigrationUndone: "\u5df2\u64a4\u9500\u4e0a\u6b21\u6b63\u5f0f\u7b14\u8bb0\u8fc1\u79fb",
  migrationRiskCandidates: "\u8fc1\u79fb\u98ce\u9669\u5019\u9009",
  migrationReview: "\u8fc1\u79fb\u5ba1\u9605",
  migrationReviewNoDiff: "\u8fd9\u4e00\u6761\u65e0\u6cd5\u751f\u6210\u53ef\u5b89\u5168\u81ea\u52a8\u6267\u884c\u7684\u786e\u5b9a diff\u3002",
  migrationReviewApplied: "\u5df2\u6267\u884c\u5ba1\u9605\u540e\u7684\u8fc1\u79fb",
  migrationAlreadyApplied: "\u5df2\u5904\u7406",
  planEditor: "\u53ef\u7f16\u8f91\u8ba1\u5212",
  taskLog: "\u4efb\u52a1\u65e5\u5fd7",
  anchors: "\u8349\u7a3f\u951a\u70b9",
  maxAgentSteps: "Agent \u6700\u5927\u6b65\u6570",
  formalProposal: "\u6b63\u5f0f\u7b14\u8bb0\u63d0\u6848",
  formalProposalNoWrite: "\u672a\u4fee\u6539\u4efb\u4f55\u6b63\u5f0f\u7b14\u8bb0\u3002\u8fd9\u53ea\u662f\u4e00\u4efd\u53ea\u8bfb\u63d0\u6848\u3002",
  formalProposalCandidates: "\u5019\u9009\u7b14\u8bb0",
  agentPlanSummary: "\u8ba1\u5212\u6458\u8981",
  agentPlanGoal: "\u76ee\u6807",
  agentPlanWrites: "\u5199\u5165",
  agentPlanReads: "\u8bfb\u53d6",
  agentPlanSafety: "\u5b89\u5168",
  agentPlanDraftOnly: "\u4ec5\u5199\u5165 AI \u8349\u7a3f",
  agentPlanReadOnly: "\u53ea\u8bfb",
  agentPlanFormalSafe: "\u6b63\u5f0f\u7b14\u8bb0\u53d7\u4fdd\u62a4\uff1b\u53ea\u4f1a\u751f\u6210\u63d0\u6848\u3002",
  agentPlanTarget: "\u76ee\u6807\u4f4d\u7f6e",
  agentPlanSources: "\u53ef\u80fd\u6765\u6e90",
  agentPlanNoTarget: "\u6ca1\u6709\u63d0\u4f9b\u7cbe\u786e\u63d2\u5165\u4f4d\u7f6e\u3002",
  insertionTargetFallback: "\u63d2\u5165\u4f4d\u7f6e\u56de\u9000",
  topicCoverageReport: "\u8986\u76d6\u68c0\u67e5",
  resultsToShow: "\u663e\u793a\u7ed3\u679c\u6570\u91cf",
  resultsToShowDesc: "\u804a\u5929\u9762\u677f\u91cc\u663e\u793a\u591a\u5c11\u6761\u641c\u7d22\u7ed3\u679c\u3002",
  openFailed: "\u65e0\u6cd5\u6253\u5f00",
  opened: "\u5df2\u6253\u5f00",
});

function t(settings, key) {
  const language = settings && settings.language === "zh" ? "zh" : "en";
  return (UI_TEXT[language] && UI_TEXT[language][key]) || UI_TEXT.en[key] || key;
}

function lt(settings, en, zh) {
  return settings && settings.language === "zh" ? zh : en;
}

function normalizeToolKeywordName(value) {
  return String(value || "")
    .replace(/[\s_\-:：]/g, "")
    .toLowerCase();
}

function findToolKeywordDef(rawKeyword) {
  const normalized = normalizeToolKeywordName(rawKeyword);
  if (!normalized) return null;
  return TOOL_KEYWORD_DEFS.find((def) => {
    if (normalizeToolKeywordName(def.keyword) === normalized) return true;
    return (def.aliases || []).some((alias) => normalizeToolKeywordName(alias) === normalized);
  }) || null;
}

function parseLeadingToolKeyword(text) {
  const value = String(text || "");
  const match = value.match(/^\s*(?:\[([^\]\r\n]{1,32})\]|【([^】\r\n]{1,32})】)\s*/);
  if (!match) return null;
  const raw = match[1] || match[2] || "";
  const def = findToolKeywordDef(raw);
  if (!def) return null;
  return {
    ...def,
    raw,
    token: match[0].trim(),
    text: value.slice(match[0].length).trim(),
  };
}

function normalizeMathCanonical(text) {
  return String(text || "")
    .replace(/\\(?:operatorname|text)\{([^{}]+)\}/g, "$1")
    .replace(/\\mathbb\{C\}/g, " C ")
    .replace(/\\mathbb\{R\}/g, " R ")
    .replace(/\\mathbb\{Z\}/g, " Z ")
    .replace(/\\mathbb\{Q\}/g, " Q ")
    .replace(/c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)/gi, " C星 ")
    .replace(/\\ast/g, "星")
    .replace(/\\infty/g, "无穷")
    .replace(/\\text/g, " text ")
    .replace(/\\operatorname/g, " operatorname ");
}

function normalizeMathAliases(text) {
  return String(text || "")
    .replace(/\\(?:operatorname|text)\{([^{}]+)\}/g, "$1")
    .replace(/\\mathbb\{C\}/g, " C 复数 complex ")
    .replace(/\\mathbb\{R\}/g, " R 实数 real ")
    .replace(/\\mathbb\{Z\}/g, " Z 整数 integer ")
    .replace(/\\mathbb\{Q\}/g, " Q 有理数 rational ")
    .replace(/c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)/gi, " C星 C星代数 Cstar C* ")
    .replace(/\\bar\s*\{?\s*\\partial\s*\}?/g, " dbar barpartial Cauchy-Riemann CR 方程 ")
    .replace(/\\infty/g, "无穷 infinity")
    .replace(/\\ast/g, "星 ast")
    .replace(/\\Delta/g, "Delta Δ")
    .replace(/\\text/g, " text ")
    .replace(/\\operatorname/g, " operatorname ");
}

function addSearchAliases(text) {
  const value = normalizeMathAliases(text);
  const aliases = [];
  const compact = value.replace(/\s+/g, "");
  const checks = [
    [/c星|cstar|c\*/i, "C星 C星代数 cstar Cstar C* C*-代数 C*代数"],
    [/topos|拓扑斯/i, "topos 拓扑斯 初等拓扑斯 Grothendieck拓扑斯"],
    [/sheaf|层\b|层范畴/i, "sheaf 层 层范畴 Sh"],
    [/presheaf|预层/i, "presheaf 预层 预层范畴"],
    [/grothendieck\s*topology|grothendieck拓扑|覆盖筛|景/i, "Grothendieck拓扑 覆盖筛 site 景"],
    [/geometric\s*morphism|几何态射/i, "geometric morphism 几何态射 direct-image inverse-image"],
    [/subobject\s*classifier|子对象分类子/i, "subobject classifier 子对象分类子 真值对象"],
    [/locale|位象/i, "locale 位象 frame 帧"],
    [/heyting/i, "Heyting 海廷 Heyting代数"],
    [/banach/i, "Banach 巴拿赫 Banach空间"],
    [/hilbert/i, "Hilbert 希尔伯特 Hilbert空间"],
    [/hahn[-\s]?banach/i, "Hahn-Banach 延拓 分离"],
    [/拓扑向量|topological\s*vector|tvs/i, "拓扑向量空间 TVS topological vector space"],
    [/模型范畴|model\s*category/i, "模型范畴 model category cofibration fibration weak equivalence"],
    [/quillen/i, "Quillen Quillen伴随 Quillen等价 导出函子"],
    [/reedy/i, "Reedy Reedy范畴 Reedy模型结构"],
    [/bousfield/i, "Bousfield 局部化"],
    [/谱序列|spectral\s*sequence/i, "谱序列 spectral sequence 滤过 正合对"],
    [/galois/i, "Galois 伽罗瓦 Galois扩张 Galois对应"],
    [/hilbert\s*90/i, "Hilbert90 Hilbert 90 上同调"],
    [/多复变|several\s*complex/i, "多复变函数 多复变 复分析 SCV"],
    [/解析集|analytic\s*set/i, "解析集 analytic set 正则点 奇异点"],
    [/多重次调和|plurisubharmonic|psh/i, "多重次调和函数 plurisubharmonic psh Levi形式"],
    [/拟凸|pseudoconvex/i, "拟凸域 pseudoconvex Levi拟凸 全纯凸"],
    [/hartogs/i, "Hartogs 延拓 Hartogs引理"],
    [/riemann/i, "Riemann 可去奇性"],
    [/weierstrass/i, "Weierstrass 预备定理 Weierstrass映射"],
    [/abel/i, "Abel范畴 abelian category 阿贝尔范畴"],
    [/yoneda/i, "Yoneda 米田 可表"],
    [/kan/i, "Kan扩张 Kan extension"],
    [/nip/i, "NIP 稳定性理论 交错数"],
    [/morley/i, "Morley 稳定性 型"],
    [/definition|定义|定義|是什么|基本定义|概念/i, "定义 基本定义 概念 是什么"],
    [/proposition|命题|命題/i, "命题 proposition"],
    [/theorem|定理/i, "定理 theorem"],
    [/proof|证明|證明/i, "证明 proof"],
    [/morphism|态射|同态|homomorphism/i, "态射 同态 morphism homomorphism"],
    [/representation|表示论|表示/i, "表示 表示论 representation"],
  ];
  for (const [pattern, alias] of checks) {
    if (pattern.test(value)) aliases.push(alias);
  }
  if (/c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)/i.test(String(text || "")) || /c星/i.test(value)) {
    aliases.push("C星 C星代数 cstar Cstar C* C*-代数 C*代数");
  }
  if (/\\ast|\*/.test(value)) aliases.push("星 星代数");
  return `${value} ${compact} ${aliases.join(" ")}`;
}

function tokenize(text) {
  const value = addSearchAliases(text).toLowerCase();
  const terms = [];
  const asciiMatches = value.match(/[a-z0-9_\\-]+/g) || [];
  for (const word of asciiMatches) {
    const cleaned = word.replace(/^-+|-+$/g, "");
    if (cleaned.length > 1 || cleaned.startsWith("\\")) terms.push(cleaned);
  }
  const cjkMatches = value.match(/[\u3400-\u9fff]+/g) || [];
  for (const sequence of cjkMatches) {
    if (sequence.length <= 10) terms.push(sequence);
    for (const size of [2, 3, 4, 5]) {
      if (sequence.length < size) continue;
      for (let index = 0; index <= sequence.length - size; index += 1) {
        terms.push(sequence.slice(index, index + size));
      }
    }
  }
  return [...new Set(terms.filter((word) => word.length > 0))].slice(0, 220);
}

function tokenizePlainKnowledge(text) {
  const value = String(text || "").toLowerCase();
  const terms = [];
  const asciiMatches = value.match(/[a-z0-9_\\*-]+/g) || [];
  for (const word of asciiMatches) {
    const cleaned = word.replace(/^-+|-+$/g, "");
    if (cleaned.length > 1 || cleaned.startsWith("\\")) terms.push(cleaned);
  }
  const cjkMatches = value.match(/[\u3400-\u9fff]+/g) || [];
  for (const sequence of cjkMatches) {
    if (sequence.length <= 10) terms.push(sequence);
    for (const size of [2, 3, 4, 5]) {
      if (sequence.length < size) continue;
      for (let index = 0; index <= sequence.length - size; index += 1) {
        terms.push(sequence.slice(index, index + size));
      }
    }
  }
  return [...new Set(terms.filter(Boolean))].slice(0, 120);
}

const KNOWLEDGE_CORE_CALLOUT_TYPES = new Set([
  "definition",
  "def",
  "proposition",
  "prop",
  "theorem",
  "thm",
  "lemma",
  "corollary",
  "example",
  "remark",
  "notation",
  "axiom",
  "construction",
]);

const KNOWLEDGE_AUXILIARY_CALLOUT_TYPES = new Set(["proof", "solution"]);

function getKnowledgeCalloutRole(type) {
  const normalized = String(type || "").toLowerCase();
  if (KNOWLEDGE_AUXILIARY_CALLOUT_TYPES.has(normalized)) return "auxiliary";
  if (KNOWLEDGE_CORE_CALLOUT_TYPES.has(normalized)) return "core";
  return "context";
}

function stripKnowledgeFocusNoise(query) {
  let value = String(query || "");
  for (const phrase of [
    "基本定义",
    "重要定理",
    "定义",
    "定理",
    "命题",
    "性质",
    "基本",
    "重要",
    "应用",
    "关系",
    "整理",
    "总结",
    "证明",
    "直观",
    "意义",
    "例子",
    "有什么",
    "是什么",
    "怎么",
    "如何",
    "的",
    "和",
    "与",
  ]) {
    value = value.replaceAll(phrase, " ");
  }
  return value;
}

function getKnowledgeEntityAliasTerms(query) {
  const value = String(query || "");
  const lower = value.toLowerCase();
  const terms = [];
  if (/c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)|c星|c\*/i.test(value)) {
    terms.push("c*", "cstar", "c星代数", "星代数");
  }
  if (/表示|representation/i.test(value)) terms.push("表示", "representation");
  if (/态|gns/i.test(value)) terms.push("态", "gns");
  if (/多复变|several complex|scv/i.test(value)) terms.push("多复变", "复变函数", "several", "complex");
  if (/解析集|analytic set/i.test(value)) terms.push("解析集", "analytic");
  if (/拟凸|pseudoconvex/i.test(value)) terms.push("拟凸", "pseudoconvex", "levi");
  if (lower.includes("hartogs")) {
    terms.push("hartogs");
    if (value.includes("延拓")) terms.push("hartogs延拓");
  }
  if (/topos|拓扑斯/i.test(value)) terms.push("topos", "拓扑斯");
  if (lower.includes("grothendieck")) terms.push("grothendieck");
  if (/层|sheaf/i.test(value)) terms.push("层", "sheaf");
  if (lower.includes("heyting")) terms.push("heyting");
  if (/locale|位象|frame/i.test(value)) terms.push("locale", "位象", "frame");
  if (/模型范畴|model category/i.test(value)) terms.push("模型范畴", "model", "category");
  if (/谱序列|spectral sequence/i.test(value)) terms.push("谱序列", "spectral", "sequence");
  if (lower.includes("galois")) terms.push("galois");
  if (/\bnip\b/i.test(value)) terms.push("nip");
  if (lower.includes("banach")) terms.push("banach");
  if (lower.includes("hilbert")) terms.push("hilbert");
  if (lower.includes("yoneda")) terms.push("yoneda");
  return terms;
}

function isGenericKnowledgeFocusTerm(term) {
  const compact = String(term || "").toLowerCase().trim();
  if (!compact) return true;
  if (compact.includes("hartogs") && compact.includes("延拓")) return false;
  if (compact.length <= 1) return true;
  if (
    [
      "definition",
      "theorem",
      "proposition",
      "property",
      "basic",
      "application",
      "relationship",
      "what",
      "how",
      "and",
      "algebra",
      "operator",
      "space",
      "function",
      "category",
      "theory",
    ].includes(compact)
  ) {
    return true;
  }
  const genericParts = [
    "定义",
    "定理",
    "命题",
    "性质",
    "基本",
    "重要",
    "应用",
    "关系",
    "整理",
    "总结",
    "证明",
    "直观",
    "意义",
    "延拓",
    "理论",
    "例子",
    "代数",
    "函数",
    "空间",
    "什么",
    "观意",
  ];
  if (genericParts.some((part) => compact.includes(part))) return true;
  if (/[\u3400-\u9fff]/.test(compact) && ["的", "和", "与", "有", "么"].some((item) => compact.includes(item))) return true;
  return false;
}

function getKnowledgeFocusTerms(query) {
  const terms = [...tokenizePlainKnowledge(stripKnowledgeFocusNoise(query)), ...getKnowledgeEntityAliasTerms(query)];
  const seen = new Set();
  const result = [];
  for (const term of terms) {
    const compact = String(term || "").toLowerCase().trim();
    if (isGenericKnowledgeFocusTerm(compact)) continue;
    if (seen.has(compact)) continue;
    seen.add(compact);
    result.push(compact);
  }
  return result.slice(0, 10);
}

function scoreKnowledgeFocus(text, focusTerms) {
  return lineScore(String(text || ""), focusTerms || []);
}

function aliasCompactSearch(value) {
  return addSearchAliases(value).toLowerCase().replace(/\s+/g, "");
}

function plainCompactSearch(value) {
  return normalizeMathCanonical(value).toLowerCase().replace(/\s+/g, "");
}

function plainEqualSearch(left, right) {
  const normalized = plainCompactSearch(left);
  return Boolean(normalized && normalized === plainCompactSearch(right));
}

function plainContainsSearch(haystack, needle) {
  const target = plainCompactSearch(needle);
  return Boolean(target && plainCompactSearch(haystack).includes(target));
}

function compactEqualSearch(left, right) {
  return plainEqualSearch(left, right) || Boolean(aliasCompactSearch(left) && aliasCompactSearch(left) === aliasCompactSearch(right));
}

function exactishContainsSearch(haystack, needle) {
  if (plainContainsSearch(haystack, needle)) return true;
  const target = aliasCompactSearch(needle);
  return Boolean(target && aliasCompactSearch(haystack).includes(target));
}

const QUERY_INTENT_WORDS =
  /(请|帮我|解释|说明|整理|总结|相关|内容|主要|给我|一下|是什么|什么是|定义|基本定义|概念|定理|命题|证明|应用|如何|怎么|why|what|how|definition|theorem|proposition|proof)/gi;

function getQueryFocus(query) {
  const value = normalizeMathCanonical(query)
    .replace(QUERY_INTENT_WORDS, " ")
    .replace(/[\s,，。:：；;?？!！]+/g, " ")
    .trim();
  return value || String(query || "").trim();
}

function getQueryFocusParts(query) {
  const focus = getQueryFocus(query);
  const result = [];
  for (const piece of focus.split(/[\s,，。:：；;?？!！/]+/g)) {
    const cleaned = piece.trim();
    if (cleaned.length >= 2 && !cleaned.match(QUERY_INTENT_WORDS)) result.push(cleaned);
  }
  for (const match of focus.matchAll(/[A-Za-z][A-Za-z0-9\-]{1,}|[\u3400-\u9fff]{2,}/g)) {
    const item = match[0];
    if (!item.match(QUERY_INTENT_WORDS)) result.push(item);
  }
  const seen = new Set();
  return result
    .filter((item) => {
      const key = plainCompactSearch(item);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 12);
}

const TOPIC_CORE_HINTS = [
  ["c星代数", ["C星代数", "表示", "范畴性质", "正锥", "连续函数演算", "von Neumann"]],
  ["多复变函数", ["解析集", "全纯映射", "多重次调和", "拟凸", "全纯凸", "解析分歧覆盖", "Hartogs"]],
  ["拓扑斯", ["拓扑斯", "几何态射", "Grothendieck拓扑", "Grothendieck拓扑上的层范畴", "预层范畴", "子对象分类子", "位象"]],
  ["模型范畴", ["模型范畴", "Quillen伴随", "Quillen等价", "Reedy模型结构", "Bousfield局部化", "单纯集的模型结构"]],
  ["谱序列", ["谱序列", "Grothendieck谱序列", "滤过对象"]],
  ["galois理论", ["Galois对应", "Galois扩张", "Hilbert 90", "Kummer理论", "正规基定理"]],
];

function getTopicCoreHints(query) {
  const focused = aliasCompactSearch(getQueryFocus(query));
  const hints = [];
  for (const [key, values] of TOPIC_CORE_HINTS) {
    const compactKey = aliasCompactSearch(key);
    if (compactKey && focused && (focused.includes(compactKey) || compactKey.includes(focused))) {
      hints.push(...values);
    }
  }
  return hints;
}

function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function highlightTerms(text, terms) {
  let result = text;
  for (const term of [...terms].sort((a, b) => b.length - a.length)) {
    if (!term) continue;
    result = result.replace(new RegExp(escapeRegExp(term), "gi"), (match) => `[${match}]`);
  }
  return result;
}

function cleanSnippet(text, limit = 320) {
  const compact = String(text || "").replace(/\s+/g, " ").trim();
  return compact.length > limit ? `${compact.slice(0, limit - 3).trim()}...` : compact;
}

function limitTextBlock(text, limit = 12000) {
  const value = String(text || "");
  return value.length > limit ? `${value.slice(0, Math.max(0, limit - 80)).trim()}\n\n[section shortened by plugin]` : value;
}

function normalizeMathDelimiters(markdown) {
  return String(markdown || "")
    .replace(/(^|[^\\$])\$(?!\$)[ \t]+([^$\n]*?)\$(?!\$)/g, (_match, prefix, content) => {
      return `${prefix}$${content}$`;
    })
    .replace(/(^|[^\\$])\$(?!\$)([^$\n]*?)[ \t]+\$(?!\$)/g, (_match, prefix, content) => {
      return `${prefix}$${content}$`;
    });
}

function unwrapMarkdownFence(markdown) {
  const text = String(markdown || "").trim();
  const match = text.match(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```$/i);
  return match ? match[1].trim() : text;
}

function parseJsonObject(text) {
  const raw = String(text || "").trim();
  const fenced = raw.match(/```(?:json)?\s*\n([\s\S]*?)\n```/i);
  const candidate = fenced ? fenced[1].trim() : raw;
  try {
    return JSON.parse(candidate);
  } catch (error) {
    const start = candidate.indexOf("{");
    const end = candidate.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(candidate.slice(start, end + 1));
    }
    throw error;
  }
}

function getNearestHeading(lines, lineIndex, fallback = "(no heading)") {
  for (let index = lineIndex; index >= 0; index -= 1) {
    const match = lines[index].match(/^(#{1,6})\s+(.+?)\s*$/);
    if (match) return match[2].trim();
  }
  return fallback;
}

function getHeadingPath(lines, lineIndex) {
  const stack = [];
  for (let index = 0; index <= lineIndex && index < lines.length; index += 1) {
    const match = lines[index].match(/^(#{1,6})\s+(.+?)\s*$/);
    if (!match) continue;
    const level = match[1].length;
    stack[level - 1] = match[2].trim();
    stack.length = level;
  }
  return stack.filter(Boolean).join(" > ") || "(no heading)";
}

function obsidianNotePath(path) {
  return String(path || "").replace(/\\/g, "/").replace(/\.md$/i, "");
}

function makeObsidianSourceLink(path, label = "", blockId = "", heading = "") {
  const cleanPath = obsidianNotePath(path);
  const cleanLabel = cleanSnippet(label || cleanPath, 80).replace(/\|/g, " ");
  if (blockId) return `[[${cleanPath}#^${blockId}|${cleanLabel}]]`;
  if (heading && heading !== "(no heading)") return `[[${cleanPath}#${heading}|${cleanLabel}]]`;
  return `[[${cleanPath}|${cleanLabel}]]`;
}

function lineScore(line, terms) {
  const lower = addSearchAliases(line).toLowerCase();
  let score = 0;
  for (const term of terms) {
    if (lower.includes(term)) {
      score += 10 + Math.min(8, lower.split(term).length - 1);
    }
  }
  return score;
}

function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0;
  let aNorm = 0;
  let bNorm = 0;
  for (let index = 0; index < a.length; index += 1) {
    dot += a[index] * b[index];
    aNorm += a[index] * a[index];
    bNorm += b[index] * b[index];
  }
  if (aNorm === 0 || bNorm === 0) return 0;
  return dot / (Math.sqrt(aNorm) * Math.sqrt(bNorm));
}

function safeJoinUrl(baseUrl, path) {
  return `${String(baseUrl || "").replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}

async function postJson(url, body, headers = {}) {
  const response = await requestUrl({
    url,
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
    body: JSON.stringify(body),
  });
  return response.json;
}

function parseDataUrl(dataUrl) {
  const match = String(dataUrl || "").match(/^data:([^;]+);base64,(.+)$/);
  if (!match) throw new Error("Invalid image data.");
  return {
    mimeType: match[1],
    base64: match[2],
  };
}

class EmbeddingProvider {
  constructor(plugin) {
    this.plugin = plugin;
  }

  get settings() {
    return this.plugin.settings;
  }

  getProviderKey() {
    return this.settings.embeddingProvider;
  }

  getModelName() {
    const provider = this.getProviderKey();
    if (provider === "ollama") return this.settings.ollamaModel;
    if (provider === "openai") return this.settings.openaiModel;
    if (provider === "gemini") return this.settings.geminiModel;
    if (provider === "qwen") return this.settings.qwenModel;
    return this.settings.customModel;
  }

  getIndexSignature() {
    const signature = {
      provider: this.getProviderKey(),
      model: this.getModelName(),
    };
    if (this.getProviderKey() === "qwen") {
      signature.dimensions = Number.parseInt(this.settings.qwenDimensions, 10) || 0;
    }
    return signature;
  }

  async embed(text) {
    const provider = this.getProviderKey();
    if (provider === "ollama") return this.embedWithOllama(text);
    if (provider === "openai") {
      return this.embedWithOpenAICompatible(
        this.settings.openaiBaseUrl,
        this.settings.openaiApiKey,
        this.settings.openaiModel,
        text
      );
    }
    if (provider === "gemini") return this.embedWithGemini(text);
    if (provider === "qwen") {
      return this.embedWithQwen(text);
    }
    return this.embedWithOpenAICompatible(
      this.settings.customBaseUrl,
      this.settings.customApiKey,
      this.settings.customModel,
      text
    );
  }

  async embedWithOllama(text) {
    const baseUrl = this.settings.ollamaBaseUrl;
    const model = this.settings.ollamaModel;
    try {
      const modern = await postJson(safeJoinUrl(baseUrl, "/api/embed"), {
        model,
        input: text,
      });
      if (modern && Array.isArray(modern.embeddings) && modern.embeddings[0]) {
        return modern.embeddings[0];
      }
    } catch (error) {
      console.warn("Ollama /api/embed failed, trying /api/embeddings", error);
    }

    const legacy = await postJson(safeJoinUrl(baseUrl, "/api/embeddings"), {
      model,
      prompt: text,
    });
    if (!legacy || !Array.isArray(legacy.embedding)) {
      throw new Error("Ollama did not return an embedding.");
    }
    return legacy.embedding;
  }

  async embedWithOpenAICompatible(baseUrl, apiKey, model, text) {
    if (!baseUrl || !model) {
      throw new Error("Base URL and model are required for this provider.");
    }
    const headers = apiKey ? { Authorization: `Bearer ${apiKey}` } : {};
    const json = await postJson(
      safeJoinUrl(baseUrl, "/embeddings"),
      {
        model,
        input: text,
      },
      headers
    );
    const embedding = json && json.data && json.data[0] && json.data[0].embedding;
    if (!Array.isArray(embedding)) {
      throw new Error("The provider did not return an OpenAI-compatible embedding.");
    }
    return embedding;
  }

  async embedWithQwen(text) {
    if (!this.settings.qwenBaseUrl || !this.settings.qwenModel) {
      throw new Error("Qwen / DashScope base URL and model are required.");
    }
    if (!this.settings.qwenApiKey) {
      throw new Error("Qwen / DashScope API key is required.");
    }

    const body = {
      model: this.settings.qwenModel,
      input: text,
      encoding_format: "float",
    };
    const dimensions = Number.parseInt(this.settings.qwenDimensions, 10);
    if (Number.isFinite(dimensions) && dimensions > 0) {
      body.dimensions = dimensions;
    }

    const json = await postJson(
      safeJoinUrl(this.settings.qwenBaseUrl, "/embeddings"),
      body,
      { Authorization: `Bearer ${this.settings.qwenApiKey}` }
    );
    const embedding = json && json.data && json.data[0] && json.data[0].embedding;
    if (!Array.isArray(embedding)) {
      throw new Error("Qwen / DashScope did not return an embedding.");
    }
    return embedding;
  }

  async embedWithGemini(text) {
    const key = this.settings.geminiApiKey;
    const model = this.settings.geminiModel;
    if (!key || !model) {
      throw new Error("Gemini API key and model are required.");
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      model
    )}:embedContent?key=${encodeURIComponent(key)}`;
    const json = await postJson(url, {
      content: {
        parts: [{ text }],
      },
    });
    const embedding = json && json.embedding && json.embedding.values;
    if (!Array.isArray(embedding)) {
      throw new Error("Gemini did not return an embedding.");
    }
    return embedding;
  }
}

class ChatProvider {
  constructor(plugin) {
    this.plugin = plugin;
  }

  get settings() {
    return this.plugin.settings;
  }

  getPreferenceBlock(context = "") {
    const preferences = String(this.settings.userWritingPreferences || "").trim();
    const preferenceBlock = preferences ? `\n\nUser writing preferences:\n${preferences}` : "";
    const feedbackBlock =
      this.plugin && this.plugin.buildNegativeFeedbackContext
        ? this.plugin.buildNegativeFeedbackContext(context)
        : "";
    return `${preferenceBlock}${feedbackBlock}`;
  }

  async answer(question, results, conversationContext = [], knowledgeContext = "") {
    const mode = this.settings.answerSourceMode || "notes_only";
    const context =
      mode === "model_only"
        ? "(not used)"
        : results
            .slice(0, this.settings.answerContextLimit)
            .map((result, index) => {
              const maxChars = Number.parseInt(this.settings.maxAnswerContextChars, 10) || 5000;
              const contextText = result.context || result.snippet || "";
              const trimmedContext =
                contextText.length > maxChars
                  ? `${contextText.slice(0, maxChars).trim()}\n[context shortened by plugin]`
                  : contextText;
              const sourceLink =
                result.sourceLink ||
                makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
              return `[${index + 1}] ${result.path}
Source link: ${sourceLink}
Source precision: ${result.sourcePrecision || (result.heading && result.heading !== "(no heading)" ? "heading" : "note")}
Heading: ${result.heading}
Content:
${trimmedContext}`;
            })
            .join("\n\n");

    const systemPrompt =
      mode === "model_only"
        ? "You are a careful assistant inside Obsidian. Answer from your general knowledge. Do not claim that unsupported content came from the user's notes. Keep the answer concise."
        : mode === "notes_model"
        ? "You are a careful note assistant inside Obsidian. Use the provided note excerpts first, cite them with bracket numbers like [1], and clearly mark any model-supplied additions as supplemental knowledge. When writing Obsidian links, copy the provided Source link exactly; never invent a heading or block anchor. Keep the answer concise."
        : "You are a careful note assistant inside Obsidian. Answer only from the provided note excerpts. If the excerpts are not enough, say that the notes do not provide enough evidence. Always cite sources using bracket numbers like [1]. When writing Obsidian links, copy the provided Source link exactly; never invent a heading or block anchor. Keep the answer concise.";
    const conversationText = conversationContext.length
      ? conversationContext
          .map((turn, index) => {
            const sources = (turn.sources || [])
              .map((source) => `${source.path}${source.heading ? ` (${source.heading})` : ""}`)
              .join("; ");
            return `Turn ${index + 1}\nUser: ${turn.question}\nAssistant: ${
              turn.answer || "(no answer recorded)"
            }\nSources: ${sources || "(none)"}`;
          })
          .join("\n\n")
      : "(none)";
    const knowledgeBlock = knowledgeContext
      ? `\n\nKnowledge index hints:\n${knowledgeContext}\n\nImportant: knowledge index hints are for navigation and organization. Do not treat them as sufficient evidence for substantive claims unless the same claim appears in the retrieved note excerpts.`
      : "";
    const userPrompt = `Conversation so far:\n${conversationText}\n\nCurrent question:\n${question}${knowledgeBlock}\n\nRetrieved note excerpts:\n${context}`;

    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(question)}`);
  }

  async draft(topic, results, conversationContext = []) {
    const sourceMode = this.settings.draftSourceMode || "notes_model";
    const context =
      sourceMode === "model_only"
        ? "(not used)"
        : results
            .slice(0, this.settings.answerContextLimit)
            .map((result, index) => {
              const maxChars = Number.parseInt(this.settings.maxAnswerContextChars, 10) || 5000;
              const contextText = result.context || result.snippet || "";
              const trimmedContext =
                contextText.length > maxChars
                  ? `${contextText.slice(0, maxChars).trim()}\n[context shortened by plugin]`
                  : contextText;
              const sourceLink =
                result.sourceLink ||
                makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
              return `[${index + 1}] ${result.path}
Source link: ${sourceLink}
Source precision: ${result.sourcePrecision || (result.heading && result.heading !== "(no heading)" ? "heading" : "note")}
Heading: ${result.heading}
Content:
${trimmedContext}`;
            })
            .join("\n\n");
    const conversationText = conversationContext.length
      ? conversationContext
          .map((turn, index) => `Turn ${index + 1}\nUser: ${turn.question}\nAssistant: ${turn.answer || ""}`)
          .join("\n\n")
      : "(none)";
    const modeInstruction =
      sourceMode === "notes_only"
        ? "Use only the provided note excerpts. If they are insufficient, create a clearly incomplete draft and mark gaps as TODO."
        : sourceMode === "model_only"
        ? "Use your own general knowledge. Do not claim that unsupported content came from the user's notes."
        : "Use the provided note excerpts first, and then supplement with your own general knowledge where helpful. Clearly separate note-based content from model-supplied additions.";
    const systemPrompt =
      "You are a careful Obsidian note drafting assistant. Produce a Markdown note draft only. Use headings, concise explanations, formulas when useful, and an optional Sources section. Do not include chatty prefaces.";
    const userPrompt = `${modeInstruction}\n\nTopic or request:\n${topic}\n\nConversation so far:\n${conversationText}\n\nRelevant note excerpts:\n${context}\n\nReturn only the Markdown content for the draft note.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(topic)}`);
  }

  async topicSynthesis(topic, results, conversationContext = [], knowledgeContext = "", calloutEvidence = "") {
    const context = (results || [])
      .slice(0, Math.max(12, this.settings.answerContextLimit || 8))
      .map((result, index) => {
        const maxChars = Number.parseInt(this.settings.maxAnswerContextChars, 10) || 5000;
        const contextText = result.context || result.snippet || "";
        const trimmedContext =
          contextText.length > maxChars
            ? `${contextText.slice(0, maxChars).trim()}\n[context shortened by plugin]`
            : contextText;
        const sourceLink =
          result.sourceLink ||
          makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
        return `[${index + 1}] ${sourceLink}
Path: ${result.path}
Source link: ${sourceLink}
Source precision: ${result.sourcePrecision || (result.heading && result.heading !== "(no heading)" ? "heading" : "note")}
Heading: ${result.heading || "(none)"}
Content:
${trimmedContext}`;
      })
      .join("\n\n");
    const conversationText = conversationContext.length
      ? conversationContext
          .map((turn, index) => `Turn ${index + 1}\nUser: ${turn.question}\nAssistant: ${turn.answer || ""}`)
          .join("\n\n")
      : "(none)";
    const systemPrompt =
      "You are a careful Obsidian research assistant. Base note-supported claims on the provided note excerpts and callout evidence. You may add your own mathematical synthesis only when it is clearly labeled as model-supplied, and you must never present unsupported content as if it came from the user's notes.";
    const userPrompt = `Topic:
${topic || "Untitled"}

Conversation context:
${conversationText}

Retrieved note excerpts:
${context || "(none)"}

Callout-level note evidence:
${calloutEvidence || "(none)"}

Knowledge index hints:
${knowledgeContext || "(none)"}

Write an AI-generated Markdown file in Chinese unless the source notes are clearly in another language.

Requirements:
- Start with "# ${topic || "Topic"}".
- Use the user's note content and callout evidence as the main material.
- You may use model reasoning to connect ideas, fill explanatory gaps, and make the exposition coherent, but clearly mark genuinely model-supplied additions as "\u6a21\u578b\u8865\u5145" when they are not directly supported by the notes.
- Organize into sections such as 核心定义, 动机, 主要结论, 例子, 与其他主题的关系, 待检查问题 when useful.
- If Knowledge index hints include a "Topic coverage map", treat those notes as required coverage candidates for a broad topic. Include high-coverage linked, backlink, same-folder, or title-related notes when their callout evidence is relevant.
- Do not omit a major linked subtopic merely because the user did not type its exact name. For example, if a broad topic has a representation/category/example page in the coverage map, create a subsection for it when evidence is present.
- Preserve important original phrasing or formulas from the notes when helpful, but do not dump raw excerpts without organization.
- Every substantive paragraph or bullet should cite at least one source. Prefer copying the provided Source link exactly, especially block links like [[Note#^id|label]]. Never invent a heading or block anchor.
- Include a final "## 来源" section listing all source links with short descriptions.
- If a specific formal statement is present in callout-level note evidence, treat it as note evidence even if it is not repeated in the retrieved excerpts.
- Use knowledge index hints for navigation and structure; use retrieved excerpts and callout-level note evidence for note-supported claims.
- Return only Markdown, no chatty preface.

Additional anti-hallucination rules:
- Treat retrieved excerpts plus callout-level note evidence as the note evidence set.
- Do not present model reasoning as if it came from the user's notes.
- If using background mathematical knowledge to connect ideas, label it as model-supplied synthesis.
- Prefer a complete, well-organized explanation, but keep source boundaries clear.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(topic)}`);
  }

  async rewriteForDraft(answer, results) {
    const sources = (results || [])
      .slice(0, this.settings.answerContextLimit)
      .map((result, index) => {
        const sourceLink =
          result.sourceLink ||
          makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
        return `[${index + 1}] ${sourceLink}\nPath: ${result.path}\nHeading: ${result.heading}`;
      })
      .join("\n\n");
    const systemPrompt =
      "You are a careful Obsidian note editor. Rewrite the supplied assistant answer as a reusable Markdown note section. Do not write a full article unless the source answer is already article-length.";
    const userPrompt = `Rewrite this answer into an Obsidian Markdown note fragment.\n\nRequirements:\n- No chatty preface.\n- Use clear headings when useful.\n- Preserve mathematical notation.\n- Keep useful source citations like [1].\n- If content is model-supplied rather than note-supported, mark it as supplemental.\n- Return only Markdown.\n\nAssistant answer:\n${answer}\n\nSources:\n${sources || "(none)"}`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(answer)}`);
  }

  async editDraftSelection(selection, instruction, draftContext) {
    const systemPrompt =
      "You are a careful Obsidian Markdown editor. Rewrite only the selected draft text according to the user's instruction. Return only the replacement Markdown, with no explanation or preface.";
    const userPrompt = `User instruction:\n${
      instruction || "Improve this selected draft text while preserving its meaning."
    }\n\nCurrent draft context:\n${draftContext || "(no broader draft context provided)"}\n\nSelected text to replace:\n${selection}\n\nRequirements:\n- Return only the replacement Markdown for the selected text.\n- Preserve Obsidian-friendly Markdown and LaTeX math.\n- Do not add source claims unless present in the selected text or draft context.\n- Keep the same language as the selected text unless the instruction asks otherwise.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(instruction)}`);
  }

  async editDraftDocument(currentMarkdown, instruction) {
    const systemPrompt =
      "You are a careful Obsidian Markdown editor. Rewrite the current AI draft according to the user's instruction. Return the complete updated Markdown document only, with no explanation or preface.";
    const userPrompt = `User instruction:\n${instruction}\n\nCurrent AI draft Markdown:\n${currentMarkdown}\n\nRequirements:\n- Return the entire updated Markdown document, not a diff.\n- Preserve useful existing content unless the instruction asks to remove or reorganize it.\n- Preserve Obsidian-friendly Markdown links, headings, lists, and LaTeX math.\n- Do not add unsupported source claims.\n- Keep the same main language as the draft unless the instruction asks otherwise.\n- Return only Markdown.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(instruction)}`);
  }

  async draftInsertion(instruction, target, draftContext) {
    const systemPrompt =
      "You are a careful Obsidian Markdown editor. Write only the Markdown fragment that should be inserted into the current AI draft. Do not say you cannot insert; the plugin will insert your returned fragment.";
    const userPrompt = `User insertion instruction:\n${instruction}\n\nInsertion target:\n${target || "(not specified)"}\n\nCurrent draft context:\n${draftContext || "(no broader draft context provided)"}\n\nRequirements:\n- Return only the Markdown fragment to insert.\n- Preserve Obsidian-friendly Markdown and LaTeX math.\n- If the user asks for a theorem, definition, example, proof, or explanation, write that content directly.\n- Do not include a chatty preface.\n- Keep the same main language as the draft unless the instruction asks otherwise.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(instruction)}`);
  }

  async routeUserIntent(userText, state) {
    const systemPrompt =
      "You are an intent router for an Obsidian assistant plugin. Choose the plugin action that best matches the user's request. Return only a compact JSON object.";
    const userPrompt = `Available actions:
- search_answer: answer/search normally.
- agent_task: use several plugin tools in sequence for a multi-step draft task.
- image_to_markdown: convert the attached image to Markdown.
- create_blank_draft: create an empty AI draft.
- generate_draft: generate a draft preview.
- edit_current_draft: directly rewrite the current AI draft.
- edit_selection: rewrite selected text in the current AI draft.
- insert_into_draft: insert content into the current AI draft at a target marker.
- formal_note_proposal: read formal notes and produce a safe modification proposal without writing formal notes.

State:
${JSON.stringify(state)}

User request:
${userText || ""}

Return JSON only with this shape:
{
  "action": "search_answer",
  "target": "",
  "position": "after",
  "useLastAnswer": false,
  "artifactId": 0,
  "memoryId": 0,
  "sourceQuery": "",
  "directText": "",
  "topic": "",
  "steps": [],
  "reason": ""
}

Rules:
- Understand Chinese natural instructions. "整理/梳理/总结某主题并生成文件/笔记/资料/页面" usually means generate_draft; the view may convert it to a topic synthesis file.
- "新建/创建/打开/开一页/生成一个空白草稿/空白文档/不要生成内容" means create_blank_draft, not generate_draft.
- "改写/优化/扩写/补全/润色当前草稿/这篇草稿/这篇/本文/整篇" means edit_current_draft when a current draft exists.
- "改写选中内容/这段/所选段落" means edit_selection when selected text exists.
- "插入/加入/追加/放到/放进/写进/塞到 #tag 后面/下面/前面/上面" means insert_into_draft. Extract #tag/tag/[[target]]/<!-- target --> into target.
- "把刚才/刚生成/上面/之前/上一轮的回答插入/改写后插入" usually requires agent_task with use_artifact or use_memory before insert_into_draft. If it also asks to 改写/整理/摘要/转成某格式, include generate_markdown before insert_into_draft.
- For pure knowledge questions such as "X 是什么", "解释 X", "X 有什么应用", use search_answer.
- "讲讲/说说/回忆一下/我忘了/看看/哪里说了/怎么定义/有什么区别" are usually search_answer unless the user explicitly asks to create or edit a draft.
- If an image is attached, prefer image_to_markdown unless the user clearly asks for another action.
- If the request requires multiple operations, such as finding earlier content, rewriting it, and inserting it into a draft, use agent_task.
- For agent_task, fill "steps" directly using the same step schema as the planner when possible, so the plugin can skip a second planning call.
- If the user asks to insert/add/put/place content at a marker, use insert_into_draft.
- For insert_into_draft, extract target markers such as tag1, #tag1, [[tag1]], <!-- tag1 -->.
- If the user says previous/above/that proof/刚才/上面/上一条/这个证明/这段, set useLastAnswer true.
- If the user refers to an earlier assistant output that is not the latest one, choose the best matching item from state.assistantArtifacts and set artifactId to that id.
- If the content is older and only appears in state.longTermMemory, set memoryId to that id, or put a short search phrase in sourceQuery.
- If you cannot choose a specific item but know what earlier content the user wants, put a short search phrase in sourceQuery.
- If the user includes quoted text or a markdown code block to insert, put it in directText.
- If the user asks to change the whole/current draft, use edit_current_draft.
- If the user refers to selected text/this paragraph/选中/这段 and selected text exists, use edit_selection.
- If the user asks to modify formal notes directly, use formal_note_proposal, not a writing tool.
- If unsure, use search_answer.`;
    const response = await this.complete(systemPrompt, userPrompt);
    const route = parseJsonObject(response);
    if (!route || typeof route !== "object") throw new Error("Router returned invalid JSON.");
    return route;
  }

  async routeUserIntent(userText, state) {
    const toolCatalog = JSON.stringify(this.plugin.getAgentToolCatalog(), null, 2);
    const systemPrompt =
      "You are the intent router for a safe Obsidian assistant. Do not answer the user. Choose the best local tool action and return one compact JSON object only.";
    const userPrompt = `Tool catalog:
${toolCatalog}

Current state:
${JSON.stringify(state)}

User request:
${userText || ""}

Return JSON only with this shape:
{
  "action": "search_answer",
  "confidence": 0.0,
  "target": "",
  "position": "after",
  "useLastAnswer": false,
  "artifactId": 0,
  "memoryId": 0,
  "sourceQuery": "",
  "directText": "",
  "topic": "",
  "steps": [],
  "reason": ""
}

Rules:
- Prefer the user's real goal over individual keywords. The user mainly writes Chinese and may phrase requests informally.
- Pure questions such as "X 是什么", "解释 X", "X 有什么应用", and "这和上一问有什么关系" use search_answer.
- "整理/梳理/总结/综述/汇总某主题，并生成文件/资料/笔记/页面" uses generate_draft. The view may convert it into a topic synthesis file.
- "新建/创建/开一页/生成一个空白草稿/空白文档/不要生成内容" uses create_blank_draft.
- "改写/优化/润色/扩写/补全 当前草稿/这篇草稿/全文/整篇" uses edit_current_draft when a current draft exists.
- "改写选中内容/这段/所选段落/selected text" uses edit_selection when selected text exists.
- "插入/加入/追加/放到/放进/写进/塞到 #tag 后面/下面/前面/上面" uses insert_into_draft. Extract #tag, tag1, [[target]], or <!-- target --> into target.
- If the user refers to earlier output, such as "刚才/刚生成/上面/上一轮/之前/那个证明/那段回答", set useLastAnswer true or choose artifactId, memoryId, or sourceQuery.
- If the request combines earlier output, transformation, and insertion, use agent_task with steps such as use_artifact, generate_markdown, insert_into_draft.
- If an image is attached and the request asks about a screenshot, PDF excerpt, proof, formula, table, or OCR, use image_to_markdown.
- "打开/查看/管理 记忆/知识索引/迁移工具/迁移审阅/ChatGPT交接" opens the matching panel action.
- "检查索引变化" uses check_index_changes. "更新变更索引" uses update_changed_index. "重建索引" uses build_index.
- Never route direct edits to formal notes. If the user asks to modify formal notes directly, choose formal_note_proposal unless they explicitly ask for migration tooling.
- If uncertain, use search_answer with low confidence.`;
    const response = await this.complete(systemPrompt, userPrompt);
    const route = parseJsonObject(response);
    if (!route || typeof route !== "object") throw new Error("Router returned invalid JSON.");
    return route;
  }

  async planAgentTask(userText, state, maxSteps) {
    const systemPrompt =
      "Plan safe Obsidian draft tool steps. Return compact JSON only.";
    const userPrompt = `Goal:
${userText || ""}

State:
${JSON.stringify(state)}

Available safe tools:
- use_artifact: choose a previous assistant output. Fields: artifactId, sourceQuery.
- use_memory: choose an older saved assistant output. Fields: memoryId, sourceQuery.
- generate_markdown: create a Markdown fragment from the instruction and any selected artifact. Fields: instruction.
- insert_into_draft: insert a Markdown fragment into current AI Draft. Fields: target, position, directText, useWorkingText, artifactId, memoryId, sourceQuery.
- edit_current_draft: rewrite the current AI Draft. Fields: instruction.
- edit_selection: rewrite selected text in current AI Draft. Fields: instruction.
- create_blank_draft: create an empty AI Draft. Fields: topic.
- image_to_markdown: convert attached image to Markdown. Fields: instruction.
- search_answer: search/answer normally and store the answer as working text. Fields: query.

Rules:
- Maximum ${maxSteps} steps.
- Only operate on the current AI Draft; never modify formal notes.
- Prefer use_artifact before insert_into_draft when the user references earlier output.
- Prefer use_memory before insert_into_draft when the user references older output from state.longTermMemory.
- Use generate_markdown before insert_into_draft if the user asks to transform, summarize, or supplement earlier output.
- If the user gives a target like #tag2, tag2, [[target]], or <!-- target -->, put the target text in target and position as "after" unless they say before/前面/上面.
- Chinese phrases like 刚生成/上一轮/前述/那段 usually refer to earlier assistant output.
- If unsure, return one search_answer step.

Return JSON only:
{
  "steps": [
    {
      "action": "search_answer",
      "instruction": "",
      "query": "",
      "target": "",
      "position": "after",
      "artifactId": 0,
      "memoryId": 0,
      "sourceQuery": "",
      "directText": "",
      "useWorkingText": false,
      "topic": ""
    }
  ]
}`;
    const response = await this.complete(systemPrompt, userPrompt);
    return parseJsonObject(response);
  }

  async planAgentTask(userText, state, maxSteps) {
    const systemPrompt =
      "You plan safe Obsidian draft tool steps. Return compact JSON only. Never modify formal notes.";
    const userPrompt = `Goal:
${userText || ""}

Current state:
${JSON.stringify(state)}

Available safe tools:
- use_artifact: choose a previous assistant output. Fields: artifactId, sourceQuery.
- use_memory: choose an older saved assistant output. Fields: memoryId, sourceQuery.
- generate_markdown: create a Markdown fragment from the instruction and working text. Fields: instruction.
- insert_into_draft: insert a Markdown fragment into the current AI draft. Fields: target, position, directText, useWorkingText, artifactId, memoryId, sourceQuery.
- edit_current_draft: rewrite the current AI draft. Fields: instruction.
- edit_selection: rewrite selected text in the current AI draft. Fields: instruction.
- create_blank_draft: create an empty AI draft. Fields: topic.
- image_to_markdown: convert attached image to Markdown. Fields: instruction.
- search_answer: search/answer normally and store the answer as working text. Fields: query.

Rules:
- Maximum ${maxSteps} steps.
- Only operate on the current AI Draft. Never edit formal notes.
- If the user says "刚才/刚生成/上面/上一轮/之前/那个证明/那段回答", start with use_artifact unless a better artifactId is obvious.
- If the user asks for older saved content, start with use_memory or put a short phrase in sourceQuery.
- If the user asks to rewrite, summarize, polish, convert format, or make something more note-like before inserting, add generate_markdown before insert_into_draft.
- If the user gives a target like #tag2, tag2, [[target]], or <!-- target -->, put it in target and use position "after" unless they say before/前面/上面.
- For "把刚才那段证明改成命题-证明格式，然后放到 #tag2 后面", return use_artifact, generate_markdown, insert_into_draft.
- If unsure, return one search_answer step.

Return JSON only:
{
  "steps": [
    {
      "action": "search_answer",
      "instruction": "",
      "query": "",
      "target": "",
      "position": "after",
      "artifactId": 0,
      "memoryId": 0,
      "sourceQuery": "",
      "directText": "",
      "useWorkingText": false,
      "topic": ""
    }
  ]
}`;
    const response = await this.complete(systemPrompt, userPrompt);
    const plan = parseJsonObject(response);
    if (!plan || typeof plan !== "object") throw new Error("Planner returned invalid JSON.");
    return plan;
  }

  async generateAgentMarkdown(instruction, sourceText, draftContext) {
    const systemPrompt =
      "You are a careful Obsidian Markdown writer. Produce a reusable Markdown fragment for an AI draft. Return only Markdown.";
    const userPrompt = `Instruction:
${instruction || "Create a useful Markdown fragment."}

Source material:
${sourceText || "(none)"}

Current draft context:
${draftContext || "(none)"}

Requirements:
- Return only Markdown.
- Preserve LaTeX math and Obsidian-friendly formatting.
- If source material is provided, use it faithfully and improve structure as requested.
- Do not include a chatty preface.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(instruction)}`);
  }

  async reviewAgentResult(goal, executionSummary, draftContext) {
    const systemPrompt =
      "You are a concise Chinese reviewer for an Obsidian draft assistant. Explain the result in plain, readable Chinese. Avoid emoji and avoid technical jargon.";
    const userPrompt = `Original goal:
${goal || ""}

Executed steps:
${executionSummary || "(none)"}

Current draft context:
${draftContext || "(none)"}

Please return exactly this format in Chinese:
结果：一句话说明是否完成。
位置：一句话说明内容大概放在哪里。
注意：如果发现重复、位置可疑、公式或结构问题，用一句话指出；如果没有明显问题，写“没有发现明显问题”。

Keep it short. Do not use emoji.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(goal)}`);
  }

  async reviewAgentResult(goal, executionSummary, draftContext) {
    const systemPrompt =
      "You are a concise Chinese reviewer for an Obsidian draft assistant. Explain the result in plain Chinese. Avoid emoji and technical jargon.";
    const userPrompt = `Original goal:
${goal || ""}

Executed steps:
${executionSummary || "(none)"}

Current draft context:
${draftContext || "(none)"}

Please return exactly this short Chinese format:
结果：一句话说明是否完成。
位置：一句话说明内容大概放在哪里。
注意：如果发现重复、位置可疑、公式或结构问题，用一句话指出；如果没有明显问题，写“没有发现明显问题”。

Do not use emoji.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(goal)}`);
  }

  async analyzeNoteMigration(request, oldNote, newNote, candidates) {
    const systemPrompt =
      "You are a careful Obsidian note maintenance assistant for mathematical notes. Analyze migration risk and propose faithful edits, but do not claim that files were modified.";
    const candidateText = candidates
      .map((candidate, index) => {
        const snippets = candidate.matches
          .slice(0, 8)
          .map((match) => `line ${match.line + 1} [${match.type}]: ${match.text}`)
          .join("\n");
        const preview = candidate.preview
          ? `\nDeterministic link preview:\n${candidate.preview}`
          : "";
        return `Candidate ${index + 1}: ${candidate.path}\nInitial risk: ${candidate.risk}\nReasons: ${
          candidate.reasons.join("; ") || "(none)"
        }\nSnippets:\n${snippets || "(none)"}${preview}`;
      })
      .join("\n\n");
    const userPrompt = `User request:
${request || ""}

Old note:
Path: ${oldNote.path}
Content excerpt:
${oldNote.content}

New note:
Path: ${newNote.path}
Headings:
${newNote.headings.join("\n") || "(none)"}
Content excerpt:
${newNote.content}

Candidate related notes:
${candidateText || "(none)"}

Return a Markdown migration report in Chinese with exactly these sections:
## 迁移理解
- Explain what appears to migrate from the old note to the new note.
- Mention uncertainty explicitly.

## 风险分级
- Group candidates into low, medium, and high risk.
- Explain why each group is safe or risky.

## 候选修改
- For each candidate, describe faithful local edits.
- Prefer link updates only when safe.
- For old-note heading links, only recommend changing the heading if the new note has a corresponding heading.
- For notation changes, recommend local paragraph rewrites only when context supports it.

## 建议执行顺序
- Give a cautious order: low-risk first, then review medium-risk, skip high-risk unless confirmed.

Important:
- Do not say you modified files.
- Do not invent new theorems or definitions.
- Keep math notation Obsidian-renderable.`;
    return this.complete(systemPrompt, `${userPrompt}${this.getPreferenceBlock(request)}`);
  }

  async imageToMarkdown(instruction, image) {
    const prompt = String(instruction || "").trim();
    const systemPrompt =
      "You are a careful Obsidian Markdown assistant with vision. Convert screenshots into useful mathematical notes. Follow the requested output language exactly, while keeping standard mathematical English terms when appropriate. Preserve notation in Obsidian-renderable LaTeX, keep proof structure clear, transcribe code into fenced code blocks with language tags when possible, and return only Markdown.";
    const userPrompt = `Task:\n${
      prompt ||
      "Transcribe and explain the image as Obsidian Markdown. If it contains a proof, rewrite it as a clear Markdown proof."
    }\n\nRequirements:\n- Return only Markdown.\n- Preserve formulas using LaTeX syntax.\n- For inline math, remove spaces just inside delimiters: use $x$ rather than $ x $.\n- For display math, use $$...$$ blocks and keep important alignment readable.\n- If the image contains code, use fenced code blocks with the most likely language name, preserve indentation, and do not invent hidden lines.\n- If the image contains an error message, separate the transcription from the explanation.\n- Use headings, definitions, theorem/proof blocks, tables, or bullet points when helpful.\n- If any part is unreadable, mark it as TODO instead of guessing.`;
    return this.completeWithImage(systemPrompt, `${userPrompt}${this.getPreferenceBlock(prompt)}`, image);
  }

  async complete(systemPrompt, userPrompt) {
    const provider = this.settings.chatProvider;
    if (provider === "ollama") return this.answerWithOllama(systemPrompt, userPrompt);
    if (provider === "openai") {
      return this.answerWithOpenAICompatible(
        this.settings.openaiBaseUrl,
        this.settings.openaiApiKey,
        this.settings.openaiChatModel,
        systemPrompt,
        userPrompt
      );
    }
    if (provider === "gemini") return this.answerWithGemini(systemPrompt, userPrompt);
    if (provider === "qwen") {
      return this.answerWithOpenAICompatible(
        this.settings.qwenBaseUrl,
        this.settings.qwenApiKey,
        this.settings.qwenChatModel,
        systemPrompt,
        userPrompt
      );
    }
    if (provider === "deepseek") {
      return this.answerWithOpenAICompatible(
        this.settings.deepseekBaseUrl,
        this.settings.deepseekApiKey,
        this.settings.deepseekChatModel,
        systemPrompt,
        userPrompt
      );
    }
    return this.answerWithOpenAICompatible(
      this.settings.customBaseUrl,
      this.settings.customApiKey,
      this.settings.customChatModel || this.settings.customModel,
      systemPrompt,
      userPrompt
    );
  }

  getVisionProviderKey() {
    const provider = this.settings.visionProvider || "chat";
    return provider === "chat" ? this.settings.chatProvider : provider;
  }

  getVisionModel(provider) {
    if (provider === "ollama") return this.settings.ollamaVisionModel || this.settings.ollamaChatModel;
    if (provider === "openai") return this.settings.openaiVisionModel || this.settings.openaiChatModel;
    if (provider === "gemini") return this.settings.geminiVisionModel || this.settings.geminiChatModel;
    if (provider === "qwen") return this.settings.qwenVisionModel || this.settings.qwenChatModel;
    return this.settings.customVisionModel || this.settings.customChatModel || this.settings.customModel;
  }

  async completeWithImage(systemPrompt, userPrompt, image) {
    const provider = this.getVisionProviderKey();
    const model = this.getVisionModel(provider);
    if (provider === "ollama") return this.answerWithOllamaImage(systemPrompt, userPrompt, image, model);
    if (provider === "gemini") return this.answerWithGeminiImage(systemPrompt, userPrompt, image, model);
    if (provider === "openai") {
      return this.answerWithOpenAICompatibleImage(
        this.settings.openaiBaseUrl,
        this.settings.openaiApiKey,
        model,
        systemPrompt,
        userPrompt,
        image
      );
    }
    if (provider === "qwen") {
      return this.answerWithOpenAICompatibleImage(
        this.settings.qwenBaseUrl,
        this.settings.qwenApiKey,
        model,
        systemPrompt,
        userPrompt,
        image
      );
    }
    if (provider === "custom") {
      return this.answerWithOpenAICompatibleImage(
        this.settings.customBaseUrl,
        this.settings.customApiKey,
        model,
        systemPrompt,
        userPrompt,
        image
      );
    }
    throw new Error("This provider is not configured for image input. Choose OpenAI, Gemini, Qwen, Ollama, or Custom.");
  }

  async answerWithOllama(systemPrompt, userPrompt) {
    const json = await postJson(safeJoinUrl(this.settings.ollamaBaseUrl, "/api/chat"), {
      model: this.settings.ollamaChatModel,
      stream: false,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });
    const answer = json && json.message && json.message.content;
    if (!answer) throw new Error("Ollama did not return an answer.");
    return answer;
  }

  async answerWithOllamaImage(systemPrompt, userPrompt, image, model) {
    if (!this.settings.ollamaBaseUrl || !model) throw new Error("Ollama base URL and vision model are required.");
    const parsed = parseDataUrl(image.dataUrl);
    const json = await postJson(safeJoinUrl(this.settings.ollamaBaseUrl, "/api/chat"), {
      model,
      stream: false,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt, images: [parsed.base64] },
      ],
    });
    const answer = json && json.message && json.message.content;
    if (!answer) throw new Error("Ollama did not return an image answer.");
    return answer;
  }

  async answerWithOpenAICompatible(baseUrl, apiKey, model, systemPrompt, userPrompt) {
    if (!baseUrl || !model) throw new Error("Base URL and chat model are required.");
    if (!apiKey) throw new Error("API key is required for this chat provider.");
    const json = await postJson(
      safeJoinUrl(baseUrl, "/chat/completions"),
      {
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.2,
      },
      { Authorization: `Bearer ${apiKey}` }
    );
    const answer = json && json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content;
    if (!answer) throw new Error("The chat provider did not return an answer.");
    return answer;
  }

  async answerWithOpenAICompatibleImage(baseUrl, apiKey, model, systemPrompt, userPrompt, image) {
    if (!baseUrl || !model) throw new Error("Base URL and vision model are required.");
    if (!apiKey) throw new Error("API key is required for this vision provider.");
    const json = await postJson(
      safeJoinUrl(baseUrl, "/chat/completions"),
      {
        model,
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "text", text: userPrompt },
              { type: "image_url", image_url: { url: image.dataUrl } },
            ],
          },
        ],
        temperature: 0.1,
      },
      { Authorization: `Bearer ${apiKey}` }
    );
    const answer = json && json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content;
    if (!answer) throw new Error("The vision provider did not return an answer.");
    return answer;
  }

  async answerWithGemini(systemPrompt, userPrompt) {
    if (!this.settings.geminiApiKey || !this.settings.geminiChatModel) {
      throw new Error("Gemini API key and chat model are required.");
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      this.settings.geminiChatModel
    )}:generateContent?key=${encodeURIComponent(this.settings.geminiApiKey)}`;
    const json = await postJson(url, {
      systemInstruction: {
        parts: [{ text: systemPrompt }],
      },
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }],
        },
      ],
      generationConfig: {
        temperature: 0.2,
      },
    });
    const answer =
      json &&
      json.candidates &&
      json.candidates[0] &&
      json.candidates[0].content &&
      json.candidates[0].content.parts &&
      json.candidates[0].content.parts.map((part) => part.text || "").join("");
    if (!answer) throw new Error("Gemini did not return an answer.");
    return answer;
  }

  async answerWithGeminiImage(systemPrompt, userPrompt, image, model) {
    if (!this.settings.geminiApiKey || !model) {
      throw new Error("Gemini API key and vision model are required.");
    }
    const parsed = parseDataUrl(image.dataUrl);
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      model
    )}:generateContent?key=${encodeURIComponent(this.settings.geminiApiKey)}`;
    const json = await postJson(url, {
      systemInstruction: {
        parts: [{ text: systemPrompt }],
      },
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }, { inlineData: { mimeType: parsed.mimeType, data: parsed.base64 } }],
        },
      ],
      generationConfig: {
        temperature: 0.1,
      },
    });
    const answer =
      json &&
      json.candidates &&
      json.candidates[0] &&
      json.candidates[0].content &&
      json.candidates[0].content.parts &&
      json.candidates[0].content.parts.map((part) => part.text || "").join("");
    if (!answer) throw new Error("Gemini did not return an image answer.");
    return answer;
  }
}

class LocalNoteAssistantView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.messagesEl = null;
    this.inputEl = null;
    this.statusEl = null;
    this.conversation = [];
    this.lastUserQuestion = "";
    this.pendingFeedbackQuestion = "";
    this.lastAssistantAnswer = "";
    this.assistantArtifacts = [];
    this.lastInsertionTarget = "";
    this.pendingAgentPlan = null;
    this.imageAttachment = null;
    this.imagePanelEl = null;
    this.imageTaskMode = "auto";
    this.imageModeSelect = null;
    this.imageOutputLanguage = plugin.settings.imageOutputLanguage || "auto";
    this.imageLanguageSelect = null;
    this.voiceRecognition = null;
    this.voiceListening = false;
    this.voiceBaseText = "";
    this.voiceFinalText = "";
    this.voiceFinalizeOnEnd = true;
    this.voiceButton = null;
    this.voiceModeSelect = null;
    this.voiceInputMode = plugin.settings.voiceInputMode || "append";
    this.aiPauseButton = null;
  }

  getViewType() {
    return VIEW_TYPE;
  }

  getDisplayText() {
    return "Local Note Assistant";
  }

  getIcon() {
    return "search";
  }

  async onOpen() {
    const container = this.containerEl.children[1];
    container.empty();
    container.addClass("lna-view");
    const text = (key) => t(this.plugin.settings, key);

    const header = container.createDiv({ cls: "lna-header" });
    header.createEl("h2", { text: text("title") });

    const toolbar = container.createDiv({ cls: "lna-toolbar" });
    toolbar.createEl("button", {
      text: text("newChat"),
      attr: { type: "button" },
    }).addEventListener("click", async () => {
      await this.startNewChat();
    });
    toolbar.createEl("button", {
      text: text("memoryButton"),
      attr: { type: "button" },
    }).addEventListener("click", () => {
      new MemoryModal(this.app, this.plugin, this).open();
    });
    toolbar.createEl("button", {
      text: text("knowledgeButton"),
      attr: { type: "button" },
    }).addEventListener("click", () => {
      new KnowledgeIndexModal(this.app, this.plugin).open();
    });
    toolbar.createEl("button", {
      text: text("settings"),
      attr: { type: "button" },
    }).addEventListener("click", () => {
      this.app.setting.open();
      this.app.setting.openTabById(this.plugin.manifest.id);
    });

    this.draftBarEl = container.createDiv({ cls: "lna-draft-bar" });
    this.renderDraftBar();

    this.messagesEl = container.createDiv({ cls: "lna-messages" });
    this.addAssistantMessage(this.plugin.getIndexStatusText());

    const form = container.createEl("form", { cls: "lna-form" });
    this.inputEl = form.createEl("textarea", {
      cls: "lna-input",
      attr: {
        rows: "3",
        placeholder: text("placeholder"),
      },
    });
    this.imagePanelEl = form.createDiv({ cls: "lna-image-panel" });
    const imageFileInput = form.createEl("input", {
      cls: "lna-hidden-file",
      attr: { type: "file", accept: "image/*" },
    });

    const actions = form.createDiv({ cls: "lna-actions" });
    this.statusEl = actions.createDiv({ cls: "lna-status", text: text("ready") });
    const modeWrap = actions.createEl("label", { cls: "lna-mode lna-bottom-mode" });
    modeWrap.createSpan({ text: text("answerSourceMode") });
    const modeSelect = modeWrap.createEl("select");
    modeSelect.createEl("option", { text: text("notesOnlyMode"), value: "notes_only" });
    modeSelect.createEl("option", { text: text("modelOnlyMode"), value: "model_only" });
    modeSelect.createEl("option", { text: text("notesModelMode"), value: "notes_model" });
    modeSelect.value = this.plugin.settings.answerSourceMode || "notes_only";
    modeSelect.addEventListener("change", async () => {
      this.plugin.settings.answerSourceMode = modeSelect.value;
      await this.plugin.savePluginData();
    });
    const answerToggle = actions.createEl("label", { cls: "lna-toggle lna-bottom-toggle" });
    const answerCheckbox = answerToggle.createEl("input", { attr: { type: "checkbox" } });
    answerCheckbox.checked = Boolean(this.plugin.settings.answerWithSources);
    answerToggle.createSpan({ text: text("answerWithSources") });
    answerCheckbox.addEventListener("change", async () => {
      this.plugin.settings.answerWithSources = answerCheckbox.checked;
      await this.plugin.savePluginData();
    });
    this.aiPauseButton = actions.createEl("button", {
      cls: "lna-ai-pause-button",
      text: this.plugin.settings.aiPaused ? text("resumeAi") : text("pauseAi"),
      attr: { type: "button" },
    });
    this.aiPauseButton.addEventListener("click", async () => {
      await this.toggleAiPause();
    });
    this.refreshAiPauseButton();
    const button = actions.createEl("button", {
      cls: "mod-cta",
      text: text("send"),
      attr: { type: "submit" },
    });

    if (this.toolPanelEl) {
      this.toolPanelEl.remove();
      this.toolPanelEl = null;
    }
    const tools = form.createEl("details", { cls: "lna-tools" });
    tools.createEl("summary", { text: text("tools") });
    const toolPanel = document.body.createDiv({ cls: "lna-tools-panel" });
    this.toolPanelEl = toolPanel;
    const positionToolPanel = () => {
      if (!tools.open || typeof window === "undefined" || typeof document === "undefined") return;
      const viewportWidth = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0, 720);
      const viewportHeight = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0, 520);
      const buttonRect = tools.getBoundingClientRect();
      const leftSpace = Math.max(0, buttonRect.left - 12);
      const fallbackWidth = Math.min(420, Math.max(300, viewportWidth - 24));
      const leftOpenWidth = Math.min(520, Math.max(180, leftSpace - 8));
      const panelWidth = leftSpace >= 188 ? leftOpenWidth : fallbackWidth;
      const maxHeight = Math.min(420, Math.max(220, viewportHeight - 48));
      let left = leftSpace >= 188 ? buttonRect.left - panelWidth - 8 : 12;
      left = Math.max(12, Math.min(left, viewportWidth - panelWidth - 12));
      const panelHeight = Math.min(maxHeight, Math.max(180, toolPanel.scrollHeight || maxHeight));
      let top = buttonRect.bottom - panelHeight;
      top = Math.max(12, Math.min(top, viewportHeight - panelHeight - 12));
      toolPanel.style.setProperty("--lna-tools-panel-left", `${Math.round(left)}px`);
      toolPanel.style.setProperty("--lna-tools-panel-top", `${Math.round(top)}px`);
      toolPanel.style.setProperty("--lna-tools-panel-width", `${Math.round(panelWidth)}px`);
      toolPanel.style.setProperty("--lna-tools-panel-max-height", `${Math.round(maxHeight)}px`);
    };
    tools.addEventListener("toggle", () => {
      toolPanel.classList.toggle("lna-tools-panel-open", tools.open);
      if (tools.open) requestAnimationFrame(positionToolPanel);
    });
    if (typeof window !== "undefined") {
      this.registerDomEvent(window, "resize", positionToolPanel);
      this.registerDomEvent(window, "scroll", positionToolPanel, true);
    }
    if (typeof document !== "undefined") {
      this.registerDomEvent(document, "mousedown", (event) => {
        if (!tools.open) return;
        const target = event.target;
        if (tools.contains(target) || toolPanel.contains(target)) return;
        tools.open = false;
        toolPanel.classList.remove("lna-tools-panel-open");
      });
    }
    this.renderToolKeywordPicker(toolPanel);
    const toolActions = toolPanel.createDiv({ cls: "lna-tool-actions" });
    const rebuildButton = toolActions.createEl("button", {
      text: text("buildIndex"),
      attr: { type: "button" },
    });
    const checkIndexButton = toolActions.createEl("button", {
      text: text("checkIndexChanges"),
      attr: { type: "button" },
    });
    const updateChangedIndexButton = toolActions.createEl("button", {
      text: text("updateChangedIndex"),
      attr: { type: "button" },
    });
    const screenshotButton = toolActions.createEl("button", {
      text: text("startScreenshot"),
      attr: { type: "button" },
    });
    const clipboardImageButton = toolActions.createEl("button", {
      text: text("attachClipboardImage"),
      attr: { type: "button" },
    });
    const imageButton = toolActions.createEl("button", {
      text: text("chooseImage"),
      attr: { type: "button" },
    });
    const imageMarkdownButton = toolActions.createEl("button", {
      text: text("imageToMarkdown"),
      attr: { type: "button" },
    });
    const clearImageButton = toolActions.createEl("button", {
      text: text("clearImage"),
      attr: { type: "button" },
    });
    this.voiceButton = toolActions.createEl("button", {
      cls: "lna-voice-button",
      text: text("startVoiceInput"),
      attr: { type: "button" },
    });
    const draftButton = toolActions.createEl("button", {
      text: text("draftNote"),
      attr: { type: "button" },
    });
    const blankDraftButton = toolActions.createEl("button", {
      text: text("blankDraft"),
      attr: { type: "button" },
    });
    const editDraftButton = toolActions.createEl("button", {
      text: text("editDraft"),
      attr: { type: "button" },
    });
    const editSelectionButton = toolActions.createEl("button", {
      text: text("editSelection"),
      attr: { type: "button" },
    });
    const migrationToolButton = toolActions.createEl("button", {
      text: text("migrationToolButton"),
      attr: { type: "button" },
    });
    const chatGptHandoffButton = toolActions.createEl("button", {
      text: text("chatGptHandoffButton"),
      attr: { type: "button" },
    });
    const imageModeWrap = toolPanel.createEl("label", { cls: "lna-image-mode" });
    imageModeWrap.createSpan({ text: text("imageMode") });
    this.imageModeSelect = imageModeWrap.createEl("select");
    this.imageModeSelect.createEl("option", { value: "auto", text: text("imageModeAuto") });
    this.imageModeSelect.createEl("option", { value: "question", text: text("imageModeQuestion") });
    this.imageModeSelect.createEl("option", { value: "proof", text: text("imageModeProof") });
    this.imageModeSelect.createEl("option", { value: "formula", text: text("imageModeFormula") });
    this.imageModeSelect.createEl("option", { value: "code", text: text("imageModeCode") });
    this.imageModeSelect.createEl("option", { value: "table", text: text("imageModeTable") });
    this.imageModeSelect.value = this.imageTaskMode;
    this.imageModeSelect.addEventListener("change", () => {
      this.imageTaskMode = this.imageModeSelect.value || "auto";
    });
    const imageLanguageWrap = toolPanel.createEl("label", { cls: "lna-image-language" });
    imageLanguageWrap.createSpan({ text: text("imageOutputLanguage") });
    this.imageLanguageSelect = imageLanguageWrap.createEl("select");
    this.imageLanguageSelect.createEl("option", { value: "auto", text: text("imageLanguageAuto") });
    this.imageLanguageSelect.createEl("option", { value: "zh", text: text("imageLanguageChinese") });
    this.imageLanguageSelect.createEl("option", { value: "en", text: text("imageLanguageEnglish") });
    this.imageLanguageSelect.value = this.imageOutputLanguage || "auto";
    this.imageLanguageSelect.addEventListener("change", async () => {
      this.imageOutputLanguage = this.imageLanguageSelect.value || "auto";
      this.plugin.settings.imageOutputLanguage = this.imageOutputLanguage;
      await this.plugin.savePluginData();
    });
    const voiceModeWrap = toolPanel.createEl("label", { cls: "lna-voice-mode" });
    voiceModeWrap.createSpan({ text: text("voiceMode") });
    this.voiceModeSelect = voiceModeWrap.createEl("select");
    this.voiceModeSelect.createEl("option", { value: "append", text: text("voiceModeAppend") });
    this.voiceModeSelect.createEl("option", { value: "replace", text: text("voiceModeReplace") });
    this.voiceModeSelect.createEl("option", { value: "command", text: text("voiceModeCommand") });
    this.voiceModeSelect.value = this.voiceInputMode;
    this.voiceModeSelect.addEventListener("change", async () => {
      this.voiceInputMode = this.voiceModeSelect.value || "append";
      this.plugin.settings.voiceInputMode = this.voiceInputMode;
      await this.plugin.savePluginData();
    });
    this.refreshVoiceButton();
    rebuildButton.addEventListener("click", async () => {
      await this.rebuildIndex();
    });
    checkIndexButton.addEventListener("click", async () => {
      await this.checkIndexChanges();
    });
    updateChangedIndexButton.addEventListener("click", async () => {
      await this.updateChangedIndex();
    });
    screenshotButton.addEventListener("click", async () => {
      await this.startSystemScreenshotCapture();
    });
    clipboardImageButton.addEventListener("click", async () => {
      await this.attachClipboardImage();
    });
    draftButton.addEventListener("click", async () => {
      await this.generateDraftFromInput(button, draftButton, blankDraftButton);
    });
    blankDraftButton.addEventListener("click", async () => {
      await this.createBlankDraftFromInput(button, draftButton, blankDraftButton);
    });
    editDraftButton.addEventListener("click", async () => {
      await this.editCurrentDraftFromInput(button, draftButton, blankDraftButton, editDraftButton, editSelectionButton);
    });
    editSelectionButton.addEventListener("click", async () => {
      await this.editActiveDraftSelectionFromInput(button, draftButton, blankDraftButton, editSelectionButton);
    });
    migrationToolButton.addEventListener("click", () => {
      tools.open = false;
      toolPanel.classList.remove("lna-tools-panel-open");
      new MigrationToolModal(this.app, this.plugin).open();
    });
    chatGptHandoffButton.addEventListener("click", () => {
      tools.open = false;
      toolPanel.classList.remove("lna-tools-panel-open");
      new ChatGptHandoffModal(this.app, this.plugin, this).open();
    });
    imageButton.addEventListener("click", () => {
      if (!this.plugin.settings.enableImageInput) {
        this.addAssistantMessage(text("imageInputDisabled"));
        return;
      }
      imageFileInput.click();
    });
    imageFileInput.addEventListener("change", async () => {
      const file = imageFileInput.files && imageFileInput.files[0];
      if (file) await this.setImageAttachmentFromFile(file);
      imageFileInput.value = "";
    });
    clearImageButton.addEventListener("click", () => {
      this.clearImageAttachment();
    });
    this.voiceButton.addEventListener("click", async () => {
      await this.toggleVoiceInput();
    });
    imageMarkdownButton.addEventListener("click", async () => {
      await this.convertImageToMarkdown(button, draftButton, blankDraftButton, imageMarkdownButton);
    });
    const actionButtons = [
      button,
      rebuildButton,
      checkIndexButton,
      updateChangedIndexButton,
      screenshotButton,
      clipboardImageButton,
      imageButton,
      imageMarkdownButton,
      clearImageButton,
      draftButton,
      blankDraftButton,
      editDraftButton,
      editSelectionButton,
      migrationToolButton,
      chatGptHandoffButton,
    ];

    this.inputEl.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" || event.shiftKey || event.isComposing) return;
      event.preventDefault();
      if (this.pendingAgentPlan && !this.pendingAgentPlan.running) {
        this.runPendingAgentPlan();
        return;
      }
      if (!button.disabled) {
        form.requestSubmit();
      }
    });
    this.inputEl.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || !this.pendingAgentPlan || this.pendingAgentPlan.running) return;
      event.preventDefault();
      this.cancelPendingAgentPlan();
    });
    this.inputEl.addEventListener("paste", async (event) => {
      await this.handleImagePaste(event);
    });

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const query = this.inputEl.value.trim();
      if (!query && !this.imageAttachment) return;
      if (this.voiceListening) this.stopVoiceInput({ keepText: false });
      const keywordCommand = this.plugin.parseToolKeyword(query);
      const effectiveQuery = keywordCommand && keywordCommand.text ? keywordCommand.text : query;
      actionButtons.forEach((actionButton) => {
        actionButton.disabled = true;
      });
      this.statusEl.setText(text("searching"));
      if (this.imageAttachment) {
        this.addImageUserMessage(query, this.imageAttachment);
      } else {
        this.addUserMessage(query);
      }
      this.pendingFeedbackQuestion = query;
      this.inputEl.value = "";
      try {
        const feedbackHandled = await this.handleUnsatisfiedFeedbackPrompt(query);
        if (feedbackHandled) return;
        if (this.plugin.settings.aiPaused) {
          await this.handlePausedQuery(query, effectiveQuery);
          return;
        }
        const handled = await this.handleAutoAction(query, effectiveQuery);
        if (handled) return;

        const conversationContext = this.getConversationContext();
        const useNotes = this.plugin.settings.answerSourceMode !== "model_only";
        const searchResponse = useNotes
          ? await this.withToolStatus(text("toolSearch"), text("toolReasonSearch"), () =>
              this.plugin.search(this.plugin.buildConversationSearchQuery(effectiveQuery, conversationContext))
            )
          : { mode: "model", results: [] };
        if (useNotes) {
          await this.addResultsMessage(effectiveQuery, searchResponse);
        }
        let answer = "";
        if (
          this.plugin.settings.answerWithSources &&
          (searchResponse.results.length > 0 || this.plugin.settings.answerSourceMode === "model_only")
        ) {
          this.statusEl.setText(text("answering"));
          answer = await this.withToolStatus(text("toolAnswer"), text("toolReasonAnswer"), () =>
            this.plugin.answerWithSources(effectiveQuery, searchResponse.results, conversationContext)
          );
          await this.addAnswerMessage(answer, searchResponse.results);
        }
        this.recordConversationTurn(query, answer, searchResponse.results);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      } finally {
        actionButtons.forEach((actionButton) => {
          actionButton.disabled = false;
        });
        this.statusEl.setText(text("ready"));
        this.inputEl.focus();
      }
    });
  }

  async handleImagePaste(event) {
    if (!this.plugin.settings.enableImageInput) return;
    const items = event.clipboardData && event.clipboardData.items;
    if (!items) return;
    for (const item of items) {
      if (item.kind === "file" && item.type && item.type.startsWith("image/")) {
        const file = item.getAsFile();
        if (!file) return;
        event.preventDefault();
        await this.setImageAttachmentFromFile(file);
        return;
      }
    }
  }

  async startSystemScreenshotCapture() {
    const text = (key) => t(this.plugin.settings, key);
    try {
      await this.withToolStatus(text("startScreenshot"), text("toolReasonImage"), async () => {
        await this.plugin.openSystemScreenshotTool();
      });
      this.addAssistantMessage(text("screenshotStarted"));
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("clipboardReadFailed")}: ${error.message || error}`);
    }
  }

  async attachClipboardImage() {
    const text = (key) => t(this.plugin.settings, key);
    if (!this.plugin.settings.enableImageInput) {
      this.addAssistantMessage(text("imageInputDisabled"));
      return false;
    }
    try {
      const file = await this.withToolStatus(text("attachClipboardImage"), text("toolReasonImage"), () =>
        this.readClipboardImageFile()
      );
      if (!file) {
        this.addAssistantMessage(text("noClipboardImage"));
        return false;
      }
      await this.setImageAttachmentFromFile(file);
      this.addAssistantMessage(`${text("clipboardImageAttached")}: ${file.name || "clipboard-image.png"}`);
      return true;
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("clipboardReadFailed")}: ${error.message || error}`);
      return false;
    }
  }

  async prepareScreenshotQuestion() {
    const attached = await this.attachClipboardImage();
    if (!attached) return false;
    this.setImageTaskMode("question");
    if (this.inputEl && !this.inputEl.value.trim()) {
      this.inputEl.value = "[图片转写] 请根据这张截图回答我的问题，并把有用内容整理成 Obsidian Markdown。";
    }
    if (this.inputEl) {
      this.inputEl.focus();
      const end = this.inputEl.value.length;
      this.inputEl.setSelectionRange(end, end);
    }
    return true;
  }

  async readClipboardImageFile() {
    const webFile = await this.readClipboardImageWithWebApi();
    if (webFile) return webFile;
    return this.readClipboardImageWithElectron();
  }

  async readClipboardImageWithWebApi() {
    if (!navigator.clipboard || !navigator.clipboard.read) return null;
    let items = [];
    try {
      items = await navigator.clipboard.read();
    } catch (error) {
      return null;
    }
    for (const item of items || []) {
      const imageType = (item.types || []).find((type) => String(type || "").startsWith("image/"));
      if (!imageType) continue;
      const blob = await item.getType(imageType);
      return this.makeImageFileFromBlob(blob, this.getClipboardImageName(imageType), imageType);
    }
    return null;
  }

  readClipboardImageWithElectron() {
    try {
      const electron = require("electron");
      const clipboard = electron && electron.clipboard;
      if (!clipboard || !clipboard.readImage) return null;
      const nativeImage = clipboard.readImage();
      if (!nativeImage || nativeImage.isEmpty()) return null;
      const buffer = nativeImage.toPNG();
      const blob = new Blob([buffer], { type: "image/png" });
      return this.makeImageFileFromBlob(blob, this.getClipboardImageName("image/png"), "image/png");
    } catch (error) {
      return null;
    }
  }

  makeImageFileFromBlob(blob, name, type) {
    const safeType = type || blob.type || "image/png";
    try {
      return new File([blob], name, { type: safeType });
    } catch (error) {
      blob.name = name;
      return blob;
    }
  }

  getClipboardImageName(type = "image/png") {
    const extension = String(type).includes("jpeg") || String(type).includes("jpg") ? "jpg" : "png";
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    return `clipboard-screenshot-${stamp}.${extension}`;
  }

  setImageTaskMode(mode) {
    this.imageTaskMode = mode || "auto";
    if (this.imageModeSelect) this.imageModeSelect.value = this.imageTaskMode;
  }

  buildImageInstruction(prompt = "") {
    const mode = this.imageTaskMode || "auto";
    const base = String(prompt || "").trim();
    const modePrompts = {
      auto: "自动判断截图类型。如果包含数学、代码、表格或证明，请选择最适合的 Markdown 结构。",
      question: "请把截图作为问题上下文，直接回答用户想问的问题；必要时先转写关键内容，再给出解释。",
      proof: "如果截图包含数学证明，请转写为清晰的 Obsidian Markdown 证明，保留逻辑步骤、定义、引理、结论和 LaTeX 公式。",
      formula: "如果截图包含公式，请精确转写为 Obsidian 可渲染的 LaTeX；行内公式使用紧贴内容的 $x$，不要写成 $ x $。",
      code: "如果截图包含代码，请转写为带语言标记的 fenced code block，保留缩进、注释和错误信息；若用户要求解释，再给出简洁说明。",
      table: "如果截图包含表格或结构化数据，请转写为 Markdown 表格；无法确认的单元格用 TODO 标记。",
    };
    return [base, `截图模式: ${mode}\n${modePrompts[mode] || modePrompts.auto}`].filter(Boolean).join("\n\n");
  }

  buildImageInstruction(prompt = "") {
    const mode = this.imageTaskMode || "auto";
    const base = String(prompt || "").trim();
    const outputLanguage = this.imageOutputLanguage || this.plugin.settings.imageOutputLanguage || "auto";
    const languagePrompts = {
      auto:
        "Output language: choose the best language from the user's request and interface context. If unsure, use Chinese for explanations and keep standard English mathematical terms when appropriate.",
      zh:
        "Output language: Chinese mathematical notes. Use clear Chinese prose, but keep English terms when they are standard, have no fixed Chinese translation, or would be clearer in English. On first mention, you may write 中文术语（English term） when helpful.",
      en:
        "Output language: English mathematical notes. Use standard mathematical English and keep notation faithful to the image.",
    };
    const modePrompts = {
      auto:
        "Automatically identify the screenshot type. If it contains mathematics, code, a table, a proof, or a theorem, choose the Markdown structure that best fits mathematical notes.",
      question:
        "Treat the screenshot as context for the user's question. Transcribe only the key parts needed, then answer directly in a mathematical-note style.",
      proof:
        "If the screenshot contains a proof, rewrite it as a clear Obsidian Markdown proof. Preserve assumptions, definitions, lemmas, logical steps, conclusion, and LaTeX formulas.",
      formula:
        "If the screenshot contains formulas, transcribe them precisely as Obsidian-renderable LaTeX. Inline math must be $x$, not $ x $. Use $$...$$ blocks for display math.",
      code:
        "If the screenshot contains code, transcribe it into fenced code blocks with the most likely language tag. Preserve indentation, comments, variable names, and visible error messages. Add a short mathematical-note explanation only when useful.",
      table:
        "If the screenshot contains a table or structured data, convert it into a Markdown table. Use TODO for cells that cannot be read reliably.",
    };
    return [
      base,
      `Screenshot mode: ${mode}\n${modePrompts[mode] || modePrompts.auto}`,
      languagePrompts[outputLanguage] || languagePrompts.auto,
      "Writing norm: optimize for mathematical notes, not casual explanation. Preserve symbols exactly unless the user asks for rewriting.",
    ]
      .filter(Boolean)
      .join("\n\n");
  }

  getSpeechRecognitionConstructor() {
    const scope = typeof window !== "undefined" ? window : globalThis;
    return scope.SpeechRecognition || scope.webkitSpeechRecognition || null;
  }

  getVoiceLanguage() {
    const configured = String(this.plugin.settings.voiceInputLanguage || "").trim();
    if (configured) return configured;
    return this.plugin.settings.language === "zh" ? "zh-CN" : "en-US";
  }

  refreshVoiceButton() {
    if (!this.voiceButton) return;
    const text = (key) => t(this.plugin.settings, key);
    this.voiceButton.setText(this.voiceListening ? text("stopVoiceInput") : text("startVoiceInput"));
    this.voiceButton.toggleClass("lna-voice-active", Boolean(this.voiceListening));
    this.voiceButton.setAttr("aria-pressed", this.voiceListening ? "true" : "false");
    this.voiceButton.setAttr("title", text("voiceInput"));
  }

  async toggleVoiceInput() {
    if (this.voiceListening) {
      this.stopVoiceInput();
      return false;
    }
    return this.startVoiceInput();
  }

  async startVoiceInput() {
    const text = (key) => t(this.plugin.settings, key);
    if (!this.plugin.settings.enableVoiceInput) {
      this.addAssistantMessage(text("voiceInputDisabled"));
      return false;
    }
    const SpeechRecognition = this.getSpeechRecognitionConstructor();
    if (!SpeechRecognition) {
      this.addAssistantMessage(text("voiceUnsupported"));
      return false;
    }
    if (!this.inputEl || this.voiceListening) return false;

    this.voiceBaseText = this.inputEl.value || "";
    this.voiceFinalText = "";
    this.voiceFinalizeOnEnd = true;

    const recognition = new SpeechRecognition();
    recognition.lang = this.getVoiceLanguage();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      this.voiceListening = true;
      if (this.statusEl) this.statusEl.setText(text("voiceListening"));
      this.refreshVoiceButton();
      new Notice(text("voicePermissionHint"));
    };

    recognition.onresult = (event) => {
      let finalDelta = "";
      let interimText = "";
      for (let index = event.resultIndex || 0; index < event.results.length; index += 1) {
        const result = event.results[index];
        const transcript = result && result[0] ? String(result[0].transcript || "") : "";
        if (!transcript) continue;
        if (result.isFinal) finalDelta = [finalDelta, transcript].filter(Boolean).join(" ");
        else interimText = [interimText, transcript].filter(Boolean).join(" ");
      }
      if (finalDelta) {
        this.voiceFinalText = this.formatVoiceTranscript(
          [this.voiceFinalText, finalDelta].filter(Boolean).join(" ")
        );
      }
      this.applyVoiceTranscript(interimText);
    };

    recognition.onerror = (event) => {
      const reason = event && event.error ? event.error : "unknown";
      this.voiceFinalizeOnEnd = false;
      this.addAssistantMessage(`${text("voiceError")}: ${reason}`);
    };

    recognition.onend = () => {
      const shouldFinalize = this.voiceFinalizeOnEnd;
      this.voiceListening = false;
      this.voiceRecognition = null;
      if (shouldFinalize) this.applyVoiceTranscript("");
      if (this.statusEl) this.statusEl.setText(text("ready"));
      this.refreshVoiceButton();
    };

    this.voiceRecognition = recognition;
    try {
      recognition.start();
      return true;
    } catch (error) {
      this.voiceListening = false;
      this.voiceRecognition = null;
      this.refreshVoiceButton();
      this.addAssistantMessage(`${text("voiceError")}: ${error.message || error}`);
      return false;
    }
  }

  stopVoiceInput(options = {}) {
    const keepText = options.keepText !== false;
    this.voiceFinalizeOnEnd = keepText;
    if (this.voiceRecognition) {
      try {
        this.voiceRecognition.stop();
        return true;
      } catch (error) {
        this.voiceRecognition = null;
      }
    }
    this.voiceListening = false;
    this.refreshVoiceButton();
    return false;
  }

  applyVoiceTranscript(interimText = "") {
    if (!this.inputEl) return;
    const finalText = this.voiceFinalText || "";
    const draftText = this.formatVoiceTranscript([finalText, interimText].filter(Boolean).join(" "));
    this.inputEl.value = this.composeVoiceInputText(draftText);
    this.inputEl.focus();
    const end = this.inputEl.value.length;
    this.inputEl.setSelectionRange(end, end);
  }

  composeVoiceInputText(voiceText) {
    const mode = this.voiceInputMode || this.plugin.settings.voiceInputMode || "append";
    const cleanVoiceText = this.formatVoiceTranscript(voiceText);
    if (!cleanVoiceText) return this.voiceBaseText || "";
    if (mode === "replace") return cleanVoiceText;
    if (mode === "command") return this.normalizeVoiceCommandText(cleanVoiceText);
    const base = this.voiceBaseText || "";
    if (!base.trim()) return cleanVoiceText;
    const spacer = /\s$/.test(base) || /^[,.;:!?，。！？；：、]/.test(cleanVoiceText) ? "" : " ";
    return `${base}${spacer}${cleanVoiceText}`;
  }

  formatVoiceTranscript(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .replace(/([\u4e00-\u9fff])\s+([\u4e00-\u9fff])/g, "$1$2")
      .replace(/\s+([,.;:!?，。！？；：、])/g, "$1")
      .replace(/([([{（《「『])\s+/g, "$1")
      .replace(/\s+([)\]}）》，」』])/g, "$1")
      .trim();
  }

  normalizeVoiceCommandText(value) {
    const clean = this.formatVoiceTranscript(value);
    const mappings = [
      [/^(\u4e3b\u9898\u6574\u7406|\u6574\u7406\u4e3b\u9898|\u751f\u6210\u4e3b\u9898\u6574\u7406)\s*/i, "\u005b\u4e3b\u9898\u6574\u7406\u005d "],
      [/^(\u56fe\u7247\u8f6c\u5199|\u622a\u56fe\u8f6c\u5199|\u8bc6\u522b\u56fe\u7247|\u8bc6\u522b\u622a\u56fe)\s*/i, "\u005b\u56fe\u7247\u8f6c\u5199\u005d "],
      [/^(\u6539\u5199\u8349\u7a3f|\u4fee\u6539\u8349\u7a3f|\u7f16\u8f91\u8349\u7a3f)\s*/i, "\u005b\u6539\u8349\u7a3f\u005d "],
      [/^(\u8fc1\u79fb|\u94fe\u63a5\u8fc1\u79fb|\u7b26\u53f7\u8fc1\u79fb)\s*/i, "\u005b\u8fc1\u79fb\u005d "],
      [/^(\u95ee\u7b54|\u641c\u7d22|\u67e5\u627e)\s*/i, "\u005b\u95ee\u7b54\u005d "],
    ];
    for (const [pattern, token] of mappings) {
      if (pattern.test(clean)) return clean.replace(pattern, token).trim();
    }
    return clean;
  }

  refreshAiPauseButton() {
    if (!this.aiPauseButton) return;
    const text = (key) => t(this.plugin.settings, key);
    const paused = Boolean(this.plugin.settings.aiPaused);
    this.aiPauseButton.setText(paused ? text("resumeAi") : text("pauseAi"));
    this.aiPauseButton.toggleClass("lna-ai-pause-active", paused);
    this.aiPauseButton.setAttr("aria-pressed", paused ? "true" : "false");
  }

  async setAiPaused(paused) {
    const text = (key) => t(this.plugin.settings, key);
    this.plugin.settings.aiPaused = Boolean(paused);
    await this.plugin.savePluginData();
    this.refreshAiPauseButton();
    const message = this.plugin.settings.aiPaused ? text("aiPausedNotice") : text("aiResumed");
    this.addAssistantMessage(message);
    new Notice(this.plugin.settings.aiPaused ? text("aiPaused") : text("aiResumed"));
  }

  async toggleAiPause() {
    await this.setAiPaused(!this.plugin.settings.aiPaused);
  }

  blockIfAiPaused() {
    if (!this.plugin.settings.aiPaused) return false;
    const text = (key) => t(this.plugin.settings, key);
    this.addAssistantMessage(text("pauseBlockedAction"));
    new Notice(text("aiPaused"));
    return true;
  }

  beginToolStatus(title, reason = "") {
    if (!this.messagesEl) return null;
    const text = (key) => t(this.plugin.settings, key);
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant lna-tool-status-message" });
    const bubble = message.createDiv({ cls: "lna-bubble lna-tool-status lna-tool-status-running" });
    const icon = bubble.createSpan({ cls: "lna-tool-status-icon" });
    const body = bubble.createDiv({ cls: "lna-tool-status-body" });
    const titleRow = body.createDiv({ cls: "lna-tool-status-title-row" });
    const titleEl = titleRow.createSpan({ cls: "lna-tool-status-title", text: title || text("autoAction") });
    const stateEl = titleRow.createSpan({ cls: "lna-tool-status-state", text: text("toolRunning") });
    const reasonEl = body.createDiv({
      cls: "lna-tool-status-reason",
      text: reason ? `${text("toolWhy")}: ${reason}` : "",
    });
    this.scrollToBottom();
    return { bubble, icon, titleEl, stateEl, reasonEl };
  }

  setToolStatus(status, state, detail = "") {
    if (!status || !status.bubble) return;
    const text = (key) => t(this.plugin.settings, key);
    status.bubble.removeClass("lna-tool-status-running");
    status.bubble.removeClass("lna-tool-status-done");
    status.bubble.removeClass("lna-tool-status-failed");
    if (state === "done") {
      status.bubble.addClass("lna-tool-status-done");
      status.icon.setText("✓");
      status.stateEl.setText(detail || text("toolDone"));
    } else if (state === "failed") {
      status.bubble.addClass("lna-tool-status-failed");
      status.icon.setText("!");
      status.stateEl.setText(detail || text("toolFailed"));
    } else {
      status.bubble.addClass("lna-tool-status-running");
      status.icon.setText("");
      status.stateEl.setText(detail || text("toolRunning"));
    }
    this.scrollToBottom();
  }

  async withToolStatus(title, reason, task) {
    const status = this.beginToolStatus(title, reason);
    try {
      const result = await task(status);
      this.setToolStatus(status, "done");
      return result;
    } catch (error) {
      this.setToolStatus(status, "failed", `${t(this.plugin.settings, "toolFailed")}: ${error.message || error}`);
      throw error;
    }
  }

  getToolReason(action) {
    const text = (key) => t(this.plugin.settings, key);
    if (/migration/i.test(action || "")) return text("toolReasonMigration");
    if (/image/i.test(action || "")) return text("toolReasonImage");
    if (/draft|insert|edit|synthesis|agent/i.test(action || "")) return text("toolReasonDraft");
    if (/memory|knowledge|panel/i.test(action || "")) return text("toolReasonPanel");
    if (/answer/i.test(action || "")) return text("toolReasonAnswer");
    if (/search/i.test(action || "")) return text("toolReasonSearch");
    return text("toolReasonRoute");
  }

  async handlePausedQuery(query, effectiveQuery) {
    const text = (key) => t(this.plugin.settings, key);
    const command = this.plugin.parseToolKeyword(query);
    const pausedState = {
      hasImage: Boolean(this.imageAttachment),
      hasCurrentDraft: Boolean(this.plugin.lastDraftPath),
      hasDraftSelection: await this.plugin.hasActiveDraftSelection(),
    };
    const route = command
      ? this.plugin.routeFromToolKeyword(command, command.text || effectiveQuery, pausedState)
      : this.plugin.inferLocalIntent(effectiveQuery || query, pausedState);
    if (route && route.action === "resume_ai") {
      await this.setAiPaused(false);
      return true;
    }
    if (route && route.action === "pause_ai") {
      this.addAssistantMessage(text("aiPausedNotice"));
      return true;
    }
    if (route && route.action === "memory") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new MemoryModal(this.app, this.plugin, this).open();
      });
      return true;
    }
    if (route && route.action === "knowledge") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new KnowledgeIndexModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (route && route.action === "concept_cards") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new ConceptCardReviewModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (route && route.action === "migration_tool") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationToolModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (route && route.action === "migration_review") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationReviewModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (route && route.action === "check_index_changes") {
      await this.checkIndexChanges();
      return true;
    }
    if (route && route.action !== "search_answer") {
      this.addAssistantMessage(text("pauseBlockedAction"));
      return true;
    }
    if (this.imageAttachment) {
      this.addAssistantMessage(text("pauseBlockedAction"));
      return true;
    }
    const searchText = String(effectiveQuery || query || "").trim();
    if (!searchText) {
      this.addAssistantMessage(text("aiPausedNotice"));
      return true;
    }
    if (this.plugin.settings.answerSourceMode === "model_only") {
      this.addAssistantMessage(text("pauseBlockedAction"));
      return true;
    }
    this.statusEl.setText(text("searching"));
    const conversationContext = this.getConversationContext();
    const searchResponse = await this.withToolStatus(text("toolSearch"), text("toolReasonPausedSearch"), () =>
      this.plugin.search(this.plugin.buildConversationSearchQuery(searchText, conversationContext))
    );
    await this.addResultsMessage(searchText, searchResponse);
    this.addAssistantMessage(text("pausedSearchOnly"));
    return true;
  }

  renderToolKeywordPicker(container) {
    const text = (key) => t(this.plugin.settings, key);
    const keywords = this.plugin.getToolKeywordDefinitions();
    if (!keywords.length) return;
    const panel = container.createDiv({ cls: "lna-keyword-picker" });
    panel.createSpan({ cls: "lna-keyword-label", text: `${text("toolKeywords")}:` });
    const select = panel.createEl("select", {
      cls: "lna-keyword-select",
      attr: { "aria-label": text("toolKeywords") },
    });
    select.createEl("option", { value: "", text: text("chooseKeyword") });
    for (const def of keywords) {
      select.createEl("option", {
        value: def.keyword,
        text: `[${def.keyword}] ${this.plugin.getToolKeywordDisplay(def)}`,
      });
    }
    select.addEventListener("change", () => {
      if (!select.value) return;
      this.insertToolKeyword(select.value);
      select.value = "";
    });

    panel.createSpan({ cls: "lna-keyword-label lna-keyword-common-label", text: text("commonKeywords") });
    const chips = panel.createDiv({ cls: "lna-keyword-chips" });
    for (const def of keywords.slice(0, 6)) {
      const chip = chips.createEl("button", {
        cls: "lna-keyword-chip",
        text: `[${def.keyword}]`,
        attr: {
          type: "button",
          title: `${this.plugin.getToolKeywordDisplay(def)} - ${this.plugin.getToolKeywordHint(def)}`,
        },
      });
      chip.addEventListener("click", () => {
        this.insertToolKeyword(def.keyword);
      });
    }
  }

  insertToolKeyword(keyword) {
    if (!this.inputEl) return;
    const token = `[${keyword}]`;
    const current = this.inputEl.value || "";
    const withoutExistingKeyword = current.replace(/^\s*(?:\[[^\]\r\n]{1,32}\]|【[^】\r\n]{1,32}】)\s*/, "");
    const spacer = withoutExistingKeyword.trim() ? " " : " ";
    this.inputEl.value = `${token}${spacer}${withoutExistingKeyword}`.trimEnd();
    this.inputEl.focus();
    const end = this.inputEl.value.length;
    this.inputEl.setSelectionRange(end, end);
  }

  async setImageAttachmentFromFile(file) {
    const text = (key) => t(this.plugin.settings, key);
    if (!this.plugin.settings.enableImageInput) {
      this.addAssistantMessage(text("imageInputDisabled"));
      return;
    }
    const maxBytes = Number.parseInt(this.plugin.settings.maxImageBytes, 10) || 5242880;
    if (!file.type || !file.type.startsWith("image/")) {
      this.addAssistantMessage(text("imageRequired"));
      return;
    }
    if (file.size > maxBytes) {
      this.addAssistantMessage(`${text("imageTooLarge")} (${Math.round(file.size / 1024)} KB)`);
      return;
    }
    const dataUrl = await this.readFileAsDataUrl(file);
    this.imageAttachment = {
      name: file.name || "pasted-image",
      type: file.type,
      size: file.size,
      dataUrl,
    };
    this.renderImageAttachment();
    this.statusEl.setText(`${text("imageReady")}: ${this.imageAttachment.name}`);
  }

  readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(reader.error || new Error("Could not read image."));
      reader.readAsDataURL(file);
    });
  }

  renderImageAttachment() {
    if (!this.imagePanelEl) return;
    this.imagePanelEl.empty();
    if (!this.imageAttachment) return;
    const text = (key) => t(this.plugin.settings, key);
    const preview = this.imagePanelEl.createDiv({ cls: "lna-image-preview" });
    preview.createEl("img", {
      attr: {
        src: this.imageAttachment.dataUrl,
        alt: this.imageAttachment.name,
      },
    });
    preview.createDiv({
      cls: "lna-image-meta",
      text: `${text("imageReady")}: ${this.imageAttachment.name} (${Math.round(
        this.imageAttachment.size / 1024
      )} KB)`,
    });
  }

  clearImageAttachment() {
    this.imageAttachment = null;
    this.renderImageAttachment();
    if (this.statusEl) this.statusEl.setText(t(this.plugin.settings, "ready"));
  }

  addImageUserMessage(prompt, image) {
    const text = (key) => t(this.plugin.settings, key);
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-user" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    bubble.createDiv({ text: `${text("imageToMarkdown")}: ${prompt || image.name}` });
    const details = bubble.createEl("details", { cls: "lna-user-image-details" });
    details.createEl("summary", { text: image.name });
    const thumb = details.createDiv({ cls: "lna-user-image" });
    thumb.createEl("img", {
      attr: {
        src: image.dataUrl,
        alt: image.name,
      },
    });
    this.scrollToBottom();
  }

  normalizeIntentText(text) {
    return String(text || "").toLowerCase();
  }

  isBlankDraftIntent(text) {
    const value = this.normalizeIntentText(text);
    return /空白草稿|新建空白|创建空白|blank draft|empty draft/.test(value);
  }

  isGenerateDraftIntent(text) {
    const value = this.normalizeIntentText(text);
    return /生成.*草稿|创建.*草稿|新建.*草稿|写.*草稿|draft note|create draft|generate draft/.test(value);
  }

  isSelectionEditIntent(text) {
    const value = this.normalizeIntentText(text);
    const hasSelectionWord = /选中|所选|这段|这一段|selected|selection/.test(value);
    const hasEditWord = /改写|修改|润色|整理|补充|扩写|缩写|翻译|rewrite|revise|edit|polish|expand|translate/.test(value);
    return hasSelectionWord || hasEditWord;
  }

  hasSelectionReference(text) {
    return /选中|所选|这段|这一段|selected|selection/.test(this.normalizeIntentText(text));
  }

  isCurrentDraftEditIntent(text) {
    const value = this.normalizeIntentText(text);
    const mentionsDraft = /当前草稿|这篇草稿|草稿|全文|整篇|draft/.test(value);
    const hasEditWord = /修改|改写|整理|润色|补充|删除|重写|调整|优化|扩写|缩写|rewrite|revise|edit|polish|organize|expand|delete/.test(value);
    return mentionsDraft && hasEditWord;
  }

  isDraftInsertIntent(text) {
    const value = this.normalizeIntentText(text);
    const hasInsertWord = /插入|添加|加入|加到|放到|补到|补在|写入|放在|接在|追加到|insert|add|put|place/.test(value);
    const hasRememberedTarget = Boolean(this.lastInsertionTarget) && /那里|该处|同一处|原处|刚才的位置|same place|there/.test(value);
    return hasInsertWord && (Boolean(this.extractInsertTarget(text)) || hasRememberedTarget);
  }

  isTopicSynthesisIntent(text) {
    const value = String(text || "");
    if (!value.trim()) return false;
    const wantsOrganize =
      /\u6574\u7406|\u68b3\u7406|\u6c47\u603b|\u603b\u7ed3|\u7efc\u8ff0|\u751f\u6210.*\u4e3b\u9898|\u751f\u6210.*\u7b14\u8bb0|\u751f\u6210.*\u6587\u4ef6|\u76f8\u5173\u5185\u5bb9|topic synthesis|synthesize|organize|summarize/i.test(
        value
      );
    const notesScope = /\u7b14\u8bb0|notes?|vault|\u5e93\u4e2d|\u6211\u7684|\u76f8\u5173/i.test(value);
    const excludesDraftEdit =
      /\u5f53\u524d\u8349\u7a3f|\u9009\u4e2d|\u63d2\u5165|\u8ffd\u52a0|\u6539\u5199|\u6da6\u8272|\u4fee\u6539\u8349\u7a3f|draft edit|insert/i.test(
        value
      );
    return wantsOrganize && notesScope && !excludesDraftEdit;
  }

  extractTopicSynthesisTopic(text) {
    return String(text || "")
      .replace(/\u8bf7|\u5e2e\u6211|\u4e3a\u6211|\u6839\u636e|\u57fa\u4e8e|\u6211\u7684|\u7b14\u8bb0\u4e2d|\u7b14\u8bb0\u91cc|notes?|vault/gi, " ")
      .replace(/\u6574\u7406|\u68b3\u7406|\u6c47\u603b|\u603b\u7ed3|\u7efc\u8ff0|\u751f\u6210|\u521b\u5efa|\u4e00\u4e2a|\u4e00\u7bc7|\u4e3b\u9898\u7b14\u8bb0|\u4e3b\u9898\u6574\u7406|\u76f8\u5173\u5185\u5bb9|\u6587\u4ef6|AI generated|synthesize|organize|summarize/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  extractInsertTarget(text) {
    const raw = String(text || "");
    const tagMatch = raw.match(/(?:<!--\s*([A-Za-z0-9_\-\u0080-\uffff]{1,80})\s*-->)|(?:\[\[([^\]\n]{1,80})\]\])|(?:#([A-Za-z0-9_\-\u0080-\uffff]{1,80}))|(?:\b(tag[A-Za-z0-9_\-]{0,60})\b)/i);
    if (tagMatch) {
      return (tagMatch[1] || tagMatch[2] || tagMatch[3] || tagMatch[4] || "").trim();
    }
    const placeWords = "(?:\\u5904|\\u4f4d\\u7f6e|\\u9644\\u8fd1|\\u540e\\u9762|\\u524d\\u9762|\\u4e0b\\u9762|\\u4e0a\\u9762|\\u540e|\\u524d)";
    const draftWords = "(?:\\u5f53\\u524d\\u8349\\u7a3f|\\u8349\\u7a3f|\\u7b14\\u8bb0|note)?";
    const insertWords = "(?:\\u63d2\\u5165|\\u6dfb\\u52a0|\\u52a0\\u5165|\\u52a0\\u5230|\\u653e\\u5230|\\u8865\\u5230|\\u8865\\u5728|\\u5199\\u5165|\\u653e\\u5728|\\u63a5\\u5728|\\u8ffd\\u52a0\\u5230)";
    const patterns = [
      new RegExp(`\\u5728\\s*${draftWords}\\s*([^\\s,，。；;：:]{1,80})\\s*${placeWords}?\\s*${insertWords}`, "i"),
      new RegExp(`${insertWords}[\\s\\S]{0,80}?(?:\\u5230|\\u5728)\\s*${draftWords}\\s*([^\\s,，。；;：:]{1,80})\\s*${placeWords}?`, "i"),
      /(?:at|after|before|below|above|near)\s+([#\w-]{1,80})/i,
    ];
    for (const pattern of patterns) {
      const match = raw.match(pattern);
      if (match && match[1]) {
        return this.normalizeInsertionTarget(match[1]);
      }
    }
    return "";
  }

  getInsertPosition(text) {
    const value = this.normalizeIntentText(text);
    if (/前面|上面|之前|前|before|above/.test(value)) return "before";
    return "after";
  }

  extractQuotedInsertion(text) {
    const raw = String(text || "");
    const fence = raw.match(/```(?:markdown|md)?\s*\n([\s\S]*?)\n```/i);
    if (fence && fence[1] && fence[1].trim().length > 0) return fence[1].trim();
    const quote = raw.match(/[“"]([^”"]{8,})[”"]|[‘']([^’']{8,})[’']/);
    if (quote) return (quote[1] || quote[2] || "").trim();
    const afterColon = raw.match(/(?:内容|文本|如下|为)[:：]\s*([\s\S]{8,})$/);
    if (afterColon) return afterColon[1].trim();
    return "";
  }

  getDirectInsertionForPrompt(text, target) {
    const quoted = this.extractQuotedInsertion(text);
    if (quoted) return quoted;
    const answer = String(this.lastAssistantAnswer || "").trim();
    if (!answer) return "";
    const value = this.normalizeIntentText(text);
    if (/刚才|上面|上一|前面|这个证明|这段证明|这个定理|这段|这个回答|上一条|previous|above|last answer|that proof|this proof/.test(value)) {
      return answer;
    }
    const remaining = String(text || "")
      .replace(target || "", "")
      .replace(this.lastInsertionTarget || "", "")
      .replace(/#\s*/g, "")
      .replace(/在|到|把|将|请|帮我|插入|添加|加入|加到|放到|补到|补在|写入|放在|接在|追加到|处|位置|附近|后面|前面|下面|上面|之后|之前|后|前|insert|add|put|place|after|before|below|above|near/gi, "")
      .replace(/[，。；;：:,.!?！？\s]/g, "")
      .trim();
    return remaining.length <= 4 ? answer : "";
  }

  extractDraftTopic(text) {
    return String(text || "")
      .replace(/请|帮我|为我/g, "")
      .replace(/创建|新建|生成|写|一个|一篇|空白|草稿|blank draft|empty draft|draft note|create draft|generate draft/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  async buildAgentState(hasDraftSelection = null, prompt = "") {
    const outline = this.plugin.lastDraftPath ? await this.plugin.getDraftOutline(this.plugin.lastDraftPath) : [];
    return {
      hasImage: Boolean(this.imageAttachment),
      hasCurrentDraft: Boolean(this.plugin.lastDraftPath),
      currentDraftPath: this.plugin.lastDraftPath || "",
      draftOutline: outline.slice(0, 20).map((heading) => heading.text),
      hasDraftSelection: hasDraftSelection === null ? await this.plugin.hasActiveDraftSelection() : hasDraftSelection,
      hasLastAssistantAnswer: Boolean(this.lastAssistantAnswer),
      assistantArtifacts: this.assistantArtifacts.map((artifact) => ({
        id: artifact.id,
        kind: artifact.kind,
        label: artifact.label,
        summary: artifact.summary,
      })),
      longTermMemory: this.plugin.getMemorySummaries ? this.plugin.getMemorySummaries(20) : [],
      relevantMemory: this.plugin.getRelevantMemorySummaries ? this.plugin.getRelevantMemorySummaries(prompt, 8) : [],
      memoryStats: this.plugin.getMemoryStats ? this.plugin.getMemoryStats() : {},
      negativeFeedback: this.plugin.getNegativeFeedbackSummaries ? this.plugin.getNegativeFeedbackSummaries(8) : [],
      lastInsertionTarget: this.lastInsertionTarget || "",
      writeMode: this.plugin.settings.writeMode,
    };
  }

  async executeAgentTask(prompt, initialState = null, routedSteps = null) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return true;
    this.statusEl.setText(text("agentWorking"));
    const state = initialState || (await this.buildAgentState(null, prompt));
    let steps = this.plugin.normalizeAgentSteps(routedSteps || []);
    if (!steps.length) {
      steps = await this.withToolStatus(text("agentPlan"), text("toolReasonRoute"), () =>
        this.plugin.planAgentTask(prompt, state)
      );
    }
    if (!steps.length) return false;
    if (this.plugin.settings.confirmAgentPlans) {
      await this.addAgentPlanPreview(prompt, state, steps);
      return true;
    }

    return this.executeAgentSteps(prompt, state, steps);
  }

  async executeAgentSteps(prompt, initialState, steps) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return true;
    this.statusEl.setText(text("agentWorking"));
    let workingText = "";
    let touchedFile = null;
    const summary = [];
    for (const step of steps) {
      if (step.action === "use_artifact") {
        const status = this.beginToolStatus("use_artifact", text("toolReasonPanel"));
        workingText = this.getArtifactForRoute(step, prompt) || workingText;
        this.setToolStatus(status, "done");
        summary.push(`use_artifact ${step.artifactId || step.sourceQuery || ""}`.trim());
        continue;
      }

      if (step.action === "use_memory") {
        const status = this.beginToolStatus("use_memory", text("toolReasonPanel"));
        workingText = this.plugin.getMemoryContentForRoute(step, prompt) || workingText;
        this.setToolStatus(status, "done");
        summary.push(`use_memory ${step.memoryId || step.sourceQuery || ""}`.trim());
        continue;
      }

      if (step.action === "generate_markdown") {
        const draftContext = this.plugin.lastDraftPath ? await this.plugin.getDraftContext(this.plugin.lastDraftPath) : "";
        const sourceText = workingText || this.getArtifactForRoute(step, prompt) || this.lastAssistantAnswer;
        workingText = await this.withToolStatus("generate_markdown", text("toolReasonDraft"), () =>
          this.plugin.generateAgentMarkdown(step.instruction || prompt, sourceText, draftContext)
        );
        this.rememberAssistantArtifact("agent", workingText, step.instruction || prompt);
        summary.push("generate_markdown");
        continue;
      }

      if (step.action === "image_to_markdown") {
        if (!this.imageAttachment) {
          this.addAssistantMessage(text("imageRequired"));
          return true;
        }
        workingText = await this.withToolStatus(text("imageToMarkdown"), text("toolReasonImage"), () =>
          this.plugin.imageToMarkdown(this.buildImageInstruction(step.instruction || prompt), this.imageAttachment)
        );
        await this.addAnswerMessage(workingText, []);
        this.clearImageAttachment();
        summary.push("image_to_markdown");
        continue;
      }

      if (step.action === "formal_note_proposal") {
        const report = await this.withToolStatus(text("formalProposal"), text("toolReasonSearch"), () =>
          this.plugin.generateFormalNoteProposal(step.instruction || step.query || prompt)
        );
        workingText = report.markdown || "";
        await this.addAnswerMessage(workingText, report.results || []);
        summary.push("formal_note_proposal");
        continue;
      }

      if (step.action === "search_answer") {
        const query = step.query || step.instruction || prompt;
        const conversationContext = this.getConversationContext();
        const useNotes = this.plugin.settings.answerSourceMode !== "model_only";
        const searchResponse = useNotes
          ? await this.withToolStatus(text("toolSearch"), text("toolReasonSearch"), () =>
              this.plugin.search(this.plugin.buildConversationSearchQuery(query, conversationContext))
            )
          : { mode: "model", results: [] };
        workingText = await this.withToolStatus(text("toolAnswer"), text("toolReasonAnswer"), () =>
          this.plugin.answerWithSources(query, searchResponse.results || [], conversationContext)
        );
        await this.addAnswerMessage(workingText, searchResponse.results || []);
        summary.push("search_answer");
        continue;
      }

      if (step.action === "create_blank_draft") {
        if (this.plugin.settings.writeMode !== "draft") {
          this.addAssistantMessage(text("writeDisabled"));
          return true;
        }
        touchedFile = await this.withToolStatus(text("blankDraft"), text("toolReasonDraft"), () =>
          this.plugin.createDraftNote(step.topic || this.extractDraftTopic(prompt) || prompt || "Untitled", "")
        );
        this.addDraftCreatedMessage(touchedFile);
        await this.plugin.openPath(touchedFile.path);
        summary.push(`create_blank_draft ${touchedFile.path}`);
        continue;
      }

      if (step.action === "insert_into_draft") {
        if (this.plugin.settings.writeMode !== "draft") {
          this.addAssistantMessage(text("writeDisabled"));
          return true;
        }
        const target = step.target || this.extractInsertTarget(prompt) || this.lastInsertionTarget;
        const directText =
          step.directText ||
          (step.useWorkingText ? workingText : "") ||
          this.getArtifactForRoute(step, prompt) ||
          this.plugin.getMemoryContentForRoute(step, prompt) ||
          workingText ||
          this.lastAssistantAnswer;
        touchedFile = await this.withToolStatus(text("insertedIntoDraft"), text("toolReasonDraft"), () =>
          this.plugin.insertIntoCurrentDraft(
            step.instruction || prompt,
            target,
            step.position || this.getInsertPosition(prompt),
            directText,
            workingText || this.lastAssistantAnswer
          )
        );
        this.lastInsertionTarget = target;
        summary.push(`insert_into_draft ${target || "(end)"}`);
        continue;
      }

      if (step.action === "edit_current_draft") {
        if (this.plugin.settings.writeMode !== "draft") {
          this.addAssistantMessage(text("writeDisabled"));
          return true;
        }
        touchedFile = await this.withToolStatus(text("editDraft"), text("toolReasonDraft"), () =>
          this.plugin.editCurrentDraft(step.instruction || prompt)
        );
        summary.push("edit_current_draft");
        continue;
      }

      if (step.action === "edit_selection") {
        if (this.plugin.settings.writeMode !== "draft") {
          this.addAssistantMessage(text("writeDisabled"));
          return true;
        }
        touchedFile = await this.withToolStatus(text("editSelection"), text("toolReasonDraft"), () =>
          this.plugin.editActiveDraftSelection(step.instruction || prompt)
        );
        summary.push("edit_selection");
      }
    }

    await this.refreshDraftBar();
    if (this.plugin.lastDraftChangeSummary) {
      this.addAssistantMessage(`${text("draftChangeSummary")}: ${this.plugin.lastDraftChangeSummary}`);
    }
    if (touchedFile) {
      new Notice(`${text("agentFinished")}: ${touchedFile.path}`);
      this.addAssistantMessage(`${text("agentFinished")}: ${touchedFile.path}`);
      if (this.plugin.logTask) {
        await this.plugin.logTask({
          goal: prompt,
          file: touchedFile.path,
          steps: summary,
          change: this.plugin.lastDraftChangeSummary || "",
        });
      }
      await this.addAgentSelfCheck(prompt, touchedFile.path, summary);
    } else if (workingText) {
      this.addAssistantMessage(text("agentFinished"));
      if (this.plugin.logTask) {
        await this.plugin.logTask({
          goal: prompt,
          file: "",
          steps: summary,
          change: "",
        });
      }
    }
    return true;
  }

  async addAgentPlanPreview(prompt, state, steps) {
    const text = (key) => t(this.plugin.settings, key);
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    bubble.createDiv({ cls: "lna-result-summary", text: text("agentPlan") });
    const planSummary = this.summarizeAgentPlan(prompt, state, steps);
    const summaryBox = bubble.createDiv({ cls: "lna-agent-plan-summary" });
    summaryBox.createDiv({ cls: "lna-result-summary", text: text("agentPlanSummary") });
    const summaryList = summaryBox.createEl("ul");
    summaryList.createEl("li", { text: `${text("agentPlanGoal")}: ${planSummary.goal || "(empty)"}` });
    summaryList.createEl("li", { text: `${text("agentPlanWrites")}: ${planSummary.writes}` });
    summaryList.createEl("li", { text: `${text("agentPlanReads")}: ${planSummary.reads}` });
    if (planSummary.target) summaryList.createEl("li", { text: `${text("agentPlanTarget")}: ${planSummary.target}` });
    if (planSummary.currentDraft) summaryList.createEl("li", { text: `${text("currentDraft")}: ${planSummary.currentDraft}` });
    if (planSummary.safety) summaryList.createEl("li", { text: `${text("agentPlanSafety")}: ${planSummary.safety}` });
    const list = bubble.createEl("ol", { cls: "lna-agent-plan" });
    for (let index = 0; index < steps.length; index += 1) {
      list.createEl("li", { text: this.formatAgentPlanStep(steps[index], index) });
    }
    bubble.createDiv({ cls: "lna-result-summary", text: text("planEditor") });
    const editor = bubble.createEl("textarea", {
      cls: "lna-plan-editor",
      attr: { rows: "8" },
    });
    editor.value = JSON.stringify(steps, null, 2);
    const actions = bubble.createDiv({ cls: "lna-draft-actions" });
    const runButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("runAgentPlan"),
      attr: { type: "button" },
    });
    const cancelButton = actions.createEl("button", {
      text: text("cancelAgentPlan"),
      attr: { type: "button" },
    });
    this.pendingAgentPlan = { prompt, state, steps, editor, runButton, cancelButton, running: false };
    runButton.addEventListener("click", async () => {
      await this.runPendingAgentPlan();
    });
    cancelButton.addEventListener("click", () => {
      this.cancelPendingAgentPlan();
    });
    this.inputEl.focus();
    this.scrollToBottom();
  }

  async runPendingAgentPlan() {
    const text = (key) => t(this.plugin.settings, key);
    const pending = this.pendingAgentPlan;
    if (!pending || pending.running) return;
    if (this.blockIfAiPaused()) return;
    pending.running = true;
    pending.runButton.disabled = true;
    pending.cancelButton.disabled = true;
    try {
      let steps = pending.steps;
      if (pending.editor && pending.editor.value.trim()) {
        const parsed = JSON.parse(pending.editor.value);
        steps = this.plugin.normalizeAgentSteps(Array.isArray(parsed) ? parsed : parsed.steps);
      }
      await this.executeAgentSteps(pending.prompt, pending.state, steps);
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
    } finally {
      this.pendingAgentPlan = null;
    }
  }

  cancelPendingAgentPlan() {
    const text = (key) => t(this.plugin.settings, key);
    const pending = this.pendingAgentPlan;
    if (!pending || pending.running) return;
    pending.runButton.disabled = true;
    pending.cancelButton.disabled = true;
    this.pendingAgentPlan = null;
    this.addAssistantMessage(text("agentCancelled"));
  }

  summarizeAgentPlan(prompt, state, steps) {
    const text = (key) => t(this.plugin.settings, key);
    const catalog = new Map((this.plugin.getAgentToolCatalog ? this.plugin.getAgentToolCatalog() : []).map((tool) => [tool.action, tool]));
    const writeSteps = (steps || []).filter((step) => catalog.get(step.action) && catalog.get(step.action).writes);
    const draftWrites = writeSteps.filter((step) =>
      ["topic_synthesis", "agent_task", "create_blank_draft", "generate_draft", "insert_into_draft", "edit_current_draft", "edit_selection"].includes(
        step.action
      )
    );
    const readSources = new Set();
    const targets = new Set();
    for (const step of steps || []) {
      if (["search_answer", "topic_synthesis", "generate_draft"].includes(step.action)) readSources.add("notes");
      if (step.action === "use_artifact" || step.artifactId || step.useLastAnswer) readSources.add("recent answer");
      if (step.action === "use_memory" || step.memoryId) readSources.add("memory");
      if (step.action === "image_to_markdown") readSources.add("image");
      if (step.target) targets.add(step.target);
    }
    const safety = [];
    if (!writeSteps.length) safety.push(text("agentPlanReadOnly"));
    if (draftWrites.length) safety.push(text("agentPlanDraftOnly"));
    if ((steps || []).some((step) => step.action === "formal_note_proposal")) safety.push(text("agentPlanFormalSafe"));
    if ((steps || []).some((step) => step.action === "insert_into_draft") && !targets.size) safety.push(text("agentPlanNoTarget"));
    return {
      goal: cleanSnippet(prompt || "", 180),
      writes: writeSteps.length ? draftWrites.map((step) => catalog.get(step.action)?.label || step.action).join(", ") : text("agentPlanReadOnly"),
      reads: readSources.size ? [...readSources].join(", ") : text("agentPlanReadOnly"),
      target: targets.size ? [...targets].join(", ") : "",
      safety: safety.join(" / "),
      hasFormalProposal: (steps || []).some((step) => step.action === "formal_note_proposal"),
      stepCount: (steps || []).length,
      currentDraft: state && state.currentDraftPath ? state.currentDraftPath : "",
    };
  }

  formatAgentPlanStep(step, index) {
    const catalog = new Map((this.plugin.getAgentToolCatalog ? this.plugin.getAgentToolCatalog() : []).map((tool) => [tool.action, tool]));
    const tool = catalog.get(step.action) || {};
    const parts = [`${index + 1}. ${tool.label || step.action}`];
    if (step.target) parts.push(`target=${step.target}`);
    if (step.position) parts.push(`position=${step.position}`);
    if (step.artifactId) parts.push(`artifact=${step.artifactId}`);
    if (step.memoryId) parts.push(`memory=${step.memoryId}`);
    if (step.sourceQuery) parts.push(`source=${cleanSnippet(step.sourceQuery, 80)}`);
    if (step.directText) parts.push("direct text");
    if (step.useWorkingText) parts.push("working text");
    return parts.join(" | ");
  }

  async addAgentSelfCheck(prompt, path, summary) {
    const text = (key) => t(this.plugin.settings, key);
    try {
      const draftContext = await this.plugin.getDraftContext(path);
      const review = await this.plugin.reviewAgentResult(prompt, summary.join("\n"), draftContext);
      if (review) this.addAssistantMessage(`${text("agentSelfCheck")}:\n${review}`);
    } catch (error) {
      console.warn("Agent self-check failed", error);
    }
  }

  async handleAutoAction(query, effectivePrompt = null) {
    const text = (key) => t(this.plugin.settings, key);
    const command = this.plugin.parseToolKeyword(query);
    const prompt = effectivePrompt === null ? (command ? command.text : query || "") : effectivePrompt || query || "";
    const keywordRoute = command ? this.plugin.routeFromToolKeyword(command, prompt, { hasImage: Boolean(this.imageAttachment) }) : null;
    if (keywordRoute && keywordRoute.action === "pause_ai") {
      await this.setAiPaused(true);
      return true;
    }
    if (keywordRoute && keywordRoute.action === "resume_ai") {
      await this.setAiPaused(false);
      return true;
    }
    if (keywordRoute && keywordRoute.action === "memory") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new MemoryModal(this.app, this.plugin, this).open();
      });
      return true;
    }
    if (keywordRoute && keywordRoute.action === "knowledge") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new KnowledgeIndexModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (keywordRoute && keywordRoute.action === "concept_cards") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new ConceptCardReviewModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (keywordRoute && keywordRoute.action === "migration_tool") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationToolModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (keywordRoute && keywordRoute.action === "migration_review") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationReviewModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (keywordRoute && keywordRoute.action === "chatgpt_handoff") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new ChatGptHandoffModal(this.app, this.plugin, this, prompt).open();
      });
      return true;
    }
    if (keywordRoute && keywordRoute.action === "topic_synthesis") {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("topicSynthesis"));
      const topic = keywordRoute.topic || this.extractTopicSynthesisTopic(prompt) || prompt || command.keyword;
      const report = await this.withToolStatus(text("topicSynthesis"), text("toolReasonDraft"), () =>
        this.plugin.generateTopicSynthesisFile(topic, this.getConversationContext())
      );
      await this.refreshDraftBar();
      await this.plugin.openPath(report.file.path);
      new Notice(`${text("topicSynthesisCreated")}: ${report.file.path}`);
      this.addAssistantMessage(`${text("topicSynthesisCreated")}: ${report.file.path}`);
      this.recordConversationTurn(`[${text("topicSynthesis")}] ${prompt}`, report.markdown, report.results || []);
      return true;
    }
    if (this.plugin.isUndoMigrationRequest(prompt)) {
      try {
        const report = await this.withToolStatus(text("noteMigration"), text("toolReasonMigration"), () =>
          this.plugin.undoLastFormalMigration()
        );
        await this.addAnswerMessage(report.markdown, []);
        this.recordConversationTurn(`[${text("noteMigration")}] ${prompt}`, report.markdown, []);
      } catch (error) {
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      }
      return true;
    }
    if (this.plugin.isOpenMigrationReviewRequest(prompt)) {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationToolModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (this.plugin.isListRiskMigrationRequest(prompt)) {
      try {
        const report = await this.withToolStatus(text("noteMigration"), text("toolReasonMigration"), () =>
          this.plugin.listMigrationRiskCandidates()
        );
        await this.addAnswerMessage(report.markdown, report.results || []);
        this.recordConversationTurn(`[${text("noteMigration")}] ${prompt}`, report.markdown, report.results || []);
      } catch (error) {
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      }
      return true;
    }
    if (this.plugin.isReviewMigrationCandidateRequest(prompt)) {
      try {
        const report = await this.withToolStatus(text("noteMigration"), text("toolReasonMigration"), () =>
          this.plugin.reviewMigrationCandidate(prompt)
        );
        await this.addAnswerMessage(report.markdown, report.results || []);
        this.recordConversationTurn(`[${text("noteMigration")}] ${prompt}`, report.markdown, report.results || []);
      } catch (error) {
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      }
      return true;
    }
    if (this.plugin.isApplyReviewedMigrationRequest(prompt)) {
      try {
        const report = await this.withToolStatus(text("noteMigration"), text("toolReasonMigration"), () =>
          this.plugin.applyReviewedMigrationCandidate(prompt)
        );
        await this.addAnswerMessage(report.markdown, report.results || []);
        this.recordConversationTurn(`[${text("noteMigration")}] ${prompt}`, report.markdown, report.results || []);
      } catch (error) {
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      }
      return true;
    }
    if (this.plugin.isApplyLowRiskMigrationRequest(prompt)) {
      try {
        const report = await this.withToolStatus(text("noteMigration"), text("toolReasonMigration"), () =>
          this.plugin.applyLastMigrationLowRisk()
        );
        await this.addAnswerMessage(report.markdown, report.results || []);
        this.recordConversationTurn(`[${text("noteMigration")}] ${prompt}`, report.markdown, report.results || []);
      } catch (error) {
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      }
      return true;
    }
    if (this.plugin.isNoteMigrationRequest(prompt)) {
      this.statusEl.setText(text("noteMigrationScanning"));
      try {
        const report = await this.withToolStatus(text("noteMigration"), text("toolReasonMigration"), () =>
          this.plugin.previewNoteMigration(prompt)
        );
        await this.addAnswerMessage(report.markdown, report.results || []);
        this.recordConversationTurn(`[${text("noteMigration")}] ${prompt}`, report.markdown, report.results || []);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
      }
      return true;
    }
    const hasDraftSelection = await this.plugin.hasActiveDraftSelection();
    let agentState = null;
    let route = null;
    try {
      agentState = await this.buildAgentState(hasDraftSelection, prompt);
      this.statusEl.setText(text("autoAction"));
      route =
        keywordRoute ||
        (await this.withToolStatus(text("toolRoute"), text("toolReasonRoute"), () =>
          this.plugin.routeUserIntent(prompt, agentState)
        ));
    } catch (error) {
      console.warn("Intent router failed, falling back to local rules", error);
      route = keywordRoute;
    }

    if (route && route.action === "pause_ai") {
      await this.setAiPaused(true);
      return true;
    }

    if (route && route.action === "resume_ai") {
      await this.setAiPaused(false);
      return true;
    }

    if (route && route.action === "memory") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new MemoryModal(this.app, this.plugin, this).open();
      });
      return true;
    }

    if (route && route.action === "knowledge") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new KnowledgeIndexModal(this.app, this.plugin).open();
      });
      return true;
    }
    if (route && route.action === "concept_cards") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new ConceptCardReviewModal(this.app, this.plugin).open();
      });
      return true;
    }

    if (route && route.action === "migration_tool") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationToolModal(this.app, this.plugin).open();
      });
      return true;
    }

    if (route && route.action === "migration_review") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonMigration"), async () => {
        new MigrationReviewModal(this.app, this.plugin).open();
      });
      return true;
    }

    if (route && route.action === "chatgpt_handoff") {
      await this.withToolStatus(text("toolOpenPanel"), text("toolReasonPanel"), async () => {
        new ChatGptHandoffModal(this.app, this.plugin, this, prompt).open();
      });
      return true;
    }

    if (route && route.action === "formal_note_proposal") {
      const report = await this.withToolStatus(text("formalProposal"), text("toolReasonSearch"), () =>
        this.plugin.generateFormalNoteProposal(prompt)
      );
      await this.addAnswerMessage(report.markdown, report.results || []);
      this.recordConversationTurn(`[${text("formalProposal")}] ${prompt}`, report.markdown, report.results || []);
      return true;
    }

    if (route && route.action === "check_index_changes") {
      await this.checkIndexChanges();
      return true;
    }

    if (route && route.action === "update_changed_index") {
      await this.updateChangedIndex();
      return true;
    }

    if (route && route.action === "build_index") {
      await this.rebuildIndex();
      return true;
    }

    if (route && route.action === "agent_task") {
      return this.executeAgentTask(prompt, agentState, route.steps);
    }

    if (route && route.action === "image_to_markdown" && !this.imageAttachment) {
      this.addAssistantMessage(text("imageRequired"));
      return true;
    }

    if ((route && route.action === "image_to_markdown") || (!route && this.imageAttachment)) {
      this.statusEl.setText(text("convertingImage"));
      const answer = await this.withToolStatus(text("imageToMarkdown"), text("toolReasonImage"), () =>
        this.plugin.imageToMarkdown(this.buildImageInstruction(prompt), this.imageAttachment)
      );
      await this.addAnswerMessage(answer, []);
      this.recordConversationTurn(`[${text("imageToMarkdown")}] ${prompt}`, answer, []);
      this.clearImageAttachment();
      return true;
    }

    if (
      this.isTopicSynthesisIntent(prompt) &&
      (!route || route.action === "search_answer" || route.action === "generate_draft")
    ) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("topicSynthesis"));
      const topic = this.extractTopicSynthesisTopic(prompt) || prompt;
      const report = await this.withToolStatus(text("topicSynthesis"), text("toolReasonDraft"), () =>
        this.plugin.generateTopicSynthesisFile(topic, this.getConversationContext())
      );
      await this.refreshDraftBar();
      await this.plugin.openPath(report.file.path);
      new Notice(`${text("topicSynthesisCreated")}: ${report.file.path}`);
      this.addAssistantMessage(`${text("topicSynthesisCreated")}: ${report.file.path}`);
      this.recordConversationTurn(`[${text("topicSynthesis")}] ${prompt}`, report.markdown, report.results || []);
      return true;
    }

    if ((route && route.action === "create_blank_draft") || (!route && this.isBlankDraftIntent(prompt))) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("creatingBlankDraft"));
      const topic = (route && route.topic) || this.extractDraftTopic(prompt) || prompt || "Untitled";
      const file = await this.withToolStatus(text("blankDraft"), text("toolReasonDraft"), () =>
        this.plugin.createDraftNote(topic, "")
      );
      this.addDraftCreatedMessage(file);
      await this.refreshDraftBar();
      await this.plugin.openPath(file.path);
      return true;
    }

    if ((route && route.action === "generate_draft") || (!route && this.isGenerateDraftIntent(prompt))) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("drafting"));
      const topic = (route && route.topic) || this.extractDraftTopic(prompt) || prompt;
      const draft = await this.withToolStatus(text("draftNote"), text("toolReasonDraft"), () =>
        this.plugin.generateDraft(topic, this.getConversationContext())
      );
      await this.addDraftPreview(topic, draft);
      return true;
    }

    if ((route && route.action === "insert_into_draft") || (!route && this.isDraftInsertIntent(prompt))) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("editingDraftDirectly"));
      const target = (route && route.target) || this.extractInsertTarget(prompt) || this.lastInsertionTarget;
      const routedArtifact = route ? this.getArtifactForRoute(route, prompt) : "";
      const directInsertion =
        (route && route.directText) ||
        routedArtifact ||
        (route && route.useLastAnswer ? this.lastAssistantAnswer : "") ||
        this.getDirectInsertionForPrompt(prompt, target);
      const file = await this.withToolStatus(text("insertedIntoDraft"), text("toolReasonDraft"), () =>
        this.plugin.insertIntoCurrentDraft(
          prompt,
          target,
          (route && route.position) || this.getInsertPosition(prompt),
          directInsertion,
          routedArtifact || this.lastAssistantAnswer
        )
      );
      this.lastInsertionTarget = target;
      await this.refreshDraftBar();
      new Notice(`${text("insertedIntoDraft")}: ${file.path}`);
      this.addAssistantMessage(`${text("insertedIntoDraft")}: ${file.path}`);
      return true;
    }

    if ((route && route.action === "edit_selection") || (!route && hasDraftSelection && this.hasSelectionReference(prompt))) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("editingSelection"));
      const file = await this.withToolStatus(text("editSelection"), text("toolReasonDraft"), () =>
        this.plugin.editActiveDraftSelection(prompt)
      );
      await this.refreshDraftBar();
      new Notice(`${text("selectionEdited")}: ${file.path}`);
      this.addAssistantMessage(`${text("selectionEdited")}: ${file.path}`);
      return true;
    }

    if ((route && route.action === "edit_current_draft") || (!route && this.isCurrentDraftEditIntent(prompt))) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("editingDraftDirectly"));
      const file = await this.withToolStatus(text("editDraft"), text("toolReasonDraft"), () =>
        this.plugin.editCurrentDraft(prompt)
      );
      await this.refreshDraftBar();
      new Notice(`${text("draftEditedDirectly")}: ${file.path}`);
      this.addAssistantMessage(`${text("draftEditedDirectly")}: ${file.path}`);
      return true;
    }

    if (!route && hasDraftSelection && this.isSelectionEditIntent(prompt)) {
      if (this.plugin.settings.writeMode !== "draft") {
        this.addAssistantMessage(text("writeDisabled"));
        return true;
      }
      this.statusEl.setText(text("editingSelection"));
      const file = await this.withToolStatus(text("editSelection"), text("toolReasonDraft"), () =>
        this.plugin.editActiveDraftSelection(prompt)
      );
      await this.refreshDraftBar();
      new Notice(`${text("selectionEdited")}: ${file.path}`);
      this.addAssistantMessage(`${text("selectionEdited")}: ${file.path}`);
      return true;
    }

    return false;
  }

  async convertImageToMarkdown(searchButton, draftButton, blankDraftButton, imageMarkdownButton) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    if (!this.plugin.settings.enableImageInput) {
      this.addAssistantMessage(text("imageInputDisabled"));
      return;
    }
    if (!this.imageAttachment) {
      this.addAssistantMessage(text("imageRequired"));
      return;
    }

    const prompt = this.inputEl.value.trim();
    searchButton.disabled = true;
    draftButton.disabled = true;
    blankDraftButton.disabled = true;
    imageMarkdownButton.disabled = true;
    try {
      await this.convertCurrentImageToMarkdown(prompt);
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("answerFailed")}: ${error.message || error}`);
    } finally {
      searchButton.disabled = false;
      draftButton.disabled = false;
      blankDraftButton.disabled = false;
      imageMarkdownButton.disabled = false;
      this.statusEl.setText(text("ready"));
      this.inputEl.focus();
    }
  }

  async convertCurrentImageToMarkdown(promptOverride = null) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return false;
    if (!this.plugin.settings.enableImageInput) {
      this.addAssistantMessage(text("imageInputDisabled"));
      return false;
    }
    if (!this.imageAttachment) {
      this.addAssistantMessage(text("imageRequired"));
      return false;
    }
    const prompt = promptOverride === null ? this.inputEl.value.trim() : String(promptOverride || "").trim();
    this.statusEl.setText(text("convertingImage"));
    this.addImageUserMessage(prompt, this.imageAttachment);
    this.pendingFeedbackQuestion = `[${text("imageToMarkdown")}] ${prompt}`;
    if (this.inputEl) this.inputEl.value = "";
    const answer = await this.withToolStatus(text("imageToMarkdown"), text("toolReasonImage"), () =>
      this.plugin.imageToMarkdown(this.buildImageInstruction(prompt), this.imageAttachment)
    );
    await this.addAnswerMessage(answer, []);
    this.recordConversationTurn(`[${text("imageToMarkdown")}] ${prompt}`, answer, []);
    return true;
  }

  async editCurrentDraftFromInput(searchButton, draftButton, blankDraftButton, editDraftButton, editSelectionButton) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    const instruction = this.inputEl.value.trim();
    if (!instruction) {
      this.addAssistantMessage(text("draftInstructionRequired"));
      return;
    }
    if (this.plugin.settings.writeMode !== "draft") {
      this.addAssistantMessage(text("writeDisabled"));
      return;
    }

    searchButton.disabled = true;
    draftButton.disabled = true;
    blankDraftButton.disabled = true;
    editDraftButton.disabled = true;
    editSelectionButton.disabled = true;
    this.statusEl.setText(text("editingDraftDirectly"));
    this.addUserMessage(`${text("editDraft")}: ${instruction}`);
    try {
      const file = await this.withToolStatus(text("editDraft"), text("toolReasonDraft"), () =>
        this.plugin.editCurrentDraft(instruction)
      );
      this.inputEl.value = "";
      await this.refreshDraftBar();
      new Notice(`${text("draftEditedDirectly")}: ${file.path}`);
      this.addAssistantMessage(`${text("draftEditedDirectly")}: ${file.path}`);
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
    } finally {
      searchButton.disabled = false;
      draftButton.disabled = false;
      blankDraftButton.disabled = false;
      editDraftButton.disabled = false;
      editSelectionButton.disabled = false;
      this.statusEl.setText(text("ready"));
      this.inputEl.focus();
    }
  }

  async editActiveDraftSelectionFromInput(searchButton, draftButton, blankDraftButton, editSelectionButton) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    const instruction = this.inputEl.value.trim();
    if (this.plugin.settings.writeMode !== "draft") {
      this.addAssistantMessage(text("writeDisabled"));
      return;
    }

    searchButton.disabled = true;
    draftButton.disabled = true;
    blankDraftButton.disabled = true;
    editSelectionButton.disabled = true;
    this.statusEl.setText(text("editingSelection"));
    try {
      const file = await this.withToolStatus(text("editSelection"), text("toolReasonDraft"), () =>
        this.plugin.editActiveDraftSelection(instruction)
      );
      this.inputEl.value = "";
      await this.refreshDraftBar();
      new Notice(`${text("selectionEdited")}: ${file.path}`);
      this.addAssistantMessage(`${text("selectionEdited")}: ${file.path}`);
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
    } finally {
      searchButton.disabled = false;
      draftButton.disabled = false;
      blankDraftButton.disabled = false;
      editSelectionButton.disabled = false;
      this.statusEl.setText(text("ready"));
      this.inputEl.focus();
    }
  }

  async generateDraftFromInput(searchButton, draftButton, blankDraftButton) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    const topic = this.inputEl.value.trim();
    if (!topic) return;
    if (this.plugin.settings.writeMode !== "draft") {
      this.addAssistantMessage(text("writeDisabled"));
      return;
    }

    searchButton.disabled = true;
    draftButton.disabled = true;
    blankDraftButton.disabled = true;
    this.statusEl.setText(text("drafting"));
    this.addUserMessage(`${text("draftNote")}: ${topic}`);
    this.inputEl.value = "";
    try {
      const conversationContext = this.getConversationContext();
      const draft = await this.withToolStatus(text("draftNote"), text("toolReasonDraft"), () =>
        this.plugin.generateDraft(topic, conversationContext)
      );
      await this.addDraftPreview(topic, draft);
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("draftFailed")}: ${error.message || error}`);
    } finally {
      searchButton.disabled = false;
      draftButton.disabled = false;
      blankDraftButton.disabled = false;
      this.statusEl.setText(text("ready"));
      this.inputEl.focus();
    }
  }

  async createBlankDraftFromInput(searchButton, draftButton, blankDraftButton) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    const topic = this.inputEl.value.trim();
    if (!topic) return;
    if (this.plugin.settings.writeMode !== "draft") {
      this.addAssistantMessage(text("writeDisabled"));
      return;
    }

    searchButton.disabled = true;
    draftButton.disabled = true;
    blankDraftButton.disabled = true;
    this.statusEl.setText(text("creatingBlankDraft"));
    this.addUserMessage(`${text("blankDraft")}: ${topic}`);
    this.inputEl.value = "";
    try {
      const file = await this.withToolStatus(text("blankDraft"), text("toolReasonDraft"), () =>
        this.plugin.createDraftNote(topic, "")
      );
      this.addDraftCreatedMessage(file);
      await this.refreshDraftBar();
      await this.plugin.openPath(file.path);
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`${text("draftFailed")}: ${error.message || error}`);
    } finally {
      searchButton.disabled = false;
      draftButton.disabled = false;
      blankDraftButton.disabled = false;
      this.statusEl.setText(text("ready"));
      this.inputEl.focus();
    }
  }

  renderDraftBar() {
    if (!this.draftBarEl) return;
    const text = (key) => t(this.plugin.settings, key);
    this.draftBarEl.empty();

    const path = this.plugin.lastDraftPath || "";
    this.draftBarEl.createSpan({
      cls: "lna-draft-label",
      text: `${text("currentDraft")}: `,
    });
    this.draftBarEl.createSpan({
      cls: path ? "lna-draft-path" : "lna-draft-empty",
      text: path || text("noDraftSelected"),
    });

    const controls = this.draftBarEl.createDiv({ cls: "lna-draft-bar-actions" });
    const openButton = controls.createEl("button", {
      text: text("openDraft"),
      attr: { type: "button" },
    });
    openButton.disabled = !path;
    openButton.addEventListener("click", async () => {
      if (this.plugin.lastDraftPath) await this.plugin.openPath(this.plugin.lastDraftPath);
    });

    controls.createEl("button", {
      text: text("useActiveDraft"),
      attr: { type: "button" },
    }).addEventListener("click", async () => {
      try {
        const file = await this.plugin.setActiveFileAsDraft();
        this.renderDraftBar();
        new Notice(`${text("activeDraftSet")}: ${file.path}`);
      } catch (error) {
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
      }
    });

    const undoButton = controls.createEl("button", {
      text: text("undoDraftEdit"),
      attr: { type: "button" },
    });
    undoButton.disabled = !this.plugin.lastDraftUndo;
    undoButton.addEventListener("click", async () => {
      try {
        const file = await this.plugin.undoLastDraftEdit();
        await this.refreshDraftBar();
        new Notice(`${text("draftEditUndone")}: ${file.path}`);
        this.addAssistantMessage(`${text("draftEditUndone")}: ${file.path}`);
      } catch (error) {
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
      }
    });

    controls.createEl("button", {
      text: text("clearDraft"),
      attr: { type: "button" },
    }).addEventListener("click", async () => {
      await this.plugin.clearCurrentDraft();
      this.renderDraftBar();
    });

    this.draftOutlineEl = this.draftBarEl.createDiv({ cls: "lna-draft-outline" });
    this.renderDraftOutline(path);
  }

  async refreshDraftBar() {
    this.renderDraftBar();
  }

  async renderDraftOutline(path) {
    if (!this.draftOutlineEl) return;
    const text = (key) => t(this.plugin.settings, key);
    this.draftOutlineEl.empty();
    if (!path) return;
    try {
      const headings = await this.plugin.getDraftOutline(path);
      const details = this.draftOutlineEl.createEl("details", { cls: "lna-draft-outline-details" });
      details.createEl("summary", {
        text: `${text("draftOutline")}: ${headings.length || text("noDraftHeadings")}`,
      });
      const list = details.createEl("ul");
      for (const heading of headings) {
        const item = list.createEl("li", {
          cls: `lna-draft-outline-depth-${Math.min(heading.level, 6)}`,
        });
        const link = item.createEl("button", {
          text: heading.text,
          attr: { type: "button" },
        });
        link.addEventListener("click", async () => {
          await this.plugin.openPathAtLine(path, heading.line);
        });
      }
      const anchors = await this.plugin.getDraftAnchors(path);
      if (anchors.length) {
        const anchorDetails = this.draftOutlineEl.createEl("details", { cls: "lna-draft-outline-details" });
        anchorDetails.createEl("summary", { text: `${text("anchors")}: ${anchors.length}` });
        const anchorList = anchorDetails.createEl("ul");
        for (const anchor of anchors.slice(0, 30)) {
          const item = anchorList.createEl("li");
          const link = item.createEl("button", {
            text: anchor.text,
            attr: { type: "button" },
          });
          link.addEventListener("click", async () => {
            await this.plugin.openPathAtLine(path, anchor.line);
          });
        }
      }
      if (Array.isArray(this.plugin.taskLog) && this.plugin.taskLog.length) {
        const logDetails = this.draftOutlineEl.createEl("details", { cls: "lna-draft-outline-details" });
        logDetails.createEl("summary", { text: `${text("taskLog")}: ${this.plugin.taskLog.length}` });
        const logList = logDetails.createEl("ul");
        for (const task of this.plugin.taskLog.slice(-5).reverse()) {
          logList.createEl("li", { text: `${cleanSnippet(task.goal || "", 80)} - ${cleanSnippet(task.change || task.stepsText || "", 120)}` });
        }
      }
    } catch (error) {
      this.draftOutlineEl.createDiv({ cls: "lna-warning", text: error.message || String(error) });
    }
  }

  getSelectionInside(container) {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return "";
    const text = selection.toString().trim();
    if (!text) return "";
    const range = selection.getRangeAt(0);
    const startNode = range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer
      : range.startContainer.parentElement;
    const endNode = range.endContainer.nodeType === Node.ELEMENT_NODE
      ? range.endContainer
      : range.endContainer.parentElement;
    if (!startNode || !endNode) return "";
    if (!container.contains(startNode) || !container.contains(endNode)) return "";
    return text;
  }

  async appendSelectionFromBubble(bubble) {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    const selected = this.getSelectionInside(bubble);
    if (!selected) {
      this.addAssistantMessage(text("noSelection"));
      return;
    }
    const file = await this.withToolStatus(text("appendSelectionToDraft"), text("toolReasonDraft"), () =>
      this.plugin.appendSelectionToCurrentDraft(selected)
    );
    await this.refreshDraftBar();
    new Notice(`${text("appendedToDraft")}: ${file.path}`);
    this.addAssistantMessage(`${text("appendedToDraft")}: ${file.path}`);
  }

  async startNewChat() {
    this.conversation = [];
    this.lastUserQuestion = "";
    this.pendingFeedbackQuestion = "";
    this.lastAssistantAnswer = "";
    this.assistantArtifacts = [];
    this.lastInsertionTarget = "";
    if (this.plugin.startMemoryConversation) {
      await this.plugin.startMemoryConversation();
    }
    if (this.messagesEl) {
      this.messagesEl.empty();
      this.addAssistantMessage(this.plugin.getIndexStatusText());
    }
  }

  resetChatPanel() {
    this.conversation = [];
    this.lastUserQuestion = "";
    this.pendingFeedbackQuestion = "";
    this.lastAssistantAnswer = "";
    this.assistantArtifacts = [];
    this.lastInsertionTarget = "";
    this.pendingAgentPlan = null;
    if (!this.messagesEl) return;
    const text = (key) => t(this.plugin.settings, key);
    this.messagesEl.empty();
    this.addAssistantMessage(this.plugin.getIndexStatusText());
  }

  parseMemoryConversationTurn(item) {
    const content = String((item && item.content) || "");
    const match = content.match(/^Question:\n([\s\S]*?)\n\nAnswer:\n([\s\S]*?)(?:\n\nSources:\n([\s\S]*))?$/);
    if (!match) return null;
    return {
      question: match[1].trim(),
      answer: match[2].trim(),
      sourcesText: (match[3] || "").trim(),
      createdAt: item.createdAt || "",
    };
  }

  async addRestoredAnswerMessage(answer) {
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    const answerEl = bubble.createDiv({ cls: "lna-answer markdown-rendered" });
    await MarkdownRenderer.renderMarkdown(answer || "", answerEl, "", this);
    this.scrollToBottom();
  }

  async restoreMemoryConversation(conversationId) {
    const text = (key) => t(this.plugin.settings, key);
    const conversation = await this.plugin.switchMemoryConversation(conversationId);
    if (!conversation || !this.messagesEl) return;
    this.conversation = [];
    this.lastUserQuestion = "";
    this.pendingFeedbackQuestion = "";
    this.lastAssistantAnswer = "";
    this.assistantArtifacts = [];
    this.lastInsertionTarget = "";
    this.pendingAgentPlan = null;
    this.messagesEl.empty();
    this.addAssistantMessage(`${text("conversationRestored")}: ${conversation.title || text("memoryConversation")}`);
    const turns = this.plugin
      .getMemoryItemsForConversation(conversationId)
      .filter((item) => item.kind === "conversation")
      .map((item) => this.parseMemoryConversationTurn(item))
      .filter(Boolean);
    if (!turns.length) {
      this.addAssistantMessage(text("noMemory"));
      return;
    }
    for (const turn of turns) {
      this.addUserMessage(turn.question);
      await this.addRestoredAnswerMessage(turn.answer);
      this.lastUserQuestion = turn.question;
      this.conversation.push({
        question: turn.question,
        answer: cleanSnippet(turn.answer || "", 1000),
        sources: [],
      });
      const artifact = {
        id: this.assistantArtifacts.length + 1,
        kind: "answer",
        label: turn.question || "Restored answer",
        summary: cleanSnippet(turn.answer || "", 240),
        content: turn.answer || "",
        createdAt: turn.createdAt || new Date().toISOString(),
      };
      this.assistantArtifacts.push(artifact);
      this.lastAssistantAnswer = artifact.content;
    }
    const limit = this.plugin.getConversationTurnLimit();
    this.conversation = limit > 0 ? this.conversation.slice(-limit) : [];
    this.scrollToBottom();
  }

  getConversationContext() {
    if (!this.plugin.settings.useConversationMemory) return [];
    const limit = this.plugin.getConversationTurnLimit();
    if (limit <= 0) return [];
    return this.conversation.slice(-limit);
  }

  isUnsatisfiedFeedbackIntent(text) {
    const value = String(text || "").trim();
    if (!value) return false;
    const negative = /\u4e0d\u6ee1\u610f|\u4e0d\u597d|\u4e0d\u5bf9|\u9519\u4e86|\u6709\u95ee\u9898|\u5931\u8d25|\u7f16\u9020|\u5e7b\u89c9|\u5f15\u7528\u9519|\u6765\u6e90\u9519|bad answer|unsatisfied|wrong response|not satisfied/i.test(value);
    const answerRef = /\u8fd9\u6b21|\u521a\u624d|\u521a\u521a|\u4e0a\u6b21|\u4e0a\u4e00\u8f6e|\u56de\u7b54|\u7b54\u6848|\u7ed3\u679c|\u4f60|answer|response|previous|last/i.test(value);
    return negative && answerRef;
  }

  extractUnsatisfiedReason(text) {
    return String(text || "")
      .replace(/^\s*(\u8fd9\u6b21|\u521a\u624d|\u521a\u521a|\u4e0a\u6b21|\u4e0a\u4e00\u8f6e)?\s*(\u56de\u7b54|\u7b54\u6848|\u7ed3\u679c)?\s*(\u8ba9\u6211)?\s*(\u5f88)?\s*(\u4e0d\u6ee1\u610f|\u4e0d\u597d|\u4e0d\u5bf9|\u9519\u4e86|\u6709\u95ee\u9898|\u5931\u8d25)\s*[,，:：-]?\s*/i, "")
      .replace(/^\s*(because|because:|reason:|unsatisfied:|bad answer:)\s*/i, "")
      .trim();
  }

  async handleUnsatisfiedFeedbackPrompt(text) {
    const label = (key) => t(this.plugin.settings, key);
    if (!this.isUnsatisfiedFeedbackIntent(text)) return false;
    const answer = String(this.lastAssistantAnswer || "").trim();
    if (!answer) {
      this.addAssistantMessage(label("unsatisfiedMissingAnswer"));
      return true;
    }
    const reason = this.extractUnsatisfiedReason(text) || text;
    await this.plugin.addNegativeFeedback({
      question: this.lastUserQuestion || this.pendingFeedbackQuestion || "",
      answer,
      reason,
      conversationId: this.plugin.currentMemoryConversationId || "",
    });
    this.pendingFeedbackQuestion = "";
    this.addAssistantMessage(label("unsatisfiedSaved"));
    new Notice(label("unsatisfiedSaved"));
    return true;
  }

  recordConversationTurn(question, answer, results) {
    this.lastUserQuestion = question || this.lastUserQuestion || "";
    this.pendingFeedbackQuestion = "";
    if (this.plugin && this.plugin.rememberMemoryItem && answer) {
      const sourceText = (results || [])
        .slice(0, 5)
        .map((result) => `${result.path}${result.heading ? `#${result.heading}` : ""}`)
        .join("\n");
      this.plugin.rememberMemoryItem({
        kind: "conversation",
        label: question || "Question",
        summary: cleanSnippet(`${question}\n${answer}`, 240),
        content: `Question:\n${question}\n\nAnswer:\n${answer}${sourceText ? `\n\nSources:\n${sourceText}` : ""}`,
      }).catch((error) => console.warn("Could not save conversation memory", error));
      this.plugin.renameCurrentMemoryConversation(question).catch((error) =>
        console.warn("Could not rename memory conversation", error)
      );
    }
    if (!this.plugin.settings.useConversationMemory) return;
    const limit = this.plugin.getConversationTurnLimit();
    if (limit <= 0) return;
    this.conversation.push({
      question,
      answer: cleanSnippet(answer || "", 1000),
      sources: (results || []).slice(0, 5).map((result) => ({
        path: result.path,
        heading: result.heading,
      })),
    });
    this.conversation = this.conversation.slice(-limit);
  }

  rememberAssistantArtifact(kind, content, label = "") {
    const text = String(content || "").trim();
    if (!text) return null;
    const artifact = {
      id: this.assistantArtifacts.length + 1,
      kind,
      label: label || kind,
      summary: cleanSnippet(text, 240),
      content: text,
      createdAt: new Date().toISOString(),
    };
    this.assistantArtifacts.push(artifact);
    const keep = Number.parseInt(this.plugin.settings.assistantArtifactsToKeep, 10) || 12;
    this.assistantArtifacts = this.assistantArtifacts.slice(-Math.max(1, Math.min(keep, 50)));
    for (let index = 0; index < this.assistantArtifacts.length; index += 1) {
      this.assistantArtifacts[index].id = index + 1;
    }
    this.lastAssistantAnswer = text;
    if (this.plugin && this.plugin.rememberMemoryItem && kind !== "answer") {
      this.plugin.rememberMemoryItem({
        kind,
        label: label || kind,
        summary: artifact.summary,
        content: text,
      }).catch((error) => console.warn("Could not save assistant memory", error));
    }
    return artifact;
  }

  getArtifactForRoute(route, prompt = "") {
    if (!this.assistantArtifacts.length) {
      return this.plugin.getMemoryContentForRoute ? this.plugin.getMemoryContentForRoute(route, prompt) : "";
    }
    const id = Number.parseInt(route && (route.artifactId || route.sourceId), 10);
    if (Number.isFinite(id) && id > 0) {
      const byId = this.assistantArtifacts.find((artifact) => artifact.id === id);
      if (byId) return byId.content;
    }
    const sourceQuery = String((route && (route.sourceQuery || route.sourceHint)) || prompt || "").trim();
    if (sourceQuery) {
      const queryTerms = tokenize(sourceQuery);
      let best = null;
      let bestScore = 0;
      for (const artifact of this.assistantArtifacts) {
        const score = lineScore(`${artifact.label} ${artifact.summary} ${artifact.content.slice(0, 1000)}`, queryTerms);
        if (score > bestScore) {
          best = artifact;
          bestScore = score;
        }
      }
      const memoryText = this.plugin.getMemoryContentForRoute ? this.plugin.getMemoryContentForRoute(route, prompt) : "";
      if (
        memoryText &&
        (/之前|早些|历史|记忆|某次|earlier|history|memory/i.test(sourceQuery) || bestScore === 0)
      ) {
        return memoryText;
      }
      if (best && bestScore > 0) return best.content;
    }
    if (route && route.useLastAnswer) return this.assistantArtifacts[this.assistantArtifacts.length - 1].content;
    return this.plugin.getMemoryContentForRoute ? this.plugin.getMemoryContentForRoute(route, prompt) : "";
  }

  async rebuildIndex() {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    this.addAssistantMessage(text("buildingIndex"));
    this.statusEl.setText(text("indexing"));
    try {
      await this.withToolStatus(text("buildIndex"), text("toolReasonSearch"), () =>
        this.plugin.buildIndex((message) => {
          this.statusEl.setText(message);
        })
      );
      this.addAssistantMessage(this.plugin.getIndexStatusText());
      new Notice(text("indexRebuilt"));
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`Index build failed: ${error.message || error}`);
      new Notice(text("indexFailed"));
    } finally {
      this.statusEl.setText(text("ready"));
    }
  }

  formatIndexChangePlan(plan) {
    const text = (key) => t(this.plugin.settings, key);
    const added = Array.isArray(plan && plan.added) ? plan.added : [];
    const modified = Array.isArray(plan && plan.modified) ? plan.modified : [];
    const deleted = Array.isArray(plan && plan.deleted) ? plan.deleted : [];
    const unchanged = Array.isArray(plan && plan.unchanged) ? plan.unchanged : [];
    const changedPaths = [...added, ...modified, ...deleted].map((item) => item.path).filter(Boolean);
    const lines = [
      `${text("indexChangeSummary")}:`,
      `${text("indexAdded")}: ${added.length}`,
      `${text("indexModified")}: ${modified.length}`,
      `${text("indexDeleted")}: ${deleted.length}`,
      `${text("indexUnchanged")}: ${unchanged.length}`,
      `${text("indexEstimateChunks")}: ${Number(plan && plan.estimatedChunks) || 0}`,
    ];
    if (plan && plan.fullRebuildNeeded) {
      lines.push(text("indexFullRebuildNeeded"));
    } else if (!changedPaths.length) {
      lines.push(text("indexNoChanges"));
    }
    if (changedPaths.length) {
      lines.push("");
      lines.push(...changedPaths.slice(0, 12).map((path) => `- ${path}`));
      if (changedPaths.length > 12) lines.push(`... ${changedPaths.length - 12} more`);
    }
    return lines.join("\n");
  }

  async checkIndexChanges() {
    const text = (key) => t(this.plugin.settings, key);
    this.statusEl.setText(text("indexing"));
    try {
      const plan = await this.withToolStatus(text("checkIndexChanges"), text("toolReasonSearch"), () =>
        this.plugin.getSemanticIndexChangePlan({ estimateChunks: true })
      );
      this.addAssistantMessage(this.formatIndexChangePlan(plan));
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`Index check failed: ${error.message || error}`);
    } finally {
      this.statusEl.setText(text("ready"));
    }
  }

  async updateChangedIndex() {
    const text = (key) => t(this.plugin.settings, key);
    if (this.blockIfAiPaused()) return;
    this.statusEl.setText(text("indexing"));
    try {
      const plan = await this.plugin.getSemanticIndexChangePlan({ estimateChunks: true });
      this.addAssistantMessage(this.formatIndexChangePlan(plan));
      if (plan.fullRebuildNeeded) {
        new Notice(text("indexFullRebuildNeeded"));
        return;
      }
      if (!plan.hasChanges) {
        new Notice(text("indexNoChanges"));
        return;
      }
      const limit = this.plugin.getIncrementalIndexChunkLimit();
      if (plan.estimatedChunks > limit) {
        this.addAssistantMessage(`${text("indexUpdateBlockedByLimit")} (${plan.estimatedChunks}/${limit})`);
        new Notice(text("indexUpdateBlockedByLimit"));
        return;
      }
      const index = await this.withToolStatus(text("updateChangedIndex"), text("toolReasonSearch"), () =>
        this.plugin.buildIndexIncremental((message) => {
          this.statusEl.setText(message);
        }, plan)
      );
      const stats = index && index.lastIncrementalUpdate ? index.lastIncrementalUpdate : {};
      this.addAssistantMessage(
        [
          text("indexIncrementalUpdated"),
          `${text("indexReusedChunks")}: ${Number(stats.reusedChunkCount) || 0}`,
          `${text("indexEmbeddedChunks")}: ${Number(stats.embeddedChunkCount) || 0}`,
          `${text("indexDeletedChunks")}: ${Number(stats.deletedChunkCount) || 0}`,
        ].join("\n")
      );
      new Notice(text("indexIncrementalUpdated"));
    } catch (error) {
      console.error(error);
      this.addAssistantMessage(`Index update failed: ${error.message || error}`);
      new Notice(text("indexFailed"));
    } finally {
      this.statusEl.setText(text("ready"));
    }
  }

  addUserMessage(text) {
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-user" });
    message.createDiv({ cls: "lna-bubble", text });
    this.scrollToBottom();
  }

  addAssistantMessage(text) {
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    message.createDiv({ cls: "lna-bubble", text });
    this.scrollToBottom();
  }

  async addAnswerMessage(answer, results) {
    const text = (key) => t(this.plugin.settings, key);
    const feedbackQuestion = this.pendingFeedbackQuestion || this.lastUserQuestion || "";
    this.rememberAssistantArtifact("answer", answer, "Assistant answer");
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    const answerEl = bubble.createDiv({ cls: "lna-answer markdown-rendered" });
    await MarkdownRenderer.renderMarkdown(answer, answerEl, "", this);

    const answerActions = bubble.createDiv({ cls: "lna-answer-actions" });
    const rewriteButton = answerActions.createEl("button", {
      text: text("rewriteForDraft"),
      attr: { type: "button" },
    });
    rewriteButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      rewriteButton.disabled = true;
      rewriteButton.setText(text("rewritingForDraft"));
      try {
        const rewritten = await this.withToolStatus(text("rewriteForDraft"), text("toolReasonDraft"), () =>
          this.plugin.rewriteAnswerForDraft(answer, results)
        );
        await this.addRewrittenDraftPreview(rewritten);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
      } finally {
        rewriteButton.setText(text("rewriteForDraft"));
        rewriteButton.disabled = false;
      }
    });
    const appendSelectionButton = answerActions.createEl("button", {
      text: text("appendSelectionToDraft"),
      attr: { type: "button" },
    });
    appendSelectionButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      appendSelectionButton.disabled = true;
      try {
        await this.appendSelectionFromBubble(bubble);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
      } finally {
        appendSelectionButton.disabled = false;
      }
    });
    const appendButton = answerActions.createEl("button", {
      text: text("appendToDraft"),
      attr: { type: "button" },
    });
    appendButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      appendButton.disabled = true;
      try {
        const file = await this.withToolStatus(text("appendToDraft"), text("toolReasonDraft"), () =>
          this.plugin.appendAnswerToCurrentDraft(answer, results)
        );
        await this.refreshDraftBar();
        new Notice(`${text("appendedToDraft")}: ${file.path}`);
        this.addAssistantMessage(`${text("appendedToDraft")}: ${file.path}`);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
        appendButton.disabled = false;
      }
    });
    const feedbackButton = answerActions.createEl("button", {
      cls: "lna-feedback-button",
      text: text("markUnsatisfied"),
      attr: { type: "button" },
    });
    feedbackButton.addEventListener("click", () => {
      new NegativeFeedbackModal(this.app, this.plugin, {
        question: feedbackQuestion,
        answer,
        onSave: () => {
          this.addAssistantMessage(text("unsatisfiedSaved"));
        },
      }).open();
    });

    const sourceList = bubble.createDiv({ cls: "lna-sources" });
    sourceList.createDiv({ cls: "lna-result-summary", text: text("sources") });
    for (const [index, result] of results.slice(0, this.plugin.settings.answerContextLimit).entries()) {
      const source = sourceList.createDiv({ cls: "lna-source" });
      const button = source.createEl("button", {
        cls: "lna-result-path",
        text: `[${index + 1}] ${result.path}`,
        attr: { type: "button" },
      });
      button.addEventListener("click", async () => {
        await this.plugin.openPath(result.path);
      });
    }
    this.scrollToBottom();
  }

  async addRewrittenDraftPreview(markdown) {
    const text = (key) => t(this.plugin.settings, key);
    this.rememberAssistantArtifact("rewrite", markdown, "Rewritten draft preview");
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    bubble.createDiv({ cls: "lna-result-summary", text: text("rewrittenPreview") });
    const preview = bubble.createDiv({ cls: "lna-draft-preview markdown-rendered" });
    await MarkdownRenderer.renderMarkdown(markdown, preview, "", this);
    const actions = bubble.createDiv({ cls: "lna-draft-actions" });
    const appendButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("appendRewrittenToDraft"),
      attr: { type: "button" },
    });
    appendButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      appendButton.disabled = true;
      try {
        const file = await this.withToolStatus(text("appendRewrittenToDraft"), text("toolReasonDraft"), () =>
          this.plugin.appendRewrittenToCurrentDraft(markdown)
        );
        await this.refreshDraftBar();
        new Notice(`${text("appendedToDraft")}: ${file.path}`);
        this.addAssistantMessage(`${text("appendedToDraft")}: ${file.path}`);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
        appendButton.disabled = false;
      }
    });
    this.scrollToBottom();
  }

  async addDraftPreview(topic, draft) {
    const text = (key) => t(this.plugin.settings, key);
    this.rememberAssistantArtifact("draft", draft, topic || "Draft preview");
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    bubble.createDiv({ cls: "lna-result-summary", text: text("draftPreview") });
    const draftEl = bubble.createDiv({ cls: "lna-draft-preview markdown-rendered" });
    await MarkdownRenderer.renderMarkdown(draft, draftEl, "", this);

    const actions = bubble.createDiv({ cls: "lna-draft-actions" });
    const createButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("createDraft"),
      attr: { type: "button" },
    });
    createButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      createButton.disabled = true;
      createButton.setText(text("creatingDraft"));
      try {
        const file = await this.withToolStatus(text("createDraft"), text("toolReasonDraft"), () =>
          this.plugin.createDraftNote(topic, draft)
        );
        this.renderDraftCreatedLink(bubble, file);
        await this.refreshDraftBar();
        new Notice(`${text("draftCreated")}: ${file.path}`);
        createButton.remove();
        await this.plugin.openPath(file.path);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("draftFailed")}: ${error.message || error}`);
        createButton.setText(text("createDraft"));
        createButton.disabled = false;
      }
    });
    this.scrollToBottom();
  }

  addDraftCreatedMessage(file) {
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    this.renderDraftCreatedLink(bubble, file);
    const text = (key) => t(this.plugin.settings, key);
    new Notice(`${text("draftCreated")}: ${file.path}`);
    this.scrollToBottom();
  }

  renderDraftCreatedLink(container, file) {
    const text = (key) => t(this.plugin.settings, key);
    const created = container.createDiv({ cls: "lna-draft-created" });
    created.createSpan({ text: `${text("draftCreated")}: ` });
    const link = created.createEl("button", {
      cls: "lna-result-path",
      text: file.path,
      attr: { type: "button" },
    });
    link.addEventListener("click", async () => {
      await this.plugin.openPath(file.path);
    });
  }

  async addResultsMessage(query, response) {
    const message = this.messagesEl.createDiv({ cls: "lna-message lna-assistant" });
    const bubble = message.createDiv({ cls: "lna-bubble" });
    const results = response.results || [];
    const text = (key) => t(this.plugin.settings, key);

    if (results.length === 0) {
      bubble.createDiv({ text: text("noResults") });
      this.scrollToBottom();
      return;
    }

    bubble.createDiv({
      cls: "lna-result-summary",
      text:
        this.plugin.settings.language === "zh"
          ? `${response.mode === "semantic" ? text("semantic") : text("keyword")}${text(
              "found"
            )} ${results.length} ${text("matchesFor")}：${query}`
          : `${response.mode === "semantic" ? text("semantic") : text("keyword")} ${text(
              "found"
            )} ${results.length} ${text("matchesFor")}: ${query}`,
    });

    if (response.warning) {
      bubble.createDiv({ cls: "lna-warning", text: response.warning });
    }

    const resultActions = bubble.createDiv({ cls: "lna-result-actions" });
    const appendSelectionButton = resultActions.createEl("button", {
      text: text("appendSelectionToDraft"),
      attr: { type: "button" },
    });
    appendSelectionButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      appendSelectionButton.disabled = true;
      try {
        await this.appendSelectionFromBubble(bubble);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
      } finally {
        appendSelectionButton.disabled = false;
      }
    });
    const appendResultsButton = resultActions.createEl("button", {
      text: text("appendResultsToDraft"),
      attr: { type: "button" },
    });
    appendResultsButton.addEventListener("click", async () => {
      if (this.blockIfAiPaused()) return;
      appendResultsButton.disabled = true;
      try {
        const file = await this.withToolStatus(text("appendResultsToDraft"), text("toolReasonDraft"), () =>
          this.plugin.appendSearchResultsToCurrentDraft(query, results)
        );
        await this.refreshDraftBar();
        new Notice(`${text("appendedToDraft")}: ${file.path}`);
        this.addAssistantMessage(`${text("appendedToDraft")}: ${file.path}`);
      } catch (error) {
        console.error(error);
        this.addAssistantMessage(`${text("appendFailed")}: ${error.message || error}`);
        appendResultsButton.disabled = false;
      }
    });

    for (const result of results) {
      const item = bubble.createDiv({ cls: "lna-result" });
      const header = item.createDiv({ cls: "lna-result-header" });
      const pathButton = header.createEl("button", {
        cls: "lna-result-path",
        text: result.path,
        attr: { type: "button" },
      });
      pathButton.addEventListener("click", async () => {
        await this.plugin.openPath(result.path);
      });

      const scoreText =
        response.mode === "semantic" && typeof result.score === "number"
          ? `${text("similarity")}: ${result.score.toFixed(3)}`
          : `${text("score")}: ${Math.round(result.score)}`;
      item.createDiv({ cls: "lna-result-heading", text: `${text("heading")}: ${result.heading}` });
      item.createDiv({ cls: "lna-result-score", text: scoreText });

      const details = item.createEl("details", { cls: "lna-result-details" });
      details.createEl("summary", { text: text("snippet") });
      const snippetEl = details.createDiv({ cls: "lna-result-snippet markdown-rendered" });
      await MarkdownRenderer.renderMarkdown(result.snippet || "", snippetEl, result.path || "", this);
    }

    this.scrollToBottom();
  }

  scrollToBottom() {
    window.setTimeout(() => {
      this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    }, 0);
  }

  async onClose() {
    if (this.toolPanelEl) {
      this.toolPanelEl.remove();
      this.toolPanelEl = null;
    }
  }
}

class MigrationToolModal extends Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    this.oldInput = null;
    this.newInput = null;
    this.searchInput = null;
    this.preciseSymbolInput = null;
    this.modeSelect = null;
    this.oldLabelText = null;
    this.newLabelText = null;
    this.searchLabel = null;
    this.notesInput = null;
    this.resultEl = null;
    this.linkAssistEls = [];
  }

  onOpen() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    if (this.modalEl) this.modalEl.addClass("lna-migration-tool-shell");
    contentEl.empty();
    contentEl.addClass("lna-migration-tool-modal");
    contentEl.createEl("h2", { text: text("migrationToolButton") });
    contentEl.createDiv({
      cls: "lna-modal-desc",
      text: text("migrationToolDesc"),
    });

    const modeLabel = contentEl.createEl("label", { cls: "lna-migration-mode" });
    modeLabel.createSpan({ text: text("migrationMode") });
    this.modeSelect = modeLabel.createEl("select");
    this.modeSelect.createEl("option", { text: text("linkMigrationMode"), value: "link" });
    this.modeSelect.createEl("option", { text: text("pageMigrationMode"), value: "page" });
    this.modeSelect.createEl("option", { text: text("symbolMigrationMode"), value: "symbol" });
    this.modeSelect.addEventListener("change", () => this.updateModeLabels());

    const grid = contentEl.createDiv({ cls: "lna-migration-form" });
    const oldLabel = grid.createEl("label");
    this.oldLabelText = oldLabel.createSpan({ text: text("oldTarget") });
    this.oldInput = oldLabel.createEl("input", {
      attr: { type: "text", placeholder: "[[Old note#^block]]" },
    });
    this.oldInput.addEventListener("input", () => {
      if (this.modeSelect && this.modeSelect.value === "symbol" && this.searchInput && !this.searchInput.value) {
        this.searchInput.placeholder = this.extractCoreSymbol(this.oldInput.value) || "L";
      }
    });

    const newLabel = grid.createEl("label");
    this.newLabelText = newLabel.createSpan({ text: text("newTarget") });
    this.newInput = newLabel.createEl("input", {
      attr: { type: "text", placeholder: "[[New note#Heading]]" },
    });

    this.attachLinkAssist(oldLabel, this.oldInput);
    this.attachLinkAssist(newLabel, this.newInput);

    this.searchLabel = grid.createEl("label", { cls: "lna-symbol-search-row" });
    this.searchLabel.createSpan({ text: text("searchSymbol") });
    this.searchInput = this.searchLabel.createEl("input", {
      attr: { type: "text", placeholder: "A" },
    });

    this.preciseSymbolLabel = grid.createEl("label", { cls: "lna-symbol-precise-row" });
    const preciseRow = this.preciseSymbolLabel.createDiv({ cls: "lna-inline-check" });
    this.preciseSymbolInput = preciseRow.createEl("input", {
      attr: { type: "checkbox" },
    });
    this.preciseSymbolInput.checked = true;
    preciseRow.createSpan({ text: text("preciseSymbolMatch") });

    const notesLabel = contentEl.createEl("label", { cls: "lna-migration-notes" });
    notesLabel.createSpan({ text: text("migrationNotes") });
    this.notesInput = notesLabel.createEl("textarea", {
      attr: {
        rows: "3",
        placeholder: text("migrationNotesPlaceholder"),
      },
    });

    const actions = contentEl.createDiv({ cls: "lna-modal-actions" });
    const scanButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("scanMigration"),
      attr: { type: "button" },
    });
    const reviewButton = actions.createEl("button", {
      text: text("openMigrationReview"),
      attr: { type: "button" },
    });
    reviewButton.disabled = !this.plugin.lastMigrationPreview;
    reviewButton.addEventListener("click", () => {
      new MigrationReviewModal(this.app, this.plugin).open();
    });
    scanButton.addEventListener("click", async () => {
      scanButton.disabled = true;
      reviewButton.disabled = true;
      try {
        const request = this.buildRequest();
        const report =
          request && request.mode === "symbol"
            ? await this.plugin.previewSymbolMigration(
                request.oldTarget,
                request.newTarget,
                request.notes,
                request.searchTarget,
                request.preciseSymbolMatching
              )
            : await this.plugin.previewNoteMigration(request);
        this.renderReport(report.markdown);
        reviewButton.disabled = false;
      } catch (error) {
        this.renderReport(error.message || String(error));
      } finally {
        scanButton.disabled = false;
      }
    });

    this.resultEl = contentEl.createDiv({ cls: "lna-migration-tool-result" });
    this.updateModeLabels();
  }

  updateModeLabels() {
    const text = (key) => t(this.plugin.settings, key);
    const mode = this.modeSelect ? this.modeSelect.value : "link";
    if (mode === "symbol") {
      this.setLinkAssistVisible(false);
      if (this.oldLabelText) this.oldLabelText.setText(text("oldSymbolContext"));
      if (this.newLabelText) this.newLabelText.setText(text("newSymbol"));
      if (this.oldInput) this.oldInput.placeholder = "$A+\\dots$ (optional)";
      if (this.newInput) this.newInput.placeholder = "B";
      if (this.searchLabel) this.searchLabel.style.display = "";
      if (this.preciseSymbolLabel) this.preciseSymbolLabel.style.display = "";
      if (this.searchInput && !this.searchInput.value) {
        this.searchInput.placeholder = this.extractCoreSymbol(this.oldInput && this.oldInput.value) || "A";
      }
      if (this.notesInput) this.notesInput.placeholder = text("migrationSymbolNotesPlaceholder");
      return;
    }
    if (this.oldLabelText) this.oldLabelText.setText(mode === "page" ? text("oldPage") : text("oldTarget"));
    this.setLinkAssistVisible(true);
    if (this.newLabelText) this.newLabelText.setText(mode === "page" ? `${text("defaultNewPage")} (${lt(this.plugin.settings, "optional", "可选")})` : text("newTarget"));
    if (this.oldInput) this.oldInput.placeholder = mode === "page" ? "[[Old note]]" : "[[Old note#^block]]";
    if (this.newInput) this.newInput.placeholder = mode === "page" ? "[[New note]] (optional)" : "[[New note#Heading]]";
    if (this.searchLabel) this.searchLabel.style.display = "none";
    if (this.preciseSymbolLabel) this.preciseSymbolLabel.style.display = "none";
    if (this.notesInput) this.notesInput.placeholder = text("migrationNotesPlaceholder");
  }

  buildRequest() {
    const oldTarget = this.normalizeTarget(this.oldInput && this.oldInput.value);
    const newTarget = this.normalizeTarget(this.newInput && this.newInput.value);
    const notes = String((this.notesInput && this.notesInput.value) || "").trim();
    if (!oldTarget || !newTarget) {
      throw new Error(t(this.plugin.settings, "noteMigrationNeedTwoLinks"));
    }
    return `把 [[${oldTarget}]] 迁移到 [[${newTarget}]]，全库扫描，先不要修改。${notes ? `\n\n补充说明：${notes}` : ""}`;
  }

  buildRequest() {
    const mode = this.modeSelect ? this.modeSelect.value : "link";
    const oldTarget = this.normalizeTarget(this.oldInput && this.oldInput.value);
    const newTarget = this.normalizeTarget(this.newInput && this.newInput.value);
    const notes = String((this.notesInput && this.notesInput.value) || "").trim();
    if (mode === "symbol") {
      const searchTarget =
        this.normalizeTarget(this.searchInput && this.searchInput.value) || this.extractCoreSymbol(oldTarget);
      if (!searchTarget || !newTarget) {
        throw new Error(t(this.plugin.settings, "noteMigrationNeedTwoLinks"));
      }
      return {
        mode,
        oldTarget,
        newTarget,
        searchTarget,
        preciseSymbolMatching: !this.preciseSymbolInput || this.preciseSymbolInput.checked,
        notes,
      };
    }
    if (mode === "page" && oldTarget && !newTarget) {
      return {
        mode: "page-retarget",
        oldTarget: this.stripAnchor(oldTarget),
        notes,
      };
    }
    if (!oldTarget || !newTarget) {
      throw new Error(t(this.plugin.settings, "noteMigrationNeedTwoLinks"));
    }
    const oldRef = mode === "page" ? this.stripAnchor(oldTarget) : oldTarget;
    const newRef = mode === "page" ? this.stripAnchor(newTarget) : newTarget;
    return this.plugin.settings.language === "zh"
      ? `把 [[${oldRef}]] 迁移到 [[${newRef}]]，全库扫描，先不要修改笔记。${notes ? `\n\n补充说明：${notes}` : ""}`
      : `Migrate [[${oldRef}]] to [[${newRef}]] across the full vault. Scan first and do not modify notes.${notes ? `\n\nNotes: ${notes}` : ""}`;
  }

  stripAnchor(value) {
    return String(value || "").split("#")[0].trim();
  }

  normalizeTarget(value) {
    return String(value || "")
      .trim()
      .replace(/^\[\[/, "")
      .replace(/\]\]$/, "")
      .trim();
  }

  extractCoreSymbol(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const simplified = raw
      .replace(/^\\\(|\\\)$/g, "")
      .replace(/^\\\[|\\\]$/g, "")
      .replace(/^\$+|\$+$/g, "")
      .replace(/\\dots|\\cdots|\\ldots/g, " ")
      .replace(/[{}]/g, " ")
      .trim();
    const command = simplified.match(/\\[A-Za-z]+/);
    const word = simplified.match(/[A-Za-z][A-Za-z0-9_]*/);
    if (word) return word[0];
    if (command) return command[0];
    return simplified;
  }

  renderReport(markdown) {
    if (!this.resultEl) return;
    this.resultEl.empty();
    this.resultEl.createEl("pre", { text: markdown || "" });
  }

  onClose() {
    this.contentEl.empty();
  }

  attachLinkAssist(parent, input) {
    if (!parent || !input) return;
    const listId = `lna-link-suggestions-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    input.setAttr("list", listId);
    const datalist = parent.createEl("datalist", { attr: { id: listId } });
    const preview = parent.createEl("details", { cls: "lna-link-assist-preview" });
    preview.createEl("summary", { text: t(this.plugin.settings, "migrationTargetPreview") });
    const previewBody = preview.createDiv({ cls: "lna-link-assist-preview-body" });
    const update = async () => {
      this.plugin.renderMigrationLinkSuggestions(input, datalist);
      await this.plugin.renderMigrationLinkPreview(input.value, previewBody);
    };
    input.addEventListener("focus", update);
    input.addEventListener("input", update);
    this.linkAssistEls.push({ input, datalist, previewBody });
  }

  setLinkAssistVisible(visible) {
    for (const item of this.linkAssistEls || []) {
      if (item.previewBody && item.previewBody.parentElement) {
        item.previewBody.parentElement.style.display = visible ? "" : "none";
      }
    }
  }
}

class MigrationReviewModal extends Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    this.rows = [];
    this.filterRisk = "all";
    this.filterFolder = "";
    this.formulaOnly = false;
    this.tableWrap = null;
  }

  async onOpen() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    if (this.modalEl) this.modalEl.addClass("lna-migration-review-shell");
    contentEl.empty();
    contentEl.addClass("lna-migration-modal");
    contentEl.createEl("h2", { text: text("migrationReviewButton") });
    try {
      this.rows = await this.plugin.getMigrationReviewRows();
      this.renderRows();
    } catch (error) {
      contentEl.createDiv({ cls: "lna-modal-desc", text: error.message || String(error) });
    }
  }

  renderRows() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    const summary = contentEl.createDiv({ cls: "lna-modal-desc" });
    const applicable = this.rows.filter((row) => row.canApply).length;
    const applied = this.rows.filter((row) => row.alreadyApplied).length;
    summary.setText(
      `${this.rows.length} ${text("migrationCandidateSummary")}, ${applicable} ${text(
        "migrationCanApplySummary"
      )}, ${applied} ${text("migrationAlreadyAppliedSummary")}.`
    );

    const controls = contentEl.createDiv({ cls: "lna-migration-controls" });
    const riskLabel = controls.createEl("label");
    riskLabel.createSpan({ text: text("migrationFilterRisk") });
    const riskSelect = riskLabel.createEl("select");
    [
      ["all", text("allRisk")],
      ["low", text("lowRisk")],
      ["medium", text("mediumRisk")],
      ["high", text("highRisk")],
    ].forEach(([value, label]) => riskSelect.createEl("option", { value, text: label }));
    riskSelect.addEventListener("change", () => {
      this.filterRisk = riskSelect.value;
      this.renderTable();
    });

    const folderLabel = controls.createEl("label");
    folderLabel.createSpan({ text: text("migrationFilterFolder") });
    const folderInput = folderLabel.createEl("input", { attr: { type: "text", placeholder: text("folderFilterPlaceholder") } });
    folderInput.addEventListener("input", () => {
      this.filterFolder = folderInput.value;
      this.renderTable();
    });

    const formulaLabel = controls.createEl("label", { cls: "lna-inline-check" });
    const formulaInput = formulaLabel.createEl("input", { attr: { type: "checkbox" } });
    formulaLabel.createSpan({ text: text("migrationFormulaOnly") });
    formulaInput.addEventListener("change", () => {
      this.formulaOnly = formulaInput.checked;
      this.renderTable();
    });

    const aiButton = controls.createEl("button", { text: text("migrationAiJudge"), attr: { type: "button" } });
    aiButton.addEventListener("click", async () => {
      aiButton.disabled = true;
      try {
        const visible = this.getVisibleRows().map((row) => row.index);
        await this.plugin.judgeMigrationCandidatesWithAI(visible);
        this.rows = await this.plugin.getMigrationReviewRows();
        this.renderTable();
        new Notice(text("migrationAiAdvice"));
      } catch (error) {
        new Notice(error.message || String(error));
      } finally {
        aiButton.disabled = false;
      }
    });

    this.tableWrap = contentEl.createDiv({ cls: "lna-migration-table-wrap" });
    this.renderTable();

    this.renderHistory(contentEl);

    const actions = contentEl.createDiv({ cls: "lna-modal-actions" });
    const applyButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("applySelected"),
      attr: { type: "button" },
    });
    applyButton.addEventListener("click", async () => {
      applyButton.disabled = true;
      try {
        const selected = [...contentEl.querySelectorAll("input[type='checkbox']:checked")]
          .map((input) => {
            const index = Number.parseInt(input.dataset.index, 10);
            const targetInput = contentEl.querySelector(`input[data-target-index="${index}"]`);
            return targetInput ? { index, target: targetInput.value } : index;
          })
          .filter(Boolean);
        const report = await this.plugin.applySelectedMigrationCandidates(selected);
        new Notice(text("selectedApplied"));
        await this.renderAppliedReport(report.markdown);
      } catch (error) {
        new Notice(error.message || String(error));
        applyButton.disabled = false;
      }
    });
  }

  async renderAppliedReport(markdown) {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    const cleanMarkdown = String(markdown || "").replace(
      /You can undo this operation by asking:.*/i,
      this.plugin.settings.language === "zh"
        ? "可以在聊天框输入“撤销上次迁移”来回滚这次操作。"
        : "You can undo this operation by asking: undo last migration."
    );
    contentEl.empty();
    contentEl.addClass("lna-migration-modal");
    contentEl.addClass("lna-migration-success");
    const modalEl = contentEl.closest(".modal");
    if (modalEl) modalEl.scrollTop = 0;
    contentEl.scrollTop = 0;

    const header = contentEl.createDiv({ cls: "lna-migration-success-header" });
    header.createDiv({ cls: "lna-migration-success-mark", text: "✓" });
    const titleWrap = header.createDiv();
    titleWrap.createEl("h2", { text: text("selectedApplied") });
    titleWrap.createDiv({
      cls: "lna-modal-desc",
      text: this.plugin.settings.language === "zh" ? "已完成写入，并已保存撤销快照。" : "Changes were written and an undo snapshot was saved.",
    });

    const body = contentEl.createDiv({ cls: "lna-migration-success-body markdown-rendered" });
    await MarkdownRenderer.renderMarkdown(cleanMarkdown, body, "", this.plugin);

    const actions = contentEl.createDiv({ cls: "lna-modal-actions lna-migration-success-actions" });
    const reviewButton = actions.createEl("button", {
      text: text("migrationReviewButton"),
      attr: { type: "button" },
    });
    reviewButton.addEventListener("click", async () => {
      contentEl.empty();
      contentEl.removeClass("lna-migration-success");
      contentEl.addClass("lna-migration-modal");
      contentEl.createEl("h2", { text: text("migrationReviewButton") });
      this.rows = await this.plugin.getMigrationReviewRows();
      this.renderRows();
    });
    const closeButton = actions.createEl("button", {
      cls: "mod-cta",
      text: this.plugin.settings.language === "zh" ? "关闭" : "Close",
      attr: { type: "button" },
    });
    closeButton.addEventListener("click", () => this.close());
  }

  async renderAppliedReport(markdown) {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    const cleanMarkdown = String(markdown || "").replace(
      /You can undo this operation by asking:.*/i,
      text("migrationUndoHint")
    );
    contentEl.empty();
    contentEl.addClass("lna-migration-modal");
    contentEl.addClass("lna-migration-success");
    const modalEl = contentEl.closest(".modal");
    if (modalEl) modalEl.scrollTop = 0;
    contentEl.scrollTop = 0;

    const header = contentEl.createDiv({ cls: "lna-migration-success-header" });
    header.createDiv({ cls: "lna-migration-success-mark", text: "✓" });
    const titleWrap = header.createDiv();
    titleWrap.createEl("h2", { text: text("selectedApplied") });
    titleWrap.createDiv({
      cls: "lna-modal-desc",
      text: text("selectedAppliedDetail"),
    });

    const body = contentEl.createDiv({ cls: "lna-migration-success-body markdown-rendered" });
    await MarkdownRenderer.renderMarkdown(cleanMarkdown, body, "", this.plugin);

    const actions = contentEl.createDiv({ cls: "lna-modal-actions lna-migration-success-actions" });
    const reviewButton = actions.createEl("button", {
      text: text("migrationReviewButton"),
      attr: { type: "button" },
    });
    reviewButton.addEventListener("click", async () => {
      contentEl.empty();
      contentEl.removeClass("lna-migration-success");
      contentEl.addClass("lna-migration-modal");
      contentEl.createEl("h2", { text: text("migrationReviewButton") });
      this.rows = await this.plugin.getMigrationReviewRows();
      this.renderRows();
    });
    const closeButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("close"),
      attr: { type: "button" },
    });
    closeButton.addEventListener("click", () => this.close());
  }

  getVisibleRows() {
    const folder = String(this.filterFolder || "").trim().toLowerCase();
    return this.rows.filter((row) => {
      if (this.filterRisk !== "all" && row.risk !== this.filterRisk) return false;
      if (this.formulaOnly && !row.hasFormula) return false;
      if (folder && !String(row.path || "").toLowerCase().includes(folder)) return false;
      return true;
    });
  }

  renderTable() {
    const text = (key) => t(this.plugin.settings, key);
    if (!this.tableWrap) return;
    this.tableWrap.empty();
    const visibleRows = this.getVisibleRows();
    this.tableWrap.createDiv({
      cls: "lna-modal-desc",
      text: `${visibleRows.length} ${text("visibleCandidates")}.`,
    });

    const list = this.tableWrap.createDiv({ cls: "lna-migration-review-list" });
    for (const row of visibleRows) {
      const card = list.createDiv({
        cls: row.alreadyApplied
          ? "lna-migration-review-card lna-migration-applied"
          : row.canApply
          ? "lna-migration-review-card lna-migration-can-apply"
          : "lna-migration-review-card lna-migration-cannot-apply",
      });

      const header = card.createDiv({ cls: "lna-migration-card-header" });
      const checkbox = header.createEl("input", { attr: { type: "checkbox" } });
      checkbox.dataset.index = String(row.index);
      checkbox.disabled = !row.canApply;
      checkbox.checked = row.canApply && row.risk === "low";
      header.createSpan({ cls: "lna-migration-card-index", text: `#${row.index}` });
      const riskText =
        row.risk === "low"
          ? text("lowRisk")
          : row.risk === "medium"
          ? text("mediumRisk")
          : row.risk === "high"
          ? text("highRisk")
          : row.risk;
      header.createSpan({
        cls: `lna-risk-pill lna-risk-${row.risk}`,
        text: `${riskText}${row.kind === "superseded_notice" ? ` ${lt(this.plugin.settings, "notice", "提示")}` : ""}${
          row.alreadyApplied ? ` ${text("migrationAlreadyApplied")}` : ""
        }`,
      });
      const fileButton = header.createEl("button", {
        cls: "lna-migration-file-button",
        text: row.path,
        attr: { type: "button" },
      });
      fileButton.addEventListener("click", async () => {
        await this.plugin.openPath(row.path);
      });

      if (row.targetEditable) {
        const targetSection = card.createDiv({ cls: "lna-migration-card-section lna-migration-card-target" });
        targetSection.createDiv({ cls: "lna-migration-card-label", text: text("migrationTarget") });
        const targetInput = targetSection.createEl("input", {
          cls: "lna-migration-target-input",
          attr: {
            type: "text",
            placeholder: text("migrationTargetPlaceholder"),
            value: row.target || "",
          },
        });
        targetInput.dataset.targetIndex = String(row.index);
        const listId = `lna-target-suggestions-${row.index}-${Date.now()}`;
        targetInput.setAttr("list", listId);
        const suggestionList = targetSection.createEl("datalist", { attr: { id: listId } });
        const previewDetails = targetSection.createEl("details", { cls: "lna-link-assist-preview" });
        previewDetails.createEl("summary", { text: text("migrationTargetPreview") });
        const previewEl = previewDetails.createDiv({ cls: "lna-link-assist-preview-body" });
        const updateTargetAssist = async () => {
          this.plugin.renderMigrationLinkSuggestions(targetInput, suggestionList);
          await this.plugin.renderMigrationLinkPreview(targetInput.value, previewEl, { maxLines: 4 });
        };
        const saveTarget = async () => {
          await this.plugin.setMigrationCandidateTarget(row.index, targetInput.value);
          this.rows = await this.plugin.getMigrationReviewRows();
          this.renderTable();
        };
        targetInput.addEventListener("focus", updateTargetAssist);
        targetInput.addEventListener("input", updateTargetAssist);
        targetInput.addEventListener("change", saveTarget);
        targetInput.addEventListener("keydown", async (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            await saveTarget();
          }
        });
        updateTargetAssist();
      }

      const originalSection = card.createDiv({ cls: "lna-migration-card-section" });
      originalSection.createDiv({ cls: "lna-migration-card-label", text: text("migrationOriginal") });
      originalSection.createEl("pre", { text: row.original || `(${text("noneText")})` });

      const changeSection = card.createDiv({ cls: "lna-migration-card-section" });
      changeSection.createDiv({ cls: "lna-migration-card-label", text: text("migrationChange") });
      const changeCell = changeSection.createDiv();
      this.renderDiff(changeCell, row.modified || `(${text("noneText")})`, row);

      const aiSection = card.createDiv({ cls: "lna-migration-card-section" });
      aiSection.createDiv({ cls: "lna-migration-card-label", text: text("migrationAiAdvice") });
      aiSection.createEl("pre", { cls: "lna-migration-ai-advice", text: row.aiAdvice || `(${text("notJudged")})` });
    }
  }

  renderHighlightedLine(container, line, highlight) {
    const text = String(line || "");
    const target = String(highlight || "");
    if (!target) {
      container.appendText(text || " ");
      return;
    }
    let cursor = 0;
    let index = text.indexOf(target, cursor);
    if (index < 0) {
      container.appendText(text || " ");
      return;
    }
    while (index >= 0) {
      if (index > cursor) container.appendText(text.slice(cursor, index));
      container.createSpan({ cls: "lna-symbol-highlight", text: target });
      cursor = index + target.length;
      index = text.indexOf(target, cursor);
    }
    if (cursor < text.length) container.appendText(text.slice(cursor));
  }

  renderDiff(container, diffText, row = {}) {
    const pre = container.createEl("pre", { cls: "lna-migration-diff" });
    const lines = String(diffText || "").split(/\r?\n/);
    for (const line of lines) {
      const cls = line.startsWith("+ ")
        ? "lna-diff-add"
        : line.startsWith("- ")
        ? "lna-diff-remove"
        : line.startsWith("@@")
        ? "lna-diff-hunk"
        : "";
      const span = pre.createEl("span", { cls });
      if (line.startsWith("- ") && row.searchSymbol) {
        this.renderHighlightedLine(span, line || " ", row.searchSymbol);
      } else if (line.startsWith("+ ") && row.newSymbol) {
        this.renderHighlightedLine(span, line || " ", row.newSymbol);
      } else {
        span.setText(line || " ");
      }
      pre.createEl("br");
    }
  }

  renderHistory(container) {
    const history = Array.isArray(this.plugin.migrationHistory) ? this.plugin.migrationHistory.slice(-5).reverse() : [];
    if (!history.length) return;
    const details = container.createEl("details", { cls: "lna-migration-history" });
    details.createEl("summary", { text: t(this.plugin.settings, "migrationHistory") });
    for (const item of history) {
      const when = item.createdAt ? new Date(item.createdAt).toLocaleString() : "";
      details.createEl("pre", {
        text: `${when} ${item.type || "migration"}\n${(item.modified || []).map((path) => `- ${path}`).join("\n")}`,
      });
    }
  }

  onClose() {
    this.contentEl.empty();
  }
}

class ConceptCardReviewModal extends Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    this.filter = "";
    this.queueFilter = "review";
  }

  onOpen() {
    if (this.modalEl) this.modalEl.addClass("lna-concept-card-shell");
    this.render();
  }

  onClose() {
    this.contentEl.empty();
  }

  statusText(card) {
    const text = (key) => t(this.plugin.settings, key);
    if (card.status === "accepted") return text("conceptCardAcceptedStatus");
    if (card.status === "rejected") return text("conceptCardRejectedStatus");
    return this.queueLabel(this.plugin.getConceptCardQueue(card));
  }

  queueLabel(queue) {
    const text = (key) => t(this.plugin.settings, key);
    const labels = {
      all: text("conceptCardQueueAll"),
      review: text("conceptCardQueueReview"),
      auto_pass: text("conceptCardQueueAuto"),
      insufficient: text("conceptCardQueueInsufficient"),
      confirmed: text("conceptCardQueueConfirmed"),
      rejected: text("conceptCardQueueRejected"),
      changed: text("conceptCardQueueChanged"),
    };
    return labels[queue] || labels.review;
  }

  changeStatusText(status) {
    const text = (key) => t(this.plugin.settings, key);
    if (status === "new") return text("conceptCardChangeNew");
    if (status === "changed") return text("conceptCardChangeChanged");
    return text("conceptCardChangeUnchanged");
  }

  cardMatchesFilter(card) {
    const queue = this.plugin.getConceptCardQueue(card);
    if (this.queueFilter && this.queueFilter !== "all") {
      if (this.queueFilter === "changed") {
        if (card.changeStatus !== "changed") return false;
      } else if (queue !== this.queueFilter) {
        return false;
      }
    }
    const filter = String(this.filter || "").trim().toLowerCase();
    if (!filter) return true;
    const haystack = [
      card.name,
      ...(card.aliases || []),
      ...(card.sourcePaths || []),
      card.generatedName,
      card.parentTopic,
      card.userNote,
      ...(card.customAliases || []),
      ...(card.childConcepts || []).map((item) => item.name),
      ...(card.relatedConcepts || []).map((item) => item.name),
      ...(card.mergeSuggestions || []).map((item) => item.name),
      ...(card.reviewReasons || []),
      queue,
      card.changeStatus,
    ]
      .join("\n")
      .toLowerCase();
    return haystack.includes(filter);
  }

  getVisibleRows(rows) {
    return rows.filter((card) => this.cardMatchesFilter(card));
  }

  async ensureCards(statusEl) {
    if (!this.plugin.conceptCards || this.plugin.isConceptCardIndexStale()) {
      await this.plugin.buildConceptCards((message) => {
        if (statusEl) statusEl.setText(message);
      });
    }
  }

  renderEvidenceList(container, title, items, emptyText = "") {
    const text = (key) => t(this.plugin.settings, key);
    const details = container.createEl("details", { cls: "lna-concept-card-details" });
    details.createEl("summary", { text: `${title} (${(items || []).length})` });
    if (!items || !items.length) {
      details.createDiv({ cls: "lna-knowledge-meta", text: emptyText || text("noneText") });
      return;
    }
    for (const item of items.slice(0, 8)) {
      const row = details.createDiv({ cls: "lna-concept-evidence-row" });
      const source = row.createEl("button", {
        cls: "lna-link-button",
        text: item.sourceLink || item.path || "(source)",
        attr: { type: "button" },
      });
      source.addEventListener("click", async () => {
        if (item.path) await this.plugin.openPath(item.path);
      });
      row.createDiv({
        cls: "lna-knowledge-summary",
        text: `${item.type || "evidence"}${item.line ? ` line ${item.line}` : ""}: ${item.summary || ""}`,
      });
    }
  }

  renderCardEditPanel(container, card) {
    const text = (key) => t(this.plugin.settings, key);
    const details = container.createEl("details", { cls: "lna-concept-card-edit" });
    details.createEl("summary", { text: text("conceptCardEditDetails") });
    const grid = details.createDiv({ cls: "lna-concept-card-edit-grid" });
    const titleLabel = grid.createEl("label");
    titleLabel.createSpan({ text: text("conceptCardDisplayTitle") });
    const titleInput = titleLabel.createEl("input", {
      attr: { type: "text", placeholder: card.generatedName || card.name || "" },
    });
    titleInput.value = card.customTitle || "";
    const aliasLabel = grid.createEl("label");
    aliasLabel.createSpan({ text: text("conceptCardAliases") });
    const aliasInput = aliasLabel.createEl("textarea", {
      attr: { rows: "3", placeholder: "topic, synonym, search word" },
    });
    aliasInput.value = (card.customAliases || []).join("\n");
    const parentLabel = grid.createEl("label");
    parentLabel.createSpan({ text: text("conceptCardParentTopic") });
    const parentInput = parentLabel.createEl("input", {
      attr: { type: "text", placeholder: card.parentTopic || "" },
    });
    parentInput.value = card.parentTopic || "";
    const noteLabel = grid.createEl("label");
    noteLabel.createSpan({ text: text("conceptCardNote") });
    const noteInput = noteLabel.createEl("textarea", {
      attr: { rows: "3", placeholder: text("conceptCardNote") },
    });
    noteInput.value = card.userNote || "";
    const actionRow = details.createDiv({ cls: "lna-concept-card-edit-actions" });
    const save = actionRow.createEl("button", { text: text("conceptCardSaveEdit"), attr: { type: "button" } });
    save.addEventListener("click", async () => {
      await this.plugin.setConceptCardEdit(card.id, {
        title: titleInput.value,
        aliases: aliasInput.value,
        parentTopic: parentInput.value,
        note: noteInput.value,
      });
      new Notice(text("conceptCardEditSaved"));
      this.render();
    });
    const reset = actionRow.createEl("button", { text: text("conceptCardResetEdit"), attr: { type: "button" } });
    reset.addEventListener("click", async () => {
      await this.plugin.clearConceptCardEdit(card.id);
      new Notice(text("conceptCardEditReset"));
      this.render();
    });
  }

  renderCards(listEl, rows) {
    const text = (key) => t(this.plugin.settings, key);
    listEl.empty();
    const visible = this.getVisibleRows(rows);
    const shown = visible.slice(0, 80);
    listEl.createDiv({
      cls: "lna-knowledge-meta",
      text: `${shown.length}/${visible.length}/${rows.length} ${text("conceptCards")} · ${text("conceptCardReviewQueueHint")}`,
    });
    for (const card of shown) {
      const queue = this.plugin.getConceptCardQueue(card);
      const cardEl = listEl.createDiv({
        cls: `lna-concept-card lna-concept-status-${card.status || "auto"} lna-concept-queue-${queue} lna-risk-${card.risk || "medium"}`,
      });
      const header = cardEl.createDiv({ cls: "lna-concept-card-header" });
      const titleWrap = header.createDiv();
      titleWrap.createEl("h3", { text: card.name || "(untitled)" });
      titleWrap.createDiv({
        cls: "lna-knowledge-meta",
        text: `${text("conceptCardQueue")}: ${this.queueLabel(queue)} · ${this.statusText(card)} · ${text("conceptCardChangeStatus")}: ${this.changeStatusText(
          card.changeStatus
        )} · ${text("conceptCardConfidence")}: ${card.confidence || "medium"} · ${text("conceptCardRisk")}: ${
          card.risk || "medium"
        } · score ${Number(card.reviewScore || 0).toFixed(1)}`,
      });
      if (card.generatedName && card.generatedName !== card.name) {
        titleWrap.createDiv({
          cls: "lna-knowledge-meta",
          text: `${text("conceptCardGeneratedName")}: ${card.generatedName}`,
        });
      }
      if (card.parentTopic || (card.childConcepts || []).length) {
        titleWrap.createDiv({
          cls: "lna-knowledge-meta",
          text: `${text("conceptCardHierarchy")}: ${
            card.parentTopic ? `${text("conceptCardParentTopic")} = ${card.parentTopic}` : ""
          } ${(card.childConcepts || []).length ? `${text("conceptCardChildren")} = ${(card.childConcepts || []).map((item) => item.name).join(", ")}` : ""}`.trim(),
        });
      }
      const actions = header.createDiv({ cls: "lna-concept-card-actions" });
      const accept = actions.createEl("button", {
        cls: card.status === "accepted" ? "mod-cta" : "",
        text: text("conceptCardAccept"),
        attr: { type: "button" },
      });
      accept.addEventListener("click", async () => {
        await this.plugin.setConceptCardDecision(card.id, "accepted");
        new Notice(text("conceptCardAccepted"));
        this.render();
      });
      const reject = actions.createEl("button", {
        text: text("conceptCardReject"),
        attr: { type: "button" },
      });
      reject.addEventListener("click", async () => {
        await this.plugin.setConceptCardDecision(card.id, "rejected");
        new Notice(text("conceptCardRejected"));
        this.render();
      });

      const meta = cardEl.createDiv({ cls: "lna-concept-card-grid" });
      meta.createDiv({
        cls: "lna-concept-card-box",
        text: `${text("conceptCardRelations")}: ${(card.relatedConcepts || [])
          .slice(0, 8)
          .map((item) => item.name)
          .join(", ") || text("noneText")}`,
      });
      meta.createDiv({
        cls: "lna-concept-card-box",
        text: `${text("conceptCardReviewReasons")}: ${(card.reviewReasons || []).join("; ") || text("noneText")}`,
      });
      if ((card.mergeSuggestions || []).length) {
        meta.createDiv({
          cls: "lna-concept-card-box lna-concept-card-merge-box",
          text: `${text("conceptCardMergeSuggestions")}: ${(card.mergeSuggestions || [])
            .slice(0, 5)
            .map((item) => `${item.name}${item.reason ? ` (${item.reason})` : ""}`)
            .join("; ")}`,
        });
      }
      if (card.userNote || (card.customAliases || []).length) {
        meta.createDiv({
          cls: "lna-concept-card-box",
          text: `${text("conceptCardAliases")}: ${(card.customAliases || []).join(", ") || text("noneText")}${
            card.userNote ? ` · ${text("conceptCardNote")}: ${card.userNote}` : ""
          }`,
        });
      }
      this.renderCardEditPanel(cardEl, card);
      this.renderEvidenceList(cardEl, text("conceptCardEvidence"), [
        ...(card.coreDefinitions || []),
        ...(card.statements || []),
        ...(card.examples || []),
        ...(card.remarks || []),
      ]);
      this.renderEvidenceList(cardEl, text("conceptCardProofEntrances"), card.proofEntrances || []);
    }
  }

  async render() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("lna-knowledge-modal");
    contentEl.addClass("lna-concept-card-modal");
    contentEl.createEl("h2", { text: text("conceptCardReviewTitle") });
    contentEl.createEl("p", { cls: "lna-modal-desc", text: text("conceptCardsDesc") });
    const actions = contentEl.createDiv({ cls: "lna-knowledge-actions" });
    const buildButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("buildConceptCards"),
      attr: { type: "button" },
    });
    const statusEl = actions.createDiv({ cls: "lna-status", text: text("ready") });
    buildButton.addEventListener("click", async () => {
      buildButton.disabled = true;
      try {
        await this.plugin.buildConceptCards((message) => statusEl.setText(message));
        new Notice(text("conceptCardsBuilt"));
        this.render();
      } catch (error) {
        statusEl.setText(error.message || String(error));
      } finally {
        buildButton.disabled = false;
      }
    });

    await this.ensureCards(statusEl);
    const rows = this.plugin.getConceptCardReviewRows();
    if (!rows.length) {
      contentEl.createDiv({ cls: "lna-modal-desc", text: text("conceptCardEmpty") });
      return;
    }
    const stats = this.plugin.conceptCards && this.plugin.conceptCards.stats ? this.plugin.conceptCards.stats : {};
    const queues = stats.queues || {};
    contentEl.createDiv({
      cls: "lna-knowledge-stats",
      text: `${text("conceptCardStats")}: ${stats.total || rows.length} total, ${stats.accepted || 0} accepted, ${stats.rejected || 0} rejected, ${
        stats.high || 0
      } high-confidence, ${queues.review || 0} review, ${queues.auto_pass || 0} ready, ${queues.insufficient || 0} insufficient.`,
    });
    const controls = contentEl.createDiv({ cls: "lna-concept-review-controls" });
    const queueSelect = controls.createEl("select", { cls: "lna-concept-queue-select", attr: { "aria-label": text("conceptCardQueue") } });
    for (const [value, label] of [
      ["review", text("conceptCardQueueReview")],
      ["auto_pass", text("conceptCardQueueAuto")],
      ["insufficient", text("conceptCardQueueInsufficient")],
      ["changed", text("conceptCardQueueChanged")],
      ["confirmed", text("conceptCardQueueConfirmed")],
      ["rejected", text("conceptCardQueueRejected")],
      ["all", text("conceptCardQueueAll")],
    ]) {
      const option = queueSelect.createEl("option", { text: label });
      option.value = value;
    }
    queueSelect.value = this.queueFilter || "review";
    const batchAccept = controls.createEl("button", {
      text: text("conceptCardBatchAcceptVisible"),
      attr: { type: "button" },
    });
    const batchReject = controls.createEl("button", {
      text: text("conceptCardBatchRejectVisible"),
      attr: { type: "button" },
    });
    const search = contentEl.createEl("input", {
      cls: "lna-knowledge-search",
      attr: { type: "search", placeholder: text("conceptCardFilterPlaceholder") },
    });
    search.value = this.filter || "";
    const listEl = contentEl.createDiv({ cls: "lna-concept-card-list" });
    queueSelect.addEventListener("change", () => {
      this.queueFilter = queueSelect.value || "review";
      this.renderCards(listEl, rows);
    });
    batchAccept.addEventListener("click", async () => {
      const ids = this.getVisibleRows(rows)
        .filter((card) => {
          const queue = this.plugin.getConceptCardQueue(card);
          return card.status !== "accepted" && card.status !== "rejected" && queue === "auto_pass" && card.changeStatus !== "changed";
        })
        .map((card) => card.id)
        .filter(Boolean);
      if (!ids.length) return;
      await this.plugin.setConceptCardDecisions(ids, "accepted");
      new Notice(text("conceptCardBatchDone"));
      this.render();
    });
    batchReject.addEventListener("click", async () => {
      const ids = this.getVisibleRows(rows)
        .filter((card) => {
          const queue = this.plugin.getConceptCardQueue(card);
          return card.status !== "accepted" && card.status !== "rejected" && queue === "insufficient";
        })
        .map((card) => card.id)
        .filter(Boolean);
      if (!ids.length) return;
      await this.plugin.setConceptCardDecisions(ids, "rejected");
      new Notice(text("conceptCardBatchDone"));
      this.render();
    });
    search.addEventListener("input", () => {
      this.filter = search.value;
      this.renderCards(listEl, rows);
    });
    this.renderCards(listEl, rows);
  }
}

class KnowledgeIndexModal extends Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }

  onOpen() {
    if (this.modalEl) this.modalEl.addClass("lna-knowledge-shell");
    this.render();
  }

  onClose() {
    this.contentEl.empty();
  }

  async buildIndex(button, statusEl) {
    const text = (key) => t(this.plugin.settings, key);
    button.disabled = true;
    statusEl.setText(text("buildKnowledge"));
    try {
      await this.plugin.buildKnowledgeIndex((message) => {
        statusEl.setText(message);
      });
      new Notice(text("knowledgeBuilt"));
      this.render();
    } catch (error) {
      console.error(error);
      statusEl.setText(error.message || String(error));
    } finally {
      button.disabled = false;
    }
  }

  render() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("lna-knowledge-modal");
    contentEl.createEl("h2", { text: text("knowledgeTitle") });
    contentEl.createEl("p", { cls: "lna-modal-desc", text: text("knowledgeDesc") });

    const actions = contentEl.createDiv({ cls: "lna-knowledge-actions" });
    const buildButton = actions.createEl("button", {
      cls: "mod-cta",
      text: text("buildKnowledge"),
      attr: { type: "button" },
    });
    const statusEl = actions.createDiv({ cls: "lna-status", text: text("ready") });
    buildButton.addEventListener("click", async () => {
      await this.buildIndex(buildButton, statusEl);
    });
    const conceptButton = actions.createEl("button", {
      text: text("buildConceptCards"),
      attr: { type: "button" },
    });
    conceptButton.addEventListener("click", async () => {
      conceptButton.disabled = true;
      try {
        await this.plugin.buildConceptCards((message) => statusEl.setText(message));
        new Notice(text("conceptCardsBuilt"));
        this.render();
      } catch (error) {
        console.error(error);
        statusEl.setText(error.message || String(error));
      } finally {
        conceptButton.disabled = false;
      }
    });
    const reviewButton = actions.createEl("button", {
      text: text("conceptCardReviewButton"),
      attr: { type: "button" },
    });
    reviewButton.addEventListener("click", () => {
      new ConceptCardReviewModal(this.app, this.plugin).open();
    });

    const index = this.plugin.knowledgeIndex;
    if (!index || !Array.isArray(index.profiles)) {
      contentEl.createDiv({ cls: "lna-modal-desc", text: text("knowledgeEmpty") });
      return;
    }

    const stats = contentEl.createDiv({ cls: "lna-knowledge-stats" });
    const conceptCount = Array.isArray(index.concepts) ? index.concepts.length : 0;
    const conceptTotal = index.conceptTotal || conceptCount;
    const domainCount = Array.isArray(index.domains) ? index.domains.length : 0;
    const stale = this.plugin.isKnowledgeIndexStale();
    stats.createDiv({
      text: `${text("knowledgeStats")}: ${index.fileCount || index.profiles.length} notes, ${conceptTotal} concepts, ${domainCount} folders/domains, ${
        index.builtAt ? new Date(index.builtAt).toLocaleString() : ""
      }${stale ? " (refresh recommended)" : ""}`,
    });
    const conceptCards = this.plugin.conceptCards;
    if (conceptCards && Array.isArray(conceptCards.cards)) {
      const cardStats = conceptCards.stats || {};
      stats.createDiv({
        text: `${text("conceptCardStats")}: ${cardStats.total || conceptCards.cards.length} cards, ${cardStats.accepted || 0} accepted, ${
          cardStats.rejected || 0
        } rejected, ${cardStats.high || 0} high-confidence${this.plugin.isConceptCardIndexStale() ? " (refresh recommended)" : ""}`,
      });
    }

    const notesSection = contentEl.createEl("details", { cls: "lna-knowledge-section" });
    notesSection.open = true;
    notesSection.createEl("summary", { text: text("knowledgeTopNotes") });
    const noteList = notesSection.createDiv({ cls: "lna-knowledge-list" });
    for (const profile of index.profiles.slice(0, 30)) {
      const item = noteList.createDiv({ cls: "lna-knowledge-note" });
      const button = item.createEl("button", {
        cls: "lna-result-path",
        text: profile.path,
        attr: { type: "button" },
      });
      button.addEventListener("click", async () => {
        await this.plugin.openPath(profile.path);
      });
      item.createDiv({
        cls: "lna-knowledge-meta",
        text: `in ${profile.inboundCount || 0} / out ${profile.outboundCount || 0} / callouts ${
          profile.calloutCount || 0
        }${this.plugin.getCalloutTypeCounts(profile) ? ` (${this.plugin.getCalloutTypeCounts(profile)})` : ""}`,
      });
      item.createDiv({
        cls: "lna-knowledge-summary",
        text: profile.summary || (profile.headings || []).slice(0, 6).map((heading) => heading.text).join("; "),
      });
      const callouts = (profile.callouts || []).slice(0, 5);
      if (callouts.length) {
        item.createDiv({
          cls: "lna-knowledge-callouts",
          text: callouts.map((entry) => this.plugin.getCalloutLabel(entry, false)).join(" | "),
        });
      }
    }

    const conceptSection = contentEl.createEl("details", { cls: "lna-knowledge-section" });
    conceptSection.createEl("summary", { text: text("knowledgeConcepts") });
    const conceptSearch = conceptSection.createEl("input", {
      cls: "lna-knowledge-search",
      attr: { type: "search", placeholder: "Search concepts, folders, topics..." },
    });
    const conceptList = conceptSection.createDiv({ cls: "lna-knowledge-concepts" });
    const renderConcepts = () => {
      conceptList.empty();
      const filter = String(conceptSearch.value || "").trim().toLowerCase();
      const concepts = (index.concepts || []).filter((concept) => {
        if (!filter) return true;
        return String(concept.name || "").toLowerCase().includes(filter);
      });
      const shown = concepts.slice(0, 120);
      conceptList.createDiv({
        cls: "lna-knowledge-meta",
        text: filter
          ? `Showing ${shown.length}/${concepts.length} matching concepts.`
          : `Showing top ${shown.length}/${concepts.length} concepts. Use search for hidden concepts such as folder names.`,
      });
      for (const concept of shown) {
        conceptList.createSpan({
          cls: "lna-knowledge-chip",
          text: `${concept.name} (${concept.count})`,
        });
      }
    };
    conceptSearch.addEventListener("input", renderConcepts);
    renderConcepts();

    const domainSection = contentEl.createEl("details", { cls: "lna-knowledge-section" });
    domainSection.open = true;
    domainSection.createEl("summary", { text: text("knowledgeDomains") });
    const domainList = domainSection.createDiv({ cls: "lna-knowledge-concepts" });
    for (const domain of (index.domains || []).slice(0, 120)) {
      domainList.createSpan({
        cls: "lna-knowledge-chip lna-knowledge-domain-chip",
        text: `${domain.name} (${domain.count})`,
      });
    }
  }
}

class MemoryModal extends Modal {
  constructor(app, plugin, view = null) {
    super(app);
    this.plugin = plugin;
    this.view = view;
    this.filterText = "";
  }

  onOpen() {
    this.render();
  }

  render() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("lna-memory-modal");
    contentEl.createEl("h2", { text: text("memoryTitle") });
    const search = contentEl.createEl("input", {
      cls: "lna-memory-search",
      attr: {
        type: "search",
        placeholder: text("memorySearch"),
      },
    });
    search.value = this.filterText;
    search.addEventListener("input", () => {
      this.filterText = search.value;
      this.render();
      window.setTimeout(() => {
        const nextSearch = this.contentEl.querySelector(".lna-memory-search");
        if (!nextSearch) return;
        nextSearch.focus();
        nextSearch.setSelectionRange(nextSearch.value.length, nextSearch.value.length);
      }, 0);
    });
    const normalizedFilter = String(this.filterText || "").trim().toLowerCase();
    let groups = this.plugin.getMemoryConversationGroups();
    let feedbackItems = Array.isArray(this.plugin.negativeFeedbackItems) ? this.plugin.negativeFeedbackItems.slice().reverse() : [];
    if (normalizedFilter) {
      groups = groups.filter((group) => {
        const haystack = [
          group.title,
          group.updatedAt,
          ...(group.items || []).flatMap((item) => [item.kind, item.label, item.summary, String(item.content || "").slice(0, 500)]),
        ]
          .filter(Boolean)
          .join("\n")
          .toLowerCase();
        return haystack.includes(normalizedFilter);
      });
      feedbackItems = feedbackItems.filter((item) => {
        const haystack = [item.question, item.reason, item.summary, (item.tags || []).join(" "), item.answerSnippet]
          .filter(Boolean)
          .join("\n")
          .toLowerCase();
        return haystack.includes(normalizedFilter);
      });
    }
    this.renderNegativeFeedbackSection(contentEl, feedbackItems, normalizedFilter);
    if (!groups.length && !feedbackItems.length) {
      contentEl.createDiv({ cls: "lna-modal-desc", text: normalizedFilter ? text("noMemoryMatches") : text("noMemory") });
      return;
    }

    if (!groups.length) return;
    const list = contentEl.createDiv({ cls: "lna-memory-conversation-list" });
    for (const group of groups) {
      const card = list.createDiv({ cls: "lna-memory-conversation" });
      const header = card.createDiv({ cls: "lna-memory-conversation-header" });
      const titleWrap = header.createDiv({ cls: "lna-memory-conversation-title-wrap" });
      const date = group.updatedAt ? new Date(group.updatedAt).toLocaleString() : "";
      titleWrap.createDiv({
        cls: "lna-memory-conversation-title",
        text: group.title || text("memoryConversation"),
      });
      titleWrap.createDiv({
        cls: "lna-memory-conversation-meta",
        text: `${group.items.length} ${text("memoryItems")}${date ? ` - ${date}` : ""}`,
      });
      const actions = header.createDiv({ cls: "lna-memory-conversation-actions" });
      actions.createEl("button", {
        text: text("restoreConversation"),
        attr: { type: "button" },
      }).addEventListener("click", async () => {
        await this.plugin.switchMemoryConversation(group.id);
        if (this.view && this.view.restoreMemoryConversation) {
          await this.view.restoreMemoryConversation(group.id);
        }
        new Notice(text("conversationRestored"));
        this.close();
      });
      actions.createEl("button", {
        text: text("deleteConversation"),
        attr: { type: "button" },
      }).addEventListener("click", async () => {
        if (!window.confirm(text("deleteConversationConfirm"))) return;
        const deletedCurrent = await this.plugin.deleteMemoryConversation(group.id);
        if (deletedCurrent && this.view && this.view.resetChatPanel) {
          this.view.resetChatPanel();
        }
        new Notice(text("conversationDeleted"));
        this.render();
      });

      const details = card.createEl("details", { cls: "lna-memory-group" });
      details.createEl("summary", { text: `${text("memoryItems")}: ${group.items.length}` });
      for (const item of group.items.slice().reverse().slice(0, 20)) {
        const itemDetails = details.createEl("details", { cls: "lna-memory-item" });
        itemDetails.createEl("summary", {
          text: `${item.kind || "memory"} - ${item.label || item.summary || ""}`,
        });
        itemDetails.createDiv({
          cls: "lna-memory-summary",
          text: item.summary || "",
        });
        itemDetails.createEl("pre", {
          cls: "lna-memory-content",
          text: item.content || "",
        });
      }
    }
  }

  renderNegativeFeedbackSection(contentEl, feedbackItems, normalizedFilter) {
    const text = (key) => t(this.plugin.settings, key);
    const section = contentEl.createEl("details", { cls: "lna-negative-feedback-section" });
    section.open = Boolean(feedbackItems.length);
    section.createEl("summary", {
      text: `${text("negativeFeedbackTitle")}: ${feedbackItems.length} ${text("negativeFeedbackItems")}`,
    });
    section.createDiv({ cls: "lna-modal-desc", text: text("negativeFeedbackDesc") });
    if (!feedbackItems.length) {
      section.createDiv({ cls: "lna-modal-desc", text: normalizedFilter ? text("noMemoryMatches") : text("noNegativeFeedback") });
      return;
    }
    const list = section.createDiv({ cls: "lna-negative-feedback-list" });
    for (const item of feedbackItems.slice(0, 40)) {
      const card = list.createEl("details", { cls: "lna-negative-feedback-item" });
      const tags = (item.tags || []).join(", ") || "answer-quality";
      const date = item.createdAt ? new Date(item.createdAt).toLocaleString() : "";
      card.createEl("summary", {
        text: `${tags}${item.question ? ` - ${cleanSnippet(item.question, 80)}` : ""}${date ? ` - ${date}` : ""}`,
      });
      card.createDiv({ cls: "lna-feedback-tags", text: `${text("feedbackTags")}: ${tags}` });
      card.createDiv({ cls: "lna-memory-summary", text: item.reason || "" });
      if (item.answerSnippet) {
        card.createEl("pre", { cls: "lna-memory-content", text: item.answerSnippet });
      }
      const actions = card.createDiv({ cls: "lna-memory-conversation-actions" });
      actions
        .createEl("button", { text: text("deleteFeedback"), attr: { type: "button" } })
        .addEventListener("click", async () => {
          if (!window.confirm(text("deleteFeedbackConfirm"))) return;
          await this.plugin.deleteNegativeFeedback(item.id);
          this.render();
        });
    }
  }

  onClose() {
    this.contentEl.empty();
  }
}

class NegativeFeedbackModal extends Modal {
  constructor(app, plugin, options = {}) {
    super(app);
    this.plugin = plugin;
    this.question = String(options.question || "").trim();
    this.answer = String(options.answer || "").trim();
    this.onSave = options.onSave || null;
  }

  onOpen() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("lna-feedback-modal");
    contentEl.createEl("h2", { text: text("unsatisfiedFeedback") });
    contentEl.createEl("p", { cls: "lna-modal-desc", text: text("unsatisfiedFeedbackDesc") });
    if (this.question) {
      contentEl.createEl("p", { cls: "lna-modal-desc", text: cleanSnippet(this.question, 220) });
    }
    const textarea = contentEl.createEl("textarea", {
      attr: {
        rows: "5",
        placeholder: text("unsatisfiedReasonPlaceholder"),
      },
    });
    textarea.focus();
    const actions = contentEl.createDiv({ cls: "lna-modal-actions" });
    actions
      .createEl("button", { cls: "mod-cta", text: text("saveFeedback"), attr: { type: "button" } })
      .addEventListener("click", async () => {
        await this.plugin.addNegativeFeedback({
          question: this.question,
          answer: this.answer,
          reason: textarea.value.trim(),
          conversationId: this.plugin.currentMemoryConversationId || "",
        });
        new Notice(text("unsatisfiedSaved"));
        if (this.onSave) this.onSave();
        this.close();
      });
  }

  onClose() {
    this.contentEl.empty();
  }
}

class ChatGptHandoffModal extends Modal {
  constructor(app, plugin, view = null, initialTopic = "") {
    super(app);
    this.plugin = plugin;
    this.view = view;
    this.topic = String(initialTopic || "").trim();
    this.mode = "note_completion";
    this.report = null;
    this.outputText = "";
    this.importPreview = [];
  }

  onOpen() {
    this.render();
  }

  onClose() {
    this.contentEl.empty();
  }

  render() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("lna-handoff-modal");
    contentEl.createEl("h2", { text: text("chatGptHandoffTitle") });
    contentEl.createEl("p", { cls: "lna-modal-desc", text: text("chatGptHandoffDesc") });

    const controls = contentEl.createDiv({ cls: "lna-handoff-controls" });
    const topicLabel = controls.createEl("label", { cls: "lna-handoff-field" });
    topicLabel.createSpan({ text: text("handoffTopic") });
    const topicInput = topicLabel.createEl("textarea", {
      attr: { rows: "3", placeholder: text("handoffTopic") },
    });
    topicInput.value = this.topic;
    topicInput.addEventListener("input", () => {
      this.topic = topicInput.value;
    });

    const modeLabel = controls.createEl("label", { cls: "lna-handoff-field" });
    modeLabel.createSpan({ text: text("handoffMode") });
    const modeSelect = modeLabel.createEl("select");
    for (const mode of this.plugin.getChatGptHandoffModes()) {
      modeSelect.createEl("option", { value: mode.id, text: text(mode.labelKey) });
    }
    modeSelect.value = this.mode;
    modeSelect.addEventListener("change", () => {
      this.mode = modeSelect.value;
    });

    const actionRow = contentEl.createDiv({ cls: "lna-modal-actions lna-handoff-actions" });
    const generateButton = actionRow.createEl("button", {
      cls: "mod-cta",
      text: text("generateHandoffPrompt"),
      attr: { type: "button" },
    });
    generateButton.addEventListener("click", async () => {
      await this.generatePrompt(generateButton);
    });

    if (this.report) {
      this.renderPromptSection(contentEl);
    }
    this.renderImportSection(contentEl);
  }

  async generatePrompt(button) {
    const text = (key) => t(this.plugin.settings, key);
    const topic = String(this.topic || "").trim();
    if (!topic) {
      new Notice(text("handoffTopicRequired"));
      return;
    }
    button.disabled = true;
    button.setText(text("generatingHandoff"));
    try {
      const conversationContext = this.view && this.view.getConversationContext ? this.view.getConversationContext() : [];
      this.report = await this.plugin.generateChatGptHandoffPackage(topic, this.mode, conversationContext);
      new Notice(`${text("handoffCreated")}: ${this.report.file.path}`);
      this.render();
    } catch (error) {
      console.error(error);
      new Notice(`${text("draftFailed")}: ${error.message || error}`);
    } finally {
      button.disabled = false;
      button.setText(text("generateHandoffPrompt"));
    }
  }

  renderPromptSection(contentEl) {
    const text = (key) => t(this.plugin.settings, key);
    const section = contentEl.createEl("details", { cls: "lna-handoff-section" });
    section.open = true;
    section.createEl("summary", { text: text("handoffPrompt") });
    const quality = this.report.quality || {};
    const qualityBox = section.createDiv({ cls: "lna-handoff-quality" });
    qualityBox.createDiv({
      cls: "lna-handoff-quality-meta",
      text: `${text("handoffQuality")}: ${quality.sourceCount || 0} sources, ${quality.linkCount || 0} links, ${quality.charCount || String(this.report.prompt || "").length} chars`,
    });
    const list = qualityBox.createEl("ul");
    for (const message of quality.messages || []) {
      list.createEl("li", { text: message });
    }

    const promptArea = section.createEl("textarea", {
      cls: "lna-handoff-prompt",
      attr: { rows: "12" },
    });
    promptArea.value = this.report.prompt || "";
    const actions = section.createDiv({ cls: "lna-modal-actions lna-handoff-actions" });
    actions
      .createEl("button", { text: text("copyPrompt"), attr: { type: "button" } })
      .addEventListener("click", async () => {
        await this.copyText(promptArea.value, promptArea);
      });
    actions
      .createEl("button", { text: text("openPromptFile"), attr: { type: "button" } })
      .addEventListener("click", async () => {
        if (this.report && this.report.file) await this.plugin.openPath(this.report.file.path);
      });
  }

  renderImportSection(contentEl) {
    const text = (key) => t(this.plugin.settings, key);
    const section = contentEl.createEl("details", { cls: "lna-handoff-section" });
    section.open = true;
    section.createEl("summary", { text: text("handoffGptOutput") });
    const textarea = section.createEl("textarea", {
      cls: "lna-handoff-output",
      attr: {
        rows: "10",
        placeholder: text("handoffOutputPlaceholder"),
      },
    });
    textarea.value = this.outputText;
    const fileInput = section.createEl("input", {
      cls: "lna-hidden-file",
      attr: {
        type: "file",
        accept: ".md,.markdown,text/markdown,text/plain",
        multiple: "multiple",
      },
    });
    section.createDiv({ cls: "lna-handoff-file-hint", text: text("markdownOutputDropHint") });
    textarea.addEventListener("input", () => {
      this.outputText = textarea.value;
    });
    textarea.addEventListener("paste", async (event) => {
      const files = event.clipboardData && event.clipboardData.files ? Array.from(event.clipboardData.files) : [];
      if (files.length) {
        event.preventDefault();
        await this.readMarkdownOutputFiles(files, textarea);
        return;
      }
      setTimeout(() => {
        this.outputText = textarea.value;
      }, 0);
    });
    textarea.addEventListener("dragover", (event) => {
      event.preventDefault();
    });
    textarea.addEventListener("drop", async (event) => {
      const files = event.dataTransfer && event.dataTransfer.files ? Array.from(event.dataTransfer.files) : [];
      if (!files.length) return;
      event.preventDefault();
      await this.readMarkdownOutputFiles(files, textarea);
    });
    fileInput.addEventListener("change", async () => {
      const files = fileInput.files ? Array.from(fileInput.files) : [];
      await this.readMarkdownOutputFiles(files, textarea);
      fileInput.value = "";
    });
    const actions = section.createDiv({ cls: "lna-modal-actions lna-handoff-actions" });
    actions
      .createEl("button", { text: text("readClipboardOutput"), attr: { type: "button" } })
      .addEventListener("click", async () => {
        await this.readClipboardOutput(textarea);
      });
    actions
      .createEl("button", { text: text("chooseMarkdownOutput"), attr: { type: "button" } })
      .addEventListener("click", () => {
        fileInput.click();
      });
    actions
      .createEl("button", { text: text("previewImport"), attr: { type: "button" } })
      .addEventListener("click", () => {
        this.outputText = textarea.value;
        this.importPreview = this.plugin.parseChatGptHandoffFiles(this.outputText, this.topic);
        this.render();
      });
    actions
      .createEl("button", { cls: "mod-cta", text: text("importToDrafts"), attr: { type: "button" } })
      .addEventListener("click", async () => {
        await this.importOutput(textarea.value);
      });
    if (this.importPreview.length) {
      const preview = section.createDiv({ cls: "lna-handoff-import-preview" });
      preview.createDiv({ cls: "lna-result-summary", text: text("handoffImportPreview") });
      for (const item of this.importPreview) {
        preview.createDiv({
          cls: "lna-handoff-import-item",
          text: `${item.path} - ${String(item.content || "").length} chars`,
        });
      }
    }
  }

  async readMarkdownOutputFiles(fileList, textarea) {
    const text = (key) => t(this.plugin.settings, key);
    try {
      const files = Array.from(fileList || [])
        .filter((file) => {
          const name = String(file && file.name ? file.name : "");
          const type = String(file && file.type ? file.type : "");
          return /\.m(?:d|arkdown)$/i.test(name) || /\.txt$/i.test(name) || /markdown|text\/plain/i.test(type);
        })
        .slice(0, 20);
      if (!files.length) {
        new Notice(text("markdownOutputReadFailed"));
        return;
      }
      const entries = [];
      for (const file of files) {
        const raw = await file.text();
        const content = String(raw || "").trim();
        if (!content) continue;
        const rawPath = file.webkitRelativePath || file.name || "Imported.md";
        entries.push({
          path: this.plugin.sanitizeRelativeMarkdownPath(rawPath),
          content,
        });
      }
      if (!entries.length) {
        new Notice(text("markdownOutputReadFailed"));
        return;
      }
      const value = entries.map((entry) => `FILE: ${entry.path}\n${entry.content}`).join("\n\n");
      this.outputText = value;
      if (textarea) {
        textarea.value = value;
        textarea.focus();
      }
      this.importPreview = this.plugin.parseChatGptHandoffFiles(value, this.topic);
      new Notice(`${text("markdownOutputRead")}: ${entries.length} file(s)`);
      this.render();
    } catch (error) {
      console.error(error);
      if (textarea) textarea.focus();
      new Notice(text("markdownOutputReadFailed"));
    }
  }

  async readClipboardOutput(textarea) {
    const text = (key) => t(this.plugin.settings, key);
    try {
      if (typeof navigator === "undefined" || !navigator.clipboard || !navigator.clipboard.readText) {
        if (textarea) textarea.focus();
        new Notice(text("clipboardTextMissing"));
        return;
      }
      const value = String((await navigator.clipboard.readText()) || "").trim();
      if (!value) {
        if (textarea) textarea.focus();
        new Notice(text("clipboardTextMissing"));
        return;
      }
      this.outputText = value;
      if (textarea) {
        textarea.value = value;
        textarea.focus();
      }
      this.importPreview = this.plugin.parseChatGptHandoffFiles(value, this.topic);
      new Notice(text("clipboardOutputRead"));
      this.render();
    } catch (error) {
      console.error(error);
      if (textarea) textarea.focus();
      new Notice(text("clipboardReadFailed"));
    }
  }

  async copyText(value, textarea) {
    const text = (key) => t(this.plugin.settings, key);
    try {
      if (typeof navigator !== "undefined" && navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(value);
      } else if (textarea && typeof document !== "undefined") {
        textarea.focus();
        textarea.select();
        document.execCommand("copy");
      }
      new Notice(text("promptCopied"));
    } catch (error) {
      if (textarea) {
        textarea.focus();
        textarea.select();
      }
      new Notice(text("clipboardReadFailed"));
    }
  }

  async importOutput(output) {
    const text = (key) => t(this.plugin.settings, key);
    const content = String(output || this.outputText || "").trim();
    if (!content) {
      new Notice(text("handoffOutputRequired"));
      return;
    }
    try {
      const files = await this.plugin.importChatGptHandoffOutput(this.topic, content, this.mode);
      if (this.view && this.view.refreshDraftBar) await this.view.refreshDraftBar();
      if (files[0]) await this.plugin.openPath(files[0].path);
      new Notice(`${text("handoffImported")}: ${files.length} file(s)`);
      this.importPreview = files.map((file) => ({ path: file.path, content: "" }));
      this.render();
    } catch (error) {
      console.error(error);
      new Notice(`${text("appendFailed")}: ${error.message || error}`);
    }
  }
}

class VisionApiModal extends Modal {
  constructor(app, plugin, onSave = null) {
    super(app);
    this.plugin = plugin;
    this.onSave = onSave;
    this.draft = { ...plugin.settings };
  }

  onOpen() {
    this.render();
  }

  onClose() {
    this.contentEl.empty();
  }

  render() {
    const text = (key) => t(this.plugin.settings, key);
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("lna-vision-modal");

    contentEl.createEl("h2", { text: text("visionApiSettings") });
    contentEl.createEl("p", {
      cls: "lna-modal-desc",
      text: text("visionApiSettingsDesc"),
    });
    contentEl.createEl("p", {
      cls: "lna-modal-desc",
      text: text("apiKeyStoredLocally"),
    });

    new Setting(contentEl)
      .setName(text("enableImageInput"))
      .setDesc(text("enableImageInputDesc"))
      .addToggle((toggle) => {
        toggle.setValue(Boolean(this.draft.enableImageInput)).onChange((value) => {
          this.draft.enableImageInput = value;
        });
      });

    new Setting(contentEl)
      .setName(text("visionProvider"))
      .setDesc(text("visionProviderDesc"))
      .addDropdown((dropdown) => {
        dropdown
          .addOption("chat", text("providerUseChat"))
          .addOption("qwen", text("providerQwen"))
          .addOption("openai", text("providerOpenAI"))
          .addOption("gemini", text("providerGemini"))
          .addOption("ollama", text("providerOllama"))
          .addOption("custom", text("providerCustom"))
          .setValue(this.draft.visionProvider || "chat")
          .onChange((value) => {
            this.draft.visionProvider = value;
          });
      });

    this.addTextSetting(text("maxImageBytes"), "maxImageBytes", "5242880", text("maxImageBytesDesc"));

    contentEl.createEl("h3", { text: text("providerCredentials") });
    this.addTextSetting(text("qwenBaseUrl"), "qwenBaseUrl", "https://dashscope.aliyuncs.com/compatible-mode/v1");
    this.addSecretSetting(text("qwenApiKey"), "qwenApiKey");
    this.addTextSetting(text("openaiBaseUrl"), "openaiBaseUrl", "https://api.openai.com/v1");
    this.addSecretSetting(text("openaiApiKey"), "openaiApiKey");
    this.addSecretSetting(text("geminiApiKey"), "geminiApiKey");
    this.addTextSetting(text("ollamaBaseUrl"), "ollamaBaseUrl", "http://localhost:11434");
    this.addTextSetting(text("customBaseUrl"), "customBaseUrl", "https://example.com/v1");
    this.addSecretSetting(text("customApiKey"), "customApiKey");

    contentEl.createEl("h3", { text: text("providerModels") });
    this.addTextSetting(text("qwenVisionModel"), "qwenVisionModel", "qwen-vl-plus");
    this.addTextSetting(text("openaiVisionModel"), "openaiVisionModel", "gpt-4o-mini");
    this.addTextSetting(text("geminiVisionModel"), "geminiVisionModel", "gemini-1.5-flash");
    this.addTextSetting(text("ollamaVisionModel"), "ollamaVisionModel", "llava");
    this.addTextSetting(text("customVisionModel"), "customVisionModel", "model-name");

    const actions = contentEl.createDiv({ cls: "lna-modal-actions" });
    actions.createEl("button", {
      cls: "mod-cta",
      text: text("saveVisionApi"),
      attr: { type: "button" },
    }).addEventListener("click", async () => {
      await this.save();
    });
  }

  addTextSetting(name, key, placeholder, description = "") {
    const setting = new Setting(this.contentEl).setName(name);
    if (description) setting.setDesc(description);
    setting.addText((input) => {
      input
        .setPlaceholder(placeholder)
        .setValue(String(this.draft[key] || ""))
        .onChange((value) => {
          this.draft[key] = value.trim();
        });
    });
  }

  addSecretSetting(name, key) {
    new Setting(this.contentEl).setName(name).addText((input) => {
      input.inputEl.type = "password";
      input
        .setPlaceholder("stored locally")
        .setValue(String(this.draft[key] || ""))
        .onChange((value) => {
          this.draft[key] = value.trim();
        });
    });
  }

  async save() {
    this.plugin.settings = { ...this.plugin.settings, ...this.draft };
    await this.plugin.savePluginData();
    new Notice(t(this.plugin.settings, "visionApiSaved"));
    if (this.onSave) this.onSave();
    this.close();
  }
}

class LocalNoteAssistantSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    const text = (key) => t(this.plugin.settings, key);
    containerEl.createEl("h2", { text: text("title") });
    containerEl.createEl("p", {
      text: text("settingIntro"),
    });

    new Setting(containerEl)
      .setName(text("language"))
      .setDesc(text("languageDesc"))
      .addDropdown((dropdown) => {
        dropdown
          .addOption("en", "English")
          .addOption("zh", "中文")
          .setValue(this.plugin.settings.language)
          .onChange(async (value) => {
            this.plugin.settings.language = value;
            await this.plugin.savePluginData();
            this.display();
          });
      });

    const embeddingSection = this.createSettingsSection(text("settingsEmbeddingSection"), text("settingsEmbeddingDesc"));
    this.addProviderDropdown(embeddingSection, text("provider"), text("providerDesc"), "embeddingProvider", [
      ["ollama", text("providerOllama")],
      ["openai", text("providerOpenAI")],
      ["gemini", text("providerGemini")],
      ["qwen", text("providerQwen")],
      ["custom", text("providerCustom")],
    ]);
    this.renderEmbeddingProviderTemplate(embeddingSection);
    this.addTextSetting(
      text("maxIncrementalIndexChunks"),
      "maxIncrementalIndexChunks",
      "250",
      text("maxIncrementalIndexChunksDesc"),
      embeddingSection
    );

    const chatSection = this.createSettingsSection(text("settingsChatSection"), text("settingsChatDesc"));
    this.addProviderDropdown(chatSection, text("chatProvider"), text("chatProviderDesc"), "chatProvider", [
      ["qwen", text("providerQwen")],
      ["openai", text("providerOpenAI")],
      ["gemini", text("providerGemini")],
      ["ollama", text("providerOllama")],
      ["deepseek", text("providerDeepSeek")],
      ["custom", text("providerCustom")],
    ]);
    this.renderChatProviderTemplate(chatSection);

    const visionSection = this.createSettingsSection(text("settingsVisionSection"), text("settingsVisionDesc"));
    this.addToggleSetting(text("enableImageInput"), text("enableImageInputDesc"), "enableImageInput", visionSection);
    this.addProviderDropdown(visionSection, text("visionProvider"), text("visionProviderDesc"), "visionProvider", [
      ["chat", text("providerUseChat")],
      ["qwen", text("providerQwen")],
      ["openai", text("providerOpenAI")],
      ["gemini", text("providerGemini")],
      ["ollama", text("providerOllama")],
      ["custom", text("providerCustom")],
    ]);
    this.renderVisionProviderTemplate(visionSection);
    this.addTextSetting(text("maxImageBytes"), "maxImageBytes", "5242880", "", visionSection);
    this.addToggleSetting(text("enableVoiceInput"), text("enableVoiceInputDesc"), "enableVoiceInput", visionSection);
    this.addTextSetting(text("voiceInputLanguage"), "voiceInputLanguage", "zh-CN", "", visionSection);

    new Setting(visionSection)
      .setName(text("voiceMode"))
      .setDesc(text("voiceModeDesc"))
      .addDropdown((dropdown) => {
        dropdown
          .addOption("append", text("voiceModeAppend"))
          .addOption("replace", text("voiceModeReplace"))
          .addOption("command", text("voiceModeCommand"))
          .setValue(this.plugin.settings.voiceInputMode || "append")
          .onChange(async (value) => {
            this.plugin.settings.voiceInputMode = value || "append";
            await this.plugin.savePluginData();
          });
      });

    new Setting(containerEl)
      .setName(text("resultsToShow"))
      .setDesc(text("resultsToShowDesc"))
      .addText((text) => {
        text
          .setValue(String(this.plugin.settings.resultLimit))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed) && parsed > 0) {
              this.plugin.settings.resultLimit = Math.min(parsed, 30);
              await this.plugin.savePluginData();
            }
          });
      });

    new Setting(containerEl)
      .setName(text("answerContextLimit"))
      .setDesc(text("answerContextLimitDesc"))
      .addText((text) => {
        text
          .setValue(String(this.plugin.settings.answerContextLimit))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed) && parsed > 0) {
              this.plugin.settings.answerContextLimit = Math.min(parsed, 12);
              await this.plugin.savePluginData();
            }
          });
      });

    new Setting(containerEl)
      .setName(text("maxAnswerContextChars"))
      .setDesc(text("maxAnswerContextCharsDesc"))
      .addText((text) => {
        text
          .setValue(String(this.plugin.settings.maxAnswerContextChars))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed) && parsed > 0) {
              this.plugin.settings.maxAnswerContextChars = Math.min(parsed, 20000);
              await this.plugin.savePluginData();
            }
          });
      });

    new Setting(containerEl)
      .setName(text("maxTotalAnswerContextChars"))
      .setDesc(text("maxTotalAnswerContextCharsDesc"))
      .addText((text) => {
        text
          .setValue(String(this.plugin.settings.maxTotalAnswerContextChars))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed) && parsed > 0) {
              this.plugin.settings.maxTotalAnswerContextChars = Math.min(parsed, 100000);
              await this.plugin.savePluginData();
            }
          });
      });

    this.addToggleSetting(text("includeNeighborChunks"), text("includeNeighborChunksDesc"), "includeNeighborChunks");
    this.addTextSetting(text("neighborChunksBefore"), "neighborChunksBefore", "1");
    this.addTextSetting(text("neighborChunksAfter"), "neighborChunksAfter", "1");
    this.addToggleSetting(
      text("includeSameHeadingSection"),
      text("includeSameHeadingSectionDesc"),
      "includeSameHeadingSection"
    );

    this.addToggleSetting(
      text("useConversationMemory"),
      text("useConversationMemoryDesc"),
      "useConversationMemory"
    );

    this.addToggleSetting(
      text("useLongTermMemory"),
      text("useLongTermMemoryDesc"),
      "useLongTermMemory"
    );

    new Setting(containerEl)
      .setName(text("conversationTurnsToKeep"))
      .setDesc(text("conversationTurnsToKeepDesc"))
      .addText((text) => {
        text
          .setValue(String(this.plugin.settings.conversationTurnsToKeep))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed)) {
              this.plugin.settings.conversationTurnsToKeep = Math.max(0, Math.min(parsed, 99));
              await this.plugin.savePluginData();
            }
          });
      });

    new Setting(containerEl)
      .setName(text("longTermMemoryToKeep"))
      .setDesc(text("longTermMemoryToKeepDesc"))
      .addText((textInput) => {
        textInput
          .setValue(String(this.plugin.settings.longTermMemoryToKeep))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed)) {
              this.plugin.settings.longTermMemoryToKeep = Math.max(0, Math.min(parsed, 200));
              if (Array.isArray(this.plugin.memoryItems)) {
                this.plugin.memoryItems = this.plugin.memoryItems.slice(-this.plugin.settings.longTermMemoryToKeep);
                for (let index = 0; index < this.plugin.memoryItems.length; index += 1) {
                  this.plugin.memoryItems[index].id = index + 1;
                }
              }
              await this.plugin.savePluginData();
            }
          });
      });

    this.addToggleSetting(
      text("useNegativeFeedbackMemory"),
      text("useNegativeFeedbackMemoryDesc"),
      "useNegativeFeedbackMemory"
    );

    new Setting(containerEl)
      .setName(text("negativeFeedbackToKeep"))
      .setDesc(text("negativeFeedbackToKeepDesc"))
      .addText((textInput) => {
        textInput
          .setValue(String(this.plugin.settings.negativeFeedbackToKeep))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed)) {
              this.plugin.settings.negativeFeedbackToKeep = Math.max(0, Math.min(parsed, 200));
              if (Array.isArray(this.plugin.negativeFeedbackItems)) {
                this.plugin.negativeFeedbackItems = this.plugin.negativeFeedbackItems.slice(
                  -this.plugin.settings.negativeFeedbackToKeep
                );
                for (let index = 0; index < this.plugin.negativeFeedbackItems.length; index += 1) {
                  this.plugin.negativeFeedbackItems[index].id = index + 1;
                }
              }
              await this.plugin.savePluginData();
            }
          });
      });

    new Setting(containerEl)
      .setName(text("migrationScanLimit"))
      .setDesc(text("migrationScanLimitDesc"))
      .addText((textInput) => {
        textInput
          .setValue(String(this.plugin.settings.migrationScanLimit))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (Number.isFinite(parsed)) {
              this.plugin.settings.migrationScanLimit = Math.max(1, Math.min(parsed, 100));
              await this.plugin.savePluginData();
            }
          });
      });

    this.addToggleSetting(text("confirmAgentPlans"), text("confirmAgentPlansDesc"), "confirmAgentPlans");
    this.addTextSetting(text("maxAgentSteps"), "maxAgentSteps", "6");
    this.addTextSetting(text("userWritingPreferences"), "userWritingPreferences", DEFAULT_SETTINGS.userWritingPreferences);

    new Setting(containerEl)
      .setName(text("writeMode"))
      .setDesc(text("writeModeDesc"))
      .addDropdown((dropdown) => {
        dropdown
          .addOption("disabled", text("writeModeDisabled"))
          .addOption("draft", text("writeModeDraft"))
          .setValue(this.plugin.settings.writeMode)
          .onChange(async (value) => {
            this.plugin.settings.writeMode = value;
            await this.plugin.savePluginData();
          });
      });

    this.addTextSetting(text("draftFolder"), "draftFolder", "AI Drafts");
    this.addTextSetting(text("maxDraftEditChars"), "maxDraftEditChars", "50000");
    this.addTextSetting(text("handoffFolder"), "handoffFolder", "AI Handoffs");
    this.addTextSetting(text("maxHandoffPromptChars"), "maxHandoffPromptChars", "18000");

    new Setting(containerEl)
      .setName(text("draftSourceMode"))
      .setDesc(text("draftSourceModeDesc"))
      .addDropdown((dropdown) => {
        dropdown
          .addOption("notes_only", text("draftSourceNotesOnly"))
          .addOption("notes_model", text("draftSourceNotesModel"))
          .addOption("model_only", text("draftSourceModelOnly"))
          .setValue(this.plugin.settings.draftSourceMode)
          .onChange(async (value) => {
            this.plugin.settings.draftSourceMode = value;
            await this.plugin.savePluginData();
          });
      });
  }

  createSettingsSection(title, description = "") {
    const section = this.containerEl.createDiv({ cls: "lna-settings-section" });
    section.createEl("h3", { text: title });
    if (description) section.createDiv({ cls: "lna-settings-section-desc", text: description });
    return section;
  }

  getProviderLabel(provider) {
    const text = (key) => t(this.plugin.settings, key);
    const labels = {
      chat: text("providerUseChat"),
      ollama: text("providerOllama"),
      openai: text("providerOpenAI"),
      gemini: text("providerGemini"),
      qwen: text("providerQwen"),
      deepseek: text("providerDeepSeek"),
      custom: text("providerCustom"),
    };
    return labels[provider] || provider || "";
  }

  addProviderDropdown(parent, name, description, key, options) {
    new Setting(parent)
      .setName(name)
      .setDesc(description)
      .addDropdown((dropdown) => {
        for (const [value, label] of options) {
          dropdown.addOption(value, label);
        }
        dropdown.setValue(this.plugin.settings[key] || options[0][0]).onChange(async (value) => {
          this.plugin.settings[key] = value;
          await this.plugin.savePluginData();
          this.display();
        });
      });
  }

  createProviderTemplate(parent, provider) {
    const text = (key) => t(this.plugin.settings, key);
    const card = parent.createDiv({ cls: "lna-provider-template" });
    card.createDiv({
      cls: "lna-provider-template-title",
      text: `${text("providerTemplate")}: ${this.getProviderLabel(provider)}`,
    });
    card.createDiv({ cls: "lna-provider-template-desc", text: text("providerTemplateDesc") });
    return card;
  }

  renderEmbeddingProviderTemplate(parent) {
    const text = (key) => t(this.plugin.settings, key);
    const provider = this.plugin.settings.embeddingProvider || "ollama";
    const card = this.createProviderTemplate(parent, provider);
    if (provider === "ollama") {
      this.addTextSetting(text("ollamaBaseUrl"), "ollamaBaseUrl", "http://localhost:11434", "", card);
      this.addTextSetting(text("ollamaEmbeddingModel"), "ollamaModel", "nomic-embed-text", "", card);
    } else if (provider === "openai") {
      this.addTextSetting(text("openaiBaseUrl"), "openaiBaseUrl", "https://api.openai.com/v1", "", card);
      this.addSecretSetting(text("openaiApiKey"), "openaiApiKey", card);
      this.addTextSetting(text("openaiEmbeddingModel"), "openaiModel", "text-embedding-3-small", "", card);
    } else if (provider === "gemini") {
      this.addSecretSetting(text("geminiApiKey"), "geminiApiKey", card);
      this.addTextSetting(text("geminiEmbeddingModel"), "geminiModel", "gemini-embedding-001", "", card);
    } else if (provider === "qwen") {
      this.addTextSetting(text("qwenBaseUrl"), "qwenBaseUrl", "https://dashscope.aliyuncs.com/compatible-mode/v1", "", card);
      this.addSecretSetting(text("qwenApiKey"), "qwenApiKey", card);
      this.addTextSetting(text("qwenEmbeddingModel"), "qwenModel", "text-embedding-v4", "", card);
      this.addTextSetting(text("qwenEmbeddingDimensions"), "qwenDimensions", "1024", "", card);
    } else {
      this.addTextSetting(text("customBaseUrl"), "customBaseUrl", "https://example.com/v1", "", card);
      this.addSecretSetting(text("customApiKey"), "customApiKey", card);
      this.addTextSetting(text("customEmbeddingModel"), "customModel", "model-name", "", card);
    }
  }

  renderChatProviderTemplate(parent) {
    const text = (key) => t(this.plugin.settings, key);
    const provider = this.plugin.settings.chatProvider || "qwen";
    const card = this.createProviderTemplate(parent, provider);
    if (provider === "ollama") {
      this.addTextSetting(text("ollamaBaseUrl"), "ollamaBaseUrl", "http://localhost:11434", "", card);
      this.addTextSetting(text("ollamaChatModel"), "ollamaChatModel", "qwen2.5:7b", "", card);
    } else if (provider === "openai") {
      this.addTextSetting(text("openaiBaseUrl"), "openaiBaseUrl", "https://api.openai.com/v1", "", card);
      this.addSecretSetting(text("openaiApiKey"), "openaiApiKey", card);
      this.addTextSetting(text("openaiChatModel"), "openaiChatModel", "gpt-4o-mini", "", card);
    } else if (provider === "gemini") {
      this.addSecretSetting(text("geminiApiKey"), "geminiApiKey", card);
      this.addTextSetting(text("geminiChatModel"), "geminiChatModel", "gemini-1.5-flash", "", card);
    } else if (provider === "qwen") {
      this.addTextSetting(text("qwenBaseUrl"), "qwenBaseUrl", "https://dashscope.aliyuncs.com/compatible-mode/v1", "", card);
      this.addSecretSetting(text("qwenApiKey"), "qwenApiKey", card);
      this.addTextSetting(text("qwenChatModel"), "qwenChatModel", "qwen-plus", "", card);
    } else if (provider === "deepseek") {
      this.addTextSetting(text("deepseekBaseUrl"), "deepseekBaseUrl", "https://api.deepseek.com", "", card);
      this.addSecretSetting(text("deepseekApiKey"), "deepseekApiKey", card);
      this.addTextSetting(text("deepseekChatModel"), "deepseekChatModel", "deepseek-chat", "", card);
    } else {
      this.addTextSetting(text("customBaseUrl"), "customBaseUrl", "https://example.com/v1", "", card);
      this.addSecretSetting(text("customApiKey"), "customApiKey", card);
      this.addTextSetting(text("customChatModel"), "customChatModel", "model-name", "", card);
    }
  }

  renderVisionProviderTemplate(parent) {
    const text = (key) => t(this.plugin.settings, key);
    const provider = this.plugin.settings.visionProvider || "chat";
    const card = this.createProviderTemplate(parent, provider);
    if (provider === "chat") {
      card.createDiv({ cls: "lna-provider-template-desc", text: text("providerInheritedFromChat") });
    } else if (provider === "ollama") {
      this.addTextSetting(text("ollamaBaseUrl"), "ollamaBaseUrl", "http://localhost:11434", "", card);
      this.addTextSetting(text("ollamaVisionModel"), "ollamaVisionModel", "llava", "", card);
    } else if (provider === "openai") {
      this.addTextSetting(text("openaiBaseUrl"), "openaiBaseUrl", "https://api.openai.com/v1", "", card);
      this.addSecretSetting(text("openaiApiKey"), "openaiApiKey", card);
      this.addTextSetting(text("openaiVisionModel"), "openaiVisionModel", "gpt-4o-mini", "", card);
    } else if (provider === "gemini") {
      this.addSecretSetting(text("geminiApiKey"), "geminiApiKey", card);
      this.addTextSetting(text("geminiVisionModel"), "geminiVisionModel", "gemini-1.5-flash", "", card);
    } else if (provider === "qwen") {
      this.addTextSetting(text("qwenBaseUrl"), "qwenBaseUrl", "https://dashscope.aliyuncs.com/compatible-mode/v1", "", card);
      this.addSecretSetting(text("qwenApiKey"), "qwenApiKey", card);
      this.addTextSetting(text("qwenVisionModel"), "qwenVisionModel", "qwen-vl-plus", "", card);
    } else {
      this.addTextSetting(text("customBaseUrl"), "customBaseUrl", "https://example.com/v1", "", card);
      this.addSecretSetting(text("customApiKey"), "customApiKey", card);
      this.addTextSetting(text("customVisionModel"), "customVisionModel", "model-name", "", card);
    }
  }

  addTextSetting(name, key, placeholder, description = "", parent = this.containerEl) {
    const setting = new Setting(parent).setName(name);
    if (description) setting.setDesc(description);
    setting.addText((text) => {
      text
        .setPlaceholder(placeholder)
        .setValue(this.plugin.settings[key] || "")
        .onChange(async (value) => {
          this.plugin.settings[key] = value.trim();
          await this.plugin.savePluginData();
        });
    });
  }

  addSecretSetting(name, key, parent = this.containerEl) {
    new Setting(parent).setName(name).addText((text) => {
      text.inputEl.type = "password";
      text
        .setPlaceholder("stored locally")
        .setValue(this.plugin.settings[key] || "")
        .onChange(async (value) => {
          this.plugin.settings[key] = value.trim();
          await this.plugin.savePluginData();
        });
    });
  }

  addToggleSetting(name, description, key, parent = this.containerEl) {
    new Setting(parent)
      .setName(name)
      .setDesc(description)
      .addToggle((toggle) => {
        toggle.setValue(Boolean(this.plugin.settings[key])).onChange(async (value) => {
          this.plugin.settings[key] = value;
          await this.plugin.savePluginData();
        });
      });
  }
}

module.exports = class LocalNoteAssistantPlugin extends Plugin {
  async onload() {
    await this.loadPluginData();
    this.embeddingProvider = new EmbeddingProvider(this);
    this.chatProvider = new ChatProvider(this);

    this.registerView(VIEW_TYPE, (leaf) => new LocalNoteAssistantView(leaf, this));
    this.addSettingTab(new LocalNoteAssistantSettingTab(this.app, this));

    this.addRibbonIcon("search", "Local Note Assistant", async () => {
      await this.activateView();
    });

    this.addCommand({
      id: "open-local-note-assistant",
      name: "Open Local Note Assistant",
      callback: async () => {
        await this.activateView();
      },
    });

    this.addCommand({
      id: "start-local-note-assistant-voice-input",
      name: "Start voice input in Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        if (view && view.startVoiceInput) await view.startVoiceInput();
      },
    });

    this.addCommand({
      id: "stop-local-note-assistant-voice-input",
      name: "Stop voice input in Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        if (view && view.stopVoiceInput) view.stopVoiceInput();
      },
    });

    this.addCommand({
      id: "toggle-local-note-assistant-voice-input",
      name: "Toggle voice input in Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        if (view && view.toggleVoiceInput) await view.toggleVoiceInput();
      },
    });

    this.addCommand({
      id: "rebuild-local-note-assistant-index",
      name: "Rebuild Local Note Assistant Index",
      callback: async () => {
        new Notice(t(this.settings, "buildingIndex"));
        await this.buildIndex();
        new Notice(t(this.settings, "indexRebuilt"));
      },
    });

    this.addCommand({
      id: "build-local-note-assistant-knowledge-index",
      name: "Build Local Note Assistant Knowledge Index",
      callback: async () => {
        new Notice(t(this.settings, "buildKnowledge"));
        await this.buildKnowledgeIndex();
        new Notice(t(this.settings, "knowledgeBuilt"));
      },
    });

    this.addCommand({
      id: "open-local-note-assistant-concept-card-review",
      name: "Open Local Note Assistant Concept Card Review",
      callback: async () => {
        new ConceptCardReviewModal(this.app, this).open();
      },
    });

    this.addCommand({
      id: "open-local-note-assistant-chatgpt-handoff",
      name: "Open ChatGPT handoff in Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        new ChatGptHandoffModal(this.app, this, view).open();
      },
    });

    this.addCommand({
      id: "start-local-note-assistant-system-screenshot",
      name: "Start system screenshot for Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        if (view && view.startSystemScreenshotCapture) await view.startSystemScreenshotCapture();
      },
    });

    this.addCommand({
      id: "attach-local-note-assistant-clipboard-screenshot",
      name: "Attach clipboard screenshot to Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        if (view && view.attachClipboardImage) await view.attachClipboardImage();
      },
    });

    this.addCommand({
      id: "ask-local-note-assistant-with-clipboard-screenshot",
      name: "Ask with clipboard screenshot in Local Note Assistant",
      callback: async () => {
        const view = await this.activateView();
        if (view && view.prepareScreenshotQuestion) await view.prepareScreenshotQuestion();
      },
    });

    this.addCommand({
      id: "convert-local-note-assistant-clipboard-screenshot",
      name: "Convert clipboard screenshot to Markdown",
      callback: async () => {
        const view = await this.activateView();
        if (!view || !view.attachClipboardImage) return;
        const attached = await view.attachClipboardImage();
        if (attached && view.convertCurrentImageToMarkdown) await view.convertCurrentImageToMarkdown();
      },
    });
  }

  async onunload() {
    this.app.workspace.detachLeavesOfType(VIEW_TYPE);
  }

  async loadPluginData() {
    const data = (await this.loadData()) || {};
    this.settings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
    this.index = data.index || null;
    this.knowledgeIndex = data.knowledgeIndex || null;
    this.conceptCards = data.conceptCards || null;
    this.conceptCardDecisions = data.conceptCardDecisions && typeof data.conceptCardDecisions === "object" ? data.conceptCardDecisions : {};
    this.conceptCardEdits = data.conceptCardEdits && typeof data.conceptCardEdits === "object" ? data.conceptCardEdits : {};
    this.lastDraftPath = data.lastDraftPath || "";
    this.memoryItems = Array.isArray(data.memoryItems) ? data.memoryItems : [];
    this.memoryConversations = Array.isArray(data.memoryConversations) ? data.memoryConversations : [];
    this.currentMemoryConversationId = data.currentMemoryConversationId || "";
    this.ensureMemoryConversation();
    this.negativeFeedbackItems = Array.isArray(data.negativeFeedbackItems) ? data.negativeFeedbackItems : [];
    this.taskLog = Array.isArray(data.taskLog) ? data.taskLog : [];
    this.lastDraftUndo = data.lastDraftUndo || null;
    this.lastMigrationPreview = data.lastMigrationPreview || null;
    this.lastFormalMigrationUndo = data.lastFormalMigrationUndo || null;
    this.lastReviewedMigration = data.lastReviewedMigration || null;
    this.migrationHistory = Array.isArray(data.migrationHistory) ? data.migrationHistory : [];
    this.lastDraftChangeSummary = "";
  }

  async savePluginData() {
    await this.saveData({
      settings: this.settings,
      index: this.index,
      knowledgeIndex: this.knowledgeIndex || null,
      conceptCards: this.conceptCards || null,
      conceptCardDecisions: this.conceptCardDecisions || {},
      conceptCardEdits: this.conceptCardEdits || {},
      lastDraftPath: this.lastDraftPath || "",
      memoryItems: this.memoryItems || [],
      memoryConversations: this.memoryConversations || [],
      currentMemoryConversationId: this.currentMemoryConversationId || "",
      negativeFeedbackItems: this.negativeFeedbackItems || [],
      taskLog: this.taskLog || [],
      lastDraftUndo: this.lastDraftUndo || null,
      lastMigrationPreview: this.lastMigrationPreview || null,
      lastFormalMigrationUndo: this.lastFormalMigrationUndo || null,
      lastReviewedMigration: this.lastReviewedMigration || null,
      migrationHistory: this.migrationHistory || [],
    });
  }

  getLongTermMemoryLimit() {
    const parsed = Number.parseInt(this.settings.longTermMemoryToKeep, 10);
    if (!Number.isFinite(parsed)) return 60;
    return Math.max(0, Math.min(parsed, 200));
  }

  getNegativeFeedbackLimit() {
    const parsed = Number.parseInt(this.settings.negativeFeedbackToKeep, 10);
    if (!Number.isFinite(parsed)) return 40;
    return Math.max(0, Math.min(parsed, 200));
  }

  classifyNegativeFeedback(question = "", reason = "", answer = "") {
    const value = `${question}\n${reason}\n${answer}`.toLowerCase();
    const tags = [];
    const add = (tag, pattern) => {
      if (pattern.test(value)) tags.push(tag);
    };
    add("citation-error", /\u5f15\u7528|\u6765\u6e90|\u51fa\u5904|\u94fe\u63a5|\u951a\u70b9|source|citation|anchor|link/i);
    add("hallucination", /\u7f16\u9020|\u80e1\u8bf4|\u4e0d\u5b58\u5728|\u7b14\u8bb0\u91cc\u6ca1\u6709|\u6ca1\u6709\u8bc1\u636e|invent|hallucinat|unsupported/i);
    add("missing-context", /\u6f0f|\u9057\u6f0f|\u6ca1\u627e\u5230|\u672a\u627e\u5230|\u4e0d\u5b8c\u6574|\u7f3a\u5c11|\u622a\u65ad|context|missing|truncated/i);
    add("wrong-tool", /\u5de5\u5177|\u529f\u80fd|\u6ca1\u6709\u63d2\u5165|\u6ca1\u6709\u4fee\u6539|\u53ea\u56de\u7b54|\u8349\u7a3f|\u8fc1\u79fb|\u9875\u9762|wrong tool|insert|draft|migration/i);
    add("math-render", /\u516c\u5f0f|latex|\u6e32\u67d3|\u683c\u5f0f|markdown|\$ | \$|render|format/i);
    add("knowledge-index", /\u77e5\u8bc6\u7d22\u5f15|\u7d22\u5f15|\u6982\u5ff5|callout|concept|knowledge/i);
    add("language", /\u4e2d\u6587|\u82f1\u6587|\u8bed\u8a00|\u7ffb\u8bd1|language|translation/i);
    add("too-short", /\u592a\u5c11|\u592a\u77ed|\u4e0d\u8be6\u7ec6|\u8bf4\u4e0d\u6e05|too short|brief|not detailed/i);
    add("too-long", /\u592a\u957f|\u5570\u55e6|\u5197\u957f|too long|verbose/i);
    add("slow", /\u6162|\u5361|slow|latency/i);
    if (!tags.length) tags.push("answer-quality");
    return [...new Set(tags)].slice(0, 8);
  }

  async addNegativeFeedback(item) {
    const question = String((item && item.question) || "").trim();
    const answer = String((item && item.answer) || "").trim();
    const reason = String((item && item.reason) || "").trim();
    const keep = this.getNegativeFeedbackLimit();
    if (keep <= 0) return null;
    if (!answer && !reason) return null;
    this.negativeFeedbackItems = Array.isArray(this.negativeFeedbackItems) ? this.negativeFeedbackItems : [];
    const tags = Array.isArray(item && item.tags) && item.tags.length
      ? [...new Set(item.tags.map((tag) => String(tag || "").trim()).filter(Boolean))]
      : this.classifyNegativeFeedback(question, reason, answer);
    this.negativeFeedbackItems.push({
      id: this.negativeFeedbackItems.length + 1,
      conversationId: (item && item.conversationId) || this.currentMemoryConversationId || "",
      question,
      answerSnippet: cleanSnippet(answer, 900),
      reason: reason || "Marked unsatisfied without a written reason.",
      tags,
      summary: cleanSnippet(`${question}\n${reason || answer}`, 240),
      createdAt: new Date().toISOString(),
    });
    this.negativeFeedbackItems = this.negativeFeedbackItems.slice(-keep);
    for (let index = 0; index < this.negativeFeedbackItems.length; index += 1) {
      this.negativeFeedbackItems[index].id = index + 1;
    }
    await this.savePluginData();
    return this.negativeFeedbackItems[this.negativeFeedbackItems.length - 1];
  }

  async deleteNegativeFeedback(id) {
    const parsed = Number.parseInt(id, 10);
    this.negativeFeedbackItems = (Array.isArray(this.negativeFeedbackItems) ? this.negativeFeedbackItems : []).filter(
      (item) => item.id !== parsed
    );
    for (let index = 0; index < this.negativeFeedbackItems.length; index += 1) {
      this.negativeFeedbackItems[index].id = index + 1;
    }
    await this.savePluginData();
  }

  getNegativeFeedbackSummaries(limit = 8) {
    if (!this.settings.useNegativeFeedbackMemory) return [];
    const items = Array.isArray(this.negativeFeedbackItems) ? this.negativeFeedbackItems : [];
    return items.slice(-Math.max(0, limit)).map((item) => ({
      id: item.id,
      tags: item.tags || [],
      question: cleanSnippet(item.question || "", 100),
      reason: cleanSnippet(item.reason || "", 160),
      createdAt: item.createdAt || "",
    }));
  }

  buildNegativeFeedbackContext(context = "", limit = 6) {
    if (!this.settings.useNegativeFeedbackMemory) return "";
    const items = Array.isArray(this.negativeFeedbackItems) ? this.negativeFeedbackItems : [];
    if (!items.length) return "";
    const terms = tokenize(context);
    const scored = items.map((item, index) => {
      const haystack = `${item.question || ""}\n${item.reason || ""}\n${(item.tags || []).join(" ")}\n${item.answerSnippet || ""}`;
      const score = terms.length ? lineScore(haystack, terms) : 0;
      return { item, score, index };
    });
    scored.sort((a, b) => b.score - a.score || b.index - a.index);
    const selected = scored.slice(0, Math.max(1, Math.min(limit, 10))).map((entry) => entry.item);
    const tagRules = new Set(selected.flatMap((item) => item.tags || []));
    const rules = [];
    if (tagRules.has("citation-error")) rules.push("Copy provided source links exactly; never invent headings, block anchors, or citations.");
    if (tagRules.has("hallucination")) rules.push("Do not present unsupported content as if it came from the user's notes.");
    if (tagRules.has("missing-context")) rules.push("Search broadly and use available evidence before saying the notes are insufficient or truncated.");
    if (tagRules.has("wrong-tool")) rules.push("If the user asks for a plugin action such as draft insertion, migration, image conversion, or editing, choose that action instead of plain chat.");
    if (tagRules.has("math-render")) rules.push("Use Obsidian-renderable LaTeX; write inline math as $x$ rather than $ x $.");
    if (tagRules.has("knowledge-index")) rules.push("Use knowledge-index hints only for navigation; verify claims with retrieved excerpts or callout evidence.");
    if (tagRules.has("language")) rules.push("Answer in the user's current language unless they ask otherwise.");
    if (tagRules.has("too-short")) rules.push("Give enough structure and detail for synthesis questions.");
    if (tagRules.has("too-long")) rules.push("Keep the answer focused and avoid unnecessary repetition.");
    const itemLines = selected
      .map((item) => {
        const tags = (item.tags || []).join(", ") || "answer-quality";
        const question = cleanSnippet(item.question || "(unknown question)", 160);
        const reason = cleanSnippet(item.reason || item.summary || "", 220);
        return `- Tags: ${tags}\n  Prior question: ${question}\n  User feedback: ${reason}`;
      })
      .join("\n");
    const ruleBlock = rules.length ? `\nAvoidance rules:\n${[...new Set(rules)].map((rule) => `- ${rule}`).join("\n")}` : "";
    return `\n\nUnsatisfied-answer feedback to avoid repeating:\n${itemLines}${ruleBlock}`;
  }

  createMemoryConversation(title = "") {
    this.memoryConversations = Array.isArray(this.memoryConversations) ? this.memoryConversations : [];
    const id = `chat-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const conversation = {
      id,
      title: title || new Date().toLocaleString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.memoryConversations.push(conversation);
    this.currentMemoryConversationId = id;
    return conversation;
  }

  ensureMemoryConversation() {
    this.memoryConversations = Array.isArray(this.memoryConversations) ? this.memoryConversations : [];
    if (
      this.currentMemoryConversationId &&
      this.memoryConversations.some((conversation) => conversation.id === this.currentMemoryConversationId)
    ) {
      return this.currentMemoryConversationId;
    }
    const conversation = this.createMemoryConversation();
    return conversation.id;
  }

  async startMemoryConversation(title = "") {
    this.createMemoryConversation(title);
    await this.savePluginData();
    return this.currentMemoryConversationId;
  }

  getMemoryConversationById(id) {
    const conversations = Array.isArray(this.memoryConversations) ? this.memoryConversations : [];
    return conversations.find((conversation) => conversation.id === id) || null;
  }

  getMemoryItemsForConversation(id) {
    const items = Array.isArray(this.memoryItems) ? this.memoryItems : [];
    return items
      .filter((item) => item.conversationId === id)
      .sort((a, b) => String(a.createdAt || "").localeCompare(String(b.createdAt || "")));
  }

  async switchMemoryConversation(id) {
    const conversation = this.getMemoryConversationById(id);
    if (!conversation) return null;
    this.currentMemoryConversationId = id;
    conversation.updatedAt = new Date().toISOString();
    await this.savePluginData();
    return conversation;
  }

  async deleteMemoryConversation(id) {
    const deletingCurrent = id && id === this.currentMemoryConversationId;
    this.memoryItems = (Array.isArray(this.memoryItems) ? this.memoryItems : []).filter((item) => item.conversationId !== id);
    this.memoryConversations = (Array.isArray(this.memoryConversations) ? this.memoryConversations : []).filter(
      (conversation) => conversation.id !== id
    );
    if (deletingCurrent) {
      this.currentMemoryConversationId = "";
      this.createMemoryConversation();
    }
    for (let index = 0; index < this.memoryItems.length; index += 1) {
      this.memoryItems[index].id = index + 1;
    }
    await this.savePluginData();
    return deletingCurrent;
  }

  async renameCurrentMemoryConversation(title) {
    const trimmed = cleanSnippet(title || "", 80);
    if (!trimmed) return;
    const id = this.ensureMemoryConversation();
    const conversation = this.memoryConversations.find((item) => item.id === id);
    if (!conversation) return;
    if (!conversation.title || /^\d{1,4}\/|\d{4}-/.test(conversation.title)) {
      conversation.title = trimmed;
    }
    conversation.updatedAt = new Date().toISOString();
    await this.savePluginData();
  }

  getMemoryConversationGroups() {
    const conversations = Array.isArray(this.memoryConversations) ? this.memoryConversations : [];
    const items = Array.isArray(this.memoryItems) ? this.memoryItems : [];
    const byId = new Map();
    for (const conversation of conversations) {
      byId.set(conversation.id, { ...conversation, items: [] });
    }
    for (const item of items) {
      const id = item.conversationId || "legacy";
      if (!byId.has(id)) {
        byId.set(id, {
          id,
          title: t(this.settings, id === "legacy" ? "olderMemory" : "memory"),
          createdAt: item.createdAt || "",
          updatedAt: item.createdAt || "",
          items: [],
        });
      }
      const group = byId.get(id);
      group.items.push(item);
      if (item.createdAt && (!group.updatedAt || item.createdAt > group.updatedAt)) group.updatedAt = item.createdAt;
    }
    return [...byId.values()]
      .filter((group) => group.items.length > 0)
      .sort((a, b) => String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")));
  }

  getMemorySummaries(limit = 20) {
    if (!this.settings.useLongTermMemory) return [];
    const items = Array.isArray(this.memoryItems) ? this.memoryItems : [];
    return items
      .slice(-Math.max(0, limit))
      .map((item) => ({
        id: item.id,
        kind: item.kind,
        label: item.label,
        summary: item.summary,
        createdAt: item.createdAt,
      }));
  }

  getRelevantMemorySummaries(query = "", limit = 8) {
    if (!this.settings.useLongTermMemory) return [];
    const items = Array.isArray(this.memoryItems) ? this.memoryItems : [];
    if (!items.length) return [];
    const terms = tokenize(query);
    const scored = items.map((item, index) => {
      const haystack = `${item.kind || ""}\n${item.label || ""}\n${item.summary || ""}\n${String(item.content || "").slice(0, 1600)}`;
      const score = terms.length ? lineScore(haystack, terms) : 0;
      return { item, score, index };
    });
    scored.sort((a, b) => b.score - a.score || b.index - a.index);
    return scored
      .filter((entry, index) => entry.score > 0 || index < Math.min(3, limit))
      .slice(0, Math.max(0, limit))
      .map(({ item, score }) => ({
        id: item.id,
        conversationId: item.conversationId || "",
        kind: item.kind,
        label: item.label,
        summary: item.summary,
        score,
        createdAt: item.createdAt,
      }));
  }

  getMemoryStats() {
    const groups = this.getMemoryConversationGroups();
    return {
      conversations: groups.length,
      items: Array.isArray(this.memoryItems) ? this.memoryItems.length : 0,
      currentConversationId: this.currentMemoryConversationId || "",
      currentConversationTitle:
        (this.getMemoryConversationById(this.currentMemoryConversationId || "") || {}).title || "",
    };
  }

  async rememberMemoryItem(item) {
    if (!this.settings.useLongTermMemory) return null;
    const content = String(item && item.content ? item.content : "").trim();
    if (!content) return null;
    const keep = this.getLongTermMemoryLimit();
    if (keep <= 0) return null;
    const conversationId = item.conversationId || this.ensureMemoryConversation();
    this.memoryItems = Array.isArray(this.memoryItems) ? this.memoryItems : [];
    this.memoryItems.push({
      id: this.memoryItems.length + 1,
      conversationId,
      kind: item.kind || "answer",
      label: item.label || item.kind || "Assistant output",
      summary: item.summary || cleanSnippet(content, 240),
      content,
      createdAt: new Date().toISOString(),
    });
    const conversation = this.memoryConversations.find((entry) => entry.id === conversationId);
    if (conversation) {
      conversation.updatedAt = new Date().toISOString();
    }
    this.memoryItems = this.memoryItems.slice(-keep);
    for (let index = 0; index < this.memoryItems.length; index += 1) {
      this.memoryItems[index].id = index + 1;
    }
    await this.savePluginData();
    return this.memoryItems[this.memoryItems.length - 1];
  }

  getMemoryContentForRoute(route, prompt = "") {
    if (!this.settings.useLongTermMemory || !Array.isArray(this.memoryItems) || !this.memoryItems.length) return "";
    const id = Number.parseInt(route && (route.memoryId || route.savedId), 10);
    if (Number.isFinite(id) && id > 0) {
      const byId = this.memoryItems.find((item) => item.id === id);
      if (byId) return byId.content || "";
    }
    const sourceQuery = String((route && (route.sourceQuery || route.sourceHint)) || prompt || "").trim();
    if (!sourceQuery) return "";
    const queryTerms = tokenize(sourceQuery);
    let best = null;
    let bestScore = 0;
    for (const item of this.memoryItems) {
      const score = lineScore(`${item.label} ${item.summary} ${String(item.content || "").slice(0, 1200)}`, queryTerms);
      if (score > bestScore) {
        best = item;
        bestScore = score;
      }
    }
    return best && bestScore > 0 ? best.content || "" : "";
  }

  async logTask(entry) {
    this.taskLog = Array.isArray(this.taskLog) ? this.taskLog : [];
    const steps = Array.isArray(entry.steps) ? entry.steps : [];
    this.taskLog.push({
      goal: String(entry.goal || "").trim(),
      file: String(entry.file || ""),
      change: String(entry.change || ""),
      steps,
      stepsText: steps.join(" -> "),
      createdAt: new Date().toISOString(),
    });
    this.taskLog = this.taskLog.slice(-100);
    await this.savePluginData();
  }

  extractWikiLinks(text) {
    const links = [];
    const pattern = /\[\[([^\]\n]+)\]\]/g;
    let match;
    while ((match = pattern.exec(String(text || "")))) {
      const raw = String(match[1] || "").split("|")[0].trim();
      if (raw) links.push(raw);
    }
    return links;
  }

  normalizeKnowledgeTarget(value) {
    return String(value || "")
      .split("|")[0]
      .split("#")[0]
      .replace(/\.md$/i, "")
      .replace(/\\/g, "/")
      .trim();
  }

  getKnowledgeProfileAliases(profile) {
    const path = String((profile && profile.path) || "").replace(/\\/g, "/");
    const noExt = path.replace(/\.md$/i, "");
    const title = String((profile && profile.title) || "").trim();
    const aliases = [title, path, noExt, noExt.split("/").pop()]
      .map((item) => this.normalizeKnowledgeTarget(item).toLowerCase())
      .filter(Boolean);
    return [...new Set(aliases)];
  }

  buildKnowledgeProfileLookup(profiles) {
    const lookup = new Map();
    for (const profile of profiles || []) {
      for (const alias of this.getKnowledgeProfileAliases(profile)) {
        if (!lookup.has(alias)) lookup.set(alias, profile.path);
      }
    }
    return lookup;
  }

  resolveKnowledgeTarget(value, lookup) {
    const normalized = this.normalizeKnowledgeTarget(value).toLowerCase();
    if (!normalized) return "";
    if (lookup && lookup.has(normalized)) return lookup.get(normalized);
    const basename = normalized.split("/").pop();
    return lookup && lookup.has(basename) ? lookup.get(basename) : "";
  }

  attachKnowledgeRelations(profiles) {
    const lookup = this.buildKnowledgeProfileLookup(profiles);
    const backlinks = new Map();
    for (const profile of profiles || []) {
      const resolved = [];
      for (const link of profile.links || []) {
        const target = this.resolveKnowledgeTarget(link, lookup);
        if (target && target !== profile.path) resolved.push(target);
      }
      profile.resolvedLinks = [...new Set(resolved)].slice(0, 80);
      for (const target of profile.resolvedLinks) {
        if (!backlinks.has(target)) backlinks.set(target, new Set());
        backlinks.get(target).add(profile.path);
      }
    }
    for (const profile of profiles || []) {
      profile.backlinks = [...(backlinks.get(profile.path) || new Set())].slice(0, 120);
      profile.inboundCount = Math.max(Number(profile.inboundCount || 0), profile.backlinks.length);
      profile.relatedPaths = [...new Set([...(profile.resolvedLinks || []), ...(profile.backlinks || [])])].slice(0, 100);
    }
    return profiles;
  }

  extractTags(text) {
    const tags = [];
    const pattern = /(^|[\s([{:])#([A-Za-z0-9_\-/\u0080-\uffff]+)/g;
    let match;
    while ((match = pattern.exec(String(text || "")))) {
      const tag = String(match[2] || "").trim();
      if (tag && !/^\d+$/.test(tag)) tags.push(`#${tag}`);
    }
    return [...new Set(tags)].slice(0, 40);
  }

  extractPathConcepts(path) {
    const normalized = String(path || "").replace(/\\/g, "/");
    const parts = normalized.split("/").filter(Boolean);
    const folders = parts.slice(0, -1);
    const cumulative = [];
    for (let index = 0; index < folders.length; index += 1) {
      cumulative.push(folders.slice(0, index + 1).join("/"));
    }
    return {
      folders,
      folderPaths: cumulative,
    };
  }

  extractKnowledgeSummary(content) {
    const lines = String(content || "").split(/\r?\n/);
    const picked = [];
    let inFrontmatter = false;
    let inCode = false;
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (line === "---" && picked.length === 0) {
        inFrontmatter = !inFrontmatter;
        continue;
      }
      if (inFrontmatter) continue;
      if (line.startsWith("```")) {
        inCode = !inCode;
        continue;
      }
      if (inCode || !line || /^#{1,6}\s+/.test(line)) continue;
      picked.push(line);
      if (picked.join(" ").length >= 650 || picked.length >= 5) break;
    }
    return cleanSnippet(picked.join(" "), 650);
  }

  extractKnowledgeCallouts(content, filePath = "") {
    const lines = String(content || "").split(/\r?\n/);
    const callouts = [];
    let current = null;
    const calloutStart = /^\s*>\s*\[!([A-Za-z][\w-]*)\]([+-])?\s*(.*)$/;

    const finish = () => {
      if (!current) return;
      const body = current.bodyLines.join("\n").trim();
      const title = current.title || "";
      const type = String(current.type || "").toLowerCase();
      const role = getKnowledgeCalloutRole(type);
      const endLine = current.endLine || current.line;
      const nearestHeading = getNearestHeading(lines, Math.max(0, current.line - 1));
      const headingPath = getHeadingPath(lines, Math.max(0, current.line - 1));
      const links = this.extractWikiLinks(body)
        .map((link) => this.normalizeKnowledgeTarget(link))
        .filter(Boolean)
        .slice(0, 20);
      const tags = this.extractTags(body).slice(0, 12);
      const formulas = [...body.matchAll(/\$([^$\n]{1,120})\$/g)]
        .map((match) => cleanSnippet(match[1], 80))
        .slice(0, 12);
      const firstSentence = cleanSnippet(
        body
          .replace(/\$\$[\s\S]*?\$\$/g, " ")
          .split(/(?<=[。！？.!?])\s+/)[0] || body,
        220
      );
      const inferredTitle = title || cleanSnippet(`${headingPath.split(" > ").pop() || nearestHeading}: ${firstSentence}`, 140);
      const headingTail = headingPath.split(" > ").pop() || nearestHeading;
      const blockId = current.blockId || "";
      callouts.push({
        type,
        role,
        title,
        inferredTitle,
        hasTitle: Boolean(title),
        line: current.line,
        endLine,
        heading: nearestHeading,
        headingPath,
        blockId,
        sourceLink: makeObsidianSourceLink(current.path || "", title || inferredTitle || nearestHeading, blockId, headingTail),
        sourcePrecision: blockId ? "block" : headingTail && headingTail !== "(no heading)" ? "heading" : "note",
        links,
        tags,
        formulas,
        firstSentence,
        body: limitTextBlock(body, 2600),
        summary: cleanSnippet(body, 700),
        textForSearch: [
          current.type,
          title,
          inferredTitle,
          nearestHeading,
          headingPath,
          blockId,
          makeObsidianSourceLink(current.path || "", title || inferredTitle || nearestHeading, blockId, headingTail),
          firstSentence,
          body,
          links.join(" "),
          tags.join(" "),
          formulas.join(" "),
        ].join("\n"),
      });
      current = null;
    };

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const match = line.match(calloutStart);
      if (match) {
        finish();
        current = {
          type: String(match[1] || "").toLowerCase(),
          title: String(match[3] || "").trim(),
          line: index + 1,
          endLine: index + 1,
          path: filePath,
          blockId: "",
          inFence: false,
          bodyLines: [],
        };
        continue;
      }
      if (!current) continue;
      const blockMatch = line.match(/^\s*\^([A-Za-z0-9-]{3,})\s*$/);
      if (blockMatch && !current.inFence) {
        current.blockId = blockMatch[1];
        current.endLine = index + 1;
        finish();
      } else if (/^\s*>/.test(line)) {
        const stripped = line.replace(/^\s*>\s?/, "");
        current.bodyLines.push(stripped);
        current.endLine = index + 1;
        if (stripped.trim().startsWith("```")) current.inFence = !current.inFence;
      } else if (current.inFence) {
        current.bodyLines.push(line);
        current.endLine = index + 1;
        if (line.trim().startsWith("```")) current.inFence = false;
      } else if (!line.trim()) {
        current.bodyLines.push("");
        current.endLine = index + 1;
      } else {
        current.endLine = Math.max(current.line, index);
        finish();
      }
    }
    finish();
    return callouts;
  }

  extractKnowledgeSections(content, filePath = "") {
    const lines = String(content || "").split(/\r?\n/);
    const headings = [];
    for (let index = 0; index < lines.length; index += 1) {
      const match = lines[index].match(/^(#{1,6})\s+(.+?)\s*$/);
      if (match) {
        headings.push({
          lineIndex: index,
          level: match[1].length,
          heading: match[2].trim(),
        });
      }
    }
    const sections = [];
    for (let index = 0; index < headings.length; index += 1) {
      const current = headings[index];
      const nextLine = index + 1 < headings.length ? headings[index + 1].lineIndex : lines.length;
      const body = lines.slice(current.lineIndex, nextLine).join("\n").trim();
      if (body.length < 30) continue;
      const links = this.extractWikiLinks(body)
        .map((link) => this.normalizeKnowledgeTarget(link))
        .filter(Boolean)
        .slice(0, 20);
      const formulas = [...body.matchAll(/\$([^$\n]{1,120})\$/g)]
        .map((match) => cleanSnippet(match[1], 80))
        .slice(0, 12);
      const headingPath = getHeadingPath(lines, current.lineIndex);
      sections.push({
        heading: current.heading,
        headingPath,
        line: current.lineIndex + 1,
        sourceLink: makeObsidianSourceLink(filePath, current.heading, "", current.heading),
        sourcePrecision: "heading",
        body: limitTextBlock(body, 2200),
        summary: cleanSnippet(body, 650),
        links,
        formulas,
        textForSearch: [current.heading, headingPath, filePath, body, links.join(" "), formulas.join(" ")].join("\n"),
      });
    }
    return sections;
  }

  buildNoteProfile(file, content, inboundCount = 0) {
    const lines = String(content || "").split(/\r?\n/);
    const headings = [];
    for (const line of lines) {
      const match = line.match(/^(#{1,6})\s+(.+?)\s*$/);
      if (match) {
        headings.push({
          level: match[1].length,
          text: match[2].trim(),
        });
      }
      if (headings.length >= 40) break;
    }
    const links = this.extractWikiLinks(content)
      .map((link) => this.normalizeKnowledgeTarget(link))
      .filter(Boolean);
    const uniqueLinks = [...new Set(links)].slice(0, 60);
    const tags = this.extractTags(content);
    const summary = this.extractKnowledgeSummary(content);
    const callouts = this.extractKnowledgeCallouts(content, file.path);
    const sections = this.extractKnowledgeSections(content, file.path);
    const pathConcepts = this.extractPathConcepts(file.path);
    return {
      path: file.path,
      title: file.basename,
      folders: pathConcepts.folders,
      folderPaths: pathConcepts.folderPaths,
      headings,
      callouts,
      sections,
      tags,
      links: uniqueLinks,
      inboundCount,
      outboundCount: uniqueLinks.length,
      calloutCount: callouts.length,
      summary,
      textForSearch: [
        file.path,
        file.basename,
        pathConcepts.folders.join(" "),
        pathConcepts.folderPaths.join(" "),
        headings.map((heading) => heading.text).join(" "),
        sections.map((section) => `${section.heading} ${section.summary}`).join(" "),
        callouts.map((item) => `${item.type} ${item.title} ${item.summary}`).join(" "),
        tags.join(" "),
        uniqueLinks.join(" "),
        summary,
      ].join("\n"),
    };
  }

  normalizeSearchPath(value) {
    return String(value || "")
      .replace(/\\/g, "/")
      .replace(/^\/+|\/+$/g, "")
      .toLowerCase();
  }

  isSearchPathUnderRoot(path, root) {
    if (!root) return false;
    return path === `${root}.md` || path === root || path.startsWith(`${root}/`);
  }

  isAiGeneratedSearchPath(path) {
    const parts = this.normalizeSearchPath(path)
      .split("/")
      .map((part) => part.replace(/\.md$/i, "").trim())
      .filter(Boolean);
    return parts.some((part) => /^ai[-_\s]+generated\b/.test(part));
  }

  shouldUseFileForSearch(file) {
    if (!(file instanceof TFile) || file.extension !== "md") return false;
    const draftFolder = this.normalizeSearchPath((this.settings && this.settings.draftFolder) || "AI Drafts");
    const handoffFolder = this.normalizeSearchPath((this.settings && this.settings.handoffFolder) || "AI Handoffs");
    const path = this.normalizeSearchPath(file.path || "");
    if (this.isSearchPathUnderRoot(path, draftFolder)) return false;
    if (this.isSearchPathUnderRoot(path, handoffFolder)) return false;
    if (this.isAiGeneratedSearchPath(path)) return false;
    return true;
  }

  getSearchableMarkdownFiles() {
    return this.app.vault.getMarkdownFiles().filter((file) => this.shouldUseFileForSearch(file));
  }

  getFileSignature(file) {
    return {
      path: file.path,
      mtime: Number(file.stat && file.stat.mtime ? file.stat.mtime : 0),
      size: Number(file.stat && file.stat.size ? file.stat.size : 0),
    };
  }

  isKnowledgeIndexStale() {
    const index = this.knowledgeIndex;
    if (!index || Number(index.version || 0) < KNOWLEDGE_INDEX_VERSION) return true;
    const saved = new Map((Array.isArray(index.fileSignatures) ? index.fileSignatures : []).map((item) => [item.path, item]));
    const files = this.getSearchableMarkdownFiles();
    if (saved.size !== files.length) return true;
    for (const file of files) {
      const current = this.getFileSignature(file);
      const previous = saved.get(current.path);
      if (!previous || Number(previous.mtime || 0) !== current.mtime || Number(previous.size || 0) !== current.size) {
        return true;
      }
    }
    return false;
  }

  async buildKnowledgeIndex(onProgress = null) {
    const files = this.getSearchableMarkdownFiles();
    const byPath = new Map();
    const inbound = new Map();

    for (let index = 0; index < files.length; index += 1) {
      const file = files[index];
      if (onProgress) onProgress(`Reading notes ${index + 1}/${files.length}`);
      const content = await this.app.vault.cachedRead(file);
      byPath.set(file.path, content);
      for (const rawLink of this.extractWikiLinks(content)) {
        const target = this.normalizeKnowledgeTarget(rawLink);
        if (!target) continue;
        inbound.set(target, (inbound.get(target) || 0) + 1);
      }
    }

    const profiles = [];
    const concepts = new Map();
    const domains = new Map();
    const calloutUnits = [];
    const sectionUnits = [];
    for (let index = 0; index < files.length; index += 1) {
      const file = files[index];
      if (onProgress) onProgress(`Mapping notes ${index + 1}/${files.length}`);
      const titleKey = file.basename;
      const pathKey = file.path.replace(/\.md$/i, "");
      const profile = this.buildNoteProfile(
        file,
        byPath.get(file.path) || "",
        Math.max(inbound.get(titleKey) || 0, inbound.get(pathKey) || 0)
      );
      profiles.push(profile);
      for (const folder of profile.folders || []) {
        if (!folder) continue;
        if (!domains.has(folder)) domains.set(folder, { name: folder, count: 0, paths: [] });
        const domain = domains.get(folder);
        domain.count += 1;
        if (domain.paths.length < 12 && !domain.paths.includes(profile.path)) domain.paths.push(profile.path);
      }
      for (const [calloutIndex, callout] of (profile.callouts || []).entries()) {
        calloutUnits.push({
          id: `${profile.path}#callout-${callout.line || calloutIndex + 1}`,
          path: profile.path,
          noteTitle: profile.title,
          indexInFile: calloutIndex,
          inboundCount: profile.inboundCount || 0,
          ...callout,
          textForSearch: [
            profile.path,
            profile.title,
            callout.type,
            callout.title,
            callout.inferredTitle,
            callout.heading,
            callout.headingPath,
            callout.blockId,
            callout.sourceLink,
            callout.firstSentence,
            callout.body,
            callout.summary,
            (callout.links || []).join(" "),
            (callout.tags || []).join(" "),
            (callout.formulas || []).join(" "),
          ].join("\n"),
        });
      }
      for (const [sectionIndex, section] of (profile.sections || []).entries()) {
        sectionUnits.push({
          id: `${profile.path}#section-${section.line || sectionIndex + 1}`,
          path: profile.path,
          noteTitle: profile.title,
          indexInFile: sectionIndex,
          inboundCount: profile.inboundCount || 0,
          ...section,
          textForSearch: [
            profile.path,
            profile.title,
            section.heading,
            section.headingPath,
            section.sourceLink,
            section.body,
            section.summary,
            (section.links || []).join(" "),
            (section.formulas || []).join(" "),
          ].join("\n"),
        });
      }

      const names = [
        profile.title,
        ...(profile.folders || []),
        ...(profile.folderPaths || []),
        ...profile.headings.map((heading) => heading.text),
        ...profile.sections.map((item) => item.heading),
        ...profile.callouts.flatMap((item) =>
          item.title ? [item.title, item.type] : [item.heading, item.headingPath, item.type].filter(Boolean)
        ),
        ...profile.tags,
        ...profile.links,
      ];
      for (const name of names) {
        const key = cleanSnippet(String(name || "").replace(/^#+/, "").trim(), 120);
        if (!key || key.length < 2) continue;
        if (!concepts.has(key)) concepts.set(key, { name: key, count: 0, paths: [] });
        const concept = concepts.get(key);
        concept.count += 1;
        if (concept.paths.length < 8 && !concept.paths.includes(profile.path)) concept.paths.push(profile.path);
      }
    }

    this.attachKnowledgeRelations(profiles);
    const profilesByPath = new Map(profiles.map((profile) => [profile.path, profile]));
    for (const unit of calloutUnits) {
      const profile = profilesByPath.get(unit.path);
      if (!profile) continue;
      unit.inboundCount = profile.inboundCount || unit.inboundCount || 0;
      unit.resolvedLinks = profile.resolvedLinks || [];
      unit.backlinks = profile.backlinks || [];
      unit.relatedPaths = profile.relatedPaths || [];
    }
    for (const unit of sectionUnits) {
      const profile = profilesByPath.get(unit.path);
      if (!profile) continue;
      unit.inboundCount = profile.inboundCount || unit.inboundCount || 0;
      unit.resolvedLinks = profile.resolvedLinks || [];
      unit.backlinks = profile.backlinks || [];
      unit.relatedPaths = profile.relatedPaths || [];
    }

    profiles.sort(
      (a, b) =>
        b.inboundCount + b.outboundCount * 0.15 + b.headings.length * 0.05 + b.calloutCount * 0.25 -
        (a.inboundCount + a.outboundCount * 0.15 + a.headings.length * 0.05 + a.calloutCount * 0.25)
    );

    this.knowledgeIndex = {
      version: KNOWLEDGE_INDEX_VERSION,
      builtAt: new Date().toISOString(),
      fileCount: files.length,
      fileSignatures: files.map((file) => this.getFileSignature(file)),
      profiles,
      callouts: calloutUnits,
      sections: sectionUnits,
      concepts: [...concepts.values()].sort((a, b) => b.count - a.count),
      conceptTotal: concepts.size,
      domains: [...domains.values()].sort((a, b) => b.count - a.count),
    };
    await this.savePluginData();
    return this.knowledgeIndex;
  }

  normalizeConceptCardId(name) {
    return String(name || "")
      .toLowerCase()
      .replace(/\s+/g, "")
      .replace(/[，。,:：;；?？!！]/g, "")
      .slice(0, 160);
  }

  isInvalidConceptCardName(name) {
    const value = String(name || "").trim();
    if (!value) return true;
    if (/^\(?no\s+heading\)?$/i.test(value)) return true;
    if (/^\(?无标题\)?$/.test(value)) return true;
    if (/^\(?未命名\)?$/.test(value)) return true;
    return false;
  }

  isTechnicalConceptCardName(name, card = null) {
    const value = String(name || "").trim();
    if (this.isInvalidConceptCardName(value)) return true;
    const plain = value.replace(/\$[^$]*\$/g, "").trim();
    const formulaChars = (value.match(/[\\_^{}=<>+\-*/|()[\]]/g) || []).length;
    const symbolRatio = formulaChars / Math.max(1, value.length);
    const hasWords = /[A-Za-z\u3400-\u9fff]{2,}/.test(plain);
    if (value.length > 110) return true;
    if (!hasWords && symbolRatio > 0.25) return true;
    if (/^(case|step|claim|proof|calculation|construction|notation detail)\b/i.test(value)) return true;
    if (/(证明|计算|步骤|情形|情况|上式|下式|如下|下面|技术|细节)$/.test(value)) return true;
    if (card) {
      const sourceCount = (card.sourcePaths || []).length;
      const definitionCount = (card.coreDefinitions || []).length;
      const statementCount = (card.statements || []).length;
      if (!definitionCount && statementCount <= 1 && sourceCount <= 1 && symbolRatio > 0.18) return true;
    }
    return false;
  }

  getConceptCardName(callout, profile) {
    const title = cleanSnippet(String((callout && callout.title) || "").trim(), 100);
    if (title && !this.isInvalidConceptCardName(title)) return title;
    const type = String((callout && callout.type) || "").toLowerCase();
    const heading = cleanSnippet(String((callout && callout.headingPath) || (callout && callout.heading) || "").split(" > ").pop(), 90);
    if (heading && !this.isInvalidConceptCardName(heading) && ["definition", "def", "notation", "example", "remark"].includes(type)) return heading;
    if (type === "definition" || type === "def") {
      const profileTitle = cleanSnippet(String((profile && profile.title) || ""), 90);
      return this.isInvalidConceptCardName(profileTitle) ? "" : profileTitle;
    }
    return "";
  }

  makeConceptCardEvidence(callout, profile) {
    const heading = String((callout && callout.headingPath) || (callout && callout.heading) || "");
    const headingTail = cleanSnippet(heading.split(" > ").pop(), 90);
    const safeHeading = headingTail && !this.isInvalidConceptCardName(headingTail) ? headingTail : "";
    const safeLabel = cleanSnippet(String((callout && callout.title) || safeHeading || (profile && profile.title) || "").trim(), 120);
    const rawSourceLink = String((callout && callout.sourceLink) || "");
    return {
      type: String((callout && callout.type) || "").toLowerCase(),
      sourceLink:
        rawSourceLink && !/\(?no\s+heading\)?/i.test(rawSourceLink)
          ? rawSourceLink
          : makeObsidianSourceLink(profile.path, safeLabel || this.getCalloutLabel(callout, false), callout.blockId || "", safeHeading),
      path: String((profile && profile.path) || (callout && callout.path) || ""),
      line: Number((callout && callout.line) || 0),
      heading,
      summary: cleanSnippet(String((callout && callout.summary) || (callout && callout.firstSentence) || ""), 520),
      links: Array.isArray(callout && callout.links) ? callout.links.slice(0, 10) : [],
    };
  }

  proofMatchesConceptCard(card, proof, profile) {
    const proofLine = Number((proof && proof.line) || 0);
    const path = String((profile && profile.path) || "");
    const evidenceItems = [
      ...(card.coreDefinitions || []),
      ...(card.statements || []),
      ...(card.examples || []),
      ...(card.remarks || []),
    ].filter((item) => String(item.path || "") === path);
    if (!evidenceItems.length) return false;
    if (proofLine) {
      for (const item of evidenceItems) {
        const line = Number(item.line || 0);
        if (line && proofLine >= line && proofLine - line <= 90) return true;
      }
    }
    const haystack = [
      proof && proof.title,
      proof && proof.headingPath,
      proof && proof.heading,
      proof && proof.summary,
      proof && proof.firstSentence,
      Array.isArray(proof && proof.links) ? proof.links.join(" ") : "",
    ]
      .join("\n")
      .toLowerCase();
    return (card.aliases || []).some((alias) => {
      const key = String(alias || "").toLowerCase().trim();
      return key.length >= 3 && haystack.includes(key);
    });
  }

  addConceptCardRelation(card, value, weight = 1) {
    const key = cleanSnippet(String(value || "").trim(), 120);
    if (!key || key.length < 2) return;
    const current = card.relatedConcepts.find((item) => item.name === key);
    if (current) current.count += weight;
    else card.relatedConcepts.push({ name: key, count: weight });
  }

  normalizeConceptCardAliasList(value) {
    const raw = Array.isArray(value) ? value.join("\n") : String(value || "");
    return [...new Set(raw.split(/[\n,，;；]+/).map((item) => cleanSnippet(item.trim(), 80)).filter(Boolean))].slice(0, 24);
  }

  applyConceptCardEdit(card) {
    if (!card) return card;
    const edits = this.conceptCardEdits && typeof this.conceptCardEdits === "object" ? this.conceptCardEdits : {};
    const edit = edits[card.id] || {};
    card.generatedName = card.generatedName || card.name || "";
    card.customTitle = cleanSnippet(String(edit.title || "").trim(), 100);
    card.parentTopic = cleanSnippet(String(edit.parentTopic || card.parentTopic || "").trim(), 100);
    card.userNote = cleanSnippet(String(edit.note || "").trim(), 300);
    card.customAliases = this.normalizeConceptCardAliasList(edit.aliases || []);
    if (card.customTitle && !this.isInvalidConceptCardName(card.customTitle)) card.name = card.customTitle;
    const aliases = [card.generatedName, card.name, ...(card.generatedAliases || card.aliases || []), ...(card.customAliases || []), card.parentTopic].filter(Boolean);
    card.aliases = [...new Set(aliases.map((item) => cleanSnippet(String(item || "").trim(), 100)).filter(Boolean))].slice(0, 32);
    return card;
  }

  inferConceptCardParentTopic(card, cardsByName = new Map()) {
    if (!card) return "";
    const name = String(card.name || "").trim();
    if (!name) return "";
    const explicit = String(card.parentTopic || "").trim();
    if (explicit) return explicit;
    const paren = name.match(/^(.+?)[(（][^)）]{2,}[)）]$/);
    if (paren && paren[1].trim().length >= 2) return cleanSnippet(paren[1].trim(), 80);
    const suffix = name.match(/^(.{2,30}?)(?:上的|中的|里的|关于)(.{2,16})$/);
    if (suffix && /(性|结构|范畴|表示|拓扑|测度|积分|同调|上同调|稠密|紧性|连续|完备|正则|凸性)$/.test(suffix[2])) {
      return cleanSnippet(suffix[2].trim(), 80);
    }
    const compact = this.normalizeConceptCardMergeName(name);
    for (const other of cardsByName.values()) {
      if (!other || other.id === card.id) continue;
      const otherCompact = this.normalizeConceptCardMergeName(other.name);
      if (otherCompact.length >= 2 && compact.length >= otherCompact.length + 2 && compact.includes(otherCompact)) {
        return other.name;
      }
    }
    return "";
  }

  attachConceptCardHierarchy(cards) {
    const cardsByName = new Map();
    for (const card of cards) {
      if (card && card.name) cardsByName.set(card.name, card);
    }
    for (const card of cards) {
      const parent = this.inferConceptCardParentTopic(card, cardsByName);
      card.parentTopic = parent || "";
      card.childConcepts = [];
      card.topicLevel = parent ? "subtopic" : "topic";
    }
    const parentMap = new Map();
    for (const card of cards) {
      const parent = String(card.parentTopic || "").trim();
      if (!parent) continue;
      if (!parentMap.has(parent)) parentMap.set(parent, []);
      parentMap.get(parent).push({ id: card.id, name: card.name, risk: card.risk || "medium" });
    }
    for (const card of cards) {
      const children = parentMap.get(card.name) || parentMap.get(card.generatedName) || [];
      card.childConcepts = children.filter((item) => item.id !== card.id).slice(0, 24);
      if (card.childConcepts.length) card.topicLevel = "broad";
    }
  }

  reviewConceptCard(card) {
    let score = 0;
    const reasons = [];
    if ((card.coreDefinitions || []).length) {
      score += 35;
      reasons.push("has explicit definition/notation");
    }
    if ((card.statements || []).length) {
      score += Math.min(30, card.statements.length * 5);
      reasons.push("has theorem/proposition support");
    }
    const sourceCount = (card.sourcePaths || []).length;
    score += Math.min(20, sourceCount * 4);
    const relationCount = (card.relatedConcepts || []).reduce((sum, item) => sum + Number(item.count || 0), 0);
    if (relationCount) {
      score += Math.min(15, relationCount * 0.25);
      reasons.push("relation graph has usable neighbors");
    }
    if (!(card.coreDefinitions || []).length && (card.statements || []).length <= 1) {
      score -= 25;
      reasons.push("weak card: no definition and little support");
    }
    if (String(card.name || "").length > 80) {
      score -= 20;
      reasons.push("name is long; likely needs human review");
    }
    if (this.isTechnicalConceptCardName(card.name, card)) {
      score -= 45;
      reasons.push("likely technical detail rather than stable concept");
    }
    const allEvidence = [
      ...(card.coreDefinitions || []),
      ...(card.statements || []),
      ...(card.examples || []),
      ...(card.remarks || []),
    ];
    if (allEvidence.every((item) => item.sourceLink)) {
      score += 10;
      reasons.push("all core items have source links");
    } else {
      score -= 40;
      reasons.push("missing source link");
    }
    const proofRatio = (card.proofEntrances || []).length / Math.max(1, allEvidence.length);
    if (proofRatio > 1.2) {
      score -= 20;
      reasons.push("proof entrances too dominant");
    } else {
      reasons.push("proof kept as entrance only");
    }
    if (sourceCount >= 2 && (card.coreDefinitions || []).length) {
      score += 10;
      reasons.push("multi-note support");
    }
    score = Math.max(0, Math.round(score * 10) / 10);
    const confidence = score >= 75 ? "high" : score >= 45 ? "medium" : "low";
    const risk = score >= 75 ? "low" : score >= 45 ? "medium" : "high";
    return { score, confidence, risk, reasons: [...new Set(reasons)].slice(0, 8) };
  }

  getConceptCardEvidenceSignature(card) {
    const evidence = [
      ...(card.coreDefinitions || []),
      ...(card.statements || []),
      ...(card.examples || []),
      ...(card.remarks || []),
      ...(card.proofEntrances || []),
    ]
      .map((item) =>
        [
          item.type || "",
          item.sourceLink || "",
          item.path || "",
          Number(item.line || 0),
          cleanSnippet(item.summary || "", 220),
        ].join("|")
      )
      .sort();
    const relations = (card.relatedConcepts || [])
      .slice(0, 30)
      .map((item) => `${item.name || ""}:${Number(item.count || 0)}`)
      .sort();
    return [card.generatedName || card.name || "", ...evidence, ...relations].join("\n").slice(0, 12000);
  }

  normalizeConceptCardMergeName(name) {
    return String(name || "")
      .toLowerCase()
      .replace(/\s+/g, "")
      .replace(/definition|proposition|theorem|lemma|corollary|remark|example|notation/gi, "")
      .replace(/[定义命题定理引理推论例子记号备注]/g, "")
      .replace(/[，。；;：:、,.!?！？（）()【】\[\]{}《》<>「」『』"'`~·“”‘’]/g, "")
      .slice(0, 120);
  }

  attachConceptCardMergeSuggestions(cards) {
    const tokenIndex = new Map();
    const byId = new Map(cards.map((card) => [card.id, card]));
    for (const card of cards) {
      const tokens = tokenizePlainKnowledge(`${card.name || ""} ${(card.aliases || []).join(" ")}`)
        .filter((token) => token.length >= 2)
        .slice(0, 20);
      for (const token of tokens) {
        if (!tokenIndex.has(token)) tokenIndex.set(token, new Set());
        tokenIndex.get(token).add(card.id);
      }
    }
    for (const card of cards) {
      const tokens = tokenizePlainKnowledge(`${card.name || ""} ${(card.aliases || []).join(" ")}`)
        .filter((token) => token.length >= 2)
        .slice(0, 20);
      const counts = new Map();
      for (const token of tokens) {
        const ids = tokenIndex.get(token);
        if (!ids) continue;
        for (const id of ids) {
          if (id === card.id) continue;
          counts.set(id, Number(counts.get(id) || 0) + 1);
        }
      }
      const compact = this.normalizeConceptCardMergeName(card.name);
      const sourceSet = new Set(card.sourcePaths || []);
      const suggestions = [...counts.entries()]
        .map(([id, count]) => {
          const other = byId.get(id);
          if (!other) return null;
          const otherCompact = this.normalizeConceptCardMergeName(other.name);
          const sameSource = (other.sourcePaths || []).some((path) => sourceSet.has(path));
          const containsName =
            compact.length >= 3 &&
            otherCompact.length >= 3 &&
            (compact.includes(otherCompact) || otherCompact.includes(compact));
          const exactName = compact.length >= 2 && compact === otherCompact;
          const strongContainment = sameSource && containsName && Math.min(compact.length, otherCompact.length) >= 4 && count >= 2;
          if (!exactName && !strongContainment) return null;
          let score = count * 3;
          if (exactName) score += 35;
          if (containsName) score += 18;
          if (sameSource) score += 8;
          if ((card.relatedConcepts || []).some((item) => item.name === other.name)) score += 4;
          if (score < 40) return null;
          return {
            id: other.id,
            name: other.name,
            score,
            reason: sameSource ? "same source" : containsName ? "similar name" : "shared terms",
          };
        })
        .filter(Boolean)
        .sort((a, b) => Number(b.score || 0) - Number(a.score || 0))
        .slice(0, 5);
      card.mergeSuggestions = suggestions;
      if (suggestions.length && !(card.reviewReasons || []).includes("possible duplicate/merge target")) {
        card.reviewReasons = [...(card.reviewReasons || []), "possible duplicate/merge target"].slice(0, 9);
      }
    }
  }

  getConceptCardQueue(card) {
    const status = String((card && card.status) || "auto");
    const changeStatus = String((card && card.changeStatus) || "new");
    if (status === "accepted" && changeStatus !== "changed") return "confirmed";
    if (status === "rejected" && changeStatus !== "changed") return "rejected";
    if (changeStatus === "changed") return "review";
    if (String((card && card.risk) || "") === "high" || String((card && card.confidence) || "") === "low" || Number((card && card.reviewScore) || 0) < 45) {
      return "insufficient";
    }
    if ((card && card.mergeSuggestions && card.mergeSuggestions.length) || false) return "review";
    if (String((card && card.risk) || "") === "low" && String((card && card.confidence) || "") === "high" && Number((card && card.reviewScore) || 0) >= 75) {
      return "auto_pass";
    }
    return "review";
  }

  getConceptCardStats(cards) {
    const stats = {
      total: cards.length,
      accepted: cards.filter((card) => card.status === "accepted").length,
      rejected: cards.filter((card) => card.status === "rejected").length,
      high: cards.filter((card) => card.confidence === "high").length,
      medium: cards.filter((card) => card.confidence === "medium").length,
      low: cards.filter((card) => card.confidence === "low").length,
      changed: cards.filter((card) => card.changeStatus === "changed").length,
      new: cards.filter((card) => card.changeStatus === "new").length,
      unchanged: cards.filter((card) => card.changeStatus === "unchanged").length,
      mergeSuggestions: cards.filter((card) => (card.mergeSuggestions || []).length).length,
      queues: {},
    };
    for (const card of cards) {
      const queue = this.getConceptCardQueue(card);
      card.reviewQueue = queue;
      stats.queues[queue] = Number(stats.queues[queue] || 0) + 1;
    }
    return stats;
  }

  async buildConceptCards(onProgress = null) {
    if (!this.knowledgeIndex || !Array.isArray(this.knowledgeIndex.profiles) || this.isKnowledgeIndexStale()) {
      if (onProgress) onProgress(t(this.settings, "buildKnowledge"));
      await this.buildKnowledgeIndex(onProgress);
    }
    const index = this.knowledgeIndex || {};
    const profiles = Array.isArray(index.profiles) ? index.profiles : [];
    const previousCards = this.conceptCards && Array.isArray(this.conceptCards.cards) ? this.conceptCards.cards : [];
    const previousById = new Map(previousCards.map((card) => [card.id, card]));
    const cardsById = new Map();
    const profileByPath = new Map(profiles.map((profile) => [profile.path, profile]));
    for (let profileIndex = 0; profileIndex < profiles.length; profileIndex += 1) {
      const profile = profiles[profileIndex];
      if (onProgress && profileIndex % 25 === 0) onProgress(`Concept cards ${profileIndex + 1}/${profiles.length}`);
      for (const callout of profile.callouts || []) {
        const role = String((callout && callout.role) || getKnowledgeCalloutRole(callout && callout.type));
        if (role !== "core") continue;
        const name = this.getConceptCardName(callout, profile);
        if (!name || this.isInvalidConceptCardName(name)) continue;
        const id = this.normalizeConceptCardId(name);
        if (!id) continue;
        if (!cardsById.has(id)) {
          cardsById.set(id, {
            id,
            name,
            generatedName: name,
            aliases: [name],
            status: "auto",
            confidence: "medium",
            risk: "medium",
            reviewScore: 0,
            coreDefinitions: [],
            statements: [],
            examples: [],
            remarks: [],
            proofEntrances: [],
            relatedConcepts: [],
            sourcePaths: [],
            reviewReasons: [],
          });
        }
        const card = cardsById.get(id);
        if (!card.aliases.includes(name)) card.aliases.push(name);
        if (!card.sourcePaths.includes(profile.path)) card.sourcePaths.push(profile.path);
        for (const link of callout.links || []) this.addConceptCardRelation(card, link, 2);
        for (const relatedPath of [...(profile.resolvedLinks || []), ...(profile.backlinks || [])].slice(0, 24)) {
          const related = profileByPath.get(relatedPath);
          if (related) this.addConceptCardRelation(card, related.title, 1);
        }
        const evidence = this.makeConceptCardEvidence(callout, profile);
        const type = String((callout && callout.type) || "").toLowerCase();
        if (["definition", "def", "notation"].includes(type)) card.coreDefinitions.push(evidence);
        else if (type === "example") card.examples.push(evidence);
        else if (type === "remark") card.remarks.push(evidence);
        else card.statements.push(evidence);
      }
    }
    for (const profile of profiles) {
      const proofItems = (profile.callouts || []).filter((callout) => String((callout && callout.role) || getKnowledgeCalloutRole(callout && callout.type)) === "auxiliary");
      if (!proofItems.length) continue;
      for (const card of cardsById.values()) {
        if (!(card.sourcePaths || []).includes(profile.path)) continue;
        for (const proof of proofItems) {
          if (!this.proofMatchesConceptCard(card, proof, profile)) continue;
          card.proofEntrances.push(this.makeConceptCardEvidence(proof, profile));
          if (card.proofEntrances.length >= 8) break;
        }
      }
    }
    const decisions = this.conceptCardDecisions && typeof this.conceptCardDecisions === "object" ? this.conceptCardDecisions : {};
    const cards = [...cardsById.values()].map((card) => {
      card.relatedConcepts = (card.relatedConcepts || []).sort((a, b) => Number(b.count || 0) - Number(a.count || 0)).slice(0, 40);
      card.coreDefinitions = (card.coreDefinitions || []).slice(0, 8);
      card.statements = (card.statements || []).slice(0, 16);
      card.examples = (card.examples || []).slice(0, 8);
      card.remarks = (card.remarks || []).slice(0, 8);
      card.proofEntrances = (card.proofEntrances || []).slice(0, 8);
      card.generatedAliases = [...new Set([card.generatedName || card.name, ...(card.aliases || [])].filter(Boolean))].slice(0, 24);
      this.applyConceptCardEdit(card);
      const review = this.reviewConceptCard(card);
      card.reviewScore = review.score;
      card.confidence = review.confidence;
      card.risk = review.risk;
      card.reviewReasons = review.reasons;
      card.evidenceSignature = this.getConceptCardEvidenceSignature(card);
      const previous = previousById.get(card.id);
      if (!previous) card.changeStatus = "new";
      else if (!previous.evidenceSignature) card.changeStatus = "unchanged";
      else card.changeStatus = String(previous.evidenceSignature || "") === String(card.evidenceSignature || "") ? "unchanged" : "changed";
      if (decisions[card.id]) {
        card.status = decisions[card.id].status || card.status;
        card.decidedAt = decisions[card.id].decidedAt || "";
      }
      return card;
    });
    this.attachConceptCardMergeSuggestions(cards);
    this.attachConceptCardHierarchy(cards);
    const stats = this.getConceptCardStats(cards);
    const queuePriority = { review: 0, auto_pass: 1, insufficient: 2, confirmed: 3, rejected: 4 };
    cards.sort((a, b) => {
      const queueA = queuePriority[this.getConceptCardQueue(a)] ?? 9;
      const queueB = queuePriority[this.getConceptCardQueue(b)] ?? 9;
      if (queueA !== queueB) return queueA - queueB;
      if ((a.changeStatus || "") !== (b.changeStatus || "")) return String(a.changeStatus || "").localeCompare(String(b.changeStatus || ""));
      return Number(b.reviewScore || 0) - Number(a.reviewScore || 0);
    });
    this.conceptCards = {
      version: CONCEPT_CARD_INDEX_VERSION,
      builtAt: new Date().toISOString(),
      knowledgeBuiltAt: index.builtAt || "",
      cards,
      stats,
    };
    await this.savePluginData();
    return this.conceptCards;
  }

  isConceptCardIndexStale() {
    if (!this.conceptCards || Number(this.conceptCards.version || 0) < CONCEPT_CARD_INDEX_VERSION) return true;
    if (!this.knowledgeIndex || !this.conceptCards.knowledgeBuiltAt) return true;
    return String(this.conceptCards.knowledgeBuiltAt || "") !== String(this.knowledgeIndex.builtAt || "");
  }

  getConceptCardReviewRows() {
    const cards = this.conceptCards && Array.isArray(this.conceptCards.cards) ? this.conceptCards.cards : [];
    return cards.map((card, index) => ({ ...card, reviewQueue: card.reviewQueue || this.getConceptCardQueue(card), index: index + 1 }));
  }

  async setConceptCardDecision(cardId, status) {
    const changed = await this.setConceptCardDecisions([cardId], status);
    const id = String(cardId || "");
    return changed ? this.conceptCardDecisions[id] : null;
  }

  async setConceptCardDecisions(cardIds, status) {
    const ids = [...new Set((Array.isArray(cardIds) ? cardIds : [cardIds]).map((id) => String(id || "")).filter(Boolean))];
    if (!ids.length) return 0;
    const normalizedStatus = status === "accepted" ? "accepted" : "rejected";
    const decidedAt = new Date().toISOString();
    const idSet = new Set(ids);
    let changed = 0;
    this.conceptCardDecisions = this.conceptCardDecisions && typeof this.conceptCardDecisions === "object" ? this.conceptCardDecisions : {};
    for (const id of ids) {
      this.conceptCardDecisions[id] = {
        status: normalizedStatus,
        decidedAt,
      };
      changed += 1;
    }
    if (this.conceptCards && Array.isArray(this.conceptCards.cards)) {
      for (const card of this.conceptCards.cards) {
        if (idSet.has(card.id)) {
          card.status = normalizedStatus;
          card.decidedAt = decidedAt;
          card.reviewQueue = this.getConceptCardQueue(card);
        }
      }
      this.conceptCards.stats = this.getConceptCardStats(this.conceptCards.cards);
    }
    await this.savePluginData();
    return changed;
  }

  async setConceptCardEdit(cardId, edit) {
    const id = String(cardId || "");
    if (!id) return null;
    this.conceptCardEdits = this.conceptCardEdits && typeof this.conceptCardEdits === "object" ? this.conceptCardEdits : {};
    const normalized = {
      title: cleanSnippet(String((edit && edit.title) || "").trim(), 100),
      aliases: this.normalizeConceptCardAliasList(edit && edit.aliases),
      parentTopic: cleanSnippet(String((edit && edit.parentTopic) || "").trim(), 100),
      note: cleanSnippet(String((edit && edit.note) || "").trim(), 300),
      updatedAt: new Date().toISOString(),
    };
    if (!normalized.title && !normalized.aliases.length && !normalized.parentTopic && !normalized.note) delete this.conceptCardEdits[id];
    else this.conceptCardEdits[id] = normalized;
    if (this.conceptCards && Array.isArray(this.conceptCards.cards)) {
      for (const card of this.conceptCards.cards) {
        if (card.id !== id) continue;
        card.name = card.generatedName || card.name;
        card.aliases = [...(card.generatedAliases || [card.generatedName || card.name])].filter(Boolean);
        card.parentTopic = "";
        card.userNote = "";
        card.customAliases = [];
        this.applyConceptCardEdit(card);
        const review = this.reviewConceptCard(card);
        card.reviewScore = review.score;
        card.confidence = review.confidence;
        card.risk = review.risk;
        card.reviewReasons = review.reasons;
      }
      this.attachConceptCardMergeSuggestions(this.conceptCards.cards);
      this.attachConceptCardHierarchy(this.conceptCards.cards);
      this.conceptCards.stats = this.getConceptCardStats(this.conceptCards.cards);
    }
    await this.savePluginData();
    return this.conceptCardEdits[id] || null;
  }

  async clearConceptCardEdit(cardId) {
    return this.setConceptCardEdit(cardId, {});
  }

  knowledgeProfileHasFocus(profile, query) {
    const focusTerms = getKnowledgeFocusTerms(query);
    if (!focusTerms.length) return true;
    const anchor = [
      profile && profile.path,
      profile && profile.title,
      Array.isArray(profile && profile.folders) ? profile.folders.join(" ") : "",
      Array.isArray(profile && profile.folderPaths) ? profile.folderPaths.join(" ") : "",
      Array.isArray(profile && profile.headings) ? profile.headings.map((heading) => heading.text).join(" ") : "",
      Array.isArray(profile && profile.links) ? profile.links.join(" ") : "",
    ].join("\n");
    return scoreKnowledgeFocus(anchor, focusTerms) > 0;
  }

  getKnowledgeMatches(query, limit = 8) {
    if (!this.knowledgeIndex || !Array.isArray(this.knowledgeIndex.profiles)) return [];
    const terms = tokenize(query);
    if (!terms.length) return [];
    const focus = getQueryFocus(query);
    const parts = getQueryFocusParts(query);
    const scored = this.knowledgeIndex.profiles
      .map((profile) => {
        const title = String(profile.title || "");
        const path = String(profile.path || "");
        const folders = Array.isArray(profile.folders) ? profile.folders.join(" ") : "";
        let score = 0;
        score += lineScore(title, terms) * 5.0;
        score += lineScore(path, terms) * 3.0;
        score += lineScore(folders, terms) * 2.5;
        score += lineScore(profile.textForSearch || "", terms) * 0.45;
        if (compactEqualSearch(title, focus)) score += 180;
        else if (exactishContainsSearch(title, focus)) score += 55;
        if (exactishContainsSearch(path, focus)) score += 90;
        for (const part of parts) {
          if (compactEqualSearch(title, part)) score += 150;
          else if (exactishContainsSearch(title, part)) score += 45;
          if (exactishContainsSearch(path, part)) score += 45;
        }
        score += Math.min(30, Number(profile.inboundCount || 0) * 2);
        score += Math.min(25, Number(profile.calloutCount || 0) * 0.5);
        return { ...profile, knowledgeScore: score };
      })
      .filter((profile) => profile.knowledgeScore > 0)
      .sort((a, b) => b.knowledgeScore - a.knowledgeScore);
    const focused = scored.filter((profile) => this.knowledgeProfileHasFocus(profile, query));
    return (focused.length ? focused : scored)
      .slice(0, limit);
  }

  getKnowledgeConceptMatches(query, limit = 10) {
    if (!this.knowledgeIndex || !Array.isArray(this.knowledgeIndex.concepts)) return [];
    const terms = tokenize(query);
    if (!terms.length) return [];
    return this.knowledgeIndex.concepts
      .map((concept) => ({
        ...concept,
        score: lineScore(`${concept.name} ${(concept.paths || []).join(" ")}`, terms) + Number(concept.count || 0) * 0.2,
      }))
      .filter((concept) => concept.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  getConceptCardMatches(query, limit = 6) {
    const cards = this.conceptCards && Array.isArray(this.conceptCards.cards) ? this.conceptCards.cards : [];
    if (!cards.length) return [];
    const terms = tokenize(query);
    const focusTerms = getKnowledgeFocusTerms(query);
    return cards
      .filter((card) => card.status !== "rejected")
      .map((card) => {
        const anchor = `${card.name || ""} ${card.generatedName || ""} ${card.parentTopic || ""} ${(card.aliases || []).join(" ")} ${(card.customAliases || []).join(" ")} ${(
          card.childConcepts || []
        )
          .map((item) => item.name)
          .join(" ")} ${(card.sourcePaths || []).join(" ")}`;
        const body = `${(card.relatedConcepts || []).map((item) => item.name).join(" ")} ${[
          ...(card.coreDefinitions || []),
          ...(card.statements || []),
          ...(card.examples || []),
          ...(card.remarks || []),
        ]
          .map((item) => item.summary)
          .join(" ")}`;
        let score = lineScore(anchor, terms) * 3 + lineScore(body, terms) * 0.7 + Number(card.reviewScore || 0) * 0.25;
        score += scoreKnowledgeFocus(anchor, focusTerms) * 8 + scoreKnowledgeFocus(body, focusTerms) * 0.8;
        if (card.status === "accepted") score += 120;
        if (card.risk === "high") score -= 80;
        return { ...card, score };
      })
      .filter((card) => card.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  buildConceptCardContext(query, limit = 6) {
    const cards = this.getConceptCardMatches(query, limit);
    if (!cards.length) return "";
    return cards
      .map((card, index) => {
        const evidence = [
          ...(card.coreDefinitions || []),
          ...(card.statements || []),
          ...(card.examples || []),
          ...(card.remarks || []),
        ]
          .slice(0, 5)
          .map((item) => `- ${item.sourceLink || item.path}: ${cleanSnippet(item.summary || "", 180)}`)
          .join("\n");
        const related = (card.relatedConcepts || [])
          .slice(0, 8)
          .map((item) => item.name)
          .join(", ");
        const hierarchy = [
          card.parentTopic ? `Parent topic: ${card.parentTopic}` : "",
          (card.childConcepts || []).length ? `Child topics: ${(card.childConcepts || []).map((item) => item.name).join(", ")}` : "",
        ]
          .filter(Boolean)
          .join("\n");
        const proofs = (card.proofEntrances || [])
          .slice(0, 3)
          .map((item) => item.sourceLink || item.path)
          .join(", ");
        return `${index + 1}. ${card.name} [${card.status || "auto"}, ${card.confidence || "medium"}, risk ${card.risk || "medium"}]
${hierarchy ? `${hierarchy}\n` : ""}Aliases: ${(card.aliases || []).slice(0, 8).join(", ") || "(none)"}
Sources:
${evidence || "- (none)"}
Related: ${related || "(none)"}
Proof entrances: ${proofs || "(none)"}`;
      })
      .join("\n\n");
  }

  getCalloutLabel(item, includeSummaryFallback = false) {
    const type = String(item && item.type ? item.type : "callout").toLowerCase();
    const line = item && item.line ? `line ${item.line}` : "untitled";
    const title = String((item && item.title) || "").trim();
    if (title) return `[!${type}] ${title}`;
    const inferredTitle = String((item && item.inferredTitle) || "").trim();
    if (inferredTitle) return `[!${type}] ${inferredTitle}`;
    if (includeSummaryFallback && item && item.summary) {
      return `[!${type}] ${line}: ${cleanSnippet(item.summary, 120)}`;
    }
    return `[!${type}] ${line} (untitled)`;
  }

  getCalloutTypeCounts(profile) {
    const counts = new Map();
    for (const item of profile.callouts || []) {
      const type = String(item && item.type ? item.type : "callout").toLowerCase();
      counts.set(type, (counts.get(type) || 0) + 1);
    }
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([type, count]) => `${type} ${count}`)
      .join(", ");
  }

  getRequestedCalloutTypes(query) {
    const value = String(query || "").toLowerCase();
    const requested = new Set();
    const add = (...items) => items.forEach((item) => requested.add(item));
    if (/definition|定义|定義|概念|是什么/.test(value)) add("definition", "def");
    if (/proposition|命题|命題/.test(value)) add("proposition", "prop");
    if (/theorem|定理/.test(value)) add("theorem", "thm");
    if (/lemma|引理/.test(value)) add("lemma");
    if (/corollary|推论|推論/.test(value)) add("corollary");
    if (/proof|证明|證明/.test(value)) add("proof");
    if (/example|例子|例/.test(value)) add("example");
    if (/remark|注记|备注|说明|直观|意义/.test(value)) add("remark");
    if (/应用|application/.test(value)) add("example", "remark", "proposition", "prop", "theorem", "thm");
    if (/notation|记号|符号|記號|符號/.test(value)) add("notation");
    return requested;
  }

  scoreKnowledgeCallout(item, query, terms = tokenize(query)) {
    const requestedTypes = this.getRequestedCalloutTypes(query);
    const type = String(item && item.type ? item.type : "").toLowerCase();
    const role = String((item && item.role) || getKnowledgeCalloutRole(type));
    const title = String((item && item.title) || "");
    const label = String((item && item.inferredTitle) || title || "");
    const summary = String((item && item.summary) || "");
    const firstSentence = String((item && item.firstSentence) || "");
    const body = String((item && item.body) || "");
    const heading = String((item && item.heading) || "");
    const headingPath = String((item && item.headingPath) || "");
    const noteTitle = String((item && item.noteTitle) || "");
    const path = String((item && item.path) || "");
    const blockId = String((item && item.blockId) || "");
    const text = String((item && item.textForSearch) || `${type} ${title} ${heading} ${summary}`);
    const focus = getQueryFocus(query);
    const parts = getQueryFocusParts(query);
    const titleText = `${title} ${label}`;
    const locator = `${path} ${noteTitle} ${headingPath} ${blockId} ${String((item && item.sourceLink) || "")}`;
    const focusTerms = getKnowledgeFocusTerms(query);
    const anchorText = `${path} ${noteTitle} ${title} ${headingPath} ${blockId}`;
    const bodyText = `${((item && item.links) || []).join(" ")} ${firstSentence} ${summary} ${body}`;
    const anchorFocus = scoreKnowledgeFocus(anchorText, focusTerms);
    const bodyFocus = scoreKnowledgeFocus(bodyText, focusTerms);
    let score = 0;
    score += lineScore(titleText, terms) * 4.0;
    score += lineScore(locator, terms) * 2.2;
    score += lineScore(`${((item && item.links) || []).join(" ")} ${((item && item.formulas) || []).join(" ")}`, terms) * 1.5;
    score += lineScore(`${firstSentence} ${summary} ${body}`, terms) * 0.75;
    score += anchorFocus * 12;
    score += bodyFocus * 2.5;
    if (focusTerms.length && anchorFocus + bodyFocus === 0) score -= 260;
    else if (focusTerms.length && anchorFocus === 0) score -= 85;
    else if (focusTerms.length && anchorFocus >= 20) score += 90;
    if (requestedTypes.size) {
      if (requestedTypes.has(type)) score += 150;
      else if (requestedTypes.has("definition") || requestedTypes.has("def")) score -= 120;
      else score -= 12;
    }
    if (role === "core") score += 14;
    if (role === "auxiliary" && !requestedTypes.has("proof")) score -= 900;
    if (role === "auxiliary" && requestedTypes.has("proof")) score += 80;
    if (blockId) score += 18;
    if (compactEqualSearch(title, focus) || compactEqualSearch(label, focus)) score += 3200;
    else if (exactishContainsSearch(titleText, focus)) score += 1800;
    if (compactEqualSearch(noteTitle, focus)) score += 850;
    else if (exactishContainsSearch(noteTitle, focus)) score += 260;
    if (exactishContainsSearch(headingPath, focus)) score += 70;
    if (exactishContainsSearch(path, focus)) score += 55;
    for (const part of parts) {
      if (compactEqualSearch(title, part) || compactEqualSearch(label, part)) score += 1200;
      else if (exactishContainsSearch(titleText, part)) score += 420;
      if (compactEqualSearch(noteTitle, part)) score += 520;
      else if (exactishContainsSearch(noteTitle, part)) score += 150;
      if (/[A-Za-z]/.test(part) && exactishContainsSearch(titleText, part)) score += 700;
    }
    if (parts.length >= 2) {
      const titleOrLocatorMatches = parts.filter((part) => exactishContainsSearch(titleText, part) || exactishContainsSearch(locator, part));
      const titleMatches = parts.filter((part) => exactishContainsSearch(titleText, part));
      if (titleOrLocatorMatches.length >= 2) score += 360 + 120 * titleMatches.length;
      else score -= 220;
      if (parts.every((part) => exactishContainsSearch(`${titleText} ${locator}`, part))) score += 1500;
      if (titleMatches.length && parts.some((part) => !titleMatches.includes(part) && exactishContainsSearch(locator, part))) {
        score += 4500;
      }
    }
    score += lineScore(`${((item && item.links) || []).join(" ")} ${((item && item.formulas) || []).join(" ")}`, terms) * 1.2;
    if (["definition", "def", "proposition", "prop", "theorem", "thm", "lemma", "corollary"].includes(type)) score += 8;
    if (title) score += 6;
    if (Number((item && item.line) || 999999) <= 25 && exactishContainsSearch(noteTitle, focus)) score += 55;
    if (/定义|定義|definition|是什么|概念|基本/.test(query)) {
      if (type === "definition" || type === "def") {
        score += 25;
        if (compactEqualSearch(title, focus) || compactEqualSearch(noteTitle, focus)) score += 3000;
        if (compactEqualSearch(title, focus) || compactEqualSearch(label, focus)) score += 2200;
        if (
          Number((item && item.line) || 999999) <= 25 &&
          parts.some((part) => compactEqualSearch(title, part) || compactEqualSearch(noteTitle, part))
        ) {
          score += 1250;
        }
      } else {
        score -= 650;
      }
      const line = Number((item && item.line) || 999999);
      if (
        line <= 25 &&
        (compactEqualSearch(noteTitle, focus) ||
          compactEqualSearch(title, focus) ||
          parts.some((part) => compactEqualSearch(title, part) || compactEqualSearch(noteTitle, part)))
      ) {
        score += 900;
      }
      if (line > 220 && !parts.some((part) => exactishContainsSearch(titleText, part))) score -= 45;
    }
    if (/定理|theorem/i.test(query)) {
      if (["theorem", "thm"].includes(type)) score += 35;
      else if (["definition", "def"].includes(type)) score -= 20;
    }
    score += Math.min(10, Number((item && item.inboundCount) || 0) * 0.25);
    return score;
  }

  knowledgeCalloutHasFocus(item, query) {
    const focusTerms = getKnowledgeFocusTerms(query);
    if (!focusTerms.length) return true;
    const type = String((item && item.type) || "");
    const title = String((item && item.title) || "");
    const path = String((item && item.path) || "");
    const noteTitle = String((item && item.noteTitle) || "");
    const headingPath = String((item && item.headingPath) || "");
    const blockId = String((item && item.blockId) || "");
    const links = ((item && item.links) || []).join(" ");
    const summary = String((item && item.summary) || "");
    const body = String((item && item.body) || "");
    const anchor = `${path} ${noteTitle} ${title} ${headingPath} ${blockId} ${type}`;
    const text = `${links} ${summary} ${body}`;
    return scoreKnowledgeFocus(anchor, focusTerms) > 0 || scoreKnowledgeFocus(text, focusTerms) >= 20;
  }

  getRelevantCalloutUnits(query, limit = 28) {
    const units = this.knowledgeIndex && Array.isArray(this.knowledgeIndex.callouts) ? this.knowledgeIndex.callouts : [];
    if (!units.length) return [];
    const terms = tokenize(query);
    if (!terms.length) return [];
    const scored = units
      .map((item) => ({ ...item, calloutScore: this.scoreKnowledgeCallout(item, query, terms) }))
      .filter((item) => item.calloutScore > 0)
      .sort((a, b) => b.calloutScore - a.calloutScore);
    const focused = scored.filter((item) => this.knowledgeCalloutHasFocus(item, query));
    return (focused.length ? focused : scored)
      .slice(0, limit);
  }

  scoreKnowledgeSection(item, query, terms = tokenize(query)) {
    const heading = String((item && item.heading) || "");
    const headingPath = String((item && item.headingPath) || "");
    const noteTitle = String((item && item.noteTitle) || "");
    const path = String((item && item.path) || "");
    const summary = String((item && item.summary) || "");
    const body = String((item && item.body) || "");
    const focus = getQueryFocus(query);
    const parts = getQueryFocusParts(query);
    const focusTerms = getKnowledgeFocusTerms(query);
    const anchorText = `${path} ${noteTitle} ${heading} ${headingPath}`;
    const bodyText = `${((item && item.links) || []).join(" ")} ${summary} ${body}`;
    const anchorFocus = scoreKnowledgeFocus(anchorText, focusTerms);
    const bodyFocus = scoreKnowledgeFocus(bodyText, focusTerms);
    let score = 0;
    score += lineScore(`${heading} ${headingPath}`, terms) * 3.5;
    score += lineScore(`${path} ${noteTitle}`, terms) * 2.0;
    score += lineScore(`${summary} ${body}`, terms) * 0.45;
    score += anchorFocus * 9;
    score += bodyFocus * 1.5;
    if (focusTerms.length && anchorFocus + bodyFocus === 0) score -= 160;
    else if (focusTerms.length && anchorFocus === 0) score -= 55;
    if (compactEqualSearch(heading, focus)) score += 900;
    else if (exactishContainsSearch(`${heading} ${headingPath}`, focus)) score += 520;
    if (exactishContainsSearch(`${path} ${noteTitle}`, focus)) score += 220;
    for (const part of parts) {
      if (compactEqualSearch(heading, part)) score += 360;
      else if (exactishContainsSearch(`${heading} ${headingPath}`, part)) score += 160;
      if (exactishContainsSearch(`${path} ${noteTitle}`, part)) score += 90;
    }
    if (parts.length >= 2 && parts.every((part) => exactishContainsSearch(`${heading} ${headingPath} ${path} ${noteTitle}`, part))) {
      score += 420;
    }
    score += Math.min(8, Number((item && item.inboundCount) || 0) * 0.2);
    return score;
  }

  knowledgeSectionHasFocus(item, query) {
    const focusTerms = getKnowledgeFocusTerms(query);
    if (!focusTerms.length) return true;
    const heading = String((item && item.heading) || "");
    const headingPath = String((item && item.headingPath) || "");
    const noteTitle = String((item && item.noteTitle) || "");
    const path = String((item && item.path) || "");
    const links = ((item && item.links) || []).join(" ");
    const summary = String((item && item.summary) || "");
    const body = String((item && item.body) || "");
    const anchor = `${path} ${noteTitle} ${heading} ${headingPath}`;
    return scoreKnowledgeFocus(anchor, focusTerms) > 0 || scoreKnowledgeFocus(`${links} ${summary} ${body}`, focusTerms) >= 20;
  }

  getRelevantSectionUnits(query, limit = 14) {
    const units = this.knowledgeIndex && Array.isArray(this.knowledgeIndex.sections) ? this.knowledgeIndex.sections : [];
    if (!units.length) return [];
    const terms = tokenize(query);
    if (!terms.length) return [];
    const scored = units
      .map((item) => ({ ...item, sectionScore: this.scoreKnowledgeSection(item, query, terms) }))
      .filter((item) => item.sectionScore > 0)
      .sort((a, b) => b.sectionScore - a.sectionScore);
    const focused = scored.filter((item) => this.knowledgeSectionHasFocus(item, query));
    return (focused.length ? focused : scored)
      .slice(0, limit);
  }

  getRelevantCallouts(profile, query, limit = 16) {
    const callouts = Array.isArray(profile && profile.callouts) ? profile.callouts : [];
    if (!callouts.length) return [];
    const terms = tokenize(query);
    const importantTypes = new Set([
      "definition",
      "def",
      "proposition",
      "prop",
      "theorem",
      "thm",
      "lemma",
      "corollary",
      "proof",
      "example",
      "remark",
      "notation",
    ]);
    const scored = callouts
      .map((item, index) => {
        let score = this.scoreKnowledgeCallout(
          { ...item, path: profile.path, noteTitle: profile.title, inboundCount: profile.inboundCount },
          query,
          terms
        );
        if (importantTypes.has(String(item.type || "").toLowerCase())) score += 2;
        score += Math.max(0, 1 - index / 500);
        return { ...item, path: profile.path, noteTitle: profile.title, inboundCount: profile.inboundCount, calloutScore: score };
      })
      .filter((item) => item.calloutScore > 0)
      .sort((a, b) => b.calloutScore - a.calloutScore);
    const focused = scored.filter((item) => this.knowledgeCalloutHasFocus(item, query));
    return (focused.length ? focused : scored)
      .slice(0, limit);
  }

  profileMatchesKnowledgeRef(profile, ref) {
    const target = this.normalizeNoteRef(ref).toLowerCase();
    if (!target || !profile) return false;
    const title = this.normalizeNoteRef(profile.title).toLowerCase();
    const path = this.normalizeNoteRef(profile.path).toLowerCase();
    return target === title || target === path || path.endsWith(`/${target}`) || target.endsWith(`/${title}`);
  }

  getDeepestFolderPath(profile) {
    const folders = Array.isArray(profile && profile.folderPaths) ? profile.folderPaths : [];
    return folders.length ? folders[folders.length - 1] : "";
  }

  isDraftKnowledgeProfile(profile) {
    const draftFolder = String((this.settings && this.settings.draftFolder) || "AI Drafts")
      .replace(/\\/g, "/")
      .replace(/^\/+|\/+$/g, "")
      .toLowerCase();
    const path = String((profile && profile.path) || "").replace(/\\/g, "/").toLowerCase();
    return Boolean(draftFolder && (path === `${draftFolder}.md` || path.startsWith(`${draftFolder}/`)));
  }

  getTopicCoverageProfiles(query, limit = 12) {
    const profiles = this.knowledgeIndex && Array.isArray(this.knowledgeIndex.profiles) ? this.knowledgeIndex.profiles : [];
    if (!profiles.length) return [];
    const terms = tokenize(query);
    if (!terms.length) return [];
    const profileByPath = new Map(profiles.map((profile) => [profile.path, profile]));
    const directMatches = this.getKnowledgeMatches(query, 12);
    const calloutMatches = this.getRelevantCalloutUnits(query, 36);
    const seedPaths = new Set();
    for (const profile of directMatches.slice(0, 6)) seedPaths.add(profile.path);
    for (const item of calloutMatches.slice(0, 12)) seedPaths.add(item.path);
    const directSeedPaths = new Set(seedPaths);
    const seedProfiles = [...seedPaths].map((path) => profileByPath.get(path)).filter(Boolean);
    const seedRefs = new Set();
    const seedLinkedRefs = [];
    const seedFolders = new Set();
    for (const profile of seedProfiles) {
      for (const ref of [profile.title, profile.path, String(profile.path || "").replace(/\.md$/i, "")]) {
        const normalized = this.normalizeNoteRef(ref).toLowerCase();
        if (normalized) seedRefs.add(normalized);
      }
      for (const relatedPath of [...(profile.resolvedLinks || []), ...(profile.backlinks || [])]) {
        if (relatedPath) seedPaths.add(relatedPath);
      }
      const deepest = this.getDeepestFolderPath(profile);
      if (deepest) seedFolders.add(deepest);
      for (const link of profile.links || []) {
        const normalized = this.normalizeNoteRef(link);
        if (normalized) seedLinkedRefs.push(normalized);
      }
    }

    const compactQuery = String(query || "").replace(/\s+/g, "").toLowerCase();
    const focus = getQueryFocus(query);
    const hints = getTopicCoreHints(query);
    return profiles
      .map((profile) => {
        const reasons = [];
        const title = String(profile.title || "");
        const path = String(profile.path || "");
        const folders = Array.isArray(profile.folders) ? profile.folders.join(" ") : "";
        let score = lineScore(`${profile.textForSearch || ""}\n${path}\n${title}\n${folders}`, terms);
        if (directSeedPaths.has(profile.path)) {
          score += 120;
          reasons.push("direct match");
        } else if (seedPaths.has(profile.path)) {
          score += 65;
          reasons.push("linked seed note");
        }
        const deepest = this.getDeepestFolderPath(profile);
        if (deepest && seedFolders.has(deepest)) {
          score += 75;
          reasons.push("same topic folder");
        }
        const linksToSeed = (profile.links || []).some((link) => {
          const normalized = this.normalizeNoteRef(link).toLowerCase();
          return seedRefs.has(normalized) || [...seedProfiles].some((seed) => this.profileMatchesKnowledgeRef(seed, link));
        }) || (profile.resolvedLinks || []).some((path) => seedPaths.has(path));
        if (linksToSeed) {
          score += 70;
          reasons.push("links to seed note");
        }
        const linkedFromSeed =
          seedLinkedRefs.some((link) => this.profileMatchesKnowledgeRef(profile, link)) ||
          [...seedProfiles].some(
            (seed) => (seed.resolvedLinks || []).includes(profile.path) || (seed.backlinks || []).includes(profile.path)
          );
        if (linkedFromSeed) {
          score += 70;
          reasons.push("linked from seed note");
        }
        const compactProfile = `${title} ${path} ${folders}`.replace(/\s+/g, "").toLowerCase();
        const compactTitle = title.replace(/\s+/g, "").toLowerCase();
        const compactBasename = path
          .replace(/\\/g, "/")
          .replace(/^.*\//, "")
          .replace(/\.md$/i, "")
          .replace(/\s+/g, "")
          .toLowerCase();
        if (compactEqualSearch(title, focus) || (compactQuery && (compactTitle === compactQuery || compactBasename === compactQuery))) {
          score += 160;
          reasons.push("exact topic note");
        } else if (exactishContainsSearch(`${title} ${path}`, focus) || (compactQuery && compactProfile.includes(compactQuery))) {
          score += 45;
          reasons.push("title/path contains topic");
        }
        for (const hint of hints) {
          if (compactEqualSearch(title, hint)) {
            score += 260;
            reasons.push(`core hint: ${hint}`);
          } else if (exactishContainsSearch(`${title} ${path}`, hint)) {
            score += 170;
            reasons.push(`core hint: ${hint}`);
          }
        }
        score += Math.min(25, Number(profile.calloutCount || 0) * 0.6);
        score += Math.min(20, Number(profile.inboundCount || 0) * 1.2);
        if (this.isDraftKnowledgeProfile(profile) && !seedPaths.has(profile.path)) score -= 80;
        return { ...profile, topicCoverageScore: score, topicCoverageReasons: reasons };
      })
      .filter((profile) => profile.topicCoverageScore > 0)
      .sort((a, b) => b.topicCoverageScore - a.topicCoverageScore)
      .slice(0, limit);
  }

  buildTopicCoverageContext(query, profiles) {
    const selected = Array.isArray(profiles) ? profiles : [];
    if (!selected.length) return "";
    const lines = selected.map((profile, index) => {
      const link = `[[${String(profile.path || "").replace(/\.md$/i, "")}]]`;
      const headings = (profile.headings || [])
        .slice(0, 8)
        .map((heading) => `${"#".repeat(Math.min(6, heading.level || 1))} ${heading.text}`)
        .join("; ");
      const callouts = this.getRelevantCallouts(profile, `${query} ${profile.title}`, 6)
        .map((item) => `${item.sourceLink || makeObsidianSourceLink(profile.path, this.getCalloutLabel(item, false), item.blockId || "", item.heading)} ${this.getCalloutLabel(item, true)}${item.summary ? ` :: ${cleanSnippet(item.summary, 180)}` : ""}`)
        .join("; ");
      const reasons = (profile.topicCoverageReasons || []).join(", ") || "semantic match";
      return `${index + 1}. ${link}
Coverage reason: ${reasons}; score ${Number(profile.topicCoverageScore || 0).toFixed(1)}
Folders: ${(profile.folders || []).join(" > ") || "(root)"}
Headings: ${headings || "(none)"}
Key callouts: ${callouts || "(none)"}
Linked topics: ${(profile.links || []).slice(0, 14).join(", ") || "(none)"}`;
    });
    return `Topic coverage map. For broad topic synthesis, these linked, backlink, same-folder, or title-related notes should be considered for coverage. Do not omit a high-coverage note when it has relevant callout evidence.

${lines.join("\n\n")}`;
  }

  buildTopicCalloutEvidence(query, profiles, limit = 56) {
    const seen = new Set();
    let count = 0;
    const formatItem = (item, numberLabel = "") => {
      const key = `${item.path || ""}:${item.line || ""}:${item.title || ""}:${item.type || ""}`;
      if (seen.has(key) || count >= limit) return "";
      seen.add(key);
      count += 1;
      const link = `[[${String(item.path || "").replace(/\.md$/i, "")}]]`;
      const sourceLink = item.sourceLink || link;
      return `${numberLabel || `${count}.`} ${link} ${this.getCalloutLabel(item, false)}
   - source: ${sourceLink}
   - precision: ${item.sourcePrecision || (item.blockId ? "block" : "note")}
   - heading: ${item.headingPath || item.heading || "(none)"}
   - links: ${(item.links || []).slice(0, 8).join(", ") || "(none)"}
   - content:
${limitTextBlock(item.body || item.summary || item.firstSentence || "", 850)}`;
    };

    const coverageGroups = (profiles || [])
      .slice(0, 12)
      .map((profile) => {
        const items = this.getRelevantCallouts(profile, `${query} ${profile.title}`, 5)
          .map((item) =>
            formatItem({
              ...item,
              path: profile.path,
              noteTitle: profile.title,
              inboundCount: profile.inboundCount || 0,
            })
          )
          .filter(Boolean)
          .join("\n\n");
        const sectionTerms = tokenize(`${query} ${profile.title}`);
        const sections = (profile.sections || [])
          .map((section) => ({
            ...section,
            sectionScore: this.scoreKnowledgeSection(
              { ...section, path: profile.path, noteTitle: profile.title, inboundCount: profile.inboundCount || 0 },
              `${query} ${profile.title}`,
              sectionTerms
            ),
          }))
          .filter((section) => section.sectionScore > 0)
          .sort((a, b) => b.sectionScore - a.sectionScore)
          .slice(0, 2)
          .map(
            (section) => `- section: ${section.headingPath || section.heading || "(untitled)"}
  ${cleanSnippet(section.summary || section.body || "", 360)}`
          )
          .join("\n");
        if (!items && !sections) return "";
        return `### Coverage note: [[${String(profile.path || "").replace(/\.md$/i, "")}]]
${items || "(no focused callout)"}
${sections ? `\nFocused sections:\n${sections}` : ""}`;
      })
      .filter(Boolean)
      .join("\n\n");
    const topItems = this.getRelevantCalloutUnits(query, 18)
      .map((item) => formatItem(item))
      .filter(Boolean)
      .join("\n\n");
    return [coverageGroups ? `Required coverage callouts:\n${coverageGroups}` : "", `Top matched callouts:\n${topItems || "(none)"}`]
      .filter(Boolean)
      .join("\n\n");
  }

  buildKnowledgeContext(query, limit = 8) {
    const matches = this.getKnowledgeMatches(query, limit);
    const calloutUnits = this.getRelevantCalloutUnits(query, 24);
    const sectionUnits = this.getRelevantSectionUnits(query, 12);
    if (!matches.length && !calloutUnits.length && !sectionUnits.length) return "";
    const staleNote = this.isKnowledgeIndexStale()
      ? "Knowledge index freshness: stale or incomplete. Prefer retrieved excerpts when they conflict with index hints, and suggest refreshing Knowledge Index if coverage seems missing.\n\n"
      : "";
    const concepts = this.getKnowledgeConceptMatches(query, 8);
    const conceptCardContext = this.buildConceptCardContext(query, 6);
    const coreCalloutUnits = calloutUnits.filter((item) => String((item && item.role) || getKnowledgeCalloutRole(item && item.type)) === "core");
    const auxiliaryCalloutUnits = calloutUnits.filter((item) => String((item && item.role) || getKnowledgeCalloutRole(item && item.type)) !== "core");
    const displayedCalloutUnits = coreCalloutUnits.length ? coreCalloutUnits : calloutUnits;
    const formatCalloutHint = (item, index) => {
      const link = `[[${String(item.path || "").replace(/\.md$/i, "")}]]`;
      const features = [
        item.headingPath ? `heading: ${item.headingPath}` : item.heading ? `heading: ${item.heading}` : "",
        item.links && item.links.length ? `links: ${item.links.slice(0, 6).join(", ")}` : "",
        item.formulas && item.formulas.length ? `formulas: ${item.formulas.slice(0, 4).join("; ")}` : "",
      ]
        .filter(Boolean)
        .join(" | ");
      return `${index + 1}. ${link} ${this.getCalloutLabel(item, true)}
Source link: ${item.sourceLink || link}
Source precision: ${item.sourcePrecision || (item.blockId ? "block" : "note")}
Role: ${item.role || getKnowledgeCalloutRole(item.type)}
${features ? `${features}\n` : ""}${cleanSnippet(item.summary || item.firstSentence || "", 360)}`;
    };
    const calloutLines = displayedCalloutUnits
      .slice(0, 18)
      .map((item, index) => formatCalloutHint(item, index))
      .join("\n\n");
    const auxiliaryCalloutLines = auxiliaryCalloutUnits
      .slice(0, 6)
      .map((item, index) => formatCalloutHint(item, index))
      .join("\n\n");
    const sectionLines = sectionUnits
      .slice(0, 10)
      .map((item, index) => {
        const link = `[[${String(item.path || "").replace(/\.md$/i, "")}]]`;
        const features = [
          item.headingPath ? `heading: ${item.headingPath}` : item.heading ? `heading: ${item.heading}` : "",
          item.links && item.links.length ? `links: ${item.links.slice(0, 6).join(", ")}` : "",
          item.formulas && item.formulas.length ? `formulas: ${item.formulas.slice(0, 4).join("; ")}` : "",
        ]
          .filter(Boolean)
          .join(" | ");
        return `${index + 1}. ${link} section ${item.heading || "(untitled)"}
Source link: ${item.sourceLink || makeObsidianSourceLink(item.path, item.heading, "", item.heading)}
Source precision: ${item.sourcePrecision || "heading"}
${features ? `${features}\n` : ""}${cleanSnippet(item.summary || item.body || "", 420)}`;
      })
      .join("\n\n");
    const noteLines = matches
      .map((profile, index) => {
        const headings = (profile.headings || [])
          .slice(0, 10)
          .map((heading) => `${"#".repeat(Math.min(6, heading.level || 1))} ${heading.text}`)
          .join("; ");
        const calloutCounts = this.getCalloutTypeCounts(profile);
        const callouts = this.getRelevantCallouts(profile, query, 16)
          .map((item) => {
            const label = this.getCalloutLabel(item, true);
            return `${label}${item.summary ? ` :: ${cleanSnippet(item.summary, 180)}` : ""}`;
          })
          .join("; ");
        const tags = (profile.tags || []).slice(0, 12).join(", ");
        const links = (profile.links || []).slice(0, 12).join(", ");
        const folders = (profile.folders || []).join(" > ");
        return `${index + 1}. [[${String(profile.path || "").replace(/\.md$/i, "")}]]
Title: ${profile.title}
Folders: ${folders || "(root)"}
Inbound links: ${profile.inboundCount || 0}; Outbound links: ${profile.outboundCount || 0}; Callouts: ${profile.calloutCount || 0}${
          calloutCounts ? ` (${calloutCounts})` : ""
        }
Headings: ${headings || "(none)"}
Relevant mathematical callouts: ${callouts || "(none)"}
Tags: ${tags || "(none)"}
Linked topics: ${links || "(none)"}
Profile summary: ${profile.summary || "(none)"}`;
      })
      .join("\n\n");
    const conceptLines = concepts
      .map((concept) => `- ${concept.name} (${concept.count}) -> ${(concept.paths || []).slice(0, 3).join("; ")}`)
      .join("\n");
    return `${staleNote}Knowledge index hints. Use this only to choose and organize relevant notes; source claims still require retrieved note excerpts.

Most relevant core callout-level candidates:
${calloutLines || "(none)"}

Reviewed/auto concept card candidates:
${conceptCardContext || "(none)"}

Auxiliary proof/solution candidates, only use when the user asks for proof details or when they explain a linked result:
${auxiliaryCalloutLines || "(none)"}

Most relevant heading-section candidates:
${sectionLines || "(none)"}

Relevant note profiles:
${noteLines}

Related concepts:
${conceptLines || "(none)"}`;
  }

  async enhanceSearchResponse(query, response) {
    const matches = this.getKnowledgeMatches(query, 6);
    const calloutUnits = this.getRelevantCalloutUnits(query, 10);
    if (!matches.length && !calloutUnits.length) return response;
    const byPath = new Map(matches.map((profile, index) => [profile.path, { profile, index }]));
    const existingPaths = new Set((response.results || []).map((result) => result.path));
    const boosted = (response.results || []).map((result) => {
      const hit = byPath.get(result.path);
      if (!hit) return result;
      return {
        ...result,
        score: Number(result.score || 0) + Math.max(1, 6 - hit.index),
        knowledgeBoosted: true,
      };
    });
    const calloutSupplements = calloutUnits
      .filter((item) => !existingPaths.has(item.path))
      .slice(0, 5)
      .map((item) => ({
        path: item.path,
        heading: item.heading || this.getCalloutLabel(item, false),
        sourceLink: item.sourceLink || makeObsidianSourceLink(item.path, this.getCalloutLabel(item, false), item.blockId || "", item.heading),
        sourcePrecision: item.sourcePrecision || (item.blockId ? "block" : "note"),
        snippet: cleanSnippet(`${this.getCalloutLabel(item, true)} ${item.summary || ""}`, 320),
        context: `Callout candidate from ${item.sourceLink || `[[${String(item.path || "").replace(/\.md$/i, "")}]]`}
${this.getCalloutLabel(item, false)}
Source link: ${item.sourceLink || makeObsidianSourceLink(item.path, this.getCalloutLabel(item, false), item.blockId || "", item.heading)}
Heading: ${item.headingPath || item.heading || "(none)"}
Links: ${(item.links || []).join(", ") || "(none)"}
Formulas: ${(item.formulas || []).join("; ") || "(none)"}

${item.body || item.summary || item.firstSentence || ""}`,
        score: Number(item.calloutScore || 1) + 20,
        knowledgeCallout: true,
      }));
    const supplements = matches
      .filter((profile) => !existingPaths.has(profile.path))
      .slice(0, 3)
      .map((profile) => {
        const headings = (profile.headings || [])
          .slice(0, 14)
          .map((heading) => `${"#".repeat(Math.min(6, heading.level || 1))} ${heading.text}`)
          .join("\n");
        const callouts = this.getRelevantCallouts(profile, query, 24)
          .map((item) => `> ${this.getCalloutLabel(item, false)}\n${item.summary || ""}`.trim())
          .join("\n\n");
        return {
          path: profile.path,
          heading: "Knowledge index profile",
          sourceLink: makeObsidianSourceLink(profile.path, profile.title),
          sourcePrecision: "note",
          snippet: cleanSnippet(`${profile.title}: ${profile.summary || headings}`, 320),
          context: `Knowledge index profile for [[${String(profile.path || "").replace(/\.md$/i, "")}]]
Title: ${profile.title}
Headings:
${headings || "(none)"}
Relevant callouts:
${callouts || "(none)"}
Tags: ${(profile.tags || []).join(", ") || "(none)"}
Linked topics: ${(profile.links || []).slice(0, 20).join(", ") || "(none)"}
Opening summary:
${profile.summary || "(none)"}`,
          score: profile.knowledgeScore || 1,
          knowledgeProfile: true,
        };
      });
    return {
      ...response,
      results: [...boosted, ...calloutSupplements, ...supplements]
        .sort((a, b) => Number(b.score || 0) - Number(a.score || 0))
        .slice(0, this.settings.resultLimit),
      knowledgeMatches: matches,
    };
  }

  isNoteMigrationRequest(text) {
    const value = String(text || "");
    const links = this.extractWikiLinks(value);
    if (links.length < 2) return false;
    return /迁移|替代|取代|更新|改成|改为|链接|重构|淘汰|migrate|migration|replace|supersede|update links/i.test(
      value
    );
  }

  isApplyLowRiskMigrationRequest(text) {
    const value = String(text || "");
    return /执行|应用|修改|apply|run/i.test(value) && /低风险|low[-\s]?risk/i.test(value) && /迁移|链接|migration|links/i.test(value);
  }

  isUndoMigrationRequest(text) {
    const value = String(text || "");
    return /撤销|回滚|undo|rollback/i.test(value) && /迁移|正式笔记|migration|formal/i.test(value);
  }

  isNoteMigrationRequest(text) {
    const value = String(text || "");
    const links = this.extractWikiLinks(value);
    if (links.length < 2) return false;
    return /\u8fc1\u79fb|\u66ff\u4ee3|\u53d6\u4ee3|\u66f4\u65b0|\u6539\u6210|\u6539\u4e3a|\u94fe\u63a5|\u91cd\u6784|\u6dd8\u6c70|migrate|migration|replace|supersede|update links/i.test(
      value
    );
  }

  isApplyLowRiskMigrationRequest(text) {
    const value = String(text || "");
    return (
      /\u6267\u884c|\u5e94\u7528|\u4fee\u6539|\u786e\u8ba4|\u5904\u7406|\u6539\u6389|apply|run/i.test(value) &&
      /\u4f4e\u98ce\u9669|low[-\s]?risk/i.test(value) &&
      /\u8fc1\u79fb|\u94fe\u63a5|\u4fee\u6539|migration|links/i.test(value)
    );
  }

  isUndoMigrationRequest(text) {
    const value = String(text || "");
    return (
      /\u64a4\u9500|\u56de\u6eda|undo|rollback/i.test(value) &&
      /\u8fc1\u79fb|\u6b63\u5f0f\u7b14\u8bb0|migration|formal/i.test(value)
    );
  }

  isOpenMigrationReviewRequest(text) {
    const value = String(text || "");
    return (
      /\u6253\u5f00|\u663e\u793a|\u770b\u770b|open|show/i.test(value) &&
      /\u8fc1\u79fb/i.test(value) &&
      /\u5ba1\u9605|\u5de5\u4f5c\u53f0|\u9875\u9762|\u8868\u683c|review|workbench|table/i.test(value)
    );
  }

  isListRiskMigrationRequest(text) {
    const value = String(text || "");
    return (
      /\u5217\u51fa|\u663e\u793a|\u5269\u4f59|\u67e5\u770b|\u9700\u8981\u786e\u8ba4|\u770b\u770b|list|show/i.test(value) &&
      /\u4e2d\u98ce\u9669|\u9ad8\u98ce\u9669|\u4e2d\u9ad8\u98ce\u9669|risk|risky/i.test(value) &&
      /\u8fc1\u79fb|migration/i.test(value)
    );
  }

  isReviewMigrationCandidateRequest(text) {
    const value = String(text || "");
    return (
      this.extractMigrationCandidateNumber(value) > 0 &&
      /\u751f\u6210|\u9884\u89c8|\u5ba1\u9605|\u5efa\u8bae|diff|review|preview/i.test(value)
    );
  }

  isApplyReviewedMigrationRequest(text) {
    const value = String(text || "");
    return (
      this.extractMigrationCandidateNumber(value) > 0 &&
      /\u6267\u884c|\u5e94\u7528|\u786e\u8ba4|apply|run/i.test(value) &&
      /\u6761|\u5019\u9009|\u8fc1\u79fb|\u4e2d\u98ce\u9669|\u9ad8\u98ce\u9669|candidate|migration|risk/i.test(value)
    );
  }

  extractMigrationCandidateNumber(text) {
    const value = String(text || "");
    const match =
      value.match(/(?:\u7b2c|\#|candidate\s*|\u5019\u9009\s*)\s*(\d+)\s*(?:\u6761)?/i) ||
      value.match(/\b(\d+)\s*(?:\u6761|candidate)\b/i);
    return match ? Number.parseInt(match[1], 10) : 0;
  }

  normalizeNoteRef(ref) {
    return String(ref || "")
      .replace(/\\/g, "/")
      .replace(/\.md$/i, "")
      .replace(/^\/+|\/+$/g, "")
      .trim()
      .toLowerCase();
  }

  parseNoteRef(ref) {
    const raw = String(ref || "").split("|")[0].trim();
    const hashIndex = raw.indexOf("#");
    const note = (hashIndex >= 0 ? raw.slice(0, hashIndex) : raw).trim();
    const anchor = (hashIndex >= 0 ? raw.slice(hashIndex + 1) : "").trim();
    return { note, anchor };
  }

  normalizeAnchor(anchor) {
    return String(anchor || "").trim().toLowerCase();
  }

  anchorMatches(actualAnchor, expectedAnchor) {
    if (!expectedAnchor) return true;
    return this.normalizeAnchor(actualAnchor) === this.normalizeAnchor(expectedAnchor);
  }

  isAnchorKnown(anchor, headings) {
    const value = String(anchor || "").trim();
    if (!value) return true;
    if (value.startsWith("^")) return true;
    return Boolean(this.findNewHeadingForAnchor(value, headings));
  }

  isSameNoteRef(ref, file) {
    if (!(file instanceof TFile)) return false;
    const parsed = this.parseNoteRef(ref);
    const normalized = this.normalizeNoteRef(parsed.note);
    if (!normalized) return false;
    return normalized === this.normalizeNoteRef(file.path) || normalized === this.normalizeNoteRef(file.basename);
  }

  resolveNoteRef(ref) {
    const raw = String(ref || "").split("|")[0].split("#")[0].trim().replace(/\\/g, "/");
    if (!raw) return null;
    const directPath = raw.endsWith(".md") ? raw : `${raw}.md`;
    const direct = this.app.vault.getAbstractFileByPath(directPath);
    if (direct instanceof TFile && direct.extension === "md") return direct;
    const normalized = this.normalizeNoteRef(raw);
    return (
      this.app.vault
        .getMarkdownFiles()
        .find(
          (file) =>
            this.normalizeNoteRef(file.basename) === normalized ||
            this.normalizeNoteRef(file.path) === normalized
        ) || null
    );
  }

  extractMarkdownHeadings(content) {
    return String(content || "")
      .split(/\r?\n/)
      .map((line) => {
        const match = line.match(/^(#{1,6})\s+(.+?)\s*$/);
        return match ? match[2].trim() : "";
      })
      .filter(Boolean);
  }

  findNewHeadingForAnchor(anchor, newHeadings) {
    const normalized = String(anchor || "").replace(/^#/, "").trim().toLowerCase();
    if (!normalized) return "";
    return (newHeadings || []).find((heading) => heading.toLowerCase() === normalized) || "";
  }

  getMigrationAlias(aliasPart, oldFile, oldRef = {}, newRef = {}) {
    if (aliasPart) return `|${aliasPart}`;
    return "";
  }

  previewMigrationLine(line, oldFile, newFile, newHeadings, oldRef = {}, newRef = {}) {
    let changed = false;
    const newBase = newFile.basename;
    const updated = String(line || "")
      .replace(/(!?)\[\[([^\]\n]+)\]\]/g, (full, embed, body) => {
        const [targetPart, aliasPart] = String(body || "").split("|");
        const parsed = this.parseNoteRef(targetPart);
        if (!this.isSameNoteRef(parsed.note, oldFile)) return full;
        if (!this.anchorMatches(parsed.anchor, oldRef.anchor || "")) return full;
        const replacementAnchor = newRef.anchor || (!oldRef.anchor && parsed.anchor ? parsed.anchor : "");
        if (replacementAnchor && !this.isAnchorKnown(replacementAnchor, newHeadings)) return full;
        changed = true;
        const anchor = replacementAnchor ? `#${replacementAnchor}` : "";
        const alias = this.getMigrationAlias(aliasPart, oldFile, oldRef, newRef);
        return `${embed}[[${newBase}${anchor}${alias}]]`;
      })
      .replace(/(\[[^\]]+\]\()([^)]+?)(\))/g, (full, open, target, close) => {
        const cleanTarget = String(target || "").replace(/%20/g, " ").replace(/\.md$/i, "");
        const parsed = this.parseNoteRef(cleanTarget);
        if (!this.isSameNoteRef(parsed.note, oldFile)) return full;
        if (!this.anchorMatches(parsed.anchor, oldRef.anchor || "")) return full;
        changed = true;
        const anchor = newRef.anchor || (!oldRef.anchor && parsed.anchor ? parsed.anchor : "");
        return `${open}${newFile.path}${anchor ? `#${anchor}` : ""}${close}`;
      });
    return changed ? updated : "";
  }

  migrateLowRiskContent(content, oldFile, newFile, newHeadings, oldRef = {}, newRef = {}) {
    const lines = String(content || "").split(/\r?\n/);
    let changed = false;
    const updated = lines
      .map((line) => {
        const replacement = this.previewMigrationLine(line, oldFile, newFile, newHeadings, oldRef, newRef);
        if (replacement && replacement !== line) {
          changed = true;
          return replacement;
        }
        return line;
      })
      .join("\n");
    return changed ? updated : content;
  }

  async findNoteMigrationCandidates(oldFile, newFile = null, newHeadings = [], oldRef = {}, newRef = {}) {
    const candidates = [];
    const oldNames = [oldFile.basename, oldFile.path.replace(/\.md$/i, "")].filter(Boolean);
    const files = this.app.vault.getMarkdownFiles().filter((file) => file instanceof TFile);
    for (const file of files) {
      const content = await this.app.vault.cachedRead(file);
      const lines = content.split(/\r?\n/);
      const matches = [];
      const reasons = [];
      let highRisk = false;
      let mediumRisk = false;
      let hasOnlyLinks = true;
      for (let index = 0; index < lines.length; index += 1) {
        const line = lines[index];
        const wikiPattern = /(!?)\[\[([^\]\n]+)\]\]/g;
        let wikiMatch;
        while ((wikiMatch = wikiPattern.exec(line))) {
          const body = String(wikiMatch[2] || "").split("|")[0];
          const parsed = this.parseNoteRef(body);
          if (!this.isSameNoteRef(parsed.note, oldFile)) continue;
          if (!this.anchorMatches(parsed.anchor, oldRef.anchor || "")) continue;
          const type = wikiMatch[1] ? "embed-link" : "wiki-link";
          matches.push({ line: index, type, text: line.trim() });
          if (wikiMatch[1]) {
            highRisk = true;
            reasons.push("embedded old note link");
          }
          const replacementAnchor = newFile ? newRef.anchor || (!oldRef.anchor && parsed.anchor ? parsed.anchor : "") : "";
          if (newFile && replacementAnchor && !this.isAnchorKnown(replacementAnchor, newHeadings)) {
            highRisk = true;
            reasons.push(`new anchor not found in new note: ${replacementAnchor}`);
          }
        }
        const markdownPattern = /\[[^\]]+\]\(([^)]+)\)/g;
        let markdownMatch;
        while ((markdownMatch = markdownPattern.exec(line))) {
          const target = String(markdownMatch[1] || "").replace(/%20/g, " ").replace(/\.md$/i, "");
          const parsed = this.parseNoteRef(target);
          if (!this.isSameNoteRef(parsed.note, oldFile)) continue;
          if (!this.anchorMatches(parsed.anchor, oldRef.anchor || "")) continue;
          matches.push({ line: index, type: "markdown-link", text: line.trim() });
        }
        if (!oldRef.anchor && !matches.some((match) => match.line === index)) {
          for (const name of oldNames) {
            if (name && line.toLowerCase().includes(name.toLowerCase())) {
              matches.push({ line: index, type: "plain-mention", text: line.trim() });
              mediumRisk = true;
              hasOnlyLinks = false;
              reasons.push("plain text mention of old note name");
              break;
            }
          }
        }
      }
      if (!matches.length && (!newFile || file.path !== oldFile.path)) continue;
      if (file.path === oldFile.path && newFile) {
        matches.unshift({ line: 0, type: "old-note", text: "Old note itself may need a deprecation pointer." });
        mediumRisk = true;
        hasOnlyLinks = false;
        reasons.push("old note may need a superseded-by notice");
      }
      const previewLines = [];
      if (newFile) {
        for (const match of matches.slice(0, 12)) {
          const updated = this.previewMigrationLine(lines[match.line] || "", oldFile, newFile, newHeadings, oldRef, newRef);
          if (updated && updated !== lines[match.line]) {
            previewLines.push(`- ${lines[match.line].trim()}\n+ ${updated.trim()}`);
          }
        }
      }
      const risk = highRisk ? "high" : mediumRisk || !hasOnlyLinks ? "medium" : "low";
      candidates.push({
        path: file.path,
        kind: matches.some((match) => match.type === "old-note") && oldRef.anchor ? "superseded_notice" : "links",
        risk,
        reasons: [...new Set(reasons)],
        matches: matches.slice(0, 20),
        preview: previewLines.slice(0, 8).join("\n"),
      });
    }
    return candidates.sort((a, b) => {
      const order = { low: 0, medium: 1, high: 2 };
      return order[a.risk] - order[b.risk] || a.path.localeCompare(b.path);
    });
  }

  async previewNoteMigration(request) {
    if (request && typeof request === "object" && request.mode === "page-retarget") {
      const oldRef = this.parseNoteRef(request.oldTarget);
      const oldFile = this.resolveNoteRef(request.oldTarget);
      if (!(oldFile instanceof TFile)) {
        throw new Error(t(this.settings, "noteMigrationNeedTwoLinks"));
      }
      const candidates = await this.findNoteMigrationCandidates(oldFile, null, [], oldRef, {});
      const limit = Math.max(1, Math.min(Number.parseInt(this.settings.migrationScanLimit, 10) || 30, 100));
      const limitedCandidates = candidates.slice(0, limit);
      const counts = limitedCandidates.reduce(
        (acc, candidate) => {
          acc[candidate.risk] += 1;
          return acc;
        },
        { low: 0, medium: 0, high: 0 }
      );
      const oldDisplay = `${oldFile.basename}${oldRef.anchor ? `#${oldRef.anchor}` : ""}`;
      this.lastMigrationPreview = {
        mode: "page-retarget",
        oldPath: oldFile.path,
        oldRef,
        newPath: "",
        newRef: {},
        newHeadings: [],
        notes: request.notes || "",
        candidates,
        createdAt: new Date().toISOString(),
      };
      await this.savePluginData();
      const markdown = `# Page retarget scan: [[${oldDisplay}]]

This is a scan and preview only. No Markdown notes were modified.

- Old target: [[${oldDisplay}]]
- Candidate files: ${candidates.length}
- Visible in review table: ${limitedCandidates.length}
- Low risk: ${counts.low}
- Medium risk: ${counts.medium}
- High risk: ${counts.high}

Open the review table. Enter a target link for each row, for example [[C#Definition 1]], then review the generated diff and apply selected rows.`;
      const results = limitedCandidates.map((candidate) => ({
        path: candidate.path,
        heading: t(this.settings, "noteMigration"),
        snippet: `${candidate.risk}: ${candidate.matches.map((match) => match.text).join(" ")}`,
        score: candidate.risk === "low" ? 1 : candidate.risk === "medium" ? 0.5 : 0.1,
      }));
      return { markdown, results, candidates: limitedCandidates };
    }
    const links = this.extractWikiLinks(request);
    if (links.length < 2) {
      throw new Error(t(this.settings, "noteMigrationNeedTwoLinks"));
    }
    const oldRef = this.parseNoteRef(links[0]);
    const newRef = this.parseNoteRef(links[1]);
    const oldFile = this.resolveNoteRef(links[0]);
    const newFile = this.resolveNoteRef(links[1]);
    if (!(oldFile instanceof TFile) || !(newFile instanceof TFile)) {
      throw new Error(t(this.settings, "noteMigrationNeedTwoLinks"));
    }
    const oldContent = await this.app.vault.cachedRead(oldFile);
    const newContent = await this.app.vault.cachedRead(newFile);
    const newHeadings = this.extractMarkdownHeadings(newContent);
    const candidates = await this.findNoteMigrationCandidates(oldFile, newFile, newHeadings, oldRef, newRef);
    const limit = Math.max(1, Math.min(Number.parseInt(this.settings.migrationScanLimit, 10) || 30, 100));
    const limitedCandidates = candidates.slice(0, limit);
    const counts = limitedCandidates.reduce(
      (acc, candidate) => {
        acc[candidate.risk] += 1;
        return acc;
      },
      { low: 0, medium: 0, high: 0 }
    );
    const oldDisplay = `${oldFile.basename}${oldRef.anchor ? `#${oldRef.anchor}` : ""}`;
    const newDisplay = `${newFile.basename}${newRef.anchor ? `#${newRef.anchor}` : ""}`;
    const deterministicSummary = `# ${t(this.settings, "noteMigration")}: [[${oldDisplay}]] -> [[${newDisplay}]]

This is a scan and preview only. No Markdown notes were modified.

- Related notes scanned for migration: ${candidates.length}
- Old target: [[${oldDisplay}]]
- New target: [[${newDisplay}]]
- Sent to model for context: ${limitedCandidates.length}
- Low risk: ${counts.low}
- Medium risk: ${counts.medium}
- High risk: ${counts.high}

`;
    const aiReport = limitedCandidates.length
      ? await this.analyzeNoteMigration(request, oldFile, newFile, oldContent, newContent, newHeadings, limitedCandidates)
      : t(this.settings, "noteMigrationNoCandidates");
    const results = limitedCandidates.map((candidate) => ({
      path: candidate.path,
      heading: t(this.settings, "noteMigration"),
      snippet: `${candidate.risk}: ${candidate.matches.map((match) => match.text).join(" ")}`,
      score: candidate.risk === "low" ? 1 : candidate.risk === "medium" ? 0.5 : 0.1,
    }));
    this.lastMigrationPreview = {
      oldPath: oldFile.path,
      newPath: newFile.path,
      oldRef,
      newRef,
      newHeadings,
      candidates,
      createdAt: new Date().toISOString(),
    };
    await this.savePluginData();
    return {
      markdown: normalizeMathDelimiters(`${deterministicSummary}${aiReport}`),
      results,
      candidates: limitedCandidates,
    };
  }

  symbolRiskForLine(line, oldSymbol, notes = "", exactSymbolFound = true) {
    const text = String(line || "");
    const symbol = String(oldSymbol || "");
    const inInlineMath = new RegExp(`\\$[^$]*${escapeRegExp(symbol)}[^$]*\\$`).test(text);
    const inDisplayMath = text.includes("$$") || /\\begin\{[^}]+\}/.test(text);
    const noteTerms = tokenize(notes).filter((term) => term.length >= 2);
    const noteScore = noteTerms.length ? lineScore(text, noteTerms) : 0;
    if (!exactSymbolFound) return "high";
    if (symbol.length <= 1 && noteScore === 0) return "high";
    if (inInlineMath || inDisplayMath || noteScore > 0) return "medium";
    return "high";
  }

  extractCoreSymbol(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const simplified = raw
      .replace(/^\\\(|\\\)$/g, "")
      .replace(/^\\\[|\\\]$/g, "")
      .replace(/^\$+|\$+$/g, "")
      .replace(/\\dots|\\cdots|\\ldots/g, " ")
      .replace(/[{}]/g, " ")
      .trim();
    const command = simplified.match(/\\[A-Za-z]+/);
    const word = simplified.match(/[A-Za-z][A-Za-z0-9_]*/);
    if (word) return word[0];
    if (command) return command[0];
    return simplified;
  }

  isSymbolBoundaryChar(char) {
    return Boolean(char && /[A-Za-z0-9]/.test(char));
  }

  isSymbolBoundaryMatch(text, start, end, searchText) {
    if (!searchText) return false;
    if (searchText.startsWith("\\")) {
      const after = text[end] || "";
      return !/[A-Za-z]/.test(after);
    }
    const before = text[start - 1] || "";
    const after = text[end] || "";
    return !this.isSymbolBoundaryChar(before) && !this.isSymbolBoundaryChar(after);
  }

  findSymbolOccurrences(line, searchSymbol, precise = true) {
    const text = String(line || "");
    const searchText = String(searchSymbol || "");
    if (!searchText) return [];
    const occurrences = [];
    let start = 0;
    while (start <= text.length) {
      const index = text.indexOf(searchText, start);
      if (index < 0) break;
      const end = index + searchText.length;
      if (!precise || this.isSymbolBoundaryMatch(text, index, end, searchText)) {
        occurrences.push({ start: index, end, text: searchText });
      }
      start = Math.max(end, index + 1);
    }
    return occurrences;
  }

  replaceSymbolInText(line, searchSymbol, newSymbol, precise = true) {
    const text = String(line || "");
    const searchText = String(searchSymbol || "");
    const newText = String(newSymbol || "");
    const occurrences = this.findSymbolOccurrences(text, searchText, precise);
    if (!occurrences.length) return text;
    let output = "";
    let cursor = 0;
    for (const occurrence of occurrences) {
      output += text.slice(cursor, occurrence.start);
      output += newText;
      cursor = occurrence.end;
    }
    output += text.slice(cursor);
    return output;
  }

  getLineMathInfo(line, inDisplayMath = false) {
    const text = String(line || "");
    const dollarPairs = (text.match(/\$\$/g) || []).length;
    const beginsDisplay = /\\\[|\\begin\{(?:equation|align|aligned|gather|multline|cases|matrix|pmatrix|bmatrix|vmatrix|array)\*?\}/.test(text);
    const endsDisplay = /\\\]|\\end\{(?:equation|align|aligned|gather|multline|cases|matrix|pmatrix|bmatrix|vmatrix|array)\*?\}/.test(text);
    const inlineMath = /\$[^$\n]+\$|\\\([^)]*\\\)/.test(text);
    const isMath = inDisplayMath || inlineMath || dollarPairs > 0 || beginsDisplay || endsDisplay;
    let nextInDisplayMath = inDisplayMath;
    if (dollarPairs % 2 === 1) nextInDisplayMath = !nextInDisplayMath;
    if (beginsDisplay) nextInDisplayMath = true;
    if (endsDisplay) nextInDisplayMath = false;
    return { isMath, nextInDisplayMath };
  }

  buildSymbolReplacement(line, oldSymbol, newSymbol, searchSymbol, precise = true) {
    const text = String(line || "");
    return this.replaceSymbolInText(text, searchSymbol, newSymbol, precise);
  }

  async previewSymbolMigration(oldSymbol, newSymbol, notes = "", searchSymbol = "", preciseSymbolMatching = true) {
    const oldText = String(oldSymbol || "").trim();
    const newText = String(newSymbol || "").trim();
    const searchText = String(searchSymbol || "").trim() || this.extractCoreSymbol(oldText);
    if (!searchText || !newText) {
      throw new Error(t(this.settings, "noteMigrationNeedTwoLinks"));
    }
    const files = this.app.vault.getMarkdownFiles().filter((file) => file instanceof TFile);
    const candidates = [];
    for (const file of files) {
      const content = await this.app.vault.cachedRead(file);
      const lines = content.split(/\r?\n/);
      const matches = [];
      let highestRisk = "medium";
      let hasFormula = false;
      let inDisplayMath = false;
      for (let index = 0; index < lines.length; index += 1) {
        const line = lines[index];
        const mathInfo = this.getLineMathInfo(line, inDisplayMath);
        inDisplayMath = mathInfo.nextInDisplayMath;
        const occurrences = this.findSymbolOccurrences(line, searchText, preciseSymbolMatching);
        if (!occurrences.length) continue;
        const contextFound = oldText ? String(line || "").includes(oldText) : true;
        const risk = this.symbolRiskForLine(line, searchText, notes, contextFound && mathInfo.isMath);
        if (risk === "high") highestRisk = "high";
        if (mathInfo.isMath) hasFormula = true;
        const replacement = this.buildSymbolReplacement(line, oldText, newText, searchText, preciseSymbolMatching);
        matches.push({
          line: index,
          type: "symbol",
          search: searchText,
          contextFound,
          formula: mathInfo.isMath,
          occurrenceCount: occurrences.length,
          text: line.trim(),
          replacement: replacement.trim(),
        });
      }
      if (!matches.length) continue;
      const preview = matches
        .slice(0, 8)
        .map((match) => `- ${match.text}\n+ ${match.replacement}`)
        .join("\n");
      candidates.push({
        path: file.path,
        kind: "symbol",
        risk: highestRisk,
        hasFormula,
        reasons: [
          oldText && matches.some((match) => !match.contextFound)
            ? "found by search symbol; optional old expression/context was not present on every matched line"
            : !hasFormula
            ? "search symbol was found outside obvious math regions; review carefully"
            : highestRisk === "high"
            ? "symbol may have multiple meanings; review context before applying"
            : "symbol appears in mathematical or described context; review before applying",
        ],
        matches: matches.slice(0, 20),
        preview,
      });
    }
    const riskOrder = { low: 0, medium: 1, high: 2 };
    candidates.sort((a, b) => (riskOrder[a.risk] || 9) - (riskOrder[b.risk] || 9) || a.path.localeCompare(b.path));
    const counts = candidates.reduce(
      (acc, candidate) => {
        acc[candidate.risk] += 1;
        return acc;
      },
      { low: 0, medium: 0, high: 0 }
    );
    this.lastMigrationPreview = {
      mode: "symbol",
      oldSymbol: oldText,
      newSymbol: newText,
      searchSymbol: searchText,
      preciseSymbolMatching,
      notes,
      candidates,
      createdAt: new Date().toISOString(),
    };
    await this.savePluginData();
    const markdown = `# Symbol migration: ${searchText} -> ${newText}

This is a scan and preview only. No Markdown notes were modified.

- Old expression/context: ${oldText || "(not set)"}
- Search symbol: ${searchText}
- Exact symbol boundary: ${preciseSymbolMatching ? "on" : "off"}
- Candidate files: ${candidates.length}
- Medium risk: ${counts.medium}
- High risk: ${counts.high}

Symbol migration can be ambiguous. Open the review table and apply only the rows whose context is correct.`;
    const results = candidates.map((candidate) => ({
      path: candidate.path,
      heading: "Symbol migration",
      snippet: `${candidate.risk}: ${candidate.matches.map((match) => match.text).join(" ")}`,
      score: candidate.risk === "medium" ? 0.5 : 0.1,
    }));
    return { markdown, results, candidates };
  }

  getMigrationCandidateByNumber(number) {
    const plan = this.lastMigrationPreview;
    if (!plan || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const index = Number.parseInt(number, 10) - 1;
    if (!Number.isFinite(index) || index < 0 || index >= plan.candidates.length) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    return { plan, index, candidate: plan.candidates[index] };
  }

  normalizeMigrationTarget(value) {
    return String(value || "")
      .trim()
      .replace(/^\[\[/, "")
      .replace(/\]\]$/, "")
      .trim();
  }

  wrapMigrationLinkSuggestion(value) {
    const target = this.normalizeMigrationTarget(value);
    return target ? `[[${target}]]` : "";
  }

  getMigrationLinkSuggestions(value, limit = 80) {
    const raw = this.normalizeMigrationTarget(value).replace(/^\[/, "");
    const hashIndex = raw.indexOf("#");
    const notePartRaw = hashIndex >= 0 ? raw.slice(0, hashIndex) : raw;
    const anchorPartRaw = hashIndex >= 0 ? raw.slice(hashIndex + 1) : "";
    const notePart = String(notePartRaw || "").toLowerCase();
    const anchorPart = String(anchorPartRaw || "").toLowerCase();
    const files = this.app.vault.getMarkdownFiles().filter((file) => file instanceof TFile);
    const suggestions = [];
    const add = (target) => {
      const wrapped = this.wrapMigrationLinkSuggestion(target);
      if (wrapped && !suggestions.includes(wrapped)) suggestions.push(wrapped);
    };
    const matchingFiles = files
      .map((file) => ({
        file,
        target: file.path.replace(/\.md$/i, ""),
        basename: file.basename,
      }))
      .filter((item) => {
        if (!notePart) return true;
        return item.target.toLowerCase().includes(notePart) || item.basename.toLowerCase().includes(notePart);
      })
      .slice(0, Math.max(limit, 20));

    if (hashIndex < 0) {
      for (const item of matchingFiles.slice(0, limit)) add(item.target);
      return suggestions.slice(0, limit);
    }

    const exactFile = this.resolveNoteRef(notePartRaw) || (matchingFiles.length === 1 ? matchingFiles[0].file : null);
    const anchorFiles =
      exactFile instanceof TFile ? [{ file: exactFile, target: exactFile.path.replace(/\.md$/i, "") }] : matchingFiles.slice(0, 8);
    for (const item of anchorFiles) {
      const cache = this.app.metadataCache.getFileCache(item.file) || {};
      const headings = (cache.headings || []).map((heading) => heading.heading).filter(Boolean);
      for (const heading of headings) {
        if (anchorPart && !heading.toLowerCase().includes(anchorPart)) continue;
        add(`${item.target}#${heading}`);
        if (suggestions.length >= limit) return suggestions;
      }
      const blocks = cache.blocks || {};
      const blockIds = Object.keys(blocks).sort((a, b) => {
        const lineA = blocks[a] && blocks[a].position && blocks[a].position.start ? blocks[a].position.start.line : 0;
        const lineB = blocks[b] && blocks[b].position && blocks[b].position.start ? blocks[b].position.start.line : 0;
        return lineA - lineB;
      });
      for (const blockId of blockIds) {
        const blockAnchor = `^${blockId}`;
        if (anchorPart && !blockAnchor.toLowerCase().includes(anchorPart)) continue;
        add(`${item.target}#${blockAnchor}`);
        if (suggestions.length >= limit) return suggestions;
      }
      add(item.target);
      if (suggestions.length >= limit) return suggestions;
    }
    return suggestions.slice(0, limit);
  }

  renderMigrationLinkSuggestions(input, datalist) {
    if (!input || !datalist) return;
    datalist.empty();
    for (const suggestion of this.getMigrationLinkSuggestions(input.value)) {
      datalist.createEl("option", { attr: { value: suggestion } });
    }
  }

  findAnchorStartLine(file, content, anchor) {
    const lines = String(content || "").split(/\r?\n/);
    const value = String(anchor || "").replace(/^#/, "").trim();
    if (!value) return 0;
    if (value.startsWith("^")) {
      const blockId = value.slice(1);
      const cache = this.app.metadataCache.getFileCache(file) || {};
      const block = cache.blocks && cache.blocks[blockId];
      if (block && block.position && block.position.start) return block.position.start.line;
      const blockIndex = lines.findIndex((line) => String(line || "").includes(`^${blockId}`));
      return blockIndex >= 0 ? blockIndex : 0;
    }
    const normalized = value.toLowerCase();
    const headingIndex = lines.findIndex((line) => {
      const match = String(line || "").match(/^(#{1,6})\s+(.+?)\s*$/);
      return match && match[2].trim().toLowerCase() === normalized;
    });
    return headingIndex >= 0 ? headingIndex : 0;
  }

  async renderMigrationLinkPreview(value, container, options = {}) {
    if (!container) return;
    container.empty();
    const target = this.normalizeMigrationTarget(value);
    if (!target) return;
    const file = this.resolveNoteRef(target);
    if (!(file instanceof TFile)) {
      container.createDiv({ cls: "lna-migration-target-preview-muted", text: t(this.settings, "targetNotFoundYet") });
      return;
    }
    const parsed = this.parseNoteRef(target);
    const content = await this.app.vault.cachedRead(file);
    const lines = content.split(/\r?\n/);
    const start = this.findAnchorStartLine(file, content, parsed.anchor);
    const maxLines = Number.isFinite(options.maxLines) ? options.maxLines : 5;
    const snippet = lines.slice(start, Math.min(lines.length, start + maxLines)).join("\n").trim();
    container.createDiv({
      cls: "lna-migration-target-preview-title",
      text: `${t(this.settings, "migrationTargetPreview")}: ${file.path}${parsed.anchor ? `#${parsed.anchor}` : ""}`,
    });
    const rendered = container.createDiv({ cls: "markdown-rendered lna-migration-target-preview-content" });
    await MarkdownRenderer.renderMarkdown(snippet || file.basename, rendered, file.path, this);
  }

  async setMigrationCandidateTarget(number, target) {
    const { candidate } = this.getMigrationCandidateByNumber(number);
    candidate.customTarget = this.normalizeMigrationTarget(target);
    await this.savePluginData();
    return candidate.customTarget;
  }

  formatMigrationCandidateLine(candidate, number) {
    const reasons = candidate.reasons && candidate.reasons.length ? candidate.reasons.join("; ") : lt(this.settings, "link/context review", "链接/上下文检查");
    const matches = (candidate.matches || [])
      .slice(0, 5)
      .map((match) => `line ${match.line + 1}: ${match.text}`)
      .join("\n  ");
    return `### ${number}. ${candidate.risk.toUpperCase()} - ${candidate.path}

Reasons: ${reasons}

Matches:
  ${matches || "(none)"}
${candidate.preview ? `\nSuggested deterministic diff:\n\`\`\`diff\n${candidate.preview}\n\`\`\`\n` : ""}`;
  }

  async listMigrationRiskCandidates() {
    const plan = this.lastMigrationPreview;
    if (!plan || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const risky = plan.candidates
      .map((candidate, index) => ({ candidate, number: index + 1 }))
      .filter((item) => item.candidate.risk === "medium" || item.candidate.risk === "high");
    const markdown = `# ${t(this.settings, "migrationRiskCandidates")}

${risky.length ? risky.map((item) => this.formatMigrationCandidateLine(item.candidate, item.number)).join("\n") : "No medium or high risk candidates remain."}

To preview one item, ask: 为第 N 条生成 diff
To apply one reviewed item, ask: 执行第 N 条`;
    const results = risky.map((item) => ({
      path: item.candidate.path,
      heading: `${item.number}. ${item.candidate.risk}`,
      snippet: item.candidate.matches.map((match) => match.text).join(" "),
      score: item.candidate.risk === "medium" ? 0.5 : 0.1,
    }));
    return { markdown, results };
  }

  async listMigrationRiskCandidates() {
    const plan = this.lastMigrationPreview;
    if (!plan || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const risky = plan.candidates
      .map((candidate, index) => ({ candidate, number: index + 1 }))
      .filter((item) => item.candidate.risk === "medium" || item.candidate.risk === "high");
    const markdown = `# ${t(this.settings, "migrationRiskCandidates")}

${risky.length ? risky.map((item) => this.formatMigrationCandidateLine(item.candidate, item.number)).join("\n") : t(this.settings, "noMediumHighRisk")}

${t(this.settings, "previewMigrationItemHint")}
${t(this.settings, "applyMigrationItemHint")}`;
    const results = risky.map((item) => ({
      path: item.candidate.path,
      heading: `${item.number}. ${item.candidate.risk}`,
      snippet: item.candidate.matches.map((match) => match.text).join(" "),
      score: item.candidate.risk === "medium" ? 0.5 : 0.1,
    }));
    return { markdown, results };
  }

  buildLineDiff(before, after) {
    const beforeLines = String(before || "").split(/\r?\n/);
    const afterLines = String(after || "").split(/\r?\n/);
    const output = [];
    const max = Math.max(beforeLines.length, afterLines.length);
    for (let index = 0; index < max; index += 1) {
      if (beforeLines[index] === afterLines[index]) continue;
      output.push(`@@ line ${index + 1}`);
      if (beforeLines[index] !== undefined) output.push(`- ${beforeLines[index]}`);
      if (afterLines[index] !== undefined) output.push(`+ ${afterLines[index]}`);
    }
    return output.join("\n");
  }

  buildSupersededNoticeContent(content, oldFile, newFile, oldRef = {}, newRef = {}) {
    const oldAnchor = String(oldRef.anchor || "").trim();
    if (!oldAnchor || !oldAnchor.startsWith("^")) return String(content || "");
    const lines = String(content || "").split(/\r?\n/);
    const anchorLine = lines.findIndex((line) => String(line || "").includes(oldAnchor));
    if (anchorLine < 0) return String(content || "");
    const notice = this.getSupersededNoticeText(oldFile, newFile, oldRef, newRef);
    if (this.hasSupersededNoticeContent(content, oldFile, newFile, oldRef, newRef)) {
      return String(content || "");
    }
    let insertAt = anchorLine;
    while (insertAt > 0 && String(lines[insertAt - 1] || "").trim()) {
      insertAt -= 1;
    }
    lines.splice(insertAt, 0, notice, "");
    return lines.join("\n");
  }

  getSupersededNoticeText(oldFile, newFile, oldRef = {}, newRef = {}) {
    const oldAnchor = String(oldRef.anchor || "").trim();
    const newDisplay = `${newFile.basename}${newRef.anchor ? `#${newRef.anchor}` : ""}`;
    const oldAnchorText = `\`${oldAnchor}\``;
    return this.settings.language === "zh"
      ? `> 此内容已迁移至 [[${newDisplay}]]。\n> 旧块锚点 ${oldAnchorText} 暂时保留，以免旧链接失效。`
      : `> This content has migrated to [[${newDisplay}]].\n> The old block anchor ${oldAnchorText} is kept for now to avoid breaking old links.`;
  }

  hasSupersededNoticeContent(content, oldFile, newFile, oldRef = {}, newRef = {}) {
    const oldAnchor = String(oldRef.anchor || "").trim();
    if (!oldAnchor) return false;
    const newDisplay = `${newFile.basename}${newRef.anchor ? `#${newRef.anchor}` : ""}`;
    const text = String(content || "");
    return text.includes(`[[${newDisplay}]]`) && text.includes(`\`${oldAnchor}\``);
  }

  getCurrentMigrationMatches(content, oldFile, candidate, oldRef = {}) {
    const lines = String(content || "").split(/\r?\n/);
    const matches = [];
    if (candidate && candidate.kind === "superseded_notice") {
      const oldAnchor = String(oldRef.anchor || "").trim();
      const lineIndex = oldAnchor ? lines.findIndex((line) => String(line || "").includes(oldAnchor)) : -1;
      if (lineIndex >= 0) {
        matches.push({ line: lineIndex, type: "old-anchor", text: String(lines[lineIndex] || "").trim() });
      }
      return matches;
    }

    for (let index = 0; index < lines.length; index += 1) {
      const line = String(lines[index] || "");
      const wikiPattern = /(!?)\[\[([^\]\n]+)\]\]/g;
      let wikiMatch;
      while ((wikiMatch = wikiPattern.exec(line))) {
        const body = String(wikiMatch[2] || "").split("|")[0];
        const parsed = this.parseNoteRef(body);
        if (!this.isSameNoteRef(parsed.note, oldFile)) continue;
        if (!this.anchorMatches(parsed.anchor, oldRef.anchor || "")) continue;
        matches.push({ line: index, type: wikiMatch[1] ? "embed-link" : "wiki-link", text: line.trim() });
      }
      const markdownPattern = /\[[^\]]+\]\(([^)]+)\)/g;
      let markdownMatch;
      while ((markdownMatch = markdownPattern.exec(line))) {
        const target = String(markdownMatch[1] || "").replace(/%20/g, " ");
        const parsed = this.parseNoteRef(target);
        if (!this.isSameNoteRef(parsed.note, oldFile)) continue;
        if (!this.anchorMatches(parsed.anchor, oldRef.anchor || "")) continue;
        matches.push({ line: index, type: "markdown-link", text: line.trim() });
      }
    }
    return matches;
  }

  async buildMigrationCandidateReview(number, persist = true, targetOverride = null) {
    const { plan, index, candidate } = this.getMigrationCandidateByNumber(number);
    if (plan.mode === "symbol") {
      const file = this.app.vault.getAbstractFileByPath(candidate.path);
      if (!(file instanceof TFile)) {
        throw new Error(t(this.settings, "noteMigrationNoPlan"));
      }
      const before = await this.app.vault.cachedRead(file);
      const oldSymbol = String(plan.oldSymbol || "");
      const newSymbol = String(plan.newSymbol || "");
      const searchSymbol = String(plan.searchSymbol || oldSymbol || "");
      const preciseSymbolMatching = plan.preciseSymbolMatching !== false;
      const currentMatches = this.getCurrentSymbolMatches(before, searchSymbol, candidate, preciseSymbolMatching);
      const after = this.replaceSymbolCandidateContent(
        before,
        oldSymbol,
        newSymbol,
        currentMatches,
        searchSymbol,
        preciseSymbolMatching
      );
      const diff = before === after ? "" : this.buildLineDiff(before, after);
      const review = {
        candidateIndex: index + 1,
        path: file.path,
        risk: candidate.risk,
        reasons: candidate.reasons || [],
        currentMatches,
        before,
        after,
        diff,
        alreadyApplied: !diff && currentMatches.length === 0,
        canApply: Boolean(diff),
        createdAt: new Date().toISOString(),
      };
      if (persist) {
        this.lastReviewedMigration = review;
        await this.savePluginData();
      }
      return review;
    }
    const oldFile = this.app.vault.getAbstractFileByPath(plan.oldPath);
    const file = this.app.vault.getAbstractFileByPath(candidate.path);
    if (!(oldFile instanceof TFile) || !(file instanceof TFile)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const oldRef = plan.oldRef || { note: oldFile.basename, anchor: "" };
    const before = await this.app.vault.cachedRead(file);
    const currentMatches = this.getCurrentMigrationMatches(before, oldFile, candidate, oldRef);
    if (plan.mode === "page-retarget") {
      const target = this.normalizeMigrationTarget(targetOverride || candidate.customTarget || "");
      const targetFile = target ? this.resolveNoteRef(target) : null;
      if (!(targetFile instanceof TFile)) {
        const review = {
          candidateIndex: index + 1,
          path: file.path,
          risk: candidate.risk,
          reasons: target ? [...(candidate.reasons || []), `target not found: ${target}`] : [...(candidate.reasons || []), "target link required"],
          currentMatches,
          before,
          after: before,
          diff: "",
          target,
          alreadyApplied: currentMatches.length === 0,
          canApply: false,
          createdAt: new Date().toISOString(),
        };
        if (persist) {
          this.lastReviewedMigration = review;
          await this.savePluginData();
        }
        return review;
      }
      const targetRef = this.parseNoteRef(target);
      const targetContent = await this.app.vault.cachedRead(targetFile);
      const targetHeadings = this.extractMarkdownHeadings(targetContent);
      const after = this.migrateLowRiskContent(before, oldFile, targetFile, targetHeadings, oldRef, targetRef);
      const diff = before === after ? "" : this.buildLineDiff(before, after);
      const review = {
        candidateIndex: index + 1,
        path: file.path,
        risk: candidate.risk,
        reasons: candidate.reasons || [],
        currentMatches,
        before,
        after,
        diff,
        target,
        alreadyApplied: !diff && currentMatches.length === 0,
        canApply: Boolean(diff) && currentMatches.length > 0,
        createdAt: new Date().toISOString(),
      };
      if (persist) {
        this.lastReviewedMigration = review;
        await this.savePluginData();
      }
      return review;
    }
    const newFile = this.app.vault.getAbstractFileByPath(plan.newPath);
    if (!(newFile instanceof TFile)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const newContent = await this.app.vault.cachedRead(newFile);
    const newHeadings = Array.isArray(plan.newHeadings) ? plan.newHeadings : this.extractMarkdownHeadings(newContent);
    const newRef = plan.newRef || { note: newFile.basename, anchor: "" };
    const after =
      candidate.kind === "superseded_notice"
        ? this.buildSupersededNoticeContent(before, oldFile, newFile, oldRef, newRef)
        : this.migrateLowRiskContent(before, oldFile, newFile, newHeadings, oldRef, newRef);
    const diff = before === after ? "" : this.buildLineDiff(before, after);
    const alreadyApplied =
      !diff &&
      (candidate.kind === "superseded_notice"
        ? this.hasSupersededNoticeContent(before, oldFile, newFile, oldRef, newRef)
        : currentMatches.length === 0);
    const review = {
      candidateIndex: index + 1,
      path: file.path,
      risk: candidate.risk,
      reasons: candidate.reasons || [],
      currentMatches,
      before,
      after,
      diff,
      alreadyApplied,
      canApply: Boolean(diff) && !alreadyApplied,
      createdAt: new Date().toISOString(),
    };
    if (persist) {
      this.lastReviewedMigration = review;
      await this.savePluginData();
    }
    return review;
  }

  getCurrentSymbolMatches(content, searchSymbol, candidate, preciseSymbolMatching = true) {
    const lines = String(content || "").split(/\r?\n/);
    const expectedLines = new Set((candidate.matches || []).map((match) => match.line));
    const matches = [];
    const searchText = String(searchSymbol || "");
    let inDisplayMath = false;
    for (let index = 0; index < lines.length; index += 1) {
      const mathInfo = this.getLineMathInfo(lines[index], inDisplayMath);
      inDisplayMath = mathInfo.nextInDisplayMath;
      if (expectedLines.size && !expectedLines.has(index)) continue;
      const line = lines[index];
      const occurrences = this.findSymbolOccurrences(line, searchText, preciseSymbolMatching);
      if (!occurrences.length) continue;
      matches.push({
        line: index,
        type: "symbol",
        formula: mathInfo.isMath,
        occurrenceCount: occurrences.length,
        text: String(line || "").trim(),
      });
    }
    return matches;
  }

  replaceSymbolCandidateContent(content, oldSymbol, newSymbol, matches, searchSymbol = "", preciseSymbolMatching = true) {
    const lines = String(content || "").split(/\r?\n/);
    const newText = String(newSymbol || "");
    const searchText = String(searchSymbol || "");
    for (const match of matches || []) {
      if (typeof match.line !== "number" || match.line < 0 || match.line >= lines.length) continue;
      const line = String(lines[match.line] || "");
      lines[match.line] = this.replaceSymbolInText(line, searchText, newText, preciseSymbolMatching);
    }
    return lines.join("\n");
  }

  async getMigrationReviewRows() {
    const plan = this.lastMigrationPreview;
    if (!plan || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const rows = [];
    for (let index = 0; index < plan.candidates.length; index += 1) {
      const candidate = plan.candidates[index];
      const review = await this.buildMigrationCandidateReview(index + 1, false);
      rows.push({
        index: index + 1,
        risk: candidate.risk,
        path: candidate.path,
        kind: candidate.kind || "links",
        targetEditable: plan.mode === "page-retarget",
        target: candidate.customTarget || "",
        hasFormula: Boolean(candidate.hasFormula || (candidate.matches || []).some((match) => match.formula)),
        folder: String(candidate.path || "").includes("/") ? String(candidate.path || "").split("/").slice(0, -1).join("/") : "",
        searchSymbol: plan.mode === "symbol" ? String(plan.searchSymbol || "") : "",
        newSymbol: plan.mode === "symbol" ? String(plan.newSymbol || "") : "",
        aiAdvice: candidate.aiAdvice || "",
        reasons: candidate.reasons || [],
        original: review.currentMatches.length
          ? review.currentMatches
              .map(
                (match) =>
                  `line ${match.line + 1}${match.formula ? " [math]" : ""}${
                    match.occurrenceCount ? ` x${match.occurrenceCount}` : ""
                  }: ${match.text}`
              )
              .join("\n")
          : t(this.settings, "migrationAlreadyApplied"),
        modified:
          plan.mode === "page-retarget" && !candidate.customTarget
            ? t(this.settings, "targetLinkRequired")
            : review.alreadyApplied
            ? t(this.settings, "migrationAlreadyApplied")
            : review.diff || t(this.settings, "migrationReviewNoDiff"),
        canApply: review.canApply,
        alreadyApplied: review.alreadyApplied,
      });
    }
    return rows;
  }

  async reviewMigrationCandidate(prompt) {
    const number = this.extractMigrationCandidateNumber(prompt);
    const review = await this.buildMigrationCandidateReview(number);
    const markdown = `# ${t(this.settings, "migrationReview")}: ${review.candidateIndex}

File: [[${review.path.replace(/\.md$/i, "")}]]
Risk: ${review.risk}
Reasons: ${review.reasons.length ? review.reasons.join("; ") : "(none)"}

${review.canApply ? `\`\`\`diff\n${review.diff}\n\`\`\`\n\nIf this is correct, ask: 执行第 ${review.candidateIndex} 条` : t(this.settings, "migrationReviewNoDiff")}
`;
    return {
      markdown,
      results: [
        {
          path: review.path,
          heading: t(this.settings, "migrationReview"),
          snippet: review.diff || t(this.settings, "migrationReviewNoDiff"),
          score: 1,
        },
      ],
    };
  }

  async applyReviewedMigrationCandidate(prompt) {
    const number = this.extractMigrationCandidateNumber(prompt);
    let review = this.lastReviewedMigration;
    if (!review || review.candidateIndex !== number) {
      review = await this.buildMigrationCandidateReview(number);
    }
    if (!review.canApply || !review.diff) {
      throw new Error(t(this.settings, "migrationReviewNoDiff"));
    }
    const file = this.app.vault.getAbstractFileByPath(review.path);
    if (!(file instanceof TFile) || file.extension !== "md") {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const current = await this.app.vault.cachedRead(file);
    if (current !== review.before) {
      throw new Error(t(this.settings, "noteChangedAfterDiff"));
    }
    await this.app.vault.modify(file, review.after);
    this.lastFormalMigrationUndo = {
      createdAt: new Date().toISOString(),
      snapshots: [{ path: file.path, content: review.before }],
      reviewedCandidateIndex: review.candidateIndex,
      reverseDiff: this.buildLineDiff(review.after, review.before),
    };
    this.recordMigrationOperation("single-reviewed", [review], [file.path], this.lastFormalMigrationUndo.snapshots);
    this.lastReviewedMigration = null;
    await this.savePluginData();
    const markdown = `# ${t(this.settings, "migrationReviewApplied")}: ${number}

Modified:
- [[${file.path.replace(/\.md$/i, "")}]]

Applied diff:
\`\`\`diff
${review.diff}
\`\`\`

You can undo this operation by asking: 撤销上次迁移`;
    return {
      markdown,
      results: [
        {
          path: file.path,
          heading: t(this.settings, "migrationReviewApplied"),
          snippet: review.diff,
          score: 1,
        },
      ],
    };
  }

  async applySelectedMigrationCandidates(indexes) {
    const selections = [];
    const seen = new Set();
    for (const value of indexes || []) {
      const index = typeof value === "object" ? Number.parseInt(value.index, 10) : Number.parseInt(value, 10);
      if (!Number.isFinite(index) || index <= 0 || seen.has(index)) continue;
      seen.add(index);
      selections.push({
        index,
        target: typeof value === "object" ? this.normalizeMigrationTarget(value.target || "") : "",
      });
    }
    if (!selections.length) {
      return { markdown: t(this.settings, "noMigrationItemsSelected"), results: [] };
    }
    const reviews = [];
    for (const selection of selections) {
      if (selection.target) {
        await this.setMigrationCandidateTarget(selection.index, selection.target);
      }
      const review = await this.buildMigrationCandidateReview(selection.index, false, selection.target || null);
      if (review.canApply) reviews.push(review);
    }
    if (!reviews.length) {
      throw new Error(t(this.settings, "migrationReviewNoDiff"));
    }
    const snapshots = [];
    const modified = [];
    for (const review of reviews) {
      const file = this.app.vault.getAbstractFileByPath(review.path);
      if (!(file instanceof TFile) || file.extension !== "md") continue;
      const current = await this.app.vault.cachedRead(file);
      if (current !== review.before) {
        throw new Error(`${t(this.settings, "noteChangedAfterReview")}: ${review.path}`);
      }
      snapshots.push({ path: file.path, content: review.before });
      await this.app.vault.modify(file, review.after);
      modified.push(file.path);
    }
    this.lastFormalMigrationUndo = {
      createdAt: new Date().toISOString(),
      snapshots,
      reviewedCandidateIndexes: reviews.map((review) => review.candidateIndex),
      reverseDiff: reviews.map((review) => `# ${review.path}\n${this.buildLineDiff(review.after, review.before)}`).join("\n\n"),
    };
    this.recordMigrationOperation("selected-reviewed", reviews, modified, snapshots);
    this.lastReviewedMigration = null;
    await this.savePluginData();
    const markdown = `# ${t(this.settings, "selectedApplied")}

${this.settings.language === "zh" ? `已修改 ${modified.length} 个文件。` : `Modified ${modified.length} file(s).`}

${modified.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n")}

You can undo this operation by asking: 撤销上次迁移`;
    return {
      markdown,
      results: modified.map((path) => ({
        path,
        heading: t(this.settings, "selectedApplied"),
        snippet: "Selected migration item applied.",
        score: 1,
      })),
    };
  }

  async reviewMigrationCandidate(prompt) {
    const number = this.extractMigrationCandidateNumber(prompt);
    const review = await this.buildMigrationCandidateReview(number);
    const labels = {
      file: lt(this.settings, "File", "文件"),
      risk: lt(this.settings, "Risk", "风险"),
      reasons: lt(this.settings, "Reasons", "原因"),
      none: `(${t(this.settings, "noneText")})`,
      ask: lt(this.settings, `If this is correct, ask: apply item ${review.candidateIndex}`, `如果确认无误，请输入：执行第 ${review.candidateIndex} 条`),
    };
    const markdown = `# ${t(this.settings, "migrationReview")}: ${review.candidateIndex}

${labels.file}: [[${review.path.replace(/\.md$/i, "")}]]
${labels.risk}: ${review.risk}
${labels.reasons}: ${review.reasons.length ? review.reasons.join("; ") : labels.none}

${review.canApply ? `\`\`\`diff\n${review.diff}\n\`\`\`\n\n${labels.ask}` : t(this.settings, "migrationReviewNoDiff")}
`;
    return {
      markdown,
      results: [
        {
          path: review.path,
          heading: t(this.settings, "migrationReview"),
          snippet: review.diff || t(this.settings, "migrationReviewNoDiff"),
          score: 1,
        },
      ],
    };
  }

  async applyReviewedMigrationCandidate(prompt) {
    const number = this.extractMigrationCandidateNumber(prompt);
    let review = this.lastReviewedMigration;
    if (!review || review.candidateIndex !== number) {
      review = await this.buildMigrationCandidateReview(number);
    }
    if (!review.canApply || !review.diff) {
      throw new Error(t(this.settings, "migrationReviewNoDiff"));
    }
    const file = this.app.vault.getAbstractFileByPath(review.path);
    if (!(file instanceof TFile) || file.extension !== "md") {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const current = await this.app.vault.cachedRead(file);
    if (current !== review.before) {
      throw new Error(t(this.settings, "noteChangedAfterDiff"));
    }
    await this.app.vault.modify(file, review.after);
    this.lastFormalMigrationUndo = {
      createdAt: new Date().toISOString(),
      snapshots: [{ path: file.path, content: review.before }],
      reviewedCandidateIndex: review.candidateIndex,
      reverseDiff: this.buildLineDiff(review.after, review.before),
    };
    this.recordMigrationOperation("single-reviewed", [review], [file.path], this.lastFormalMigrationUndo.snapshots);
    this.lastReviewedMigration = null;
    await this.savePluginData();
    const markdown = `# ${t(this.settings, "migrationReviewApplied")}: ${number}

${lt(this.settings, "Modified", "已修改")}:
- [[${file.path.replace(/\.md$/i, "")}]]

${lt(this.settings, "Applied diff", "已执行 diff")}:
\`\`\`diff
${review.diff}
\`\`\`

${t(this.settings, "migrationUndoHint")}`;
    return {
      markdown,
      results: [
        {
          path: file.path,
          heading: t(this.settings, "migrationReviewApplied"),
          snippet: review.diff,
          score: 1,
        },
      ],
    };
  }

  async applySelectedMigrationCandidates(indexes) {
    const selections = [];
    const seen = new Set();
    for (const value of indexes || []) {
      const index = typeof value === "object" ? Number.parseInt(value.index, 10) : Number.parseInt(value, 10);
      if (!Number.isFinite(index) || index <= 0 || seen.has(index)) continue;
      seen.add(index);
      selections.push({
        index,
        target: typeof value === "object" ? this.normalizeMigrationTarget(value.target || "") : "",
      });
    }
    if (!selections.length) {
      return { markdown: t(this.settings, "noMigrationItemsSelected"), results: [] };
    }
    const reviews = [];
    for (const selection of selections) {
      if (selection.target) {
        await this.setMigrationCandidateTarget(selection.index, selection.target);
      }
      const review = await this.buildMigrationCandidateReview(selection.index, false, selection.target || null);
      if (review.canApply) reviews.push(review);
    }
    if (!reviews.length) {
      throw new Error(t(this.settings, "migrationReviewNoDiff"));
    }
    const snapshots = [];
    const modified = [];
    for (const review of reviews) {
      const file = this.app.vault.getAbstractFileByPath(review.path);
      if (!(file instanceof TFile) || file.extension !== "md") continue;
      const current = await this.app.vault.cachedRead(file);
      if (current !== review.before) {
        throw new Error(`${t(this.settings, "noteChangedAfterReview")}: ${review.path}`);
      }
      snapshots.push({ path: file.path, content: review.before });
      await this.app.vault.modify(file, review.after);
      modified.push(file.path);
    }
    this.lastFormalMigrationUndo = {
      createdAt: new Date().toISOString(),
      snapshots,
      reviewedCandidateIndexes: reviews.map((review) => review.candidateIndex),
      reverseDiff: reviews.map((review) => `# ${review.path}\n${this.buildLineDiff(review.after, review.before)}`).join("\n\n"),
    };
    this.recordMigrationOperation("selected-reviewed", reviews, modified, snapshots);
    this.lastReviewedMigration = null;
    await this.savePluginData();
    const modifiedLine = lt(this.settings, `Modified ${modified.length} file(s).`, `已修改 ${modified.length} 个文件。`);
    const markdown = `# ${t(this.settings, "selectedApplied")}

${modifiedLine}

${modified.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n")}

${t(this.settings, "migrationUndoHint")}`;
    return {
      markdown,
      results: modified.map((path) => ({
        path,
        heading: t(this.settings, "selectedApplied"),
        snippet: t(this.settings, "selectedApplied"),
        score: 1,
      })),
    };
  }

  async applyLastMigrationLowRisk() {
    const plan = this.lastMigrationPreview;
    if (!plan || !plan.oldPath || !plan.newPath || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const oldFile = this.app.vault.getAbstractFileByPath(plan.oldPath);
    const newFile = this.app.vault.getAbstractFileByPath(plan.newPath);
    if (!(oldFile instanceof TFile) || !(newFile instanceof TFile)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const newContent = await this.app.vault.cachedRead(newFile);
    const newHeadings = Array.isArray(plan.newHeadings) ? plan.newHeadings : this.extractMarkdownHeadings(newContent);
    const oldRef = plan.oldRef || { note: oldFile.basename, anchor: "" };
    const newRef = plan.newRef || { note: newFile.basename, anchor: "" };
    const snapshots = [];
    const changedFiles = [];
    const skipped = [];
    for (const candidate of plan.candidates.filter((item) => item.risk === "low")) {
      const file = this.app.vault.getAbstractFileByPath(candidate.path);
      if (!(file instanceof TFile) || file.extension !== "md") continue;
      const before = await this.app.vault.cachedRead(file);
      const after = this.migrateLowRiskContent(before, oldFile, newFile, newHeadings, oldRef, newRef);
      if (after === before) {
        skipped.push(file.path);
        continue;
      }
      snapshots.push({ path: file.path, content: before });
      await this.app.vault.modify(file, after);
      changedFiles.push(file.path);
    }
    this.lastFormalMigrationUndo = {
      createdAt: new Date().toISOString(),
      oldPath: oldFile.path,
      newPath: newFile.path,
      oldRef,
      newRef,
      snapshots,
      reverseDiff: snapshots
        .map((snapshot) => {
          const path = snapshot.path;
          const after = changedFiles.includes(path) ? "(see current note content)" : "";
          return `# ${path}\nSnapshot saved before migration.${after}`;
        })
        .join("\n\n"),
    };
    this.recordMigrationOperation(
      "low-risk-batch",
      plan.candidates.filter((item) => item.risk === "low").map((candidate, index) => ({ candidateIndex: index + 1, risk: candidate.risk, path: candidate.path })),
      changedFiles,
      snapshots
    );
    await this.savePluginData();
    const markdown = `# ${t(this.settings, "noteMigrationApplied")}

Modified ${changedFiles.length} low-risk file(s). Medium and high risk files were not changed.

## Modified files
${changedFiles.length ? changedFiles.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n") : "- None"}

## Skipped
${skipped.length ? skipped.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n") : "- None"}

You can undo this operation by asking: 撤销上次迁移`;
    const results = changedFiles.map((path) => ({
      path,
      heading: t(this.settings, "noteMigrationApplied"),
      snippet: `${plan.oldPath}${oldRef.anchor ? `#${oldRef.anchor}` : ""} -> ${plan.newPath}${
        newRef.anchor ? `#${newRef.anchor}` : ""
      }`,
      score: 1,
    }));
    return { markdown, results };
  }

  async applyLastMigrationLowRisk() {
    const plan = this.lastMigrationPreview;
    if (!plan || !plan.oldPath || !plan.newPath || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const oldFile = this.app.vault.getAbstractFileByPath(plan.oldPath);
    const newFile = this.app.vault.getAbstractFileByPath(plan.newPath);
    if (!(oldFile instanceof TFile) || !(newFile instanceof TFile)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const newContent = await this.app.vault.cachedRead(newFile);
    const newHeadings = Array.isArray(plan.newHeadings) ? plan.newHeadings : this.extractMarkdownHeadings(newContent);
    const oldRef = plan.oldRef || { note: oldFile.basename, anchor: "" };
    const newRef = plan.newRef || { note: newFile.basename, anchor: "" };
    const snapshots = [];
    const changedFiles = [];
    const skipped = [];
    for (const candidate of plan.candidates.filter((item) => item.risk === "low")) {
      const file = this.app.vault.getAbstractFileByPath(candidate.path);
      if (!(file instanceof TFile) || file.extension !== "md") continue;
      const before = await this.app.vault.cachedRead(file);
      const after = this.migrateLowRiskContent(before, oldFile, newFile, newHeadings, oldRef, newRef);
      if (after === before) {
        skipped.push(file.path);
        continue;
      }
      snapshots.push({ path: file.path, content: before });
      await this.app.vault.modify(file, after);
      changedFiles.push(file.path);
    }
    this.lastFormalMigrationUndo = {
      createdAt: new Date().toISOString(),
      oldPath: oldFile.path,
      newPath: newFile.path,
      oldRef,
      newRef,
      snapshots,
      reverseDiff: snapshots
        .map((snapshot) => {
          const path = snapshot.path;
          const after = changedFiles.includes(path) ? lt(this.settings, " (see current note content)", "（请查看当前笔记内容）") : "";
          return `# ${path}\n${lt(this.settings, "Snapshot saved before migration.", "迁移前快照已保存。")}${after}`;
        })
        .join("\n\n"),
    };
    this.recordMigrationOperation(
      "low-risk-batch",
      plan.candidates
        .filter((item) => item.risk === "low")
        .map((candidate, index) => ({ candidateIndex: index + 1, risk: candidate.risk, path: candidate.path })),
      changedFiles,
      snapshots
    );
    await this.savePluginData();
    const markdown = `# ${t(this.settings, "noteMigrationApplied")}

${lt(
  this.settings,
  `Modified ${changedFiles.length} low-risk file(s). Medium and high risk files were not changed.`,
  `已修改 ${changedFiles.length} 个低风险文件。中高风险文件未被修改。`
)}

## ${lt(this.settings, "Modified files", "已修改文件")}
${changedFiles.length ? changedFiles.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n") : `- ${t(this.settings, "noneText")}`}

## ${lt(this.settings, "Skipped", "已跳过")}
${skipped.length ? skipped.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n") : `- ${t(this.settings, "noneText")}`}

${t(this.settings, "migrationUndoHint")}`;
    const results = changedFiles.map((path) => ({
      path,
      heading: t(this.settings, "noteMigrationApplied"),
      snippet: `${plan.oldPath}${oldRef.anchor ? `#${oldRef.anchor}` : ""} -> ${plan.newPath}${
        newRef.anchor ? `#${newRef.anchor}` : ""
      }`,
      score: 1,
    }));
    return { markdown, results };
  }

  async undoLastFormalMigration() {
    const undo = this.lastFormalMigrationUndo;
    if (!undo || !Array.isArray(undo.snapshots) || undo.snapshots.length === 0) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const restored = [];
    for (const snapshot of undo.snapshots) {
      const file = this.app.vault.getAbstractFileByPath(snapshot.path);
      if (!(file instanceof TFile) || file.extension !== "md") continue;
      await this.app.vault.modify(file, snapshot.content || "");
      restored.push(file.path);
    }
    this.lastFormalMigrationUndo = null;
    await this.savePluginData();
    const markdown = `# ${t(this.settings, "noteMigrationUndone")}

Restored ${restored.length} file(s).

${restored.map((path) => `- [[${path.replace(/\.md$/i, "")}]]`).join("\n")}`;
    return { markdown, results: [] };
  }

  async analyzeNoteMigration(request, oldFile, newFile, oldContent, newContent, newHeadings, candidates) {
    const oldExcerpt =
      oldContent.length > 12000 ? `${oldContent.slice(0, 12000).trim()}\n[old note shortened by plugin]` : oldContent;
    const newExcerpt =
      newContent.length > 12000 ? `${newContent.slice(0, 12000).trim()}\n[new note shortened by plugin]` : newContent;
    const report = await this.chatProvider.analyzeNoteMigration(
      request,
      { path: oldFile.path, content: oldExcerpt },
      { path: newFile.path, content: newExcerpt, headings: newHeadings },
      candidates
    );
    return normalizeMathDelimiters(unwrapMarkdownFence(report)).trim();
  }

  recordMigrationOperation(type, reviews, modified, snapshots) {
    this.migrationHistory = Array.isArray(this.migrationHistory) ? this.migrationHistory : [];
    const items = Array.isArray(reviews) ? reviews : [];
    this.migrationHistory.push({
      type,
      createdAt: new Date().toISOString(),
      modified: modified || [],
      candidateIndexes: items.map((review) => review.candidateIndex).filter(Boolean),
      risks: items.map((review) => review.risk).filter(Boolean),
      snapshotCount: Array.isArray(snapshots) ? snapshots.length : 0,
      summary: items
        .slice(0, 12)
        .map((review) => `${review.candidateIndex || "?"}: ${review.path || ""}`)
        .join("\n"),
    });
    this.migrationHistory = this.migrationHistory.slice(-50);
  }

  async judgeMigrationCandidatesWithAI(indexes = []) {
    const plan = this.lastMigrationPreview;
    if (!plan || !Array.isArray(plan.candidates)) {
      throw new Error(t(this.settings, "noteMigrationNoPlan"));
    }
    const selected = [...new Set((indexes || []).map((value) => Number.parseInt(value, 10)).filter((value) => value > 0))]
      .slice(0, 20)
      .map((number) => ({ number, candidate: plan.candidates[number - 1] }))
      .filter((item) => item.candidate);
    if (!selected.length) return [];
    const candidateText = selected
      .map((item) => {
        const snippets = (item.candidate.matches || [])
          .slice(0, 6)
          .map((match) => `line ${match.line + 1}${match.formula ? " [math]" : ""}: ${match.text}\n=> ${match.replacement || ""}`)
          .join("\n");
        return `Candidate ${item.number}
Path: ${item.candidate.path}
Risk: ${item.candidate.risk}
Reasons: ${(item.candidate.reasons || []).join("; ") || "(none)"}
Snippets:
${snippets || "(none)"}`;
      })
      .join("\n\n");
    const systemPrompt =
      "You are a cautious assistant reviewing proposed edits in mathematical Obsidian notes. Return concise Chinese advice. Do not claim files were modified.";
    const userPrompt = `Migration plan:
Mode: ${plan.mode || "unknown"}
Search symbol: ${plan.searchSymbol || ""}
New symbol: ${plan.newSymbol || ""}
Old expression/context: ${plan.oldSymbol || ""}
Notes: ${plan.notes || ""}

Visible candidates:
${candidateText}

For each candidate, return exactly one line:
N: 建议修改 / 不建议修改 / 不确定 - short reason

Be conservative. If the symbol may have another meaning, say 不确定 or 不建议修改.`;
    const answer = await this.chatProvider.complete(
      systemPrompt,
      `${userPrompt}${this.chatProvider.getPreferenceBlock(`${plan.notes || ""} ${plan.searchSymbol || ""}`)}`
    );
    const lines = String(answer || "").split(/\r?\n/);
    for (const item of selected) {
      const pattern = new RegExp(`^\\s*${item.number}\\s*[:：]\\s*(.+)$`);
      const line = lines.find((entry) => pattern.test(entry));
      item.candidate.aiAdvice = line ? line.replace(pattern, "$1").trim() : String(answer || "").slice(0, 500);
    }
    await this.savePluginData();
    return selected;
  }

  async activateView() {
    const existing = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (existing) {
      this.app.workspace.revealLeaf(existing);
      return existing.view;
    }

    const leaf = this.app.workspace.getRightLeaf(false);
    await leaf.setViewState({ type: VIEW_TYPE, active: true });
    this.app.workspace.revealLeaf(leaf);
    return leaf.view;
  }

  async openSystemScreenshotTool() {
    const isWindows = typeof navigator !== "undefined" && /Windows/i.test(navigator.userAgent || "");
    if (isWindows) {
      try {
        const electron = require("electron");
        if (electron && electron.shell && electron.shell.openExternal) {
          await electron.shell.openExternal("ms-screenclip:");
          return true;
        }
      } catch (error) {
        // Fall through to window.open.
      }
      if (typeof window !== "undefined" && window.open) {
        window.open("ms-screenclip:");
        return true;
      }
    }
    throw new Error(t(this.settings, "systemScreenshotWindowsOnly"));
  }

  getCurrentSignature() {
    return this.embeddingProvider.getIndexSignature();
  }

  indexSettingsMatch(index = this.index) {
    const signature = this.getCurrentSignature();
    const indexDimensions = index && Object.prototype.hasOwnProperty.call(index, "dimensions") ? index.dimensions : signature.dimensions || "";
    return (
      index &&
      index.indexVersion === INDEX_VERSION &&
      index.provider === signature.provider &&
      index.model === signature.model &&
      String(indexDimensions || "") === String(signature.dimensions || "")
    );
  }

  indexMatchesSettings() {
    return (
      this.indexSettingsMatch(this.index) &&
      Array.isArray(this.index.chunks) &&
      this.index.chunks.length > 0
    );
  }

  getIncrementalIndexChunkLimit() {
    const parsed = Number.parseInt(this.settings.maxIncrementalIndexChunks, 10);
    if (!Number.isFinite(parsed) || parsed <= 0) return 250;
    return Math.max(1, Math.min(parsed, 5000));
  }

  signatureMatches(previous, current) {
    return (
      previous &&
      current &&
      String(previous.path || "") === String(current.path || "") &&
      Number(previous.mtime || 0) === Number(current.mtime || 0) &&
      Number(previous.size || 0) === Number(current.size || 0)
    );
  }

  getSortedSearchableMarkdownFiles() {
    return [...this.getSearchableMarkdownFiles()].sort((a, b) =>
      String(a.path || "").localeCompare(String(b.path || ""))
    );
  }

  async estimateSemanticChunkCount(files) {
    let total = 0;
    for (const file of files) {
      const content = await this.app.vault.cachedRead(file);
      total += this.makeChunksForFile(file, content).length;
    }
    return total;
  }

  async getSemanticIndexChangePlan(options = {}) {
    const estimateChunks = options.estimateChunks !== false;
    const files = this.getSortedSearchableMarkdownFiles();
    const currentSignatures = files.map((file) => this.getFileSignature(file));
    const currentByPath = new Map(currentSignatures.map((item) => [item.path, item]));
    const savedSignatures = Array.isArray(this.index && this.index.fileSignatures) ? this.index.fileSignatures : [];
    const savedByPath = new Map(savedSignatures.map((item) => [item.path, item]));
    const settingsMatch = Boolean(this.indexSettingsMatch(this.index));
    const hasChunks = Boolean(this.index && Array.isArray(this.index.chunks) && this.index.chunks.length > 0);
    const hasFileSignatures = savedSignatures.length > 0;

    if (!settingsMatch || !hasChunks || !hasFileSignatures) {
      const estimatedChunks = estimateChunks ? await this.estimateSemanticChunkCount(files) : 0;
      return {
        fullRebuildNeeded: true,
        reason: !this.index || !hasChunks ? "missing-index" : !settingsMatch ? "settings" : "legacy-index",
        hasChanges: true,
        settingsMatch,
        hasFileSignatures,
        fileCount: files.length,
        currentSignatures,
        added: currentSignatures,
        modified: [],
        deleted: [],
        unchanged: [],
        estimatedChunks,
      };
    }

    const added = [];
    const modified = [];
    const deleted = [];
    const unchanged = [];

    for (const current of currentSignatures) {
      const previous = savedByPath.get(current.path);
      if (!previous) {
        added.push(current);
      } else if (this.signatureMatches(previous, current)) {
        unchanged.push(current);
      } else {
        modified.push(current);
      }
    }

    for (const previous of savedSignatures) {
      if (!currentByPath.has(previous.path)) deleted.push(previous);
    }

    const changedPaths = new Set([...added, ...modified].map((item) => item.path));
    const changedFiles = files.filter((file) => changedPaths.has(file.path));
    const estimatedChunks = estimateChunks ? await this.estimateSemanticChunkCount(changedFiles) : 0;

    return {
      fullRebuildNeeded: false,
      reason: "",
      hasChanges: added.length > 0 || modified.length > 0 || deleted.length > 0,
      settingsMatch,
      hasFileSignatures,
      fileCount: files.length,
      currentSignatures,
      added,
      modified,
      deleted,
      unchanged,
      estimatedChunks,
    };
  }

  getIndexStatusText() {
    if (!this.index || !Array.isArray(this.index.chunks) || this.index.chunks.length === 0) {
      return t(this.settings, "noIndex");
    }
    const stale = this.indexMatchesSettings() ? "" : ` ${t(this.settings, "settingsChanged")}`;
    if (this.settings.language === "zh") {
      return `${t(this.settings, "indexReady")}：${this.index.chunks.length} ${t(
        this.settings,
        "chunksFrom"
      )} ${this.index.fileCount || "unknown"} ${t(this.settings, "notesUsing")} ${
        this.index.provider
      }/${this.index.model}。${stale}`;
    }
    return `${t(this.settings, "indexReady")}: ${this.index.chunks.length} ${t(
      this.settings,
      "chunksFrom"
    )} ${this.index.fileCount || "unknown"} ${t(this.settings, "notesUsing")} ${
      this.index.provider
    }/${this.index.model}.${stale}`;
  }

  makeChunksForFile(file, content) {
    const lines = content.split(/\r?\n/);
    const chunks = [];
    let currentHeading = t(this.settings, "noHeading");
    let currentHeadingKey = t(this.settings, "noHeading");
    let currentText = "";
    let currentStartLine = 0;

    const pushChunk = () => {
      const text = currentText.trim();
      if (text.length < 20) return;
      chunks.push({
        path: file.path,
        chunkIndexInFile: chunks.length,
        heading: currentHeading,
        headingKey: currentHeadingKey,
        sourceLink: makeObsidianSourceLink(file.path, currentHeading, "", currentHeading === t(this.settings, "noHeading") ? "" : currentHeading),
        sourcePrecision: currentHeading === t(this.settings, "noHeading") ? "note" : "heading",
        text,
        startLine: currentStartLine,
      });
    };

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const headingMatch = line.match(/^(#{1,6})\s+(.+?)\s*$/);
      if (headingMatch) {
        pushChunk();
        currentHeading = headingMatch[2].trim();
        currentHeadingKey = `${headingMatch[1].length}:${currentHeading}`;
        currentText = line;
        currentStartLine = index;
        continue;
      }

      if (!currentText) currentStartLine = index;
      if ((currentText + "\n" + line).length > this.settings.chunkSize) {
        pushChunk();
        const overlap = currentText.slice(-this.settings.chunkOverlap);
        currentText = `${overlap}\n${line}`;
        currentStartLine = index;
      } else {
        currentText += `\n${line}`;
      }
    }

    pushChunk();
    return chunks;
  }

  async buildIndex(onProgress = null) {
    const files = this.getSortedSearchableMarkdownFiles();
    const signature = this.getCurrentSignature();
    const chunks = [];
    let processed = 0;

    for (const file of files) {
      processed += 1;
      if (onProgress) onProgress(`${t(this.settings, "readingProgress")} ${processed}/${files.length}`);
      const content = await this.app.vault.cachedRead(file);
      chunks.push(...this.makeChunksForFile(file, content));
    }

    for (let index = 0; index < chunks.length; index += 1) {
      chunks[index].id = index;
    }

    const embeddedChunks = [];
    for (let index = 0; index < chunks.length; index += 1) {
      if (onProgress) onProgress(`${t(this.settings, "embeddingProgress")} ${index + 1}/${chunks.length}`);
      const chunk = chunks[index];
      const embedding = await this.embeddingProvider.embed(
        `${chunk.path}\n${chunk.heading}\n${chunk.text}`
      );
      embeddedChunks.push({ ...chunk, embedding });
    }

    this.index = {
      indexVersion: INDEX_VERSION,
      provider: signature.provider,
      model: signature.model,
      dimensions: signature.dimensions || "",
      builtAt: new Date().toISOString(),
      fileCount: files.length,
      fileSignatures: files.map((file) => this.getFileSignature(file)),
      chunks: embeddedChunks,
      lastFullRebuild: {
        fileCount: files.length,
        chunkCount: embeddedChunks.length,
        rebuiltAt: new Date().toISOString(),
      },
    };
    await this.savePluginData();
    return this.index;
  }

  async buildIndexIncremental(onProgress = null, knownPlan = null) {
    const plan = knownPlan || (await this.getSemanticIndexChangePlan({ estimateChunks: true }));
    if (plan.fullRebuildNeeded) {
      throw new Error(t(this.settings, "indexFullRebuildNeeded"));
    }
    if (!plan.hasChanges) return this.index;
    const limit = this.getIncrementalIndexChunkLimit();
    if (plan.estimatedChunks > limit) {
      throw new Error(`${t(this.settings, "indexUpdateBlockedByLimit")} (${plan.estimatedChunks}/${limit})`);
    }

    const files = this.getSortedSearchableMarkdownFiles();
    const addedOrModified = new Set([...(plan.added || []), ...(plan.modified || [])].map((item) => item.path));
    const replacedOrDeleted = new Set([...(plan.modified || []), ...(plan.deleted || [])].map((item) => item.path));
    const oldChunks = Array.isArray(this.index && this.index.chunks) ? this.index.chunks : [];
    const oldChunksByPath = new Map();
    for (const chunk of oldChunks) {
      if (!oldChunksByPath.has(chunk.path)) oldChunksByPath.set(chunk.path, []);
      oldChunksByPath.get(chunk.path).push(chunk);
    }

    const changedChunksByPath = new Map();
    const newChunks = [];
    const changedFiles = files.filter((file) => addedOrModified.has(file.path));
    for (let index = 0; index < changedFiles.length; index += 1) {
      const file = changedFiles[index];
      if (onProgress) onProgress(`${t(this.settings, "readingProgress")} ${index + 1}/${changedFiles.length}`);
      const content = await this.app.vault.cachedRead(file);
      const chunks = this.makeChunksForFile(file, content);
      changedChunksByPath.set(file.path, chunks);
      newChunks.push(...chunks);
    }

    for (let index = 0; index < newChunks.length; index += 1) {
      if (onProgress) onProgress(`${t(this.settings, "embeddingProgress")} ${index + 1}/${newChunks.length}`);
      const chunk = newChunks[index];
      chunk.embedding = await this.embeddingProvider.embed(`${chunk.path}\n${chunk.heading}\n${chunk.text}`);
    }

    const finalChunks = [];
    let reusedChunkCount = 0;
    for (const file of files) {
      const fileChunks = addedOrModified.has(file.path)
        ? changedChunksByPath.get(file.path) || []
        : oldChunksByPath.get(file.path) || [];
      if (!addedOrModified.has(file.path)) reusedChunkCount += fileChunks.length;
      for (const chunk of fileChunks) {
        finalChunks.push({ ...chunk, id: finalChunks.length });
      }
    }

    const deletedChunkCount = oldChunks.filter((chunk) => replacedOrDeleted.has(chunk.path)).length;
    const signature = this.getCurrentSignature();
    this.index = {
      ...this.index,
      indexVersion: INDEX_VERSION,
      provider: signature.provider,
      model: signature.model,
      dimensions: signature.dimensions || "",
      incrementallyUpdatedAt: new Date().toISOString(),
      fileCount: files.length,
      fileSignatures: plan.currentSignatures,
      chunks: finalChunks,
      lastIncrementalUpdate: {
        updatedAt: new Date().toISOString(),
        addedFileCount: (plan.added || []).length,
        modifiedFileCount: (plan.modified || []).length,
        deletedFileCount: (plan.deleted || []).length,
        reusedChunkCount,
        embeddedChunkCount: newChunks.length,
        deletedChunkCount,
      },
    };
    await this.savePluginData();
    return this.index;
  }

  async search(query) {
    if (this.indexMatchesSettings()) {
      try {
        return await this.enhanceSearchResponse(query, await this.semanticSearch(query));
      } catch (error) {
        console.warn("Semantic search failed, falling back to keyword search", error);
        const fallback = await this.enhanceSearchResponse(query, await this.keywordSearch(query));
        fallback.warning = `${t(this.settings, "semanticSearchFallback")}: ${
          error.message || error
        }`;
        return fallback;
      }
    }

    const fallback = await this.enhanceSearchResponse(query, await this.keywordSearch(query));
    if (this.index && !this.indexMatchesSettings()) {
      fallback.warning = t(this.settings, "semanticIndexStaleWarning");
    } else {
      fallback.warning = t(this.settings, "noSemanticIndexWarning");
    }
    return fallback;
  }

  async semanticSearch(query) {
    const terms = tokenize(query);
    const queryEmbedding = await this.embeddingProvider.embed(query);
    const results = this.index.chunks
      .map((chunk) => {
        const semanticScore = cosineSimilarity(queryEmbedding, chunk.embedding);
        const keywordBoost = lineScore(`${chunk.path} ${chunk.heading} ${chunk.text}`, terms) / 1000;
        return {
          id: chunk.id,
          path: chunk.path,
          chunkIndexInFile: chunk.chunkIndexInFile,
          heading: chunk.heading,
          headingKey: chunk.headingKey,
          sourceLink: chunk.sourceLink || makeObsidianSourceLink(chunk.path, chunk.heading, "", chunk.heading),
          sourcePrecision: chunk.sourcePrecision || (chunk.heading && chunk.heading !== "(no heading)" ? "heading" : "note"),
          snippet: highlightTerms(cleanSnippet(chunk.text), terms),
          context: chunk.text,
          score: semanticScore + keywordBoost,
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, this.settings.resultLimit);

    return { mode: "semantic", results };
  }

  async keywordSearch(query) {
    const terms = tokenize(query);
    if (terms.length === 0) return { mode: "keyword", results: [] };

    const files = this.app.vault.getMarkdownFiles().filter((file) => this.shouldUseFileForSearch(file));
    const results = [];

    for (const file of files) {
      if (!this.shouldUseFileForSearch(file)) continue;
      const content = await this.app.vault.cachedRead(file);
      const lines = content.split(/\r?\n/);
      let bestLine = -1;
      let bestScore = 0;

      for (let index = 0; index < lines.length; index += 1) {
        let score = lineScore(lines[index], terms);
        if (/^#{1,6}\s+/.test(lines[index])) score *= 2;
        if (score > bestScore) {
          bestScore = score;
          bestLine = index;
        }
      }

      const fileNameScore = lineScore(file.basename, terms) * 3;
      const totalScore = bestScore + fileNameScore;
      if (totalScore <= 0 || bestLine < 0) continue;

      const start = Math.max(0, bestLine - 1);
      const end = Math.min(lines.length, bestLine + 2);
      const snippet = highlightTerms(cleanSnippet(lines.slice(start, end).join(" ")), terms);
      const contextStart = Math.max(0, bestLine - 20);
      const contextEnd = Math.min(lines.length, bestLine + 40);
      const context = lines.slice(contextStart, contextEnd).join("\n").trim();
      const nearestHeading = getNearestHeading(lines, bestLine, t(this.settings, "noHeading"));

      results.push({
        path: file.path,
        heading: nearestHeading,
        sourceLink: makeObsidianSourceLink(file.path, nearestHeading, "", nearestHeading),
        sourcePrecision: nearestHeading === t(this.settings, "noHeading") ? "note" : "heading",
        snippet,
        context,
        score: totalScore,
      });
    }

    return {
      mode: "keyword",
      results: results.sort((a, b) => b.score - a.score).slice(0, this.settings.resultLimit),
    };
  }

  expandResultsForAnswer(results) {
    if (!this.index || !Array.isArray(this.index.chunks)) return results;

    const chunksByPath = new Map();
    for (const chunk of this.index.chunks) {
      if (!chunksByPath.has(chunk.path)) chunksByPath.set(chunk.path, []);
      chunksByPath.get(chunk.path).push(chunk);
    }
    for (const chunks of chunksByPath.values()) {
      chunks.sort((a, b) => (a.chunkIndexInFile || 0) - (b.chunkIndexInFile || 0));
    }

    let totalChars = 0;
    const maxTotal = Number.parseInt(this.settings.maxTotalAnswerContextChars, 10) || 30000;
    const maxPerSource = Number.parseInt(this.settings.maxAnswerContextChars, 10) || 5000;
    const before = Number.parseInt(this.settings.neighborChunksBefore, 10) || 0;
    const after = Number.parseInt(this.settings.neighborChunksAfter, 10) || 0;

    return results.map((result) => {
      if (typeof result.id !== "number") return result;

      const matched = this.index.chunks[result.id];
      if (!matched) return result;

      const fileChunks = chunksByPath.get(matched.path) || [];
      const selected = new Map();
      selected.set(matched.id, matched);

      if (this.settings.includeSameHeadingSection) {
        for (const chunk of fileChunks) {
          if (chunk.headingKey === matched.headingKey) {
            selected.set(chunk.id, chunk);
          }
        }
      }

      if (this.settings.includeNeighborChunks) {
        const position = fileChunks.findIndex((chunk) => chunk.id === matched.id);
        if (position >= 0) {
          const start = Math.max(0, position - before);
          const end = Math.min(fileChunks.length - 1, position + after);
          for (let index = start; index <= end; index += 1) {
            selected.set(fileChunks[index].id, fileChunks[index]);
          }
        }
      }

      const expandedText = [...selected.values()]
        .sort((a, b) => (a.startLine || 0) - (b.startLine || 0))
        .map((chunk) => chunk.text)
        .join("\n\n");

      const remaining = Math.max(0, maxTotal - totalChars);
      const limit = Math.min(maxPerSource, remaining);
      let context = expandedText;
      if (limit <= 0) {
        context = "[context omitted by plugin total limit]";
      } else if (expandedText.length > limit) {
        context = `${expandedText.slice(0, limit).trim()}\n[context shortened by plugin]`;
      }
      totalChars += context.length;

      return {
        ...result,
        context,
        expandedChunkCount: selected.size,
      };
    });
  }

  getConversationTurnLimit() {
    const parsed = Number.parseInt(this.settings.conversationTurnsToKeep, 10);
    if (!Number.isFinite(parsed)) return 4;
    return Math.max(0, Math.min(parsed, 99));
  }

  buildConversationSearchQuery(query, conversationContext = []) {
    if (!this.settings.useConversationMemory || conversationContext.length === 0) return query;
    const priorQuestions = conversationContext.map((turn) => turn.question).filter(Boolean);
    return [...priorQuestions, query].join("\n");
  }

  getAgentToolCatalog() {
    return AGENT_TOOL_SPECS.map((tool) => ({ ...tool }));
  }

  getToolKeywordDefinitions() {
    return TOOL_KEYWORD_DEFS.map((def) => ({ ...def, aliases: [...(def.aliases || [])] }));
  }

  getToolKeywordDisplay(def) {
    if (!def) return "";
    return this.settings && this.settings.language === "zh" ? def.zhLabel || def.keyword : def.enLabel || def.keyword;
  }

  getToolKeywordHint(def) {
    if (!def) return "";
    return this.settings && this.settings.language === "zh" ? def.zhHint || "" : def.enHint || "";
  }

  parseToolKeyword(text) {
    return parseLeadingToolKeyword(text);
  }

  stripToolKeyword(text) {
    const parsed = this.parseToolKeyword(text);
    return parsed ? parsed.text : String(text || "").trim();
  }

  routeFromToolKeyword(command, prompt = "", state = {}) {
    if (!command || !command.action) return null;
    const instruction = String(prompt || "").trim();
    const topic = cleanSnippet(instruction || command.keyword || "", 120);
    const target = this.extractLocalRouteTarget(instruction);
    switch (command.action) {
      case "search_answer":
        return { action: "search_answer", query: instruction };
      case "topic_synthesis":
        return { action: "topic_synthesis", topic };
      case "generate_draft":
        return { action: "generate_draft", topic };
      case "create_blank_draft":
        return { action: "create_blank_draft", topic: topic || "Untitled" };
      case "insert_into_draft":
        return {
          action: "insert_into_draft",
          target,
          position: /前面|之前|上面|before/i.test(instruction) ? "before" : "after",
          useLastAnswer: /刚才|刚刚|上面|之前|上一轮|previous|last|above|earlier/i.test(instruction),
          sourceQuery: instruction,
          instruction,
        };
      case "edit_current_draft":
        return { action: "edit_current_draft", instruction };
      case "edit_selection":
        return { action: "edit_selection", instruction };
      case "image_to_markdown":
        return { action: "image_to_markdown", instruction };
      case "migration_tool":
      case "migration_review":
      case "knowledge":
      case "concept_cards":
      case "memory":
      case "chatgpt_handoff":
      case "check_index_changes":
      case "update_changed_index":
      case "build_index":
      case "pause_ai":
      case "resume_ai":
        return { action: command.action, instruction };
      default:
        return { action: "search_answer", query: instruction };
    }
  }

  extractLocalRouteTarget(text) {
    const value = String(text || "");
    const wiki = value.match(/\[\[([^\]\n]+)\]\]/);
    if (wiki) return wiki[1].trim();
    const html = value.match(/<!--\s*([^>]+?)\s*-->/);
    if (html) return html[1].trim();
    const hash = value.match(/(^|[\s，,。；;])#([A-Za-z0-9_\-/\u0080-\uffff]+)/);
    if (hash) return `#${hash[2]}`;
    const tag = value.match(/\b(tag[0-9A-Za-z_-]+)\b/i);
    if (tag) return tag[1];
    const named = value.match(/(?:标记|锚点|位置|tag)\s*[:：]?\s*([A-Za-z0-9_\-/\u0080-\uffff]{2,})/i);
    if (named) return named[1].trim();
    return "";
  }

  extractAgentHubTarget(text) {
    const value = String(text || "");
    const direct = this.extractLocalRouteTarget(value);
    if (direct) return direct;
    const around = value.match(
      /(?:\u5728|\u5230|\u653e\u5230|\u653e\u8fdb|\u5199\u8fdb|\u5199\u5230|\u63d2\u5165\u5230|\u63a5\u5728)\s*([A-Za-z0-9_\-\u4e00-\u9fff]{1,80})\s*(?:\u5904|\u4f4d\u7f6e|\u540e\u9762|\u524d\u9762|\u4e0b\u9762|\u4e0a\u9762|\u540e|\u524d)?/i
    );
    if (around && around[1]) return this.normalizeInsertionTarget(around[1]);
    return "";
  }

  getAgentHubSignals(userText, state = {}) {
    const text = String(userText || "").trim();
    const lower = text.toLowerCase();
    const target = this.extractAgentHubTarget(text);
    const referencesPrior =
      /\u521a\u624d|\u521a\u521a|\u521a\u751f\u6210|\u4e0a\u9762|\u4e4b\u524d|\u4e0a\u4e00\u8f6e|\u4e0a\u4e00\u6761|\u524d\u9762|\u90a3\u4e2a\u56de\u7b54|\u90a3\u4e2a\u8bc1\u660e|\u90a3\u6bb5|\u8fd9\u6bb5\u56de\u7b54|\u8fd9\u4e2a\u8bc1\u660e|last|previous|above|earlier/i.test(
        text
      );
    const transformPrior =
      referencesPrior &&
      /\u6539\u5199|\u91cd\u5199|\u6da6\u8272|\u6574\u7406|\u603b\u7ed3|\u6458\u8981|\u538b\u7f29|\u6269\u5199|\u8865\u5168|\u6539\u6210|\u53d8\u6210|\u8f6c\u6210|\u683c\u5f0f|\u547d\u9898-\u8bc1\u660e|\u5b9a\u7406-\u8bc1\u660e|rewrite|summarize|polish|convert/i.test(
        text
      );
    const asksInsert =
      /\u63d2\u5165|\u52a0\u5165|\u6dfb\u52a0|\u8ffd\u52a0|\u653e\u5230|\u653e\u8fdb|\u5199\u8fdb|\u5199\u5230|\u585e\u5230|\u63a5\u5728|insert|append|add|put|place/i.test(
        text
      );
    const position =
      /\u524d\u9762|\u4e0a\u9762|\u4e4b\u524d|\u524d|before|above/i.test(text) ? "before" : "after";
    const selected = Boolean(state && state.hasDraftSelection);
    const hasDraft = Boolean(state && state.hasCurrentDraft);
    return { text, lower, target, referencesPrior, transformPrior, asksInsert, position, selected, hasDraft };
  }

  buildAgentHubInsertSteps(userText, signals, route = {}) {
    const steps = [];
    if (Number.parseInt(route.memoryId, 10) > 0) {
      steps.push({
        action: "use_memory",
        memoryId: Number.parseInt(route.memoryId, 10),
        sourceQuery: route.sourceQuery || userText,
      });
    } else {
      steps.push({
        action: "use_artifact",
        artifactId: Number.parseInt(route.artifactId, 10) || 0,
        sourceQuery: route.sourceQuery || userText,
      });
    }
    if (signals.transformPrior) {
      steps.push({
        action: "generate_markdown",
        instruction: route.instruction || userText,
      });
    }
    steps.push({
      action: "insert_into_draft",
      target: route.target || signals.target || "",
      position: route.position === "before" ? "before" : signals.position,
      useWorkingText: true,
      sourceQuery: route.sourceQuery || userText,
      directText: route.directText || "",
    });
    return steps;
  }

  inferAgentHubLocalIntent(userText, state = {}) {
    const signals = this.getAgentHubSignals(userText, state);
    const { text, lower, target, referencesPrior, transformPrior, asksInsert } = signals;
    if (!text && state && state.hasImage) return { action: "image_to_markdown", confidence: 0.95, reason: "attached image" };

    if (/\u6682\u505c\s*AI|\u6682\u505c\u6a21\u578b|\u5173\u95ed\s*AI|\u4e0d\u8981\u8c03\u7528\u6a21\u578b|pause\s*ai|pause/i.test(text)) {
      return { action: "pause_ai", confidence: 0.96, instruction: text, reason: "pause ai" };
    }
    if (/\u6062\u590d\s*AI|\u7ee7\u7eed\s*AI|\u5f00\u542f\s*AI|\u542f\u7528\s*AI|resume\s*ai|resume/i.test(text)) {
      return { action: "resume_ai", confidence: 0.96, instruction: text, reason: "resume ai" };
    }

    if (/\u68c0\u67e5.*\u7d22\u5f15|\u7d22\u5f15.*\u53d8\u5316|check.*index/i.test(text)) {
      return { action: "check_index_changes", confidence: 0.94, instruction: text, reason: "check changed index files" };
    }
    if (/\u66f4\u65b0.*\u53d8\u66f4.*\u7d22\u5f15|\u66f4\u65b0.*\u6539\u52a8.*\u7d22\u5f15|update.*changed.*index/i.test(text)) {
      return { action: "update_changed_index", confidence: 0.94, instruction: text, reason: "update changed semantic index" };
    }
    if (/\u91cd\u5efa.*\u7d22\u5f15|\u5b8c\u6574.*\u91cd\u5efa.*\u7d22\u5f15|rebuild.*index|build.*index/i.test(text)) {
      return { action: "build_index", confidence: 0.9, instruction: text, reason: "manual index rebuild" };
    }

    if (/\u8bb0\u5fc6|\u5bf9\u8bdd\u8bb0\u5f55|\u5386\u53f2\u5bf9\u8bdd|conversation memory|memory/i.test(text) && /\u6253\u5f00|\u67e5\u770b|\u8fdb\u5165|\u5c55\u5f00|\u7ba1\u7406|\u5220\u9664|\u56de\u5230|\u7ee7\u7eed|open|show|view|manage/i.test(text)) {
      return { action: "memory", confidence: 0.92, instruction: text, reason: "open memory panel" };
    }
    if (/\u6982\u5ff5\u5361\u7247|\u6982\u5ff5\u5ba1\u7406|\u5361\u7247\u5ba1\u7406|concept cards?|concept review/i.test(text) && /\u6253\u5f00|\u67e5\u770b|\u8fdb\u5165|\u751f\u6210|\u5efa\u7acb|\u5ba1\u7406|open|show|view|build|generate|review/i.test(text)) {
      return { action: "concept_cards", confidence: 0.92, instruction: text, reason: "open concept card review" };
    }
    if (/\u77e5\u8bc6\u7d22\u5f15|\u6982\u5ff5\u7d22\u5f15|\u77e5\u8bc6\u56fe\u8c31|knowledge index|knowledge/i.test(text) && /\u6253\u5f00|\u67e5\u770b|\u8fdb\u5165|\u5237\u65b0|\u6784\u5efa|\u5efa\u7acb|\u91cd\u5efa|open|show|view|build|refresh/i.test(text)) {
      return { action: "knowledge", confidence: 0.92, instruction: text, reason: "open knowledge panel" };
    }
    if (/\u8fc1\u79fb|\u94fe\u63a5\u66ff\u6362|\u7b26\u53f7\u66ff\u6362|migration/i.test(text) && /\u5ba1\u9605|\u5ba1\u6838|\u8868\u683c|review/i.test(text) && /\u6253\u5f00|\u67e5\u770b|\u8fdb\u5165|open|show|view/i.test(text)) {
      return { action: "migration_review", confidence: 0.92, instruction: text, reason: "open migration review" };
    }
    if (/\u8fc1\u79fb|\u94fe\u63a5\u66ff\u6362|\u7b26\u53f7\u66ff\u6362|migration/i.test(text) && /\u5de5\u5177|\u9875\u9762|\u9762\u677f|\u6253\u5f00|\u8fdb\u5165|\u547c\u51fa|\u4f7f\u7528|open|tool|panel/i.test(text)) {
      return { action: "migration_tool", confidence: 0.92, instruction: text, reason: "open migration tool" };
    }
    if (/chatgpt|gpt|prompt\s*\u5305|prompt\s*package|handoff|\u4ea4\u63a5/i.test(text) && /\u6253\u5f00|\u751f\u6210|\u521b\u5efa|\u5bfc\u5165|\u7c98\u8d34|\u590d\u5236|\u6a21\u5f0f|\u5305|\u6587\u4ef6|open|generate|create|import|paste|copy/i.test(text)) {
      return { action: "chatgpt_handoff", confidence: 0.92, instruction: text, reason: "open ChatGPT handoff" };
    }

    if (state && state.hasImage && /\u56fe\u7247|\u622a\u56fe|\u56fe\u50cf|\u56fe\u91cc|\u7167\u7247|\u8bc6\u522b|\u8f6c\s*markdown|\u8f6c\u6210\s*md|pdf|\u8bc1\u660e|\u516c\u5f0f|image|screenshot|ocr/i.test(text)) {
      return { action: "image_to_markdown", confidence: 0.96, instruction: text, reason: "image request" };
    }

    if (/\u6b63\u5f0f\u7b14\u8bb0|\u6b63\u5f0f\u6587\u6863|\u539f\u7b14\u8bb0|formal note|formal notes/i.test(text) && /\u6539\u6389|\u4fee\u6539|\u5220\u9664|\u66ff\u6362|\u76f4\u63a5\u6539|\u8986\u5199|remove|delete|replace|modify/i.test(text)) {
      return { action: "formal_note_proposal", confidence: 0.94, instruction: text, query: text, reason: "formal note safety proposal" };
    }

    if (/\u7a7a\u767d|\u65b0\u5efa|\u521b\u5efa|\u5efa\u7acb|\u6253\u5f00|\u5f00\u4e00\u9875|blank/.test(text) && /\u8349\u7a3f|\u6587\u6863|\u7b14\u8bb0|draft|note|\u9875\u9762/.test(lower)) {
      return { action: "create_blank_draft", confidence: 0.94, topic: cleanSnippet(text, 80), reason: "blank draft" };
    }
    if (signals.selected && /\u9009\u4e2d|\u6240\u9009|\u8fd9\u6bb5|\u8fd9\u4e00\u6bb5|selected|selection/i.test(text) && /\u6539\u5199|\u4fee\u6539|\u6da6\u8272|\u4f18\u5316|\u66ff\u6362|\u6269\u5199|\u6574\u7406|\u8bc1\u660e|rewrite|edit|replace|polish/i.test(text)) {
      return { action: "edit_selection", confidence: 0.92, instruction: text, reason: "edit selected draft text" };
    }
    if (signals.hasDraft && /\u5f53\u524d\u8349\u7a3f|\u5f53\u524d\u6587\u6863|\u8fd9\u7bc7\u8349\u7a3f|\u6574\u4e2a\u8349\u7a3f|\u8fd9\u7bc7|\u5168\u6587|\u6574\u7bc7|current draft|whole draft|draft/i.test(text) && /\u6539\u5199|\u4fee\u6539|\u91cd\u5199|\u6574\u7406|\u4f18\u5316|\u6269\u5199|\u8865\u5168|\u6da6\u8272|rewrite|edit|improve|polish/i.test(text)) {
      return { action: "edit_current_draft", confidence: 0.9, instruction: text, reason: "edit current draft" };
    }
    if (/\u6574\u7406|\u68b3\u7406|\u603b\u7ed3|\u7efc\u8ff0|\u6c47\u603b|\u751f\u6210|\u5199\u4e00\u7bc7|\u505a\u4e00\u4e2a|\u505a\u6210|\u5f62\u6210|synthesize|organize|summarize/i.test(text) && /\u6587\u4ef6|\u6587\u6863|\u7b14\u8bb0|\u8349\u7a3f|ai generated|draft|note|\u9875\u9762|\u8d44\u6599/i.test(lower)) {
      return { action: "generate_draft", confidence: 0.88, topic: cleanSnippet(text, 120), reason: "topic synthesis/draft" };
    }

    if (asksInsert && (target || /\u8349\u7a3f|draft|\u540e\u9762|\u524d\u9762|\u4e4b\u524d|\u4e4b\u540e|\u4e0b\u9762|\u4e0a\u9762|\u672b\u5c3e|\u5f00\u5934/i.test(text))) {
      if (referencesPrior) {
        return {
          action: "agent_task",
          confidence: 0.93,
          steps: this.buildAgentHubInsertSteps(text, signals, {}),
          reason: transformPrior ? "transform and insert previous assistant content" : "insert previous assistant content",
        };
      }
      return {
        action: "insert_into_draft",
        confidence: 0.88,
        target,
        position: signals.position,
        directText: "",
        reason: "insert into draft",
      };
    }

    if (/\u67e5\u627e|\u641c\u7d22|\u627e\u5230|\u68c0\u7d22|\u89e3\u91ca|\u8bf4\u660e|\u8bb2\u8bb2|\u8bf4\u8bf4|\u56de\u5fc6|\u5fd8\u4e86|\u770b\u770b|\u662f\u4ec0\u4e48|\u4ec0\u4e48\u662f|\u4e3a\u4ec0\u4e48|\u5982\u4f55|\u600e\u4e48|\u8bc1\u660e|\u5e94\u7528|\u5173\u7cfb|\u533a\u522b|\u8054\u7cfb|\u6765\u6e90|\u5f15\u7528|search|find|explain|what|why|how/i.test(lower)) {
      return { action: "search_answer", confidence: 0.88, query: text, reason: "question/search" };
    }
    return null;
  }

  normalizeAgentHubRoute(route, userText, state = {}, localRoute = null) {
    const signals = this.getAgentHubSignals(userText, state);
    const allowed = new Set(AGENT_TOOL_SPECS.map((tool) => tool.action));
    let normalized = route && typeof route === "object" ? { ...route } : {};
    const routeConfidence = Number.parseFloat(normalized.confidence || 0);
    if (localRoute && (!normalized.action || (normalized.action === "search_answer" && localRoute.action !== "search_answer") || routeConfidence < 0.55)) {
      normalized = { ...localRoute };
    }
    if (!allowed.has(normalized.action)) normalized.action = "search_answer";
    const finalConfidence = Number.parseFloat(normalized.confidence || 0);
    normalized.confidence = Number.isFinite(finalConfidence) && finalConfidence > 0 ? finalConfidence : 0.6;
    normalized.position = normalized.position === "before" ? "before" : signals.position;
    normalized.target = normalized.target || (localRoute && localRoute.target) || signals.target || "";
    normalized.topic = normalized.topic || (localRoute && localRoute.topic) || this.extractTopicSynthesisTopic(userText) || cleanSnippet(userText, 120);
    normalized.query = normalized.query || userText;
    normalized.instruction = normalized.instruction || userText;
    normalized.sourceQuery = normalized.sourceQuery || (signals.referencesPrior ? userText : "");
    if (signals.referencesPrior) normalized.useLastAnswer = normalized.useLastAnswer !== false;

    if (normalized.action === "insert_into_draft" && signals.referencesPrior) {
      normalized.action = "agent_task";
      normalized.steps = this.buildAgentHubInsertSteps(userText, signals, normalized);
      normalized.reason = normalized.reason || "insert referenced prior content";
    }
    if (normalized.action === "agent_task" && (!Array.isArray(normalized.steps) || normalized.steps.length === 0) && signals.asksInsert) {
      normalized.steps = this.buildAgentHubInsertSteps(userText, signals, normalized);
    }
    if (/\u6b63\u5f0f\u7b14\u8bb0|\u6b63\u5f0f\u6587\u6863|\u539f\u7b14\u8bb0|formal note|formal notes/i.test(userText) && /\u6539\u6389|\u4fee\u6539|\u5220\u9664|\u66ff\u6362|\u76f4\u63a5\u6539|\u8986\u5199|remove|delete|replace|modify/i.test(userText) && !/migration|\u8fc1\u79fb/i.test(userText)) {
      normalized = { action: "formal_note_proposal", confidence: 0.95, instruction: userText, query: userText, reason: "formal note safety proposal" };
    }
    if (normalized.action === "topic_synthesis") normalized.action = "generate_draft";
    return normalized;
  }

  inferLocalIntent(userText, state = {}) {
    const hubRoute = this.inferAgentHubLocalIntent(userText, state);
    if (hubRoute) return hubRoute;
    const text = String(userText || "").trim();
    if (!text && state && state.hasImage) return { action: "image_to_markdown", confidence: 0.95, reason: "attached image" };
    const lower = text.toLowerCase();
    const hasDraft = Boolean(state && state.hasCurrentDraft);
    const hasSelection = Boolean(state && state.hasDraftSelection);
    const target = this.extractLocalRouteTarget(text);
    const referencesPrior = /刚才|刚刚|刚生成|上面|之前|上一条|上一轮|前面|这个回答|这个证明|这段回答|那段|前述|last|previous|above|earlier/i.test(text);
    const transformPrior =
      referencesPrior &&
      /改写|重写|润色|整理|总结|摘要|压缩|扩写|补全|改成|变成|转成|格式|rewrite|summarize|polish|convert/i.test(text);

    if (/暂停\s*AI|暂停模型|关闭\s*AI|先不要调用模型|不要调用模型|pause\s*ai|pause/i.test(text)) {
      return { action: "pause_ai", confidence: 0.94, instruction: text, reason: "pause ai" };
    }

    if (/恢复\s*AI|继续\s*AI|开启\s*AI|启用\s*AI|resume\s*ai|resume/i.test(text)) {
      return { action: "resume_ai", confidence: 0.94, instruction: text, reason: "resume ai" };
    }

    if (/记忆|对话记录|历史对话|conversation memory|memory/i.test(text) && /打开|查看|进入|展开|管理|删除|回到|继续|open|show|view|manage/i.test(text)) {
      return { action: "memory", confidence: 0.9, instruction: text, reason: "open memory panel" };
    }

    if (/知识索引|概念索引|知识图谱|knowledge index|knowledge/i.test(text) && /打开|查看|进入|刷新|构建|建立|重建|open|show|view|build|refresh/i.test(text)) {
      return { action: "knowledge", confidence: 0.9, instruction: text, reason: "open knowledge panel" };
    }

    if (/迁移|链接替换|符号替换|migration/i.test(text) && /审阅|审核|表格|review/i.test(text) && /打开|查看|进入|open|show|view/i.test(text)) {
      return { action: "migration_review", confidence: 0.9, instruction: text, reason: "open migration review" };
    }

    if (/迁移|链接替换|符号替换|migration/i.test(text) && /工具|页面|面板|打开|进入|呼出|使用|open|tool|panel/i.test(text)) {
      return { action: "migration_tool", confidence: 0.9, instruction: text, reason: "open migration tool" };
    }

    if (/chatgpt|gpt|prompt\s*包|prompt\s*package|handoff|交接/i.test(text) && /打开|生成|创建|导入|粘贴|复制|模式|包|文件|open|generate|create|import|paste|copy/i.test(text)) {
      return { action: "chatgpt_handoff", confidence: 0.9, instruction: text, reason: "open ChatGPT handoff" };
    }

    if (state && state.hasImage && /图片|截图|图像|图里|照片|识别|转\s*markdown|转成\s*md|pdf|证明|公式|image|screenshot|ocr/i.test(text)) {
      return { action: "image_to_markdown", confidence: 0.95, instruction: text, reason: "image request" };
    }

    if (/空白|新建|创建|建立|打开|开一页|开个|blank/.test(text) && /草稿|文档|笔记|draft|note|页面/.test(lower)) {
      return { action: "create_blank_draft", confidence: 0.92, topic: cleanSnippet(text, 80), reason: "blank draft" };
    }

    if (hasSelection && /选中|選中|这段|這段|当前段落|所选|selected|selection/.test(text) && /改写|修改|润色|优化|替换|扩写|整理|证明|补齐|rewrite|edit|replace/.test(lower)) {
      return { action: "edit_selection", confidence: 0.9, instruction: text, reason: "edit selected draft text" };
    }

    if (hasDraft && /当前草稿|当前文档|这篇草稿|整个草稿|这篇|本文|整篇|current draft|whole draft|draft/.test(lower) && /改写|修改|重写|整理|优化|扩写|补全|润色|rewrite|edit|improve|polish/.test(lower)) {
      return { action: "edit_current_draft", confidence: 0.88, instruction: text, reason: "edit current draft" };
    }

    if (/正式笔记|正式文档|原笔记|formal note|formal notes/i.test(text) && /改掉|修改|删除|替换|直接改|覆写|remove|delete|replace|modify/i.test(text)) {
      return { action: "search_answer", confidence: 0.92, query: text, reason: "formal note safety boundary" };
    }

    if (/整理|梳理|总结|總結|综述|綜述|汇总|生成|写一篇|做一个|做成|整理成|形成/.test(text) && /文件|文档|笔记|草稿|ai generated|draft|note|页面|资料/.test(lower)) {
      return { action: "generate_draft", confidence: 0.86, topic: cleanSnippet(text, 120), reason: "topic synthesis/draft" };
    }

    if (/插入|加入|添加|放到|放进|写到|写进|追加|塞到|置于|append|insert|add/.test(text) && (target || /草稿|draft|后面|前面|之前|之后|下面|上面|末尾|开头/.test(lower))) {
      if (referencesPrior) {
        const steps = [{ action: "use_artifact", sourceQuery: text }];
        if (transformPrior) {
          steps.push({
            action: "generate_markdown",
            instruction: text,
          });
        }
        steps.push({
          action: "insert_into_draft",
          target,
          position: /前面|之前|上面|before/i.test(text) ? "before" : "after",
          useWorkingText: true,
          sourceQuery: text,
        });
        return {
          action: "agent_task",
          confidence: 0.9,
          steps,
          reason: "insert previous assistant content",
        };
      }
      return {
        action: "insert_into_draft",
        confidence: 0.86,
        target,
        position: /前面|之前|上面|before/i.test(text) ? "before" : "after",
        useLastAnswer: referencesPrior,
        reason: "insert into draft",
      };
    }

    if (/查找|搜索|找到|检索|解释|说明|讲讲|说说|回忆|忘了|看看|是什么|什么是|为什么|如何|怎么|证明|应用|关系|区别|联系|不要编|迁移|风险|检查|来源|引用|错|不对|search|find|explain|what|why|how/.test(lower)) {
      return { action: "search_answer", confidence: 0.86, query: text, reason: "question/search" };
    }

    return null;
  }

  async routeUserIntent(userText, state) {
    const keywordCommand = this.parseToolKeyword(userText);
    if (keywordCommand) {
      const keywordRoute = this.routeFromToolKeyword(keywordCommand, keywordCommand.text, state);
      if (keywordRoute) return this.normalizeAgentHubRoute(keywordRoute, keywordCommand.text || userText, state, keywordRoute);
    }
    const hubLocalRoute = this.inferAgentHubLocalIntent(userText, state);
    const legacyLocalRoute = hubLocalRoute || this.inferLocalIntent(userText, state);
    const localRoute = hubLocalRoute || legacyLocalRoute;
    if (localRoute && localRoute.confidence >= 0.9) {
      return this.normalizeAgentHubRoute(localRoute, userText, state, localRoute);
    }
    const route = await this.chatProvider.routeUserIntent(userText, state);
    if ((!route || route.action === "search_answer") && localRoute && localRoute.confidence >= 0.6) {
      return this.normalizeAgentHubRoute(localRoute, userText, state, localRoute);
    }
    return this.normalizeAgentHubRoute(route, userText, state, localRoute);
  }

  getMaxAgentSteps() {
    const parsed = Number.parseInt(this.settings.maxAgentSteps, 10);
    if (!Number.isFinite(parsed)) return 6;
    return Math.max(1, Math.min(parsed, 20));
  }

  async planAgentTask(userText, state) {
    const maxSteps = this.getMaxAgentSteps();
    const plan = await this.chatProvider.planAgentTask(userText, state, maxSteps);
    return this.normalizeAgentSteps(plan && plan.steps, maxSteps);
  }

  normalizeAgentSteps(rawSteps, maxSteps = this.getMaxAgentSteps()) {
    const allowed = new Set([
      "use_artifact",
      "use_memory",
      "generate_markdown",
      "insert_into_draft",
      "edit_current_draft",
      "edit_selection",
      "create_blank_draft",
      "image_to_markdown",
      "search_answer",
      "formal_note_proposal",
    ]);
    return (Array.isArray(rawSteps) ? rawSteps : [])
      .filter((step) => step && allowed.has(step.action))
      .slice(0, maxSteps)
      .map((step) => ({
        ...step,
        position: step.position === "before" ? "before" : "after",
      }));
  }

  async generateAgentMarkdown(instruction, sourceText, draftContext) {
    const markdown = await this.chatProvider.generateAgentMarkdown(instruction, sourceText, draftContext);
    return normalizeMathDelimiters(unwrapMarkdownFence(markdown)).trim();
  }

  async reviewAgentResult(goal, executionSummary, draftContext) {
    const review = await this.chatProvider.reviewAgentResult(goal, executionSummary, draftContext);
    return normalizeMathDelimiters(unwrapMarkdownFence(review)).trim();
  }

  async answerWithSources(query, results, conversationContext = []) {
    const answer = await this.chatProvider.answer(
      query,
      this.expandResultsForAnswer(results),
      conversationContext,
      limitTextBlock(this.buildKnowledgeContext(query), 10000)
    );
    return normalizeMathDelimiters(answer);
  }

  async generateFormalNoteProposal(instruction) {
    const query = String(instruction || "").trim();
    const searchResponse = await this.search(query);
    const results = this.expandResultsForAnswer(searchResponse.results || []).slice(0, Math.max(6, this.settings.answerContextLimit || 6));
    const sourceLines = results.map((result, index) => {
      const sourceLink =
        result.sourceLink ||
        makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
      const excerpt = cleanSnippet(result.context || result.snippet || "", 220);
      return `${index + 1}. ${sourceLink}\n   - ${excerpt}`;
    });
    const text = (key) => t(this.settings, key);
    const markdown = [
      `# ${text("formalProposal")}`,
      "",
      `> ${text("formalProposalNoWrite")}`,
      "",
      `## ${text("agentPlanGoal")}`,
      "",
      query || "(empty)",
      "",
      `## ${text("formalProposalCandidates")}`,
      "",
      sourceLines.length ? sourceLines.join("\n") : "- No candidate notes were found.",
      "",
      `## ${text("agentPlanSafety")}`,
      "",
      "- Do not edit formal notes directly from chat.",
      "- Use the migration page or review table when links, anchors, symbols, or repeated notation need to change.",
      "- For semantic rewrites, first create an AI draft proposal, compare it with the original note, then migrate only checked lines.",
      "",
      "## Suggested next step",
      "",
      "- If this is a link or symbol migration, open the migration tool and review the generated diff row by row.",
      "- If this is a conceptual rewrite, ask for an AI draft of the replacement section first.",
    ].join("\n");
    return { markdown, results };
  }

  async imageToMarkdown(instruction, image) {
    const markdown = await this.chatProvider.imageToMarkdown(instruction, image);
    return normalizeMathDelimiters(markdown);
  }

  async rewriteAnswerForDraft(answer, results) {
    const rewritten = await this.chatProvider.rewriteForDraft(answer, results);
    return normalizeMathDelimiters(rewritten);
  }

  async editDraftSelection(selection, instruction, draftContext) {
    const replacement = await this.chatProvider.editDraftSelection(selection, instruction, draftContext);
    return normalizeMathDelimiters(replacement).trim();
  }

  async editDraftDocument(currentMarkdown, instruction) {
    const edited = await this.chatProvider.editDraftDocument(currentMarkdown, instruction);
    return normalizeMathDelimiters(unwrapMarkdownFence(edited)).trim();
  }

  async draftInsertion(instruction, target, draftContext) {
    const insertion = await this.chatProvider.draftInsertion(instruction, target, draftContext);
    return normalizeMathDelimiters(unwrapMarkdownFence(insertion)).trim();
  }

  async generateDraft(topic, conversationContext = []) {
    let results = [];
    if (this.settings.draftSourceMode !== "model_only") {
      const searchQuery = this.buildConversationSearchQuery(topic, conversationContext);
      const searchResponse = await this.search(searchQuery);
      results = this.expandResultsForAnswer(searchResponse.results || []);
    }
    const draft = await this.chatProvider.draft(topic, results, conversationContext);
    return normalizeMathDelimiters(draft);
  }

  buildTopicSynthesisCoverageReport(topic, results = [], topicProfiles = [], calloutEvidence = "") {
    const cleanTopic = String(topic || "").trim() || "Untitled topic";
    const resultPaths = new Set((results || []).map((result) => result.path).filter(Boolean));
    const profilePaths = new Set((topicProfiles || []).map((profile) => profile.path).filter(Boolean));
    const allPaths = [...new Set([...resultPaths, ...profilePaths])].slice(0, 30);
    const calloutCount = (String(calloutEvidence || "").match(/^Source:/gm) || []).length;
    const pathLines = allPaths.map((path) => `- [[${String(path).replace(/\.md$/i, "")}]]`).join("\n");
    return [
      `## ${t(this.settings, "topicCoverageReport")}`,
      "",
      `- Topic: ${cleanTopic}`,
      `- Retrieved excerpts: ${(results || []).length}`,
      `- Knowledge coverage candidates: ${(topicProfiles || []).length}`,
      `- Callout evidence blocks considered: ${calloutCount}`,
      "- Source rule: generated claims should be checked against the source index below; model-supplied connections must remain marked as model additions.",
      "",
      pathLines || "- No source paths were selected.",
    ].join("\n");
  }

  async generateTopicSynthesisFile(topic, conversationContext = []) {
    if (this.settings.writeMode !== "draft") {
      throw new Error(t(this.settings, "writeDisabled"));
    }
    const cleanTopic = String(topic || "").trim() || "Untitled topic";
    const searchQuery = this.buildConversationSearchQuery(cleanTopic, conversationContext);
    const searchResponse = await this.search(searchQuery);
    const results = this.expandResultsForAnswer(searchResponse.results || []);
    const limitedResults = results.slice(0, Math.max(12, this.settings.answerContextLimit || 8));
    const topicProfiles = this.getTopicCoverageProfiles(cleanTopic, 14);
    const sourceEntries = [];
    const sourcePaths = new Set();
    const addSource = (path, heading = "", description = "", exactLink = "") => {
      const cleanPath = String(path || "").replace(/\.md$/i, "");
      const sourceLink = exactLink || makeObsidianSourceLink(cleanPath, heading || cleanPath, "", heading && heading !== "(no heading)" ? heading : "");
      if (!cleanPath || sourcePaths.has(sourceLink)) return;
      sourcePaths.add(sourceLink);
      const suffix = description ? ` - ${description}` : "";
      sourceEntries.push(`[${sourceEntries.length + 1}] ${sourceLink}${suffix}`);
    };
    for (const result of limitedResults) {
      addSource(
        result.path,
        result.heading && result.heading !== "(no heading)" ? result.heading : "",
        "retrieved excerpt",
        result.sourceLink || ""
      );
    }
    for (const profile of topicProfiles) {
      addSource(profile.path, "", `topic coverage: ${(profile.topicCoverageReasons || []).join(", ") || "related note"}`);
    }
    const sourceLinks = sourceEntries.join("\n");
    const knowledgeContext = limitTextBlock(
      [this.buildKnowledgeContext(cleanTopic), this.buildTopicCoverageContext(cleanTopic, topicProfiles)].filter(Boolean).join("\n\n"),
      14000
    );
    const calloutEvidence = this.buildTopicCalloutEvidence(cleanTopic, topicProfiles, 60);
    const generated = await this.chatProvider.topicSynthesis(
      cleanTopic,
      limitedResults,
      conversationContext,
      knowledgeContext,
      limitTextBlock(calloutEvidence, 9000)
    );
    const markdown = normalizeMathDelimiters(unwrapMarkdownFence(generated)).trim();
    const coverageReport = this.buildTopicSynthesisCoverageReport(cleanTopic, limitedResults, topicProfiles, calloutEvidence);
    const header = `> AI generated from local notes on ${new Date().toLocaleString()}.
> Notes-first synthesis with clearly marked model-supplied additions.

`;
    const sources = sourceLinks ? `\n\n---\n\n## 检索来源索引\n${sourceLinks}\n` : "";
    const fullMarkdown = limitTextBlock(`${header}${markdown}\n\n---\n\n${coverageReport}${sources}`, 50000);
    const file = await this.createDraftNote(`AI generated ${cleanTopic}`, fullMarkdown);
    return { file, markdown: fullMarkdown, results: limitedResults };
  }

  getChatGptHandoffModes() {
    return [
      { id: "notes_only", labelKey: "handoffNotesOnly" },
      { id: "note_completion", labelKey: "handoffNoteCompletion" },
      { id: "proof_completion", labelKey: "handoffProofCompletion" },
      { id: "topic_synthesis", labelKey: "handoffTopicSynthesis" },
      { id: "multi_file", labelKey: "handoffMultiFile" },
      { id: "check", labelKey: "handoffCheck" },
    ];
  }

  getChatGptHandoffModeInstruction(mode) {
    const instructions = {
      notes_only:
        "Mode: notes-only organization. Use only the provided note evidence. If evidence is insufficient, write TODO / insufficient evidence instead of filling gaps.",
      note_completion:
        "Mode: note completion. Use the provided note evidence first. You may add model-supplied background, examples, or missing steps, but every such addition must be explicitly labeled as 模型补充.",
      proof_completion:
        "Mode: proof completion. Reconstruct missing proof steps carefully. Separate 原笔记内容 from 模型补充推理, preserve LaTeX, and mark uncertain steps as TODO.",
      topic_synthesis:
        "Mode: topic synthesis. Produce a coherent Obsidian Markdown note based on the evidence, with model-supplied synthesis clearly labeled when not directly supported.",
      multi_file:
        "Mode: multi-file generation. Output one or more Markdown files using repeated blocks of the form FILE: relative/path.md followed by that file's Markdown content. Use short, safe file names.",
      check:
        "Mode: check / critique. Do not rewrite the whole note unless necessary. Identify hallucination risk, missing sources, bad links, weak proof steps, and formatting problems.",
    };
    return instructions[mode] || instructions.note_completion;
  }

  buildChatGptOutputContract(mode, topic) {
    if (mode === "multi_file") {
      return `Return multiple Markdown files exactly in this format:

FILE: ${this.sanitizeFileName(topic || "Topic")}/Overview.md
# ...

FILE: ${this.sanitizeFileName(topic || "Topic")}/Examples.md
# ...

Rules:
- Do not wrap the whole answer in a code block.
- Each FILE path must be relative and end with .md.
- Do not use absolute paths.
- Keep each file concise.`;
    }
    if (mode === "check") {
      return `Return a concise Markdown report with:
1. Supported claims
2. Unsupported or risky claims
3. Missing source links
4. Suggested revisions
5. Obsidian / LaTeX formatting issues`;
    }
    return `Return one concise Obsidian Markdown file.
Start with a single H1 title.
Use source numbers like [1] for note-supported claims.
Label model additions as 模型补充.
Preserve Obsidian-renderable LaTeX.`;
  }

  getChatGptHandoffModeInstruction(mode) {
    const modelLabel = "\u6a21\u578b\u8865\u5145";
    const instructions = {
      notes_only:
        "Mode: notes-only organization. Use only the provided note evidence. If evidence is insufficient, write TODO / insufficient evidence instead of filling gaps.",
      note_completion:
        `Mode: note completion. Use the provided note evidence first. You may add model-supplied background, examples, or missing steps only when they help the note, and every such addition must be explicitly labeled as ${modelLabel}.`,
      proof_completion:
        `Mode: proof completion. Reconstruct missing proof steps carefully. Separate \u539f\u7b14\u8bb0\u5185\u5bb9 from ${modelLabel}\u63a8\u7406, preserve LaTeX, and mark uncertain steps as TODO.`,
      topic_synthesis:
        `Mode: topic synthesis. Produce a coherent Obsidian Markdown note based on the evidence. Use the model to connect ideas, but label claims not directly supported by evidence as ${modelLabel}.`,
      multi_file:
        "Mode: multi-file generation. Output one or more Markdown files using repeated blocks of the form FILE: relative/path.md followed by that file's Markdown content. Use short, safe file names.",
      check:
        "Mode: check / critique. Do not rewrite the whole note unless necessary. Identify hallucination risk, missing sources, bad links, weak proof steps, and formatting problems.",
    };
    return instructions[mode] || instructions.note_completion;
  }

  buildChatGptOutputContract(mode, topic) {
    const modelLabel = "\u6a21\u578b\u8865\u5145";
    if (mode === "multi_file") {
      return `Return multiple Markdown files exactly in this format:

FILE: ${this.sanitizeFileName(topic || "Topic")}/Overview.md
# ...

FILE: ${this.sanitizeFileName(topic || "Topic")}/Examples.md
# ...

Rules:
- Do not wrap the whole answer in a code block.
- Each FILE path must be relative and end with .md.
- Do not use absolute paths.
- Keep each file concise.
- Every file must be valid Obsidian Markdown.
- Do not invent source links.`;
    }
    if (mode === "check") {
      return `Return a concise Markdown report with:
1. Supported claims
2. Unsupported or risky claims
3. Missing source links
4. Suggested revisions
5. Obsidian / LaTeX formatting issues`;
    }
    return `Return one complete Obsidian Markdown file.
Do not wrap the answer in a code block.
Start with a single H1 title.
Use source numbers like [1] for note-supported claims.
Label model additions as ${modelLabel}.
Preserve Obsidian-renderable LaTeX: use $x$ rather than $ x $, and use $$...$$ for display math.
When the prompt asks for a note, output the note itself, not commentary about the task.`;
  }

  buildChatGptHandoffPrompt({ topic, mode, results, knowledgeContext, calloutEvidence, quality }) {
    const cleanTopic = String(topic || "").trim() || "Untitled";
    const modelLabel = "\u6a21\u578b\u8865\u5145";
    const sourceBlocks = (results || [])
      .map((result, index) => {
        const sourceLink =
          result.sourceLink ||
          makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
        const context = limitTextBlock(result.context || result.snippet || "", 1600);
        return `[${index + 1}] ${sourceLink}
Path: ${result.path}
Heading: ${result.heading || "(none)"}
Source precision: ${result.sourcePrecision || "excerpt"}
Excerpt:
${context}`;
      })
      .join("\n\n");
    const qualityLines = (quality && quality.messages ? quality.messages : [])
      .map((message) => `- ${message}`)
      .join("\n");
    return `# ChatGPT Handoff Prompt

## Task
${cleanTopic}

## Prompt Mode
${this.getChatGptHandoffModeInstruction(mode)}

## Output Contract
${this.buildChatGptOutputContract(mode, cleanTopic)}

## Source Boundary Rules
- The numbered excerpts below are the only note evidence.
- Copy Obsidian links exactly when citing sources.
- Never invent headings, block anchors, note names, or source links.
- Knowledge-index hints are only navigation hints; verify claims against numbered excerpts or callout evidence.
- If you use general mathematical knowledge, mark it as 模型补充.
- Keep the answer compact. Prefer structure over long quotation.

## Required Working Method
Do this silently before writing the final Markdown:
1. Identify the exact user goal and the likely note type: definition, theorem, proof, example, topic map, or critique.
2. Extract all directly supported claims from numbered evidence.
3. Add model knowledge only where it improves continuity, and label it as ${modelLabel}.
4. Check every Obsidian link in the final answer against the links shown in this prompt.
5. Check LaTeX spacing for Obsidian rendering.

## Final Quality Checklist
- The final output is importable Markdown, not an explanation of how to write Markdown.
- Every source-backed claim has a nearby source number like [1].
- No invented note path, heading, or block anchor appears.
- The exact label for any model-supplied material is ${modelLabel}. Do not use any other label for this purpose.
- Do not claim that the original note is truncated unless the provided evidence truly lacks the needed statement.
- Mathematical notation uses Obsidian-renderable LaTeX.
- The answer is written in the same primary language as the task unless the task asks otherwise.

## Local Prompt Check
${qualityLines || "- No major local prompt issues detected."}

## Retrieved Note Evidence
${sourceBlocks || "(No retrieved note evidence. Ask for more evidence or return TODO / insufficient evidence.)"}

## Callout Evidence
${limitTextBlock(calloutEvidence || "(none)", 6000)}

## Knowledge Navigation Hints
${limitTextBlock(knowledgeContext || "(none)", 2500)}

## Final Instruction
Now produce the requested output according to the Prompt Mode and Output Contract.`;
  }

  checkChatGptHandoffPrompt(prompt, results, mode) {
    const messages = [];
    const length = String(prompt || "").length;
    const sourceCount = Array.isArray(results) ? results.length : 0;
    const linkCount = (String(prompt || "").match(/\[\[[^\]\n]+\]\]/g) || []).length;
    if (sourceCount < 3) messages.push("Evidence coverage is thin: fewer than 3 retrieved sources.");
    if (linkCount < sourceCount) messages.push("Some sources may not have exact Obsidian wiki links.");
    if (length > 16000) messages.push("Prompt is long; consider narrowing the topic if ChatGPT becomes unfocused.");
    if (mode === "multi_file") messages.push("Multi-file import expects FILE: relative/path.md blocks.");
    if (mode === "note_completion" || mode === "proof_completion") {
      messages.push("Model additions must be labeled 模型补充.");
    }
    if (mode === "note_completion" || mode === "proof_completion" || mode === "topic_synthesis") {
      messages.push("Use the exact label \u6a21\u578b\u8865\u5145 for model additions.");
    }
    if (!messages.length) messages.push("Evidence coverage and output contract look reasonable.");
    return {
      sourceCount,
      linkCount,
      charCount: length,
      messages,
    };
  }

  checkChatGptHandoffPrompt(prompt, results, mode) {
    const messages = [];
    const length = String(prompt || "").length;
    const sourceCount = Array.isArray(results) ? results.length : 0;
    const linkCount = (String(prompt || "").match(/\[\[[^\]\n]+\]\]/g) || []).length;
    if (sourceCount < 5) messages.push("Evidence coverage is thin: fewer than 5 retrieved sources.");
    if (linkCount < sourceCount) messages.push("Some sources may not have exact Obsidian wiki links.");
    if (length > 22000) messages.push("Prompt is long; keep the final output focused and structured.");
    if (mode === "multi_file") messages.push("Multi-file import expects FILE: relative/path.md blocks.");
    if (mode === "note_completion" || mode === "proof_completion" || mode === "topic_synthesis") {
      messages.push("Use the exact label \u6a21\u578b\u8865\u5145 for model additions.");
    }
    if (!messages.length) messages.push("Evidence coverage and output contract look reasonable.");
    return {
      sourceCount,
      linkCount,
      charCount: length,
      messages,
    };
  }

  buildChatGptOutputContract(mode, topic) {
    const safeTopic = this.sanitizeFileName(topic || "Topic");
    const modelLabel = "\u6a21\u578b\u8865\u5145";
    if (mode === "multi_file") {
      return `Return multiple importable Markdown files. Use exactly this wrapper for every file:

FILE: ${safeTopic}/Overview.md
# ...

FILE: ${safeTopic}/Examples.md
# ...

Rules:
- Do not wrap the answer in a code fence.
- Each FILE path must be relative and end with .md.
- Every file must be valid Obsidian Markdown.
- Do not invent source links, headings, or block anchors.
- Keep each file focused; split only when it improves note organization.`;
    }
    if (mode === "check") {
      return `Return one importable Markdown report:

FILE: ${safeTopic || "Check"}-review.md
# Review

Include:
1. Supported claims
2. Unsupported or risky claims
3. Missing source links
4. Suggested revisions
5. Obsidian / LaTeX formatting issues`;
    }
    return `Return exactly one importable Obsidian Markdown file:

FILE: ${safeTopic || "Imported"}.md
# ...

Rules:
- Do not wrap the answer in a code fence.
- Start the file content with a single H1 title.
- Use source numbers like [1] for note-supported claims.
- Label model additions as ${modelLabel}.
- Preserve Obsidian-renderable LaTeX: use $x$ rather than $ x $, and use $$...$$ for display math.
- Output the note itself, not commentary about the task.`;
  }

  buildChatGptHandoffPrompt({ topic, mode, results, knowledgeContext, calloutEvidence, quality }) {
    const cleanTopic = String(topic || "").trim() || "Untitled";
    const modelLabel = "\u6a21\u578b\u8865\u5145";
    const sourceIndex = (results || [])
      .map((result, index) => {
        const sourceLink =
          result.sourceLink ||
          makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
        return `[${index + 1}] ${sourceLink} | ${result.path} | ${result.heading || "(none)"}`;
      })
      .join("\n");
    const sourceBlocks = (results || [])
      .map((result, index) => {
        const sourceLink =
          result.sourceLink ||
          makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
        const context = limitTextBlock(result.context || result.snippet || "", 1800);
        return `### Source [${index + 1}]
Link: ${sourceLink}
Path: ${result.path}
Heading: ${result.heading || "(none)"}
Precision: ${result.sourcePrecision || "excerpt"}

${context}`;
      })
      .join("\n\n");
    const qualityLines = (quality && quality.messages ? quality.messages : [])
      .map((message) => `- ${message}`)
      .join("\n");
    return `# Local Note Assistant GPT Protocol v2

You are acting as an external reasoning and writing model for an Obsidian note assistant. The user will import your answer back into the local plugin.

## User Task
${cleanTopic}

## Mode
${this.getChatGptHandoffModeInstruction(mode)}

## Output Contract
${this.buildChatGptOutputContract(mode, cleanTopic)}

## Non-Negotiable Rules
- Return only the final importable Markdown output specified by the Output Contract.
- Do not add prefaces such as "I cannot access your notes"; the note evidence is included below.
- Never invent Obsidian note paths, headings, block anchors, or source links.
- Copy source links exactly from the Source Map when citing notes.
- Knowledge hints are only navigation hints; evidence claims must come from numbered sources or callout evidence.
- If you use general mathematical knowledge, mark it as ${modelLabel}.
- If evidence is insufficient, write a precise TODO at the relevant location instead of hallucinating.
- Do not claim a note is truncated unless the provided evidence genuinely lacks the needed statement.
- Use the same primary language as the task. For Chinese mathematical notes, keep standard English terms when they are clearer or lack a fixed translation.

## Silent Working Method
Before writing the final Markdown, silently do this:
1. Identify whether the task asks for a definition, theorem, proof, example, topic synthesis, or critique.
2. Build a claim list from numbered evidence.
3. Decide which gaps can be filled by model knowledge and label those additions as ${modelLabel}.
4. Check every source citation against the Source Map.
5. Check Obsidian LaTeX spacing and Markdown importability.

## Local Prompt Check
${qualityLines || "- No major local prompt issues detected."}

## Source Map
${sourceIndex || "(No source map.)"}

## Retrieved Evidence
${sourceBlocks || "(No retrieved note evidence. Return TODO / insufficient evidence where needed.)"}

## Callout Evidence
${limitTextBlock(calloutEvidence || "(none)", 7000)}

## Knowledge Navigation Hints
${limitTextBlock(knowledgeContext || "(none)", 3000)}

## Final Instruction
Now produce the final output. Remember: no commentary outside the required FILE block(s).`;
  }

  async getAvailableHandoffPromptPath(topic) {
    const folderRoot = await this.ensureFolder(this.settings.handoffFolder || "AI Handoffs");
    const stamp = new Date()
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\..+$/, "")
      .replace("T", "-");
    const folderName = `${stamp} ${this.sanitizeFileName(topic || "Handoff")}`;
    const folder = folderRoot ? `${folderRoot}/${folderName}` : folderName;
    await this.ensureFolder(folder);
    return `${folder}/PROMPT.md`;
  }

  async generateChatGptHandoffPackage(topic, mode = "note_completion", conversationContext = []) {
    if (this.settings.writeMode !== "draft") {
      throw new Error(t(this.settings, "writeDisabled"));
    }
    const cleanTopic = String(topic || "").trim();
    if (!cleanTopic) throw new Error(t(this.settings, "handoffTopicRequired"));
    const searchQuery = this.buildConversationSearchQuery(cleanTopic, conversationContext);
    const searchResponse = await this.search(searchQuery);
    const expanded = this.expandResultsForAnswer(searchResponse.results || []);
    const handoffResultLimit = Math.max(10, Math.min(16, (this.settings.answerContextLimit || 6) * 2));
    const results = expanded.slice(0, handoffResultLimit);
    const topicProfiles = this.getTopicCoverageProfiles(cleanTopic, 14);
    const knowledgeContext = [this.buildKnowledgeContext(cleanTopic), this.buildTopicCoverageContext(cleanTopic, topicProfiles)]
      .filter(Boolean)
      .join("\n\n");
    const calloutEvidence = this.buildTopicCalloutEvidence(cleanTopic, topicProfiles, 50);
    const draftQuality = this.checkChatGptHandoffPrompt("", results, mode);
    let prompt = this.buildChatGptHandoffPrompt({
      topic: cleanTopic,
      mode,
      results,
      knowledgeContext,
      calloutEvidence,
      quality: draftQuality,
    });
    const maxChars = Math.max(4000, Math.min(Number.parseInt(this.settings.maxHandoffPromptChars, 10) || 18000, 60000));
    prompt = limitTextBlock(prompt, maxChars);
    const quality = this.checkChatGptHandoffPrompt(prompt, results, mode);
    prompt = this.buildChatGptHandoffPrompt({
      topic: cleanTopic,
      mode,
      results,
      knowledgeContext,
      calloutEvidence,
      quality,
    });
    prompt = limitTextBlock(prompt, maxChars);
    const path = await this.getAvailableHandoffPromptPath(cleanTopic);
    const file = await this.app.vault.create(path, prompt);
    return { file, prompt, quality, results };
  }

  async getAvailablePathInFolder(folder, fileName) {
    const safeFolder = await this.ensureFolder(folder);
    const cleanName = this.sanitizeFileName(String(fileName || "Imported").replace(/\.md$/i, ""));
    let path = safeFolder ? `${safeFolder}/${cleanName}.md` : `${cleanName}.md`;
    let counter = 2;
    while (this.app.vault.getAbstractFileByPath(path)) {
      path = safeFolder ? `${safeFolder}/${cleanName}-${counter}.md` : `${cleanName}-${counter}.md`;
      counter += 1;
    }
    return path;
  }

  sanitizeRelativeMarkdownPath(path) {
    const pieces = String(path || "")
      .replace(/\\/g, "/")
      .split("/")
      .map((piece) => this.sanitizeFileName(piece.replace(/\.md$/i, "")))
      .filter(Boolean)
      .slice(0, 4);
    if (!pieces.length) pieces.push("Imported");
    const last = pieces.pop();
    pieces.push(`${last}.md`);
    return pieces.join("/");
  }

  parseChatGptHandoffFiles(output, topic = "ChatGPT output") {
    const text = String(output || "").trim();
    if (!text) return [];
    const pattern = /^FILE:\s*(.+?\.md)\s*$/gim;
    const matches = [...text.matchAll(pattern)];
    if (!matches.length) {
      return [{ path: `${this.sanitizeFileName(topic || "ChatGPT output")}.md`, content: text }];
    }
    const files = [];
    for (let index = 0; index < matches.length; index += 1) {
      const match = matches[index];
      const start = match.index + match[0].length;
      const end = index + 1 < matches.length ? matches[index + 1].index : text.length;
      const content = text.slice(start, end).trim();
      if (!content) continue;
      files.push({
        path: this.sanitizeRelativeMarkdownPath(match[1]),
        content,
      });
    }
    return files.slice(0, 20);
  }

  async importChatGptHandoffOutput(topic, output, mode = "note_completion") {
    if (this.settings.writeMode !== "draft") {
      throw new Error(t(this.settings, "writeDisabled"));
    }
    const files = this.parseChatGptHandoffFiles(output, topic);
    if (!files.length) throw new Error(t(this.settings, "handoffOutputRequired"));
    const hasFileBlocks = /^FILE:\s*.+?\.md\s*$/im.test(String(output || ""));
    const stamp = new Date()
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\..+$/, "")
      .replace("T", "-");
    const importedFiles = [];
    if (files.length === 1 && mode !== "multi_file" && !hasFileBlocks) {
      const file = await this.createDraftNote(`ChatGPT imported ${topic || "output"}`, files[0].content);
      importedFiles.push(file);
      return importedFiles;
    }
    const root = `${this.settings.draftFolder || "AI Drafts"}/ChatGPT Imports/${stamp} ${this.sanitizeFileName(topic || "Import")}`;
    for (const entry of files) {
      const relative = this.sanitizeRelativeMarkdownPath(entry.path);
      const parts = relative.split("/");
      const fileName = parts.pop();
      const folder = parts.length ? `${root}/${parts.join("/")}` : root;
      const path = await this.getAvailablePathInFolder(folder, fileName || "Imported.md");
      const file = await this.app.vault.create(path, entry.content);
      importedFiles.push(file);
    }
    if (importedFiles.length) {
      this.lastDraftPath = importedFiles[0].path;
      await this.savePluginData();
    }
    return importedFiles;
  }

  sanitizeFileName(name) {
    const cleaned = String(name || "Untitled")
      .replace(/[\\/:*?"<>|#^[\]]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return cleaned.slice(0, 80) || "Untitled";
  }

  async ensureFolder(folderPath) {
    const normalized = String(folderPath || "AI Drafts").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    if (!normalized) return "";
    const parts = normalized.split("/").filter(Boolean);
    let current = "";
    for (const part of parts) {
      current = current ? `${current}/${part}` : part;
      if (!this.app.vault.getAbstractFileByPath(current)) {
        await this.app.vault.createFolder(current);
      }
    }
    return normalized;
  }

  async getAvailableDraftPath(topic) {
    const folder = await this.ensureFolder(this.settings.draftFolder || "AI Drafts");
    const baseName = this.sanitizeFileName(topic);
    const stamp = new Date()
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\..+$/, "")
      .replace("T", "-");
    const stampedName = `${stamp} ${baseName}`;
    let path = folder ? `${folder}/${stampedName}.md` : `${stampedName}.md`;
    let counter = 2;
    while (this.app.vault.getAbstractFileByPath(path)) {
      path = folder ? `${folder}/${stampedName}-${counter}.md` : `${stampedName}-${counter}.md`;
      counter += 1;
    }
    return path;
  }

  async createDraftNote(topic, content) {
    if (this.settings.writeMode !== "draft") {
      throw new Error(t(this.settings, "writeDisabled"));
    }
    const path = await this.getAvailableDraftPath(topic);
    const file = await this.app.vault.create(path, content);
    if (!(file instanceof TFile)) {
      throw new Error(t(this.settings, "draftFileNotCreated"));
    }
    this.lastDraftPath = file.path;
    await this.savePluginData();
    return file;
  }

  async setActiveFileAsDraft() {
    const file = this.app.workspace.getActiveFile();
    if (!(file instanceof TFile) || file.extension !== "md") {
      throw new Error(t(this.settings, "activeNoteNotDraft"));
    }
    if (!this.isPathInDraftFolder(file.path)) {
      throw new Error(t(this.settings, "activeNoteNotDraft"));
    }
    this.lastDraftPath = file.path;
    await this.savePluginData();
    return file;
  }

  async clearCurrentDraft() {
    this.lastDraftPath = "";
    await this.savePluginData();
  }

  isPathInDraftFolder(path) {
    const folder = String(this.settings.draftFolder || "AI Drafts")
      .replace(/\\/g, "/")
      .replace(/^\/+|\/+$/g, "");
    if (!folder) return true;
    return String(path || "").replace(/\\/g, "/").startsWith(`${folder}/`);
  }

  async getDraftOutline(path = this.lastDraftPath) {
    if (!path || !this.isPathInDraftFolder(path)) return [];
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile) || file.extension !== "md") return [];
    const view = this.getDraftMarkdownView(path);
    const content = view && view.editor ? view.editor.getValue() : await this.app.vault.cachedRead(file);
    return content
      .split(/\r?\n/)
      .map((line, index) => {
        const match = line.match(/^(#{1,6})\s+(.+?)\s*$/);
        if (!match) return null;
        return {
          level: match[1].length,
          text: match[2].trim(),
          line: index,
        };
      })
      .filter(Boolean);
  }

  async getDraftAnchors(path = this.lastDraftPath) {
    if (!path || !this.isPathInDraftFolder(path)) return [];
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile) || file.extension !== "md") return [];
    const view = this.getDraftMarkdownView(path);
    const content = view && view.editor ? view.editor.getValue() : await this.app.vault.cachedRead(file);
    const anchors = [];
    const seen = new Set();
    content.split(/\r?\n/).forEach((line, index) => {
      const comment = line.match(/<!--\s*([^>]{1,80}?)\s*-->/);
      const tag = line.trim().match(/^#([A-Za-z0-9_\-\u0080-\uffff]{1,80})$/);
      const text = comment ? comment[1].trim() : tag ? `#${tag[1].trim()}` : "";
      if (!text || seen.has(`${text}:${index}`)) return;
      seen.add(`${text}:${index}`);
      anchors.push({ text, line: index });
    });
    return anchors;
  }

  async getDraftContext(path = this.lastDraftPath) {
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile) || file.extension !== "md") return "";
    const view = this.getDraftMarkdownView(path);
    const content = view && view.editor ? view.editor.getValue() : await this.app.vault.cachedRead(file);
    const headings = await this.getDraftOutline(path);
    const outline = headings.map((heading) => `${"  ".repeat(heading.level - 1)}- ${heading.text}`).join("\n");
    const tail = content.length > 6000 ? content.slice(-6000) : content;
    return `Draft path: ${path}\n\nOutline:\n${outline || "(no headings)"}\n\nRecent draft content:\n${tail}`;
  }

  getDraftMarkdownView(path = this.lastDraftPath) {
    const leaves = this.app.workspace.getLeavesOfType("markdown");
    for (const leaf of leaves) {
      const view = leaf.view;
      if (view instanceof MarkdownView && view.file && view.file.path === path) {
        return view;
      }
    }
    return null;
  }

  getActiveDraftCursorLine(path = this.lastDraftPath) {
    const view = this.getDraftMarkdownView(path);
    if (!view || !view.editor) return -1;
    const cursor = view.editor.getCursor();
    return cursor && Number.isFinite(cursor.line) ? cursor.line : -1;
  }

  async hasActiveDraftSelection() {
    if (!this.lastDraftPath || !this.isPathInDraftFolder(this.lastDraftPath)) return false;
    const view = this.getDraftMarkdownView(this.lastDraftPath);
    if (!view || !view.editor) return false;
    return Boolean(String(view.editor.getSelection() || "").trim());
  }

  getCurrentDraftFile() {
    if (this.settings.writeMode !== "draft") {
      throw new Error(t(this.settings, "writeDisabled"));
    }
    if (!this.lastDraftPath || !this.isPathInDraftFolder(this.lastDraftPath)) {
      throw new Error(t(this.settings, "noCurrentDraft"));
    }
    const file = this.app.vault.getAbstractFileByPath(this.lastDraftPath);
    if (!(file instanceof TFile) || file.extension !== "md") {
      throw new Error(t(this.settings, "noCurrentDraft"));
    }
    return file;
  }

  async getCurrentDraftContent(file) {
    const view = this.getDraftMarkdownView(file.path);
    if (view && view.editor) {
      return view.editor.getValue();
    }
    return this.app.vault.cachedRead(file);
  }

  async captureDraftUndo(file, content) {
    if (!(file instanceof TFile) || !this.isPathInDraftFolder(file.path)) return;
    this.lastDraftUndo = {
      path: file.path,
      content: String(content || ""),
      createdAt: new Date().toISOString(),
      previousSummary: this.lastDraftChangeSummary || "",
    };
  }

  async undoLastDraftEdit() {
    if (!this.lastDraftUndo || !this.lastDraftUndo.path) {
      throw new Error(t(this.settings, "noDraftUndo"));
    }
    if (!this.isPathInDraftFolder(this.lastDraftUndo.path)) {
      throw new Error(t(this.settings, "undoOutsideDraftFolder"));
    }
    const file = this.app.vault.getAbstractFileByPath(this.lastDraftUndo.path);
    if (!(file instanceof TFile) || file.extension !== "md") {
      throw new Error(t(this.settings, "noCurrentDraft"));
    }
    const view = this.getDraftMarkdownView(file.path);
    if (view && view.editor) {
      view.editor.setValue(this.lastDraftUndo.content || "");
    } else {
      await this.app.vault.modify(file, this.lastDraftUndo.content || "");
    }
    this.lastDraftPath = file.path;
    this.lastDraftChangeSummary = "undo_last_draft_edit";
    this.lastDraftUndo = null;
    await this.savePluginData();
    return file;
  }

  summarizeDraftChange(action, before, after, detail = "") {
    const beforeText = String(before || "");
    const afterText = String(after || "");
    const delta = afterText.length - beforeText.length;
    const beforeHeadings = (beforeText.match(/^#{1,6}\s+.+$/gm) || []).length;
    const afterHeadings = (afterText.match(/^#{1,6}\s+.+$/gm) || []).length;
    const sign = delta >= 0 ? "+" : "";
    return `${action}${detail ? ` (${detail})` : ""}: ${sign}${delta} chars, headings ${beforeHeadings}->${afterHeadings}`;
  }

  async editCurrentDraft(instruction) {
    const cleanedInstruction = String(instruction || "").trim();
    if (!cleanedInstruction) {
      throw new Error(t(this.settings, "draftInstructionRequired"));
    }
    const file = this.getCurrentDraftFile();
    const current = await this.getCurrentDraftContent(file);
    const maxChars = Number.parseInt(this.settings.maxDraftEditChars, 10) || 50000;
    if (current.length > maxChars) {
      throw new Error(t(this.settings, "draftTooLarge"));
    }
    const replacement = await this.editDraftDocument(current, cleanedInstruction);
    if (!replacement) {
      throw new Error(t(this.settings, "emptyDraftReturned"));
    }

    await this.captureDraftUndo(file, current);
    const view = this.getDraftMarkdownView(file.path);
    if (view && view.editor) {
      view.editor.setValue(replacement);
    } else {
      await this.app.vault.modify(file, replacement);
    }
    this.lastDraftChangeSummary = this.summarizeDraftChange("edit_current_draft", current, replacement);
    await this.savePluginData();
    return file;
  }

  normalizeInsertionTarget(target) {
    return String(target || "")
      .replace(/^#+/, "")
      .replace(/^\[\[|\]\]$/g, "")
      .replace(/^笔记/i, "")
      .replace(/^note/i, "")
      .replace(/(?:处|位置|附近|后面|前面|下面|上面|之前|之后|后|前)$/i, "")
      .replace(/[，。；;：:,.!?！？]+$/g, "")
      .trim();
  }

  findInsertionLine(lines, target) {
    const cleaned = this.normalizeInsertionTarget(target);
    if (!cleaned) return lines.length - 1;
    const escaped = escapeRegExp(cleaned);
    const exactPatterns = [
      new RegExp(`^\\s*<!--\\s*${escaped}\\s*-->\\s*$`, "i"),
      new RegExp(`^\\s*#${escaped}\\s*$`, "i"),
      new RegExp(`^\\s*!?\\[\\[${escaped}(?:#[^\\]|]+)?(?:\\|[^\\]]+)?\\]\\]\\s*$`, "i"),
      new RegExp(`^\\s*\\[${escaped}\\]\\s*$`, "i"),
      new RegExp(`^\\s*${escaped}:\\s*$`, "i"),
    ];
    for (let index = 0; index < lines.length; index += 1) {
      const line = String(lines[index] || "");
      if (exactPatterns.some((pattern) => pattern.test(line))) return index;
    }
    const inlinePatterns = [
      new RegExp(`<!--\\s*${escaped}\\s*-->`, "i"),
      new RegExp(`(^|[^\\w\\u0080-\\uffff-])#${escaped}(?=$|[^\\w\\u0080-\\uffff-])`, "i"),
      new RegExp(`!?\\[\\[${escaped}(?:#[^\\]|]+)?(?:\\|[^\\]]+)?\\]\\]`, "i"),
    ];
    for (let index = 0; index < lines.length; index += 1) {
      const line = String(lines[index] || "");
      if (inlinePatterns.some((pattern) => pattern.test(line))) return index;
    }
    return -1;
  }

  getDraftInsertionCandidatesFromLines(lines, target, limit = 5) {
    const cleaned = this.normalizeInsertionTarget(target);
    if (!cleaned) return [];
    const terms = tokenize(cleaned);
    const candidates = [];
    const seen = new Set();
    const add = (kind, text, line, bonus = 0) => {
      const label = String(text || "").trim();
      if (!label || !Number.isFinite(line)) return;
      const key = `${line}:${label}`;
      if (seen.has(key)) return;
      seen.add(key);
      const score = (terms.length ? lineScore(label, terms) : 0) + bonus;
      candidates.push({ kind, text: label, line, score });
    };
    for (let index = 0; index < lines.length; index += 1) {
      const line = String(lines[index] || "");
      const heading = line.match(/^(#{1,6})\s+(.+?)\s*$/);
      if (heading) add("heading", heading[2].trim(), index, 6);
      const comment = line.match(/<!--\s*([^>]{1,100}?)\s*-->/);
      if (comment) add("marker", comment[1].trim(), index, 8);
      const tag = line.trim().match(/^#([A-Za-z0-9_\-\u0080-\uffff]{1,100})$/);
      if (tag) add("tag", `#${tag[1].trim()}`, index, 8);
      const wiki = line.match(/\[\[([^\]\n]+)\]\]/);
      if (wiki) add("link", wiki[1].trim(), index, 5);
    }
    return candidates
      .filter((candidate) => candidate.score > 0)
      .sort((a, b) => b.score - a.score || a.line - b.line)
      .slice(0, Math.max(0, limit));
  }

  async insertIntoCurrentDraft(instruction, target, position = "after", directInsertion = "", fallbackInsertion = "") {
    const file = this.getCurrentDraftFile();
    const current = await this.getCurrentDraftContent(file);
    const lines = current.split(/\r?\n/);
    const cleanedTarget = this.normalizeInsertionTarget(target);
    const wantsCursor = /光标|当前位置|当前行|cursor|current position/i.test(String(target || instruction || ""));
    let lineIndex = wantsCursor ? this.getActiveDraftCursorLine(file.path) : this.findInsertionLine(lines, cleanedTarget);
    let insertionResolution = cleanedTarget ? `target=${cleanedTarget}` : "target=end";
    if (lineIndex < 0) {
      if (!cleanedTarget) {
        lineIndex = lines.length - 1;
      } else {
        const candidates = this.getDraftInsertionCandidatesFromLines(lines, cleanedTarget, 3);
        if (candidates.length && candidates[0].score >= 10) {
          lineIndex = candidates[0].line;
          insertionResolution = `fuzzy target=${cleanedTarget} -> ${candidates[0].kind}:${candidates[0].text}`;
        } else {
          lines.push("", `<!-- ${cleanedTarget} -->`);
          lineIndex = lines.length - 1;
          const hint = candidates.length ? ` candidates=${candidates.map((item) => `${item.kind}:${item.text}`).join(", ")}` : "";
          insertionResolution = `created marker=${cleanedTarget}${hint}`;
        }
      }
    }

    const draftContext = await this.getDraftContext(file.path);
    let insertion = directInsertion ? normalizeMathDelimiters(unwrapMarkdownFence(directInsertion)).trim() : "";
    if (!insertion) {
      try {
        insertion = await this.draftInsertion(instruction, cleanedTarget, draftContext);
      } catch (error) {
        if (!fallbackInsertion) throw error;
      }
    }
    if (!insertion && fallbackInsertion) {
      insertion = normalizeMathDelimiters(unwrapMarkdownFence(fallbackInsertion)).trim();
    }
    if (!insertion) {
      throw new Error(t(this.settings, "emptyInsertionReturned"));
    }

    const insertAt = position === "before" ? lineIndex : lineIndex + 1;
    const insertionLines = ["", insertion, ""];
    lines.splice(insertAt, 0, ...insertionLines);
    const updated = lines.join("\n").replace(/\n{4,}/g, "\n\n\n");
    await this.captureDraftUndo(file, current);
    const view = this.getDraftMarkdownView(file.path);
    if (view && view.editor) {
      view.editor.setValue(updated);
    } else {
      await this.app.vault.modify(file, updated);
    }
    this.lastDraftChangeSummary = this.summarizeDraftChange(
      "insert_into_draft",
      current,
      updated,
      `${position} ${cleanedTarget || "end"}; ${insertionResolution}`
    );
    await this.savePluginData();
    return file;
  }

  async editActiveDraftSelection(instruction) {
    const file = this.getCurrentDraftFile();

    const view = this.getDraftMarkdownView(file.path);
    if (!view || !view.editor) {
      throw new Error(t(this.settings, "activeDraftRequired"));
    }
    const selected = view.editor.getSelection();
    if (!selected || !selected.trim()) {
      throw new Error(t(this.settings, "draftSelectionRequired"));
    }

    const draftContext = await this.getDraftContext(file.path);
    const replacement = await this.editDraftSelection(selected, instruction, draftContext);
    if (!replacement) {
      throw new Error(t(this.settings, "emptyReplacementReturned"));
    }
    const before = view.editor.getValue();
    await this.captureDraftUndo(file, before);
    view.editor.replaceSelection(replacement);
    const after = view.editor.getValue();
    this.lastDraftChangeSummary = this.summarizeDraftChange("edit_selection", before, after);
    await this.savePluginData();
    return file;
  }

  formatAnswerForDraft(answer, results) {
    const stamp = new Date().toLocaleString();
    const sourceLines = (results || [])
      .slice(0, this.settings.answerContextLimit)
      .map((result, index) => {
        const sourceLink =
          result.sourceLink ||
          makeObsidianSourceLink(result.path, result.heading || result.path, "", result.heading && result.heading !== "(no heading)" ? result.heading : "");
        return `- [${index + 1}] ${sourceLink}`;
      })
      .join("\n");
    const sources = sourceLines ? `\n\n### Sources\n${sourceLines}` : "";
    return `## Added ${stamp}\n\n${String(answer || "").trim()}${sources}\n`;
  }

  formatSearchResultsForDraft(query, results) {
    const stamp = new Date().toLocaleString();
    const lines = (results || [])
      .slice(0, this.settings.resultLimit)
      .map((result, index) => {
        const notePath = String(result.path || "").replace(/\.md$/i, "");
        const heading = result.heading && result.heading !== "(no heading)" ? `#${result.heading}` : "";
        const score = typeof result.score === "number" ? ` score=${result.score.toFixed(3)}` : "";
        return `${index + 1}. [[${notePath}${heading}]]${score}\n   ${String(result.snippet || "").trim()}`;
      })
      .join("\n");
    return `## Search results ${stamp}\n\nQuery: ${query}\n\n${lines}\n`;
  }

  formatSelectionForDraft(selection) {
    const stamp = new Date().toLocaleString();
    return `## Selection ${stamp}\n\n${String(selection || "").trim()}\n`;
  }

  formatRewrittenForDraft(markdown) {
    const stamp = new Date().toLocaleString();
    return `## Rewritten note ${stamp}\n\n${String(markdown || "").trim()}\n`;
  }

  async appendToCurrentDraft(content) {
    if (this.settings.writeMode !== "draft") {
      throw new Error(t(this.settings, "writeDisabled"));
    }
    if (!this.lastDraftPath) {
      throw new Error(t(this.settings, "noCurrentDraft"));
    }
    if (!this.isPathInDraftFolder(this.lastDraftPath)) {
      throw new Error(t(this.settings, "currentDraftOutsideFolder"));
    }
    const file = this.app.vault.getAbstractFileByPath(this.lastDraftPath);
    if (!(file instanceof TFile) || file.extension !== "md") {
      throw new Error(t(this.settings, "noCurrentDraft"));
    }
    const current = await this.app.vault.cachedRead(file);
    const separator = current.trim().length > 0 ? "\n\n---\n\n" : "";
    await this.captureDraftUndo(file, current);
    await this.app.vault.modify(file, `${current}${separator}${content}`);
    this.lastDraftChangeSummary = this.summarizeDraftChange("append_to_draft", current, `${current}${separator}${content}`);
    await this.savePluginData();
    return file;
  }

  async appendAnswerToCurrentDraft(answer, results) {
    return this.appendToCurrentDraft(this.formatAnswerForDraft(answer, results));
  }

  async appendSearchResultsToCurrentDraft(query, results) {
    return this.appendToCurrentDraft(this.formatSearchResultsForDraft(query, results));
  }

  async appendSelectionToCurrentDraft(selection) {
    return this.appendToCurrentDraft(this.formatSelectionForDraft(selection));
  }

  async appendRewrittenToCurrentDraft(markdown) {
    return this.appendToCurrentDraft(this.formatRewrittenForDraft(markdown));
  }

  async openPath(path) {
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) {
      new Notice(`${t(this.settings, "openFailed")} ${path}`);
      return;
    }
    const leaf = this.app.workspace.getLeaf(false);
    await leaf.openFile(file);
    new Notice(`${t(this.settings, "opened")} ${file.path}`);
  }

  async openPathAtLine(path, line) {
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) {
      new Notice(`${t(this.settings, "openFailed")} ${path}`);
      return;
    }
    const leaf = this.app.workspace.getLeaf(false);
    await leaf.openFile(file);
    const view = leaf.view;
    if (view instanceof MarkdownView && view.editor) {
      const cursor = { line: Math.max(0, line || 0), ch: 0 };
      view.editor.setCursor(cursor);
      if (typeof view.editor.scrollIntoView === "function") {
        view.editor.scrollIntoView({ from: cursor, to: cursor }, true);
      }
    }
    new Notice(`${t(this.settings, "opened")} ${file.path}`);
  }
};
