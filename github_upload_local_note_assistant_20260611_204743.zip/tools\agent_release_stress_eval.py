from pathlib import Path


REPORT = Path("tools/agent_release_stress_eval_report.md")
PLUGIN_MAIN = Path("local-note-assistant-stage3/main.js")
PLUGIN_CSS = Path("local-note-assistant-stage3/styles.css")
PLUGIN_MANIFEST = Path("local-note-assistant-stage3/manifest.json")


LOCAL_ALLOWED_WHEN_PAUSED = {"search_answer", "memory", "knowledge", "migration_tool", "migration_review", "pause_ai", "resume_ai"}
BLOCKED_WHEN_PAUSED = {
    "agent_task",
    "image_to_markdown",
    "topic_synthesis",
    "generate_draft",
    "create_blank_draft",
    "insert_into_draft",
    "edit_current_draft",
    "edit_selection",
    "rewrite_for_draft",
    "append_to_draft",
    "rebuild_index",
}


def paused_policy(action):
    if action == "search_answer":
        return "local_search_only"
    if action in LOCAL_ALLOWED_WHEN_PAUSED:
        return "allowed"
    if action in BLOCKED_WHEN_PAUSED:
        return "blocked"
    return "blocked"


def paused_natural_policy(text):
    value = str(text or "")
    if any(word in value for word in ["生成", "草稿", "插入", "改写", "图片", "截图", "重建索引"]):
        return "blocked"
    return "local_search_only"


def parse_memory_turn(content):
    marker = "\n\nAnswer:\n"
    if not content.startswith("Question:\n") or marker not in content:
        return None
    question_part, rest = content[len("Question:\n") :].split(marker, 1)
    answer_part = rest.split("\n\nSources:\n", 1)[0]
    return {"question": question_part.strip(), "answer": answer_part.strip()}


def delete_current_conversation(conversations, items, current_id):
    conversations = [item for item in conversations if item["id"] != current_id]
    items = [item for item in items if item.get("conversationId") != current_id]
    new_current = "new-chat" if current_id else current_id
    if current_id:
        conversations.append({"id": new_current, "title": "New conversation", "items": []})
    return conversations, items, new_current


def memory_filter_matches(group, query):
    haystack = "\n".join(
        str(part or "")
        for part in [
            group.get("title"),
            group.get("updatedAt"),
            *[
                value
                for item in group.get("items", [])
                for value in [item.get("kind"), item.get("label"), item.get("summary"), str(item.get("content") or "")[:500]]
            ],
        ]
    ).lower()
    return query.lower() in haystack


def file_contains(path, text):
    return text in path.read_text(encoding="utf-8")


def tool_status_call_count():
    return PLUGIN_MAIN.read_text(encoding="utf-8").count("withToolStatus(")


def manifest_version():
    import json

    return json.loads(PLUGIN_MANIFEST.read_text(encoding="utf-8")).get("version")


TESTS = [
    ("pause blocks topic synthesis", lambda: paused_policy("topic_synthesis"), "blocked"),
    ("pause blocks draft generation", lambda: paused_policy("generate_draft"), "blocked"),
    ("pause blocks blank draft creation", lambda: paused_policy("create_blank_draft"), "blocked"),
    ("pause blocks image conversion", lambda: paused_policy("image_to_markdown"), "blocked"),
    ("pause blocks agent plan execution", lambda: paused_policy("agent_task"), "blocked"),
    ("pause blocks rewrite for draft", lambda: paused_policy("rewrite_for_draft"), "blocked"),
    ("pause blocks append to draft", lambda: paused_policy("append_to_draft"), "blocked"),
    ("pause blocks index rebuild", lambda: paused_policy("rebuild_index"), "blocked"),
    ("pause allows local search", lambda: paused_policy("search_answer"), "local_search_only"),
    ("pause allows memory panel", lambda: paused_policy("memory"), "allowed"),
    ("pause allows knowledge panel", lambda: paused_policy("knowledge"), "allowed"),
    ("pause allows migration tool", lambda: paused_policy("migration_tool"), "allowed"),
    ("pause allows resume command", lambda: paused_policy("resume_ai"), "allowed"),
    ("pause blocks natural draft request", lambda: paused_natural_policy("帮我生成一份主题草稿"), "blocked"),
    ("pause blocks natural insert request", lambda: paused_natural_policy("把刚才的内容插入 #tag2"), "blocked"),
    ("pause keeps natural question as local search", lambda: paused_natural_policy("C 星代数是什么"), "local_search_only"),
    (
        "memory turn parser restores question",
        lambda: parse_memory_turn("Question:\n什么是 C 星代数？\n\nAnswer:\n一个回答。\n\nSources:\nA.md")["question"],
        "什么是 C 星代数？",
    ),
    (
        "memory turn parser restores answer",
        lambda: parse_memory_turn("Question:\nQ\n\nAnswer:\nA\n\nSources:\nS")["answer"],
        "A",
    ),
    (
        "delete current conversation creates fresh current chat",
        lambda: delete_current_conversation([{"id": "old", "title": "Old"}], [{"conversationId": "old"}], "old")[2],
        "new-chat",
    ),
    (
        "delete current conversation removes old items",
        lambda: len(delete_current_conversation([{"id": "old", "title": "Old"}], [{"conversationId": "old"}], "old")[1]),
        0,
    ),
    (
        "memory filter matches restored answer content",
        lambda: memory_filter_matches(
            {"title": "代数", "items": [{"content": "Question:\nQ\n\nAnswer:\nC 星代数的表示"}]},
            "表示",
        ),
        True,
    ),
    ("tool status helper exists", lambda: file_contains(PLUGIN_MAIN, "beginToolStatus("), True),
    ("tool status wrapper is reused", lambda: tool_status_call_count() >= 15, True),
    ("tool status spinner css exists", lambda: file_contains(PLUGIN_CSS, "@keyframes lna-spin"), True),
    ("tool status done css exists", lambda: file_contains(PLUGIN_CSS, "lna-tool-status-done"), True),
    ("tool status failed css exists", lambda: file_contains(PLUGIN_CSS, "lna-tool-status-failed"), True),
    ("clipboard screenshot command exists", lambda: file_contains(PLUGIN_MAIN, "attach-local-note-assistant-clipboard-screenshot"), True),
    ("system screenshot command exists", lambda: file_contains(PLUGIN_MAIN, "start-local-note-assistant-system-screenshot"), True),
    ("screenshot question command exists", lambda: file_contains(PLUGIN_MAIN, "ask-local-note-assistant-with-clipboard-screenshot"), True),
    ("clipboard web api reader exists", lambda: file_contains(PLUGIN_MAIN, "navigator.clipboard.read"), True),
    ("electron clipboard fallback exists", lambda: file_contains(PLUGIN_MAIN, "clipboard.readImage"), True),
    ("windows screenshot protocol exists", lambda: file_contains(PLUGIN_MAIN, "ms-screenclip:"), True),
    ("code screenshot mode exists", lambda: file_contains(PLUGIN_MAIN, "fenced code block"), True),
    ("latex inline spacing rule exists", lambda: file_contains(PLUGIN_MAIN, "$x$ rather than $ x $"), True),
    ("voice input defaults exist", lambda: file_contains(PLUGIN_MAIN, "enableVoiceInput: true"), True),
    ("voice language default exists", lambda: file_contains(PLUGIN_MAIN, 'voiceInputLanguage: "zh-CN"'), True),
    ("voice mode default exists", lambda: file_contains(PLUGIN_MAIN, 'voiceInputMode: "append"'), True),
    ("web speech recognition constructor exists", lambda: file_contains(PLUGIN_MAIN, "webkitSpeechRecognition"), True),
    ("voice start command exists", lambda: file_contains(PLUGIN_MAIN, "start-local-note-assistant-voice-input"), True),
    ("voice stop command exists", lambda: file_contains(PLUGIN_MAIN, "stop-local-note-assistant-voice-input"), True),
    ("voice toggle command exists", lambda: file_contains(PLUGIN_MAIN, "toggle-local-note-assistant-voice-input"), True),
    ("voice mode setting exists", lambda: file_contains(PLUGIN_MAIN, "voiceModeDesc"), True),
    ("voice command normalizer exists", lambda: file_contains(PLUGIN_MAIN, "normalizeVoiceCommandText"), True),
    ("voice submit guard exists", lambda: file_contains(PLUGIN_MAIN, "stopVoiceInput({ keepText: false })"), True),
    ("voice button css exists", lambda: file_contains(PLUGIN_CSS, "lna-voice-active"), True),
    ("voice mode css exists", lambda: file_contains(PLUGIN_CSS, "lna-voice-mode"), True),
    ("manifest version bumped", manifest_version, "0.4.85"),
    ("localization helper exists", lambda: file_contains(PLUGIN_MAIN, "function lt(settings, en, zh)"), True),
    ("migration tool description localized", lambda: file_contains(PLUGIN_MAIN, 'text("migrationToolDesc")'), True),
    ("migration review original localized", lambda: file_contains(PLUGIN_MAIN, 'text("migrationOriginal")'), True),
    ("migration review change localized", lambda: file_contains(PLUGIN_MAIN, 'text("migrationChange")'), True),
    ("knowledge domains localized", lambda: file_contains(PLUGIN_MAIN, 'text("knowledgeDomains")'), True),
    ("settings providers localized", lambda: file_contains(PLUGIN_MAIN, 'text("providerOllama")'), True),
    ("write mode options localized", lambda: file_contains(PLUGIN_MAIN, 'text("writeModeDraft")'), True),
    ("draft source options localized", lambda: file_contains(PLUGIN_MAIN, 'text("draftSourceNotesModel")'), True),
    ("search fallback localized", lambda: file_contains(PLUGIN_MAIN, 'semanticSearchFallback'), True),
    ("screenshot error localized", lambda: file_contains(PLUGIN_MAIN, 'systemScreenshotWindowsOnly'), True),
    ("natural memory panel route exists", lambda: file_contains(PLUGIN_MAIN, 'reason: "open memory panel"'), True),
    ("natural knowledge panel route exists", lambda: file_contains(PLUGIN_MAIN, 'reason: "open knowledge panel"'), True),
    ("natural migration tool route exists", lambda: file_contains(PLUGIN_MAIN, 'reason: "open migration tool"'), True),
    ("natural pause route exists", lambda: file_contains(PLUGIN_MAIN, 'reason: "pause ai"'), True),
    ("unsatisfied feedback default exists", lambda: file_contains(PLUGIN_MAIN, "useNegativeFeedbackMemory: true"), True),
    ("unsatisfied feedback button exists", lambda: file_contains(PLUGIN_MAIN, 'text("markUnsatisfied")'), True),
    ("unsatisfied feedback modal exists", lambda: file_contains(PLUGIN_MAIN, "class NegativeFeedbackModal extends Modal"), True),
    ("unsatisfied natural prompt handler exists", lambda: file_contains(PLUGIN_MAIN, "handleUnsatisfiedFeedbackPrompt"), True),
    ("unsatisfied feedback stored in plugin data", lambda: file_contains(PLUGIN_MAIN, "negativeFeedbackItems: this.negativeFeedbackItems || []"), True),
    ("unsatisfied feedback prompt injection exists", lambda: file_contains(PLUGIN_MAIN, "Unsatisfied-answer feedback to avoid repeating"), True),
    ("unsatisfied feedback can be deleted", lambda: file_contains(PLUGIN_MAIN, "deleteNegativeFeedback"), True),
    ("unsatisfied feedback css exists", lambda: file_contains(PLUGIN_CSS, "lna-negative-feedback-section"), True),
    ("ChatGPT handoff button exists", lambda: file_contains(PLUGIN_MAIN, 'text("chatGptHandoffButton")'), True),
    ("ChatGPT handoff modal exists", lambda: file_contains(PLUGIN_MAIN, "class ChatGptHandoffModal extends Modal"), True),
    ("ChatGPT handoff package generator exists", lambda: file_contains(PLUGIN_MAIN, "generateChatGptHandoffPackage"), True),
    ("ChatGPT handoff prompt checker exists", lambda: file_contains(PLUGIN_MAIN, "checkChatGptHandoffPrompt"), True),
    ("ChatGPT handoff import parser exists", lambda: file_contains(PLUGIN_MAIN, "parseChatGptHandoffFiles"), True),
    ("ChatGPT handoff command exists", lambda: file_contains(PLUGIN_MAIN, "open-local-note-assistant-chatgpt-handoff"), True),
    ("ChatGPT handoff css exists", lambda: file_contains(PLUGIN_CSS, "lna-handoff-modal"), True),
    ("settings section helper exists", lambda: file_contains(PLUGIN_MAIN, "createSettingsSection"), True),
    ("embedding provider template exists", lambda: file_contains(PLUGIN_MAIN, "renderEmbeddingProviderTemplate"), True),
    ("chat provider template exists", lambda: file_contains(PLUGIN_MAIN, "renderChatProviderTemplate"), True),
    ("vision provider template exists", lambda: file_contains(PLUGIN_MAIN, "renderVisionProviderTemplate"), True),
    ("provider template card css exists", lambda: file_contains(PLUGIN_CSS, "lna-provider-template"), True),
    ("settings section css exists", lambda: file_contains(PLUGIN_CSS, "lna-settings-section"), True),
    ("tools panel overlay exists", lambda: file_contains(PLUGIN_CSS, "lna-tools-panel"), True),
    ("tools panel no layout jump", lambda: file_contains(PLUGIN_CSS, "position: fixed") and file_contains(PLUGIN_MAIN, "positionToolPanel"), True),
    ("tools panel lives outside assistant pane", lambda: file_contains(PLUGIN_MAIN, "document.body.createDiv") and file_contains(PLUGIN_CSS, "lna-tools-panel-open"), True),
    ("tools trigger stays on left", lambda: file_contains(PLUGIN_CSS, "align-self: flex-start") and file_contains(PLUGIN_MAIN, "buttonRect.left - panelWidth - 8"), True),
    ("tool prompt shortcuts are primary", lambda: file_contains(PLUGIN_MAIN, 'text("toolKeywords")') and file_contains(PLUGIN_CSS, "background: var(--background-secondary)"), True),
    ("handoff clipboard output reader exists", lambda: file_contains(PLUGIN_MAIN, "readClipboardOutput"), True),
    ("handoff markdown file reader exists", lambda: file_contains(PLUGIN_MAIN, "readMarkdownOutputFiles"), True),
    ("handoff prompt stronger quality checklist exists", lambda: file_contains(PLUGIN_MAIN, "Final Quality Checklist") and file_contains(PLUGIN_MAIN, "Required Working Method"), True),
    ("image output language selector exists", lambda: file_contains(PLUGIN_MAIN, "imageOutputLanguage") and file_contains(PLUGIN_MAIN, "imageLanguageChinese"), True),
    ("image Chinese math writing norm exists", lambda: file_contains(PLUGIN_MAIN, "Chinese mathematical notes") and file_contains(PLUGIN_MAIN, "English terms"), True),
    ("ChatGPT protocol v2 exists", lambda: file_contains(PLUGIN_MAIN, "Local Note Assistant GPT Protocol v2"), True),
    ("ChatGPT file block contract exists", lambda: file_contains(PLUGIN_MAIN, "Return exactly one importable Obsidian Markdown file") and file_contains(PLUGIN_MAIN, "FILE:"), True),
    ("header subtitle hidden", lambda: not file_contains(PLUGIN_MAIN, 'text("subtitle")') and file_contains(PLUGIN_CSS, ".lna-header p"), True),
    ("welcome bubble hidden", lambda: not file_contains(PLUGIN_MAIN, 'addAssistantMessage(text("welcome"))'), True),
    ("pause control is bottom action", lambda: file_contains(PLUGIN_MAIN, 'const actions = form.createDiv({ cls: "lna-actions" })') and file_contains(PLUGIN_MAIN, 'this.aiPauseButton = actions.createEl("button"'), True),
    ("answer mode is bottom action", lambda: file_contains(PLUGIN_MAIN, 'actions.createEl("label", { cls: "lna-mode lna-bottom-mode" })'), True),
    ("migration and handoff are in tools panel", lambda: file_contains(PLUGIN_MAIN, 'const migrationToolButton = toolActions.createEl("button"') and file_contains(PLUGIN_MAIN, 'const chatGptHandoffButton = toolActions.createEl("button"'), True),
    ("vision api hidden from main toolbar", lambda: not file_contains(PLUGIN_MAIN, "new VisionApiModal(this.app, this.plugin"), True),
    ("incremental index setting exists", lambda: file_contains(PLUGIN_MAIN, "maxIncrementalIndexChunks: 250"), True),
    ("semantic index change planner exists", lambda: file_contains(PLUGIN_MAIN, "getSemanticIndexChangePlan"), True),
    ("incremental index updater exists", lambda: file_contains(PLUGIN_MAIN, "buildIndexIncremental"), True),
    ("semantic index saves file signatures", lambda: file_contains(PLUGIN_MAIN, "fileSignatures: files.map((file) => this.getFileSignature(file))"), True),
    ("safe changed index button exists", lambda: file_contains(PLUGIN_MAIN, 'text("updateChangedIndex")'), True),
    ("index change check button exists", lambda: file_contains(PLUGIN_MAIN, 'text("checkIndexChanges")'), True),
    ("incremental update blocks full rebuild", lambda: file_contains(PLUGIN_MAIN, 'throw new Error(t(this.settings, "indexFullRebuildNeeded"))'), True),
    ("AI generated files excluded from indexing", lambda: file_contains(PLUGIN_MAIN, "isAiGeneratedSearchPath") and file_contains(PLUGIN_MAIN, "ai[-_\\s]+generated"), True),
    ("ChatGPT handoff folder excluded from indexing", lambda: file_contains(PLUGIN_MAIN, "handoffFolder") and file_contains(PLUGIN_MAIN, "isSearchPathUnderRoot(path, handoffFolder)"), True),
    ("agent tool catalog exists", lambda: file_contains(PLUGIN_MAIN, "AGENT_TOOL_SPECS") and file_contains(PLUGIN_MAIN, "getAgentToolCatalog"), True),
    ("agent hub local intent exists", lambda: file_contains(PLUGIN_MAIN, "inferAgentHubLocalIntent"), True),
    ("agent hub route normalizer exists", lambda: file_contains(PLUGIN_MAIN, "normalizeAgentHubRoute"), True),
    ("agent hub insert step builder exists", lambda: file_contains(PLUGIN_MAIN, "buildAgentHubInsertSteps"), True),
    ("agent hub index routes handled", lambda: file_contains(PLUGIN_MAIN, 'route.action === "check_index_changes"') and file_contains(PLUGIN_MAIN, 'route.action === "update_changed_index"'), True),
]


def main():
    passed = 0
    lines = ["# Agent Release Stress Evaluation", "", f"Total scenarios: `{len(TESTS)}`", ""]
    for name, fn, expected in TESTS:
        try:
            actual = fn()
            ok = actual == expected
        except Exception as error:
            actual = f"ERROR: {error}"
            ok = False
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        lines.append(f"  - actual: `{actual}`")
        lines.append(f"  - expected: `{expected}`")
    lines.insert(2, f"Summary: `{passed}/{len(TESTS)}` scenarios passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{len(TESTS)} scenarios passed")
    print(REPORT)
    return 0 if passed == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
