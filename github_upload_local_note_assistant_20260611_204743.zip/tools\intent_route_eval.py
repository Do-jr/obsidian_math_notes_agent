import re

KEYWORD_ACTIONS = {
    "问答": "search_answer",
    "搜索": "search_answer",
    "查找": "search_answer",
    "主题整理": "topic_synthesis",
    "主题笔记": "topic_synthesis",
    "生成草稿": "generate_draft",
    "空白草稿": "create_blank_draft",
    "插入草稿": "insert_into_draft",
    "改写草稿": "edit_current_draft",
    "改写选中": "edit_selection",
    "图片转写": "image_to_markdown",
    "迁移工具": "migration_tool",
    "迁移审阅": "migration_review",
    "知识索引": "knowledge",
    "记忆": "memory",
    "暂停AI": "pause_ai",
    "恢复AI": "resume_ai",
}


def parse_tool_keyword(text):
    value = str(text or "")
    match = re.match(r"\s*(?:\[([^\]\n]{1,32})\]|【([^】\n]{1,32})】)\s*", value)
    if not match:
        return "", value.strip()
    raw = re.sub(r"[\s_\-:：]+", "", match.group(1) or match.group(2) or "").lower()
    for keyword, action in KEYWORD_ACTIONS.items():
        normalized = re.sub(r"[\s_\-:：]+", "", keyword).lower()
        if normalized == raw:
            return action, value[match.end():].strip()
    return "", value.strip()


def infer_route(text, state):
    forced_action, stripped = parse_tool_keyword(text)
    if forced_action:
        return forced_action
    value = stripped
    lower = value.lower()
    target = ""
    wiki = re.search(r"\[\[([^\]\n]+)\]\]", value)
    if wiki:
        target = wiki.group(1).strip()
    else:
        hash_match = re.search(r"(^|[\s，,。；;])#([A-Za-z0-9_\-/\u0080-\uffff]+)", value)
        if hash_match:
            target = "#" + hash_match.group(2)
        else:
            tag = re.search(r"\b(tag[0-9A-Za-z_-]+)\b", value, re.I)
            if tag:
                target = tag.group(1)

    references_prior = re.search(r"刚才|上面|之前|上一条|前面|这个回答|这个证明|这段回答|last|previous|above|earlier", value, re.I)

    if state.get("hasImage") and re.search(r"图片|截图|图像|识别|转\s*markdown|pdf|证明|公式|image|screenshot|ocr", value, re.I):
        return "image_to_markdown"
    if re.search(r"空白|新建|创建|建立|blank", value) and re.search(r"草稿|文档|笔记|draft|note", lower):
        return "create_blank_draft"
    if re.search(r"整理|梳理|总结|總結|综述|綜述|汇总|生成|写一篇|做一个", value) and re.search(r"文件|文档|笔记|草稿|ai generated|draft|note", lower):
        return "generate_draft"
    if state.get("hasDraftSelection") and re.search(r"选中|選中|这段|這段|当前段落|所选|selected|selection", value) and re.search(r"改写|修改|润色|优化|替换|扩写|整理|证明|rewrite|edit|replace", lower):
        return "edit_selection"
    if state.get("hasCurrentDraft") and re.search(r"当前草稿|当前文档|这篇草稿|整个草稿|current draft|whole draft|draft", lower) and re.search(r"改写|修改|重写|整理|优化|扩写|补全|rewrite|edit|improve|polish", lower):
        return "edit_current_draft"
    if re.search(r"插入|加入|添加|放到|写到|追加|append|insert|add", value) and (target or re.search(r"草稿|draft|后面|前面|之前|之后|末尾|开头", lower)):
        return "agent_task" if references_prior else "insert_into_draft"
    if re.search(r"查找|搜索|找到|解释|说明|是什么|为什么|如何|证明|应用|关系|search|find|explain|what|why|how", lower):
        return "search_answer"
    return "search_answer"


TESTS = [
    ("[主题整理] C星代数的表示", {}, "topic_synthesis"),
    ("[问答] 度量化定理有什么应用", {}, "search_answer"),
    ("[空白草稿] 多复变函数", {}, "create_blank_draft"),
    ("[插入草稿] 在 #tag2 后面插入一个定理", {"hasCurrentDraft": True}, "insert_into_draft"),
    ("[改写选中] 让证明更清楚", {"hasCurrentDraft": True, "hasDraftSelection": True}, "edit_selection"),
    ("[迁移工具]", {}, "migration_tool"),
    ("[知识索引]", {}, "knowledge"),
    ("[暂停AI]", {}, "pause_ai"),
    ("[恢复AI]", {}, "resume_ai"),
    ("整理 C星代数 的内容并生成一个文件", {}, "generate_draft"),
    ("创建一个空白草稿，主题是拓扑向量空间", {}, "create_blank_draft"),
    ("把刚才的证明插入 #tag2 后面", {"hasCurrentDraft": True}, "agent_task"),
    ("在 #pp 处插入一个数学定理", {"hasCurrentDraft": True}, "insert_into_draft"),
    ("改写当前草稿，让它更像正式笔记", {"hasCurrentDraft": True}, "edit_current_draft"),
    ("帮我改写选中段落，使公式更清楚", {"hasCurrentDraft": True, "hasDraftSelection": True}, "edit_selection"),
    ("解释度量化定理有什么应用", {}, "search_answer"),
    ("把这张图片里的证明转成 Markdown", {"hasImage": True}, "image_to_markdown"),
]


def main():
    passed = 0
    lines = ["# Intent Route Evaluation", ""]
    for text, state, expected in TESTS:
        actual = infer_route(text, state)
        ok = actual == expected
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} `{text}` -> `{actual}`, expected `{expected}`")
    lines.insert(1, f"\nSummary: `{passed}/{len(TESTS)}` tests passed.\n")
    report = "tools/intent_route_eval_report.md"
    with open(report, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))
    print(f"{passed}/{len(TESTS)} tests passed")
    print(report)
    return 0 if passed == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
