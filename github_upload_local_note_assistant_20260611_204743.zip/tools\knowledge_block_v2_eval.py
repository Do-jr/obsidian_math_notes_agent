from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
EXPERIMENT = ROOT / "tools" / "knowledge_block_v2_experiment.py"
REPORT = ROOT / "tools" / "knowledge_block_v2_eval_report.md"


def contains(text: str, needle: str) -> bool:
    return needle in text


def main() -> int:
    main_js = MAIN.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    experiment = EXPERIMENT.read_text(encoding="utf-8")

    checks = [
        ("manifest bumped", manifest, '"version": "0.4.85"'),
        ("knowledge index version constant", main_js, "const KNOWLEDGE_INDEX_VERSION = 8;"),
        ("stale check uses v2 version", main_js, "Number(index.version || 0) < KNOWLEDGE_INDEX_VERSION"),
        ("saved index uses v2 version", main_js, "version: KNOWLEDGE_INDEX_VERSION"),
        ("core callout role set", main_js, "const KNOWLEDGE_CORE_CALLOUT_TYPES"),
        ("auxiliary proof role set", main_js, 'const KNOWLEDGE_AUXILIARY_CALLOUT_TYPES = new Set(["proof", "solution"]);'),
        ("callouts store role", main_js, "role,"),
        ("callouts store end line", main_js, "endLine,"),
        ("focus terms helper", main_js, "function getKnowledgeFocusTerms(query)"),
        ("focus noise strips Chinese intent words", main_js, '"基本定义"'),
        ("Hartogs compound focus", main_js, 'terms.push("hartogs延拓");'),
        ("profile lookup graph", main_js, "buildKnowledgeProfileLookup"),
        ("resolved links", main_js, "profile.resolvedLinks"),
        ("backlinks", main_js, "profile.backlinks"),
        ("concepts avoid inferred title for untitled callouts", main_js, "item.title ? [item.title, item.type]"),
        ("proof demoted unless asked", main_js, 'role === "auxiliary" && !requestedTypes.has("proof")'),
        ("core context heading", main_js, "Most relevant core callout-level candidates"),
        ("auxiliary context heading", main_js, "Auxiliary proof/solution candidates"),
        ("experiment has 20 queries", experiment, "QUERIES = ["),
        ("experiment demotes proof", experiment, 'AUX_TYPES = {"proof", "solution"}'),
    ]

    passed = 0
    lines = ["# Knowledge Block v2 Evaluation", ""]
    for name, text, needle in checks:
        ok = contains(text, needle)
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        if not ok:
            lines.append(f"  - missing: `{needle}`")
    lines.insert(1, f"\nSummary: `{passed}/{len(checks)}` checks passed.\n")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{len(checks)} checks passed")
    print(REPORT)
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
