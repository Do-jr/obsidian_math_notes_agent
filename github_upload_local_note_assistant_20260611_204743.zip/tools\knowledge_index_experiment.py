import argparse
import re
from pathlib import Path


CALLOUT_START = re.compile(r"^\s*>\s*\[!([A-Za-z][\w-]*)\]([+-])?\s*(.*)$")
HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
WIKI = re.compile(r"\[\[([^\]\n]+)\]\]")
TAG = re.compile(r"(^|[\s([{:])#([A-Za-z0-9_\-/\u0080-\uffff]+)")
INLINE_MATH = re.compile(r"\$([^$\n]{1,120})\$")


def clean_snippet(text, limit=320):
    compact = re.sub(r"\s+", " ", str(text or "")).strip()
    return compact if len(compact) <= limit else compact[: limit - 3].strip() + "..."


def add_search_aliases(text):
    value = str(text or "")
    aliases = []
    compact = re.sub(r"\s+", "", value)
    if re.search(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", value, re.I) or re.search(r"c星", value, re.I):
        aliases.append("C星 C星代数 cstar Cstar C* C*-代数 C*代数")
    if re.search(r"\\ast|\*", value):
        aliases.append("星 星代数")
    if re.search(r"definition|定义|定義|是什么|基本定义|概念", value):
        aliases.append("定义 基本定义 概念 是什么")
    if re.search(r"proposition|命题|命題", value):
        aliases.append("命题 proposition")
    if re.search(r"theorem|定理", value):
        aliases.append("定理 theorem")
    if re.search(r"proof|证明|證明", value):
        aliases.append("证明 proof")
    if re.search(r"态射|morphism|homomorphism|同态", value):
        aliases.append("态射 同态 morphism homomorphism")
    if re.search(r"表示论|表示|representation", value):
        aliases.append("表示 表示论 representation")
    return " ".join([value, compact, *aliases])


def limit_text(text, limit=2600):
    value = str(text or "")
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 80)].strip() + "\n\n[section shortened by experiment]"


def tokenize(text):
    value = add_search_aliases(text).lower()
    terms = []
    for word in re.findall(r"[a-z0-9_\\]+", value):
        if len(word) > 1 or word.startswith("\\"):
            terms.append(word)
    for seq in re.findall(r"[\u3400-\u9fff]+", value):
        if len(seq) <= 8:
            terms.append(seq)
        for size in (2, 3, 4):
            if len(seq) < size:
                continue
            for index in range(0, len(seq) - size + 1):
                terms.append(seq[index : index + size])
    seen = set()
    result = []
    for term in terms:
        if term and term not in seen:
            seen.add(term)
            result.append(term)
    return result[:180]


def line_score(text, terms):
    lower = add_search_aliases(text).lower()
    score = 0
    for term in terms:
        if term in lower:
            score += 10
            score += lower.count(term)
    return score


def extract_wiki_links(text):
    links = []
    for match in WIKI.finditer(str(text or "")):
        raw = match.group(1).split("|")[0].split("#")[0].removesuffix(".md").strip()
        if raw:
            links.append(raw)
    return list(dict.fromkeys(links))


def extract_tags(text):
    tags = []
    for match in TAG.finditer(str(text or "")):
        tag = match.group(2).strip()
        if tag and not tag.isdigit():
            tags.append("#" + tag)
    return list(dict.fromkeys(tags))


def get_heading_path(lines, line_index):
    stack = []
    for index in range(0, min(line_index + 1, len(lines))):
        match = HEADING.match(lines[index])
        if not match:
            continue
        level = len(match.group(1))
        while len(stack) < level:
            stack.append("")
        stack[level - 1] = match.group(2).strip()
        del stack[level:]
    return " > ".join(item for item in stack if item) or "(no heading)"


def extract_callouts(path, text):
    lines = text.splitlines()
    callouts = []
    current = None

    def finish():
        nonlocal current
        if not current:
            return
        body = "\n".join(current["body_lines"]).strip()
        heading_path = get_heading_path(lines, max(0, current["line"] - 1))
        links = extract_wiki_links(body)[:20]
        tags = extract_tags(body)[:12]
        formulas = [clean_snippet(match.group(1), 80) for match in INLINE_MATH.finditer(body)][:12]
        first_sentence = clean_snippet(re.split(r"(?<=[。！？.!?])\s+", re.sub(r"\$\$[\s\S]*?\$\$", " ", body))[0] or body, 220)
        callouts.append(
            {
                "path": str(path),
                "note_title": path.stem,
                "type": current["type"],
                "title": current["title"],
                "line": current["line"],
                "heading_path": heading_path,
                "links": links,
                "tags": tags,
                "formulas": formulas,
                "first_sentence": first_sentence,
                "body": limit_text(body, 2600),
                "summary": clean_snippet(body, 700),
            }
        )
        current = None

    for index, line in enumerate(lines):
        match = CALLOUT_START.match(line)
        if match:
            finish()
            current = {
                "type": match.group(1).lower(),
                "title": match.group(3).strip(),
                "line": index + 1,
                "body_lines": [],
            }
            continue
        if not current:
            continue
        if re.match(r"^\s*>", line):
            current["body_lines"].append(re.sub(r"^\s*>\s?", "", line))
        elif not line.strip():
            current["body_lines"].append("")
        else:
            finish()
    finish()
    return callouts


def requested_types(query):
    value = query.lower()
    result = set()
    if re.search(r"definition|定义|定義|概念", value):
        result.update(["definition", "def"])
    if re.search(r"proposition|命题|命題", value):
        result.update(["proposition", "prop"])
    if re.search(r"theorem|定理", value):
        result.update(["theorem", "thm"])
    if re.search(r"lemma|引理", value):
        result.add("lemma")
    if re.search(r"proof|证明|證明", value):
        result.add("proof")
    if re.search(r"example|例子|例", value):
        result.add("example")
    if re.search(r"notation|记号|符号|記號|符號", value):
        result.add("notation")
    return result


def score_callout(item, query, terms):
    req = requested_types(query)
    text = "\n".join(
        [
            item["path"],
            item["note_title"],
            item["type"],
            item["title"],
            item["heading_path"],
            item["first_sentence"],
            item["summary"],
            item["body"],
            " ".join(item["links"]),
            " ".join(item["tags"]),
            " ".join(item["formulas"]),
        ]
    )
    query_lower = query.lower().strip()
    score = line_score(text, terms)
    if item["type"] in req:
        score += 24
    if query_lower and query_lower in item["title"].lower():
        score += 50
    if query_lower and query_lower in item["heading_path"].lower():
        score += 28
    if query_lower and query_lower in item["note_title"].lower():
        score += 18
    score += line_score(f"{item['note_title']} {item['heading_path']} {item['title']}", terms) * 1.5
    score += line_score(" ".join(item["links"] + item["formulas"]), terms) * 1.2
    title_score = line_score(item["title"], terms)
    note_title_score = line_score(item["note_title"], terms)
    if item["type"] == "definition" and re.search(r"定义|定義|definition|是什么|概念|基本", query):
        score += 24
        if item["title"] and title_score > 0 and note_title_score > 0:
            score += 36
        if item["line"] <= 20:
            score += 90
        if item["line"] > 200:
            score -= 35
        specificity = f"{item['title']} {item['note_title']} {item['heading_path']}"
        for word in ["矩阵", "范畴", "表示", "态射", "阈限", "直和", "幺元化", "连续函数演算"]:
            if word in specificity and word not in query:
                score -= 55
    if item["title"]:
        score += 3
    if item["type"] in {"definition", "def", "proposition", "prop", "theorem", "thm", "lemma", "corollary"}:
        score += 4
    return score


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("vault")
    parser.add_argument("--query", action="append", default=[])
    parser.add_argument("--limit", type=int, default=12)
    args = parser.parse_args()

    vault = Path(args.vault)
    files = [path for path in vault.rglob("*.md") if ".obsidian" not in path.parts]
    callouts = []
    for path in files:
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = path.read_text(encoding="utf-8-sig", errors="ignore")
        callouts.extend(extract_callouts(path.relative_to(vault), text))

    type_counts = {}
    untitled = 0
    for item in callouts:
        type_counts[item["type"]] = type_counts.get(item["type"], 0) + 1
        if not item["title"]:
            untitled += 1

    print(f"Markdown files: {len(files)}")
    print(f"Callouts: {len(callouts)}")
    print(f"Untitled callouts: {untitled}")
    print("Top callout types:")
    for key, count in sorted(type_counts.items(), key=lambda pair: pair[1], reverse=True)[:20]:
        print(f"- {key}: {count}")

    for query in args.query:
        terms = tokenize(query)
        ranked = sorted(
            ((score_callout(item, query, terms), item) for item in callouts),
            key=lambda pair: pair[0],
            reverse=True,
        )
        print("\n" + "=" * 80)
        print(f"Query: {query}")
        print(f"Tokens: {', '.join(terms[:40])}")
        for score, item in ranked[: args.limit]:
            print(f"\n[{score:.1f}] {item['path']}:{item['line']} [{item['type']}] {item['title'] or '(untitled)'}")
            print(f"Heading: {item['heading_path']}")
            print(f"Links: {', '.join(item['links'][:8]) or '(none)'}")
            print(f"Text: {clean_snippet(item['body'] or item['summary'], 360)}")


if __name__ == "__main__":
    main()
