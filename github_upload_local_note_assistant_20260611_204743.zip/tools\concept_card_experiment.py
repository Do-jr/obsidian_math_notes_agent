import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
VAULT = Path(r"C:\Users\ddjr\Desktop\obsidian notes.valut")
REPORT = ROOT / "tools" / "concept_card_experiment_report.md"

CORE_TYPES = {
    "definition",
    "def",
    "proposition",
    "prop",
    "theorem",
    "thm",
    "lemma",
    "corollary",
    "example",
    "remark",
    "notation",
    "axiom",
    "construction",
}
AUX_TYPES = {"proof", "solution"}

TEST_TOPICS = [
    "C星代数的表示",
    "Hartogs 延拓",
    "解析集",
    "多复变函数",
    "初等拓扑斯",
    "Grothendieck 拓扑",
    "子对象分类子",
    "locale frame 位象",
    "模型范畴 cofibration fibration",
    "Quillen 伴随",
    "谱序列",
    "Galois 上同调",
    "NIP 类型",
    "Yoneda 引理",
]

UNSUPPORTED_TOPICS = [
    "GNS 表示",
]


def should_use(path: Path) -> bool:
    rel = path.relative_to(VAULT).as_posix()
    parts = [p.lower().replace(".md", "").strip() for p in rel.split("/")]
    if any(p in {"ai drafts", "ai handoffs"} for p in parts):
        return False
    if any(re.match(r"ai[-_\s]+generated\b", p) for p in parts):
        return False
    return path.suffix.lower() == ".md"


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8-sig", errors="ignore")


def clean(text: str, limit: int = 220) -> str:
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    return value if len(value) <= limit else value[: limit - 1].strip() + "…"


def normalize_ref(value: str) -> str:
    text = str(value or "").split("|", 1)[0].split("#", 1)[0]
    return re.sub(r"\.md$", "", text, flags=re.I).replace("\\", "/").strip("/")


def wikilinks(text: str):
    return [normalize_ref(m.group(1)) for m in re.finditer(r"\[\[([^\]\n]+)\]\]", text or "") if normalize_ref(m.group(1))]


def heading_path(lines, index):
    stack = []
    for line in lines[: index + 1]:
        match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not match:
            continue
        level = len(match.group(1))
        title = match.group(2).strip()
        stack = [item for item in stack if item[0] < level]
        stack.append((level, title))
    return " > ".join(title for _level, title in stack)


def source_link(path, title="", block=""):
    base = re.sub(r"\.md$", "", path)
    label = title or base
    if block:
        return f"[[{base}#^{block}|{label}]]"
    if title:
        return f"[[{base}#{title}|{title}]]"
    return f"[[{base}]]"


def tokenize(text: str):
    value = str(text or "").lower()
    value = re.sub(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", " c星代数 cstar c* ", value, flags=re.I)
    terms = []
    for word in re.findall(r"[a-z0-9_\\*-]+", value):
        if len(word.strip("-")) > 1:
            terms.append(word.strip("-"))
    for chunk in re.findall(r"[\u3400-\u9fff]+", value):
        terms.append(chunk)
        for size in (2, 3, 4, 5):
            if len(chunk) >= size:
                terms.extend(chunk[i : i + size] for i in range(len(chunk) - size + 1))
    return list(dict.fromkeys(terms))


def compact(text: str) -> str:
    value = str(text or "").lower()
    value = re.sub(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", "c星", value, flags=re.I)
    return re.sub(r"[\s,，。:：;；?？!！]+", "", value)


def merge_name(text: str) -> str:
    value = compact(text)
    value = re.sub(r"definition|proposition|theorem|lemma|corollary|remark|example|notation", "", value, flags=re.I)
    value = re.sub(r"[定义命题定理引理推论例子记号备注]", "", value)
    return value[:120]


def is_invalid_name(text: str) -> bool:
    value = str(text or "").strip()
    return not value or bool(re.match(r"^\(?no\s+heading\)?$", value, flags=re.I)) or value in {"(无标题)", "无标题", "未命名", "(未命名)"}


def is_technical_name(text: str, card=None) -> bool:
    value = str(text or "").strip()
    if is_invalid_name(value) or len(value) > 110:
        return True
    plain = re.sub(r"\$[^$]*\$", "", value).strip()
    formula_chars = len(re.findall(r"[\\_^{}=<>+\-*/|()[\]]", value))
    symbol_ratio = formula_chars / max(1, len(value))
    has_words = bool(re.search(r"[A-Za-z\u3400-\u9fff]{2,}", plain))
    if not has_words and symbol_ratio > 0.25:
        return True
    if re.search(r"(证明|计算|步骤|情形|情况|上式|下式|如下|下面|技术|细节)$", value):
        return True
    if card and not card["coreDefinitions"] and len(card["statements"]) <= 1 and len(card["sourcePaths"]) <= 1 and symbol_ratio > 0.18:
        return True
    return False


def topic_focus_terms(topic: str):
    value = str(topic or "")
    aliases = []
    if re.search(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)|c星|c\*", value, re.I):
        aliases.extend(["c星代数", "星代数", "cstar", "c*"])
    if re.search(r"表示|representation", value, re.I):
        aliases.extend(["表示", "representation"])
    if "hartogs" in value.lower():
        aliases.append("hartogs")
        if "延拓" in value:
            aliases.append("hartogs延拓")
    if re.search(r"locale|frame|位象", value, re.I):
        aliases.extend(["locale", "frame", "位象"])
    raw = tokenize(value) + aliases
    noise = ["定义", "定理", "命题", "性质", "基本", "重要", "应用", "关系", "整理", "总结", "证明", "直观", "意义", "例子"]
    result = []
    for term in raw:
        key = str(term or "").lower().strip()
        if len(key) <= 1:
            continue
        if any(part in key for part in noise):
            continue
        if re.search(r"[\u3400-\u9fff]", key) and any(ch in key for ch in ["的", "和", "与", "有", "么"]):
            continue
        if key not in result:
            result.append(key)
    return result[:10]


def line_score(text: str, terms):
    lower = str(text or "").lower()
    return sum(10 for term in terms if term and term.lower() in lower)


def callout_role(ctype: str) -> str:
    ctype = str(ctype or "").lower()
    if ctype in AUX_TYPES:
        return "auxiliary"
    if ctype in CORE_TYPES:
        return "core"
    return "context"


def parse_callouts(path: str, text: str):
    lines = text.splitlines()
    blocks = []
    current = None
    start_re = re.compile(r"^\s*>\s*\[!([A-Za-z][\w-]*)\]([+-])?\s*(.*)$")

    def finish(end_line):
        nonlocal current
        if not current:
            return
        body = "\n".join(current["body"]).strip()
        ctype = current["type"].lower()
        title = current["title"]
        hpath = heading_path(lines, max(0, current["line"] - 1))
        first = clean(re.sub(r"\$\$[\s\S]*?\$\$", " ", body).split("。")[0] or body, 180)
        inferred = title or clean(f"{hpath.split(' > ')[-1] if hpath else Path(path).stem}: {first}", 140)
        blocks.append(
            {
                "path": path,
                "type": ctype,
                "role": callout_role(ctype),
                "title": title,
                "name": title or inferred,
                "line": current["line"] + 1,
                "endLine": end_line + 1,
                "headingPath": hpath,
                "blockId": current.get("blockId", ""),
                "links": wikilinks(body),
                "body": body[:2400],
                "summary": clean(body, 650),
                "sourceLink": source_link(path, title or inferred, current.get("blockId", "")),
            }
        )
        current = None

    for i, line in enumerate(lines):
        match = start_re.match(line)
        if match:
            finish(i - 1)
            current = {"type": match.group(1), "title": match.group(3).strip(), "line": i, "body": [], "blockId": ""}
            continue
        if not current:
            continue
        block_id = re.match(r"^\s*\^([A-Za-z0-9-]{3,})\s*$", line)
        if block_id:
            current["blockId"] = block_id.group(1)
            finish(i)
        elif re.match(r"^\s*>", line):
            current["body"].append(re.sub(r"^\s*>\s?", "", line))
        elif not line.strip():
            current["body"].append("")
        else:
            finish(i - 1)
    finish(len(lines) - 1)
    return blocks


def load_profiles():
    files = [path for path in VAULT.rglob("*.md") if should_use(path)]
    profiles = []
    for path in files:
        text = read_text(path)
        rel = path.relative_to(VAULT).as_posix()
        profiles.append(
            {
                "path": rel,
                "title": path.stem,
                "folder": path.relative_to(VAULT).parent.as_posix(),
                "links": wikilinks(text),
                "callouts": parse_callouts(rel, text),
                "text": text,
            }
        )
    lookup = {}
    for profile in profiles:
        no_ext = re.sub(r"\.md$", "", profile["path"], flags=re.I)
        for alias in {profile["title"], no_ext, profile["path"], no_ext.split("/")[-1]}:
            lookup[normalize_ref(alias).lower()] = profile["path"]
    backlinks = defaultdict(set)
    for profile in profiles:
        resolved = []
        for link in profile["links"]:
            target = lookup.get(normalize_ref(link).lower())
            if target and target != profile["path"]:
                resolved.append(target)
        profile["resolvedLinks"] = sorted(set(resolved))
        for target in profile["resolvedLinks"]:
            backlinks[target].add(profile["path"])
    for profile in profiles:
        profile["backlinks"] = sorted(backlinks.get(profile["path"], set()))
    return profiles


def canonical_name(callout):
    title = clean(callout.get("title") or "", 100)
    if title and not is_invalid_name(title):
        return title
    heading = clean((callout.get("headingPath") or "").split(" > ")[-1], 80)
    if heading and not is_invalid_name(heading) and callout["type"] in {"definition", "def", "notation", "example", "remark"}:
        return heading
    if callout["type"] in {"definition", "def"}:
        return clean(Path(callout["path"]).stem, 90)
    return ""


def proof_matches_card(card, proof, path):
    evidence = [item for group in ("coreDefinitions", "statements", "examples", "remarks") for item in card[group] if item["path"] == path]
    if not evidence:
        return False
    proof_line = int(proof.get("line") or 0)
    for item in evidence:
        line = int(item.get("line") or 0)
        if line and proof_line and proof_line >= line and proof_line - line <= 90:
            return True
    haystack = " ".join(str(proof.get(key, "")) for key in ("title", "headingPath", "summary", "body")).lower()
    return any(len(str(alias)) >= 3 and str(alias).lower() in haystack for alias in card["aliases"])


def build_cards(profiles):
    profile_by_path = {p["path"]: p for p in profiles}
    cards = {}
    for profile in profiles:
        for callout in profile["callouts"]:
            if callout["role"] != "core":
                continue
            name = canonical_name(callout)
            if not name or is_invalid_name(name):
                continue
            key = re.sub(r"\s+", "", name.lower())
            card = cards.setdefault(
                key,
                {
                    "id": key,
                    "name": name,
                    "aliases": set([name]),
                    "status": "auto",
                    "confidence": "medium",
                    "risk": "medium",
                    "coreDefinitions": [],
                    "statements": [],
                    "examples": [],
                    "remarks": [],
                    "proofEntrances": [],
                    "relatedConcepts": Counter(),
                    "sourcePaths": Counter(),
                    "reviewReasons": [],
                },
            )
            card["aliases"].add(name)
            card["sourcePaths"][callout["path"]] += 1
            for link in callout["links"]:
                card["relatedConcepts"][link] += 1
            item = {
                "type": callout["type"],
                "sourceLink": callout["sourceLink"],
                "path": callout["path"],
                "line": callout["line"],
                "summary": callout["summary"],
                "links": callout["links"][:8],
            }
            if callout["type"] in {"definition", "def", "notation"}:
                card["coreDefinitions"].append(item)
            elif callout["type"] in {"example"}:
                card["examples"].append(item)
            elif callout["type"] in {"remark"}:
                card["remarks"].append(item)
            else:
                card["statements"].append(item)
            profile_links = profile.get("resolvedLinks", []) + profile.get("backlinks", [])
            for related_path in profile_links[:24]:
                related = profile_by_path.get(related_path)
                if related:
                    card["relatedConcepts"][related["title"]] += 1
    for profile in profiles:
        proof_like = [c for c in profile["callouts"] if c["role"] == "auxiliary"]
        if not proof_like:
            continue
        for card in cards.values():
            if profile["path"] in card["sourcePaths"]:
                for proof in proof_like:
                    if not proof_matches_card(card, proof, profile["path"]):
                        continue
                    card["proofEntrances"].append(
                        {
                            "sourceLink": proof["sourceLink"],
                            "path": proof["path"],
                            "line": proof["line"],
                            "summary": proof["summary"],
                        }
                    )
                    if len(card["proofEntrances"]) >= 8:
                        break
    return list(cards.values())


def review_card(card):
    score = 0
    reasons = []
    if card["coreDefinitions"]:
        score += 35
        reasons.append("has explicit definition/notation")
    if card["statements"]:
        score += min(30, len(card["statements"]) * 5)
        reasons.append("has theorem/proposition support")
    if card["sourcePaths"]:
        score += min(20, len(card["sourcePaths"]) * 4)
    if card["relatedConcepts"]:
        score += min(15, len(card["relatedConcepts"]) * 1.5)
    if not card["coreDefinitions"] and len(card["statements"]) <= 1:
        score -= 25
        reasons.append("weak card: no definition and little support")
    if len(card["name"]) > 80:
        score -= 20
        reasons.append("name too long; likely unnamed statement, needs human review")
    if is_technical_name(card["name"], card):
        score -= 45
        reasons.append("likely technical detail rather than stable concept")
    if len(card["sourcePaths"]) >= 2 and card["coreDefinitions"]:
        score += 10
        reasons.append("multi-note support")
    if score >= 70:
        confidence, risk = "high", "low"
    elif score >= 45:
        confidence, risk = "medium", "medium"
    else:
        confidence, risk = "low", "high"
    return score, confidence, risk, reasons


def independent_review_rounds(cards):
    reviewed = []
    for card in cards:
        checks = []
        score1, conf1, risk1, reasons1 = review_card(card)
        checks.append((score1, conf1, risk1, reasons1))
        source_ok = all(item.get("sourceLink") for group in ["coreDefinitions", "statements", "examples", "remarks"] for item in card[group])
        proof_ratio = len(card["proofEntrances"]) / max(1, len(card["coreDefinitions"]) + len(card["statements"]) + len(card["examples"]) + len(card["remarks"]))
        score2 = score1 + (10 if source_ok else -40) + (-20 if proof_ratio > 1.2 else 5)
        reasons2 = ["all core items have source links" if source_ok else "missing source link"]
        if proof_ratio > 1.2:
            reasons2.append("proof entrances too dominant")
        checks.append((score2, "high" if score2 >= 75 else "medium" if score2 >= 45 else "low", "low" if score2 >= 75 else "medium" if score2 >= 45 else "high", reasons2))
        relation_count = sum(card["relatedConcepts"].values())
        score3 = score1 + min(20, relation_count * 0.4) - (15 if len(card["relatedConcepts"]) > 80 else 0)
        reasons3 = ["relation graph has usable neighbors" if relation_count else "few related concepts"]
        if len(card["relatedConcepts"]) > 80:
            reasons3.append("too many neighbors; may need pruning")
        checks.append((score3, "high" if score3 >= 75 else "medium" if score3 >= 45 else "low", "low" if score3 >= 75 else "medium" if score3 >= 45 else "high", reasons3))
        avg = sum(item[0] for item in checks) / len(checks)
        card["reviewScore"] = round(avg, 1)
        card["confidence"] = "high" if avg >= 75 else "medium" if avg >= 45 else "low"
        card["risk"] = "low" if avg >= 75 else "medium" if avg >= 45 else "high"
        card["reviewReasons"] = list(dict.fromkeys(reason for _score, _conf, _risk, reasons in checks for reason in reasons))[:8]
        reviewed.append(card)
    return reviewed


def attach_merge_suggestions(cards):
    by_id = {card["id"]: card for card in cards}
    token_index = defaultdict(set)
    for card in cards:
        for token in tokenize(f"{card['name']} {' '.join(card['aliases'])}")[:20]:
            if len(token) >= 2:
                token_index[token].add(card["id"])
    for card in cards:
        counts = Counter()
        for token in tokenize(f"{card['name']} {' '.join(card['aliases'])}")[:20]:
            for cid in token_index.get(token, set()):
                if cid != card["id"]:
                    counts[cid] += 1
        compact_a = merge_name(card["name"])
        source_set = set(card["sourcePaths"])
        suggestions = []
        for cid, count in counts.items():
            other = by_id[cid]
            compact_b = merge_name(other["name"])
            same_source = bool(source_set & set(other["sourcePaths"]))
            contains = len(compact_a) >= 3 and len(compact_b) >= 3 and (compact_a in compact_b or compact_b in compact_a)
            exact = len(compact_a) >= 2 and compact_a == compact_b
            strong_containment = same_source and contains and min(len(compact_a), len(compact_b)) >= 4 and count >= 2
            if not exact and not strong_containment:
                continue
            score = count * 3 + (35 if compact_a and compact_a == compact_b else 0) + (18 if contains else 0) + (8 if same_source else 0)
            if score >= 40:
                suggestions.append({"id": cid, "name": other["name"], "score": score})
        card["mergeSuggestions"] = sorted(suggestions, key=lambda item: item["score"], reverse=True)[:5]
        if card["mergeSuggestions"]:
            card["reviewReasons"] = list(dict.fromkeys(card.get("reviewReasons", []) + ["possible duplicate/merge target"]))[:9]


def infer_parent(card, cards_by_name):
    name = str(card["name"]).strip()
    paren = re.match(r"^(.+?)[(（][^)）]{2,}[)）]$", name)
    if paren and len(paren.group(1).strip()) >= 2:
        return paren.group(1).strip()
    suffix = re.match(r"^(.{2,30}?)(?:上的|中的|里的|关于)(.{2,16})$", name)
    if suffix and re.search(r"(性|结构|范畴|表示|拓扑|测度|积分|同调|上同调|稠密|紧性|连续|完备|正则|凸性)$", suffix.group(2)):
        return suffix.group(2).strip()
    compact_name = merge_name(name)
    for other in cards_by_name.values():
        if other["id"] == card["id"]:
            continue
        other_compact = merge_name(other["name"])
        if len(other_compact) >= 2 and len(compact_name) >= len(other_compact) + 2 and other_compact in compact_name:
            return other["name"]
    return ""


def attach_hierarchy(cards):
    by_name = {card["name"]: card for card in cards}
    parent_map = defaultdict(list)
    for card in cards:
        parent = infer_parent(card, by_name)
        card["parentTopic"] = parent
        card["childConcepts"] = []
        card["topicLevel"] = "subtopic" if parent else "topic"
        if parent:
            parent_map[parent].append({"id": card["id"], "name": card["name"]})
    for card in cards:
        children = parent_map.get(card["name"], [])
        card["childConcepts"] = [item for item in children if item["id"] != card["id"]][:24]
        if card["childConcepts"]:
            card["topicLevel"] = "broad"


def queue_for_card(card):
    if card["risk"] == "high" or card["confidence"] == "low" or card["reviewScore"] < 45:
        return "insufficient"
    if card.get("mergeSuggestions"):
        return "review"
    if card["risk"] == "low" and card["confidence"] == "high" and card["reviewScore"] >= 75:
        return "auto_pass"
    return "review"


def rank_for_topic(cards, topic):
    terms = tokenize(topic)
    focus = topic_focus_terms(topic)
    compact_topic = compact(topic)
    ascii_required = [
        term
        for term in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", str(topic or ""))
        if term.upper() == term and term.lower() not in {"and", "the"}
    ]
    ranked = []
    for card in cards:
        anchor = "\n".join(
            [
                card["name"],
                " ".join(card["aliases"]),
                " ".join(path for path, _count in card["sourcePaths"].most_common(8)),
            ]
        )
        text = "\n".join(
            [
                anchor,
                " ".join(name for name, _count in card["relatedConcepts"].most_common(20)),
                " ".join(item["summary"] for item in (card["coreDefinitions"] + card["statements"])[:8]),
            ]
        )
        anchor_focus = line_score(anchor, focus)
        body_focus = line_score(text, focus)
        card_compact = compact(anchor)
        score = line_score(text, terms) * 0.35 + anchor_focus * 8 + body_focus * 0.8 + card["reviewScore"] * 1.2
        if compact_topic and compact_topic in card_compact:
            score += 850
        elif focus and anchor_focus == 0:
            score -= 160
        if focus and body_focus == 0:
            score -= 120
        lower_anchor = anchor.lower()
        for required in ascii_required:
            if required.lower() not in lower_anchor:
                score -= 1000
        if card["risk"] == "high":
            score -= 520
        elif card["risk"] == "medium":
            score -= 60
        if score > 0:
            ranked.append((score, card))
    return sorted(ranked, key=lambda item: item[0], reverse=True)


def main():
    profiles = load_profiles()
    cards = independent_review_rounds(build_cards(profiles))
    attach_merge_suggestions(cards)
    attach_hierarchy(cards)
    queue_counts = Counter(queue_for_card(card) for card in cards)
    cards.sort(key=lambda card: card["reviewScore"], reverse=True)
    type_counts = Counter()
    for card in cards:
        for item in card["coreDefinitions"] + card["statements"] + card["examples"] + card["remarks"]:
            type_counts[item["type"]] += 1
    lines = [
        "# Concept Card Experiment",
        "",
        f"Vault: `{VAULT}`",
        f"Searchable notes: `{len(profiles)}`",
        f"Generated cards: `{len(cards)}`",
        f"Confidence: `{dict(Counter(card['confidence'] for card in cards))}`",
        f"Risk: `{dict(Counter(card['risk'] for card in cards))}`",
        f"Review queues: `{dict(queue_counts)}`",
        f"Hierarchy: `{dict(Counter(card.get('topicLevel', 'topic') for card in cards))}`",
        f"Evidence types: `{dict(type_counts.most_common(12))}`",
        "",
        "## Multi-round Review Rule",
        "- Round 1: evidence coverage: definition, theorem/proposition support, source diversity.",
        "- Round 2: citation safety and proof demotion.",
        "- Round 3: relation graph usefulness and over-expansion risk.",
        "",
    ]
    passed = 0
    for topic in TEST_TOPICS:
        ranked = rank_for_topic(cards, topic)
        top = ranked[:5]
        ok = bool(top) and top[0][1]["risk"] in {"low", "medium"} and top[0][1]["reviewScore"] >= 45
        passed += int(ok)
        lines.append(f"## {'PASS' if ok else 'FAIL'} {topic}")
        for score, card in top:
            related = ", ".join(name for name, _count in card["relatedConcepts"].most_common(5))
            sources = "; ".join(path for path, _count in card["sourcePaths"].most_common(3))
            lines.append(
                f"- `{score:.1f}` {card['name']} confidence={card['confidence']} risk={card['risk']} review={card['reviewScore']} sources={sources} related={related}"
            )
        lines.append("")
    for topic in UNSUPPORTED_TOPICS:
        ranked = rank_for_topic(cards, topic)
        top = ranked[:5]
        ok = not top or top[0][0] < 80
        passed += int(ok)
        lines.append(f"## {'PASS' if ok else 'FAIL'} unsupported topic: {topic}")
        lines.append("- Expected: no accepted card, because the formal vault does not contain enough source evidence.")
        for score, card in top:
            sources = "; ".join(path for path, _count in card["sourcePaths"].most_common(3))
            lines.append(
                f"- `{score:.1f}` {card['name']} confidence={card['confidence']} risk={card['risk']} review={card['reviewScore']} sources={sources}"
            )
        lines.append("")
    total = len(TEST_TOPICS) + len(UNSUPPORTED_TOPICS)
    review_load_checks = [
        ("manual review queue is not the whole index", queue_counts["review"] < len(cards) * 0.75),
        ("auto-pass or insufficient queues absorb routine cases", queue_counts["auto_pass"] + queue_counts["insufficient"] > len(cards) * 0.25),
        ("merge suggestions are bounded", sum(1 for card in cards if card.get("mergeSuggestions")) < len(cards) * 0.45),
        ("no no-heading cards remain", not any("no heading" in card["name"].lower() for card in cards)),
        ("proof entrances are bounded by local evidence", max((len(card["proofEntrances"]) for card in cards), default=0) <= 8),
        ("hierarchy has broad/subtopic cards", any(card.get("topicLevel") == "subtopic" for card in cards)),
    ]
    lines.append("## Review Load Checks")
    for name, ok in review_load_checks:
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
    total += len(review_load_checks)
    lines.insert(2, f"Topic checks: `{passed}/{total}` passed.")
    lines.append("## Top Stable Cards")
    for card in cards[:20]:
        lines.append(
            f"- {card['name']} confidence={card['confidence']} risk={card['risk']} review={card['reviewScore']} definitions={len(card['coreDefinitions'])} statements={len(card['statements'])} proofs={len(card['proofEntrances'])}"
        )
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} topic checks passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
