from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN_MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
PLUGIN_CSS = ROOT / "local-note-assistant-stage3" / "styles.css"
REPORT = ROOT / "tools" / "settings_layout_eval_report.md"


def source(path):
    return path.read_text(encoding="utf-8")


def contains(path, text):
    return text in source(path)


def provider_fields(kind, provider):
    data = {
        "embedding": {
            "ollama": {"ollamaBaseUrl", "ollamaModel"},
            "openai": {"openaiBaseUrl", "openaiApiKey", "openaiModel"},
            "gemini": {"geminiApiKey", "geminiModel"},
            "qwen": {"qwenBaseUrl", "qwenApiKey", "qwenModel", "qwenDimensions"},
            "custom": {"customBaseUrl", "customApiKey", "customModel"},
        },
        "chat": {
            "ollama": {"ollamaBaseUrl", "ollamaChatModel"},
            "openai": {"openaiBaseUrl", "openaiApiKey", "openaiChatModel"},
            "gemini": {"geminiApiKey", "geminiChatModel"},
            "qwen": {"qwenBaseUrl", "qwenApiKey", "qwenChatModel"},
            "deepseek": {"deepseekBaseUrl", "deepseekApiKey", "deepseekChatModel"},
            "custom": {"customBaseUrl", "customApiKey", "customChatModel"},
        },
        "vision": {
            "chat": set(),
            "ollama": {"ollamaBaseUrl", "ollamaVisionModel"},
            "openai": {"openaiBaseUrl", "openaiApiKey", "openaiVisionModel"},
            "gemini": {"geminiApiKey", "geminiVisionModel"},
            "qwen": {"qwenBaseUrl", "qwenApiKey", "qwenVisionModel"},
            "custom": {"customBaseUrl", "customApiKey", "customVisionModel"},
        },
    }
    return data[kind][provider]


STATIC_CHECKS = [
    ("settings section helper", PLUGIN_MAIN, "createSettingsSection"),
    ("provider dropdown helper", PLUGIN_MAIN, "addProviderDropdown"),
    ("provider template helper", PLUGIN_MAIN, "createProviderTemplate"),
    ("embedding template renderer", PLUGIN_MAIN, "renderEmbeddingProviderTemplate"),
    ("chat template renderer", PLUGIN_MAIN, "renderChatProviderTemplate"),
    ("vision template renderer", PLUGIN_MAIN, "renderVisionProviderTemplate"),
    ("embedding section text", PLUGIN_MAIN, "settingsEmbeddingSection"),
    ("chat section text", PLUGIN_MAIN, "settingsChatSection"),
    ("vision section text", PLUGIN_MAIN, "settingsVisionSection"),
    ("provider inherited text", PLUGIN_MAIN, "providerInheritedFromChat"),
    ("settings section css", PLUGIN_CSS, "lna-settings-section"),
    ("provider template css", PLUGIN_CSS, "lna-provider-template"),
]


TEMPLATE_CHECKS = [
    ("embedding qwen fields", "embedding", "qwen"),
    ("embedding openai fields", "embedding", "openai"),
    ("embedding gemini fields", "embedding", "gemini"),
    ("chat deepseek fields", "chat", "deepseek"),
    ("chat qwen fields", "chat", "qwen"),
    ("vision chat inherits", "vision", "chat"),
    ("vision qwen fields", "vision", "qwen"),
]


def main():
    main_source = source(PLUGIN_MAIN)
    total = 0
    passed = 0
    lines = ["# Settings Layout Evaluation", ""]

    lines.append("## Static Checks")
    for name, path, needle in STATIC_CHECKS:
        total += 1
        ok = contains(path, needle)
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        if not ok:
            lines.append(f"  - missing: `{needle}`")

    lines.append("")
    lines.append("## Provider Template Checks")
    for name, kind, provider in TEMPLATE_CHECKS:
        total += 1
        fields = provider_fields(kind, provider)
        if provider == "chat" and kind == "vision":
            ok = "providerInheritedFromChat" in main_source
        else:
            ok = all(f'"{field}"' in main_source for field in fields)
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        lines.append(f"  - expected fields: `{sorted(fields)}`")

    lines.insert(2, f"Overall: `{passed}/{total}` checks passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} checks passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
