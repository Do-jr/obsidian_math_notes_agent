import re
from pathlib import Path


REPORT = Path("tools/agent_user_journey_eval_report.md")

KEYWORD_ACTIONS = {
    "问答": "search_answer",
    "搜索": "search_answer",
    "查找": "search_answer",
    "主题整理": "topic_synthesis",
    "主题笔记": "topic_synthesis",
    "整理文件": "topic_synthesis",
    "生成草稿": "generate_draft",
    "草稿": "generate_draft",
    "空白草稿": "create_blank_draft",
    "新建草稿": "create_blank_draft",
    "插入草稿": "insert_into_draft",
    "追加草稿": "insert_into_draft",
    "改写草稿": "edit_current_draft",
    "修改草稿": "edit_current_draft",
    "改写选中": "edit_selection",
    "修改选中": "edit_selection",
    "图片转写": "image_to_markdown",
    "截图转写": "image_to_markdown",
    "迁移工具": "migration_tool",
    "迁移": "migration_tool",
    "迁移审阅": "migration_review",
    "迁移表格": "migration_review",
    "知识索引": "knowledge",
    "知识": "knowledge",
    "记忆": "memory",
    "对话记忆": "memory",
    "暂停AI": "pause_ai",
    "暂停": "pause_ai",
    "恢复AI": "resume_ai",
    "继续AI": "resume_ai",
}


def normalize_keyword(value):
    return re.sub(r"[\s_\-:：]+", "", str(value or "")).lower()


def parse_tool_keyword(text):
    value = str(text or "")
    match = re.match(r"\s*(?:\[([^\]\n]{1,32})\]|【([^】\n]{1,32})】)\s*", value)
    if not match:
        return "", value.strip()
    raw = match.group(1) or match.group(2) or ""
    normalized = normalize_keyword(raw)
    for keyword, action in KEYWORD_ACTIONS.items():
        if normalize_keyword(keyword) == normalized:
            return action, value[match.end():].strip()
    return "", value.strip()


def extract_target(text):
    value = str(text or "")
    wiki = re.search(r"\[\[([^\]\n]+)\]\]", value)
    if wiki:
        return wiki.group(1).strip()
    block = re.search(r"<!--\s*([^>]+?)\s*-->", value)
    if block:
        return block.group(1).strip()
    hash_match = re.search(r"(^|[\s，,。；;：:()（）])#([A-Za-z0-9_\-/\u0080-\uffff]+)", value)
    if hash_match:
        return "#" + hash_match.group(2)
    tag = re.search(r"\b(tag[0-9A-Za-z_-]+)\b", value, re.I)
    if tag:
        return tag.group(1)
    named = re.search(r"(?:标记|锚点|位置|tag)\s*[:：]?\s*([A-Za-z0-9_\-/\u0080-\uffff]{2,})", value, re.I)
    if named:
        return named.group(1)
    return ""


def infer_route(text, state):
    forced_action, stripped = parse_tool_keyword(text)
    if forced_action:
        return forced_action
    value = stripped
    lower = value.lower()
    target = extract_target(value)
    has_draft = bool(state.get("hasCurrentDraft"))
    has_selection = bool(state.get("hasDraftSelection"))
    has_image = bool(state.get("hasImage"))
    references_prior = re.search(
        r"刚才|刚刚|刚生成|上面|之前|上一条|上一轮|前面|这个回答|这个证明|这段回答|那段|前述|last|previous|above|earlier",
        value,
        re.I,
    )
    transform_prior = references_prior and re.search(
        r"改写|重写|润色|整理|总结|摘要|压缩|扩写|补全|改成|变成|转成|格式|rewrite|summarize|polish|convert",
        lower,
    )

    if has_image and re.search(r"图片|截图|图像|图里|照片|识别|转\s*markdown|转成\s*md|pdf|证明|公式|image|screenshot|ocr", value, re.I):
        return "image_to_markdown"
    if re.search(r"空白|新建|创建|建立|打开|开一页|开个|blank", value) and re.search(r"草稿|文档|笔记|draft|note|页面", lower):
        return "create_blank_draft"
    if has_selection and re.search(r"选中|選中|这段|這段|当前段落|所选|selected|selection", value) and re.search(
        r"改写|修改|润色|优化|替换|扩写|整理|证明|补齐|rewrite|edit|replace", lower
    ):
        return "edit_selection"
    if has_draft and re.search(r"当前草稿|当前文档|这篇草稿|整个草稿|这篇|本文|整篇|current draft|whole draft|draft", lower) and re.search(
        r"改写|修改|重写|整理|优化|扩写|补全|润色|rewrite|edit|improve|polish", lower
    ):
        return "edit_current_draft"
    if re.search(r"整理|梳理|总结|總結|综述|綜述|汇总|生成|写一篇|做一个|做成|整理成|形成", value) and re.search(
        r"文件|文档|笔记|草稿|ai generated|draft|note|页面|资料", lower
    ):
        return "generate_draft"
    if re.search(r"插入|加入|添加|放到|放进|写到|写进|追加|塞到|置于|append|insert|add", value) and (
        target or re.search(r"草稿|draft|后面|前面|之前|之后|下面|上面|末尾|开头", lower)
    ):
        return "agent_task" if references_prior or transform_prior else "insert_into_draft"
    if re.search(
        r"查找|搜索|找到|检索|解释|说明|讲讲|说说|回忆|忘了|看看|是什么|什么是|为什么|如何|怎么|证明|应用|关系|区别|联系|search|find|explain|what|why|how",
        lower,
    ):
        return "search_answer"
    return "search_answer"


def infer_agent_steps(text):
    value = str(text or "")
    lower = value.lower()
    references_prior = re.search(
        r"刚才|刚刚|刚生成|上面|之前|上一条|上一轮|前面|这个回答|这个证明|这段回答|那段|前述|last|previous|above|earlier",
        value,
        re.I,
    )
    transform_prior = references_prior and re.search(
        r"改写|重写|润色|整理|总结|摘要|压缩|扩写|补全|改成|变成|转成|格式|rewrite|summarize|polish|convert",
        lower,
    )
    if not references_prior:
        return []
    steps = ["use_artifact"]
    if transform_prior:
        steps.append("generate_markdown")
    steps.append("insert_into_draft")
    return steps


TESTS = [
    ("[主题整理] C星代数的表示", {}, "topic_synthesis"),
    ("【问答】C星代数是什么", {}, "search_answer"),
    ("[空白草稿] 多复变函数复习", {}, "create_blank_draft"),
    ("[生成草稿] Grothendieck 拓扑", {}, "generate_draft"),
    ("[插入草稿] 在 #tag2 后面加入刚才的证明", {"hasCurrentDraft": True}, "insert_into_draft"),
    ("[改写草稿] 让当前草稿更像正式笔记", {"hasCurrentDraft": True}, "edit_current_draft"),
    ("[改写选中] 补齐这段证明", {"hasCurrentDraft": True, "hasDraftSelection": True}, "edit_selection"),
    ("[图片转写] 把这张截图转成 Markdown", {"hasImage": True}, "image_to_markdown"),
    ("[迁移工具]", {}, "migration_tool"),
    ("[迁移审阅]", {}, "migration_review"),
    ("[知识索引]", {}, "knowledge"),
    ("[记忆]", {}, "memory"),
    ("[暂停AI]", {}, "pause_ai"),
    ("[恢复AI]", {}, "resume_ai"),
    # 知识问答/查找
    ("我有点忘了 C星代数的表示 是怎么定义的，帮我回忆一下", {}, "search_answer"),
    ("讲讲 Grothendieck拓扑，最好从覆盖筛开始", {}, "search_answer"),
    ("看看我的笔记里哪里说了 Narasimhan", {}, "search_answer"),
    ("NIP 和交错数之间是什么关系", {}, "search_answer"),
    ("这有什么应用？", {"hasConversation": True}, "search_answer"),
    ("帮我找一下 Abel范畴 真正的定义，不要预加性范畴", {}, "search_answer"),
    # 生成文件/笔记
    ("以多复变函数为主题整理一份可放进 AI generated 的笔记", {"hasCurrentDraft": True}, "generate_draft"),
    ("把 C星代数 的表示、态射、范畴性质整理成一篇笔记", {}, "generate_draft"),
    ("生成一份关于拓扑斯的资料，包含几何态射和子对象分类子", {}, "generate_draft"),
    ("请做成一个文档：Galois基本定理及其例子", {}, "generate_draft"),
    # 空白草稿
    ("开一页新的空白草稿，标题叫 多复变复习", {}, "create_blank_draft"),
    ("新建一个空文档给我记今天的想法", {}, "create_blank_draft"),
    # 插入/追加
    ("把刚生成的那段放进 #tag2 下面", {"hasCurrentDraft": True}, "agent_task", ["use_artifact", "insert_into_draft"]),
    ("将上一轮关于 NIP 的回答改成命题-证明格式，然后放到 tag1", {"hasCurrentDraft": True}, "agent_task", ["use_artifact", "generate_markdown", "insert_into_draft"]),
    ("在 #pp 处插入一个关于谱序列的定理", {"hasCurrentDraft": True}, "insert_into_draft"),
    ("追加到草稿末尾：## 待检查问题", {"hasCurrentDraft": True}, "insert_into_draft"),
    ("把上面那段整理成 Markdown 后塞到 <!-- target --> 后面", {"hasCurrentDraft": True}, "agent_task", ["use_artifact", "generate_markdown", "insert_into_draft"]),
    # 编辑草稿/选区
    ("把这篇整理得更像正式笔记", {"hasCurrentDraft": True}, "edit_current_draft"),
    ("润色本文，保留公式和引用", {"hasCurrentDraft": True}, "edit_current_draft"),
    ("把选中的证明补齐，缺失步骤用 TODO 标注", {"hasCurrentDraft": True, "hasDraftSelection": True}, "edit_selection"),
    ("这段公式说明太乱了，帮我改写", {"hasCurrentDraft": True, "hasDraftSelection": True}, "edit_selection"),
    # 图片/截图
    ("把图里这段证明识别成 md", {"hasImage": True}, "image_to_markdown"),
    ("这个截图里的公式转成 Obsidian 可渲染的 Markdown", {"hasImage": True}, "image_to_markdown"),
    ("pdf 截图里的证明帮我整理一下", {"hasImage": True}, "image_to_markdown"),
    # 安全/边界
    ("把正式笔记A直接改掉", {"hasCurrentDraft": True}, "search_answer"),
    ("我要迁移 [[A]] 到 [[B]]，先告诉我风险", {}, "search_answer"),
    ("检查当前草稿的来源引用有没有错", {"hasCurrentDraft": True}, "search_answer"),
    ("为什么它没有找到我想要的定义？", {}, "search_answer"),
    ("请用我的笔记回答，不要编", {}, "search_answer"),
    ("打开一个草稿页面，不要生成内容", {}, "create_blank_draft"),
]


def main():
    passed = 0
    lines = ["# Agent User Journey Evaluation", "", f"Total scenarios: `{len(TESTS)}`", ""]
    categories = {
        "search_answer": 0,
        "generate_draft": 0,
        "create_blank_draft": 0,
        "agent_task": 0,
        "insert_into_draft": 0,
        "edit_current_draft": 0,
        "edit_selection": 0,
        "image_to_markdown": 0,
        "topic_synthesis": 0,
        "migration_tool": 0,
        "migration_review": 0,
        "knowledge": 0,
        "memory": 0,
        "pause_ai": 0,
        "resume_ai": 0,
    }
    for item in TESTS:
        text, state, expected = item[:3]
        expected_steps = item[3] if len(item) > 3 else None
        actual = infer_route(text, state)
        actual_steps = infer_agent_steps(text) if actual == "agent_task" else []
        ok = actual == expected and (expected_steps is None or actual_steps == expected_steps)
        passed += int(ok)
        categories[expected] = categories.get(expected, 0) + 1
        lines.append(f"- {'PASS' if ok else 'FAIL'} `{text}`")
        lines.append(f"  - state: `{state}`")
        lines.append(f"  - actual: `{actual}`, expected: `{expected}`")
        if expected_steps is not None:
            lines.append(f"  - steps: `{actual_steps}`, expected steps: `{expected_steps}`")
    lines.insert(2, f"Summary: `{passed}/{len(TESTS)}` scenarios passed.")
    lines.append("")
    lines.append("## Coverage")
    for key, count in categories.items():
        lines.append(f"- `{key}`: `{count}`")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{len(TESTS)} scenarios passed")
    print(REPORT)
    return 0 if passed == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
