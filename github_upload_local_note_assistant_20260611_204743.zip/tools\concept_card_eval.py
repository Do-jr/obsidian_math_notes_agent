from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
CSS = ROOT / "local-note-assistant-stage3" / "styles.css"
REPORT = ROOT / "tools" / "concept_card_eval_report.md"


def main() -> int:
    main_js = MAIN.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    css = CSS.read_text(encoding="utf-8")
    checks = [
        ("manifest 0.4.85", manifest, '"version": "0.4.85"'),
        ("concept card version", main_js, "const CONCEPT_CARD_INDEX_VERSION = 3;"),
        ("concept cards saved", main_js, "conceptCards: this.conceptCards || null"),
        ("concept decisions saved", main_js, "conceptCardDecisions: this.conceptCardDecisions || {}"),
        ("concept edits saved", main_js, "conceptCardEdits: this.conceptCardEdits || {}"),
        ("concept keyword route", main_js, 'action: "concept_cards"'),
        ("concept command", main_js, "open-local-note-assistant-concept-card-review"),
        ("concept modal class", main_js, "class ConceptCardReviewModal extends Modal"),
        ("build concept cards method", main_js, "async buildConceptCards(onProgress = null)"),
        ("card review method", main_js, "reviewConceptCard(card)"),
        ("proof entrances demoted", main_js, "proofEntrances"),
        ("accepted decision", main_js, 'status === "accepted"'),
        ("rejected decision", main_js, 'status === "rejected"'),
        ("concept card stale check", main_js, "isConceptCardIndexStale()"),
        ("concept card matching", main_js, "getConceptCardMatches(query"),
        ("concept card context", main_js, "buildConceptCardContext(query"),
        ("rejected cards excluded", main_js, 'filter((card) => card.status !== "rejected")'),
        ("knowledge modal build button", main_js, 'text: text("buildConceptCards")'),
        ("concept review css", css, ".lna-concept-card"),
        ("concept queue filter", main_js, "this.queueFilter = \"review\""),
        ("concept queue method", main_js, "getConceptCardQueue(card)"),
        ("concept stats method", main_js, "getConceptCardStats(cards)"),
        ("concept evidence signature", main_js, "getConceptCardEvidenceSignature(card)"),
        ("concept changed status", main_js, "card.changeStatus"),
        ("concept merge suggestions", main_js, "mergeSuggestions"),
        ("concept batch decisions", main_js, "setConceptCardDecisions(cardIds, status)"),
        ("concept batch accept text", main_js, "conceptCardBatchAcceptVisible"),
        ("concept batch reject text", main_js, "conceptCardBatchRejectVisible"),
        ("concept queue css", css, ".lna-concept-queue-review"),
        ("concept merge css", css, ".lna-concept-card-merge-box"),
        ("invalid no heading filter", main_js, "isInvalidConceptCardName(name)"),
        ("technical detail penalty", main_js, "isTechnicalConceptCardName(name, card = null)"),
        ("proof-card proximity check", main_js, "proofMatchesConceptCard(card, proof, profile)"),
        ("card edit method", main_js, "setConceptCardEdit(cardId, edit)"),
        ("card edit ui", main_js, "renderCardEditPanel(container, card)"),
        ("custom aliases", main_js, "customAliases"),
        ("parent topic", main_js, "parentTopic"),
        ("card hierarchy", main_js, "attachConceptCardHierarchy(cards)"),
        ("card edit css", css, ".lna-concept-card-edit"),
    ]
    passed = 0
    lines = ["# Concept Card Evaluation", ""]
    for name, text, needle in checks:
        ok = needle in text
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        if not ok:
            lines.append(f"  - missing: `{needle}`")
    lines.insert(1, f"\nSummary: `{passed}/{len(checks)}` checks passed.\n")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{len(checks)} checks passed")
    print(REPORT)
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
