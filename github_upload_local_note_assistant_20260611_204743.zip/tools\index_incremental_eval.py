import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN_MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
PLUGIN_MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
REPORT = ROOT / "tools" / "index_incremental_eval_report.md"


def file_contains(path, text):
    return text in path.read_text(encoding="utf-8")


def manifest_version():
    return json.loads(PLUGIN_MANIFEST.read_text(encoding="utf-8")).get("version")


def normalize_search_path(value):
    return str(value or "").replace("\\", "/").strip("/").lower()


def is_search_path_under_root(path, root):
    if not root:
        return False
    return path == f"{root}.md" or path == root or path.startswith(f"{root}/")


def is_ai_generated_search_path(path):
    parts = [part.removesuffix(".md").strip() for part in normalize_search_path(path).split("/") if part.strip()]
    import re

    return any(re.search(r"^ai[-_\s]+generated\b", part) for part in parts)


def should_use_path_for_search(path, draft_folder="AI Drafts", handoff_folder="AI Handoffs"):
    normalized = normalize_search_path(path)
    if is_search_path_under_root(normalized, normalize_search_path(draft_folder)):
        return False
    if is_search_path_under_root(normalized, normalize_search_path(handoff_folder)):
        return False
    if is_ai_generated_search_path(normalized):
        return False
    return normalized.endswith(".md")


def extract_method_body(name):
    text = PLUGIN_MAIN.read_text(encoding="utf-8")
    start = text.find(f"  async {name}(")
    if start < 0:
        start = text.find(f"  {name}(")
    if start < 0:
        return ""
    brace = text.find("{", start)
    depth = 0
    for index in range(brace, len(text)):
        char = text[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return text[brace:index + 1]
    return ""


def signature_matches(previous, current):
    return (
        previous
        and current
        and str(previous.get("path", "")) == str(current.get("path", ""))
        and int(previous.get("mtime", 0)) == int(current.get("mtime", 0))
        and int(previous.get("size", 0)) == int(current.get("size", 0))
    )


def make_plan(saved, current):
    saved_by_path = {item["path"]: item for item in saved}
    current_by_path = {item["path"]: item for item in current}
    added, modified, unchanged = [], [], []
    for item in current:
        old = saved_by_path.get(item["path"])
        if not old:
            added.append(item)
        elif signature_matches(old, item):
            unchanged.append(item)
        else:
            modified.append(item)
    deleted = [item for item in saved if item["path"] not in current_by_path]
    return {
        "added": added,
        "modified": modified,
        "deleted": deleted,
        "unchanged": unchanged,
        "hasChanges": bool(added or modified or deleted),
    }


def merge_chunks(old_chunks, current_files, plan, new_chunks_by_path):
    added_or_modified = {item["path"] for item in plan["added"] + plan["modified"]}
    replaced_or_deleted = {item["path"] for item in plan["modified"] + plan["deleted"]}
    old_by_path = {}
    for chunk in old_chunks:
        old_by_path.setdefault(chunk["path"], []).append(chunk)

    final = []
    reused = 0
    for path in current_files:
        chunks = new_chunks_by_path.get(path, []) if path in added_or_modified else old_by_path.get(path, [])
        if path not in added_or_modified:
            reused += len(chunks)
        for chunk in chunks:
            next_chunk = dict(chunk)
            next_chunk["id"] = len(final)
            final.append(next_chunk)
    deleted = sum(1 for chunk in old_chunks if chunk["path"] in replaced_or_deleted)
    embedded = sum(len(new_chunks_by_path.get(path, [])) for path in added_or_modified)
    return final, {"reused": reused, "deleted": deleted, "embedded": embedded}


SAVED = [
    {"path": "A.md", "mtime": 10, "size": 100},
    {"path": "B.md", "mtime": 20, "size": 200},
    {"path": "D.md", "mtime": 40, "size": 400},
]

CURRENT_SAME = [
    {"path": "A.md", "mtime": 10, "size": 100},
    {"path": "B.md", "mtime": 20, "size": 200},
    {"path": "D.md", "mtime": 40, "size": 400},
]

CURRENT_CHANGED = [
    {"path": "A.md", "mtime": 10, "size": 100},
    {"path": "B.md", "mtime": 21, "size": 220},
    {"path": "C.md", "mtime": 30, "size": 300},
]

OLD_CHUNKS = [
    {"id": 0, "path": "A.md", "embedding": [1]},
    {"id": 1, "path": "A.md", "embedding": [2]},
    {"id": 2, "path": "B.md", "embedding": [3]},
    {"id": 3, "path": "D.md", "embedding": [4]},
]

NEW_CHUNKS = {
    "B.md": [{"path": "B.md", "embedding": [30]}, {"path": "B.md", "embedding": [31]}],
    "C.md": [{"path": "C.md", "embedding": [50]}],
}


def incremental_body():
    return extract_method_body("buildIndexIncremental")


TESTS = [
    ("manifest version", manifest_version, "0.4.85"),
    ("planner method exists", lambda: file_contains(PLUGIN_MAIN, "async getSemanticIndexChangePlan"), True),
    ("incremental method exists", lambda: file_contains(PLUGIN_MAIN, "async buildIndexIncremental"), True),
    ("file signatures saved on full build", lambda: file_contains(PLUGIN_MAIN, "fileSignatures: files.map((file) => this.getFileSignature(file))"), True),
    ("sorted searchable files used", lambda: file_contains(PLUGIN_MAIN, "getSortedSearchableMarkdownFiles"), True),
    ("incremental limit setting exists", lambda: file_contains(PLUGIN_MAIN, "maxIncrementalIndexChunks: 250"), True),
    ("safe check button exists", lambda: file_contains(PLUGIN_MAIN, 'text("checkIndexChanges")'), True),
    ("safe update button exists", lambda: file_contains(PLUGIN_MAIN, 'text("updateChangedIndex")'), True),
    ("Qwen dimensions are part of signature", lambda: file_contains(PLUGIN_MAIN, "signature.dimensions"), True),
    ("AI generated matcher exists", lambda: file_contains(PLUGIN_MAIN, "isAiGeneratedSearchPath"), True),
    ("AI generated root excluded", lambda: should_use_path_for_search("AI generated/C star algebra.md"), False),
    ("AI generated file excluded", lambda: should_use_path_for_search("Math/AI generated C star algebra.md"), False),
    ("AI hyphen generated file excluded", lambda: should_use_path_for_search("Math/AI-generated C star algebra.md"), False),
    ("draft folder excluded", lambda: should_use_path_for_search("AI Drafts/ordinary draft.md"), False),
    ("handoff folder excluded", lambda: should_use_path_for_search("AI Handoffs/PROMPT.md"), False),
    ("ordinary note included", lambda: should_use_path_for_search("Math/C star algebra.md"), True),
    ("incremental does not rebuild knowledge index", lambda: "buildKnowledgeIndex" not in incremental_body(), True),
    ("incremental does not assign knowledge index", lambda: "this.knowledgeIndex =" not in incremental_body(), True),
    ("legacy index requires full rebuild", lambda: file_contains(PLUGIN_MAIN, '"legacy-index"'), True),
    ("incremental blocks full rebuild path", lambda: file_contains(PLUGIN_MAIN, 'throw new Error(t(this.settings, "indexFullRebuildNeeded"))'), True),
    ("round 1 unchanged has no changes", lambda: make_plan(SAVED, CURRENT_SAME)["hasChanges"], False),
    ("round 1 unchanged count", lambda: len(make_plan(SAVED, CURRENT_SAME)["unchanged"]), 3),
    ("round 2 added count", lambda: len(make_plan(SAVED, CURRENT_CHANGED)["added"]), 1),
    ("round 2 modified count", lambda: len(make_plan(SAVED, CURRENT_CHANGED)["modified"]), 1),
    ("round 2 deleted count", lambda: len(make_plan(SAVED, CURRENT_CHANGED)["deleted"]), 1),
    ("round 2 unchanged path", lambda: make_plan(SAVED, CURRENT_CHANGED)["unchanged"][0]["path"], "A.md"),
    (
        "round 2 final paths",
        lambda: [chunk["path"] for chunk in merge_chunks(OLD_CHUNKS, ["A.md", "B.md", "C.md"], make_plan(SAVED, CURRENT_CHANGED), NEW_CHUNKS)[0]],
        ["A.md", "A.md", "B.md", "B.md", "C.md"],
    ),
    (
        "round 2 ids are sequential",
        lambda: [chunk["id"] for chunk in merge_chunks(OLD_CHUNKS, ["A.md", "B.md", "C.md"], make_plan(SAVED, CURRENT_CHANGED), NEW_CHUNKS)[0]],
        [0, 1, 2, 3, 4],
    ),
    (
        "round 2 reuses unchanged embeddings",
        lambda: merge_chunks(OLD_CHUNKS, ["A.md", "B.md", "C.md"], make_plan(SAVED, CURRENT_CHANGED), NEW_CHUNKS)[1]["reused"],
        2,
    ),
    (
        "round 2 embeds only changed chunks",
        lambda: merge_chunks(OLD_CHUNKS, ["A.md", "B.md", "C.md"], make_plan(SAVED, CURRENT_CHANGED), NEW_CHUNKS)[1]["embedded"],
        3,
    ),
    (
        "round 2 removes replaced and deleted chunks",
        lambda: merge_chunks(OLD_CHUNKS, ["A.md", "B.md", "C.md"], make_plan(SAVED, CURRENT_CHANGED), NEW_CHUNKS)[1]["deleted"],
        2,
    ),
    ("round 3 large updates are guarded", lambda: "plan.estimatedChunks > limit" in incremental_body(), True),
]


def main():
    passed = 0
    lines = ["# Incremental Index Evaluation", "", f"Total scenarios: `{len(TESTS)}`", ""]
    for name, fn, expected in TESTS:
        try:
            actual = fn()
            ok = actual == expected
        except Exception as error:
            actual = f"ERROR: {error}"
            ok = False
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        lines.append(f"  - actual: `{actual}`")
        lines.append(f"  - expected: `{expected}`")
    lines.insert(2, f"Summary: `{passed}/{len(TESTS)}` scenarios passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{len(TESTS)} scenarios passed")
    print(REPORT)
    return 0 if passed == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
