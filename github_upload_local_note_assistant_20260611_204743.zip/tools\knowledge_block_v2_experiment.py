import json
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
VAULT = Path(r"C:\Users\ddjr\Desktop\obsidian notes.valut")
REPORT = ROOT / "tools" / "knowledge_block_v2_experiment_report.md"

CORE_TYPES = {
    "definition",
    "def",
    "proposition",
    "prop",
    "theorem",
    "thm",
    "lemma",
    "corollary",
    "example",
    "remark",
    "notation",
    "axiom",
    "construction",
}
AUX_TYPES = {"proof", "solution"}

ALIASES = [
    (re.compile(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)|c星|c\*|C星", re.I), "C星代数 C*-代数 C* cstar Cstar operator algebra representation 表示 态 GNS Hilbert"),
    (re.compile(r"表示|representation", re.I), "表示 representation Hilbert 有界算子 态 GNS"),
    (re.compile(r"多复变|several complex|SCV", re.I), "多复变函数 多复变 复分析 several complex variables SCV 解析集 Hartogs 拟凸 plurisubharmonic"),
    (re.compile(r"解析集|analytic set", re.I), "解析集 analytic set 正则点 奇异点"),
    (re.compile(r"拟凸|pseudoconvex", re.I), "拟凸 pseudoconvex Levi 全纯凸"),
    (re.compile(r"hartogs", re.I), "Hartogs 延拓 Hartogs引理"),
    (re.compile(r"topos|拓扑斯", re.I), "topos 拓扑斯 初等拓扑斯 Grothendieck topos sheaf subobject classifier"),
    (re.compile(r"grothendieck", re.I), "Grothendieck topology site 覆盖 sieve 拓扑"),
    (re.compile(r"层|sheaf", re.I), "层 sheaf presheaf site Grothendieck topology"),
    (re.compile(r"heyting", re.I), "Heyting algebra 直觉逻辑 locale frame"),
    (re.compile(r"locale|位象|frame", re.I), "locale 位象 frame 完备 Heyting"),
    (re.compile(r"模型范畴|model category", re.I), "模型范畴 model category Quillen cofibration fibration weak equivalence"),
    (re.compile(r"谱序列|spectral sequence", re.I), "谱序列 spectral sequence filtration exact couple"),
    (re.compile(r"galois", re.I), "Galois 伽罗瓦 扩张 群 上同调"),
    (re.compile(r"\bNIP\b|稳定", re.I), "NIP 稳定 模型论 公式 类型"),
    (re.compile(r"Banach|巴拿赫", re.I), "Banach 巴拿赫 空间 Hahn-Banach"),
    (re.compile(r"Hilbert|希尔伯特", re.I), "Hilbert 希尔伯特 空间 表示 有界算子"),
]

FOCUS_STOP = {
    "定义",
    "定理",
    "命题",
    "性质",
    "基本",
    "重要",
    "关系",
    "应用",
    "整理",
    "总结",
    "综述",
    "直观",
    "意义",
    "什么",
    "怎么",
    "如何",
    "和",
    "与",
    "的",
    "有什么",
    "definition",
    "theorem",
    "proposition",
    "property",
    "basic",
    "application",
    "relationship",
    "what",
    "how",
    "and",
}

QUERIES = [
    "整理 C星代数和表示的关系",
    "C星代数的表示有什么应用",
    "C星代数的态和 GNS 表示",
    "多复变函数的基本定义和重要定理",
    "解析集和奇异点的关系",
    "Hartogs 延拓有什么直观意义",
    "拟凸域和 Levi 形式",
    "Grothendieck 拓扑和层的关系",
    "初等拓扑斯的定义和例子",
    "子对象分类子是什么",
    "Heyting 代数在范畴逻辑中的作用",
    "locale 和 frame 的定义",
    "模型范畴中的 cofibration 和 fibration",
    "Quillen 伴随和模型范畴",
    "谱序列的应用",
    "Galois 上同调的基本想法",
    "NIP 理论中的公式和类型",
    "Banach 空间与 Hahn-Banach",
    "Hilbert 空间上的有界算子",
    "Yoneda 引理和可表函子",
]


def should_use(path: Path) -> bool:
    rel = path.relative_to(VAULT).as_posix()
    parts = [p.lower().replace(".md", "").strip() for p in rel.split("/")]
    if any(p in {"ai drafts", "ai handoffs"} for p in parts):
        return False
    if any(re.match(r"ai[-_\s]+generated\b", p) for p in parts):
        return False
    return path.suffix.lower() == ".md"


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8-sig", errors="ignore")


def clean(text: str, limit=220) -> str:
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    return value[: limit - 1] + "…" if len(value) > limit else value


def normalize_ref(value: str) -> str:
    text = str(value or "").split("|", 1)[0].split("#", 1)[0]
    text = re.sub(r"\.md$", "", text, flags=re.I).replace("\\", "/").strip("/")
    return text


def wikilinks(text: str):
    return [normalize_ref(m.group(1)) for m in re.finditer(r"\[\[([^\]\n]+)\]\]", text or "") if normalize_ref(m.group(1))]


def headings(lines):
    result = []
    for i, line in enumerate(lines):
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            result.append((i, len(m.group(1)), m.group(2).strip()))
    return result


def heading_path(lines, index):
    stack = []
    for i, line in enumerate(lines[: index + 1]):
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not m:
            continue
        level = len(m.group(1))
        title = m.group(2).strip()
        stack = [entry for entry in stack if entry[0] < level]
        stack.append((level, title))
    return " > ".join(title for _, title in stack)


def source_link(path, heading="", block=""):
    base = re.sub(r"\.md$", "", path)
    if block:
        return f"[[{base}#^{block}|{heading or base}]]"
    if heading:
        return f"[[{base}#{heading}|{heading}]]"
    return f"[[{base}]]"


def formulas(text):
    return [clean(m.group(1), 80) for m in re.finditer(r"\$([^$\n]{1,160})\$", text or "")][:16]


def tokenize(text: str):
    value = str(text or "")
    for pattern, extra in ALIASES:
        if pattern.search(value):
            value += " " + extra
    return tokenize_plain(value)


def tokenize_plain(text: str):
    value = str(text or "")
    terms = []
    for word in re.findall(r"[A-Za-z0-9_\\*-]+", value.lower()):
        word = word.strip("-")
        if len(word) > 1:
            terms.append(word)
    for chunk in re.findall(r"[\u3400-\u9fff]+", value):
        terms.append(chunk)
        for size in (2, 3, 4):
            if len(chunk) >= size:
                terms.extend(chunk[i : i + size] for i in range(len(chunk) - size + 1))
    return list(dict.fromkeys(terms))


def entity_alias_terms(query: str):
    value = str(query or "")
    lower = value.lower()
    terms = []
    if re.search(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)|c星|c\*", value, re.I):
        terms.extend(["c*", "cstar", "c星代数", "星代数"])
    if re.search(r"表示|representation", value, re.I):
        terms.extend(["表示", "representation"])
    if re.search(r"态|gns", value, re.I):
        terms.extend(["态", "gns"])
    if re.search(r"多复变|several complex|scv", value, re.I):
        terms.extend(["多复变", "复变函数", "several", "complex"])
    if re.search(r"解析集|analytic set", value, re.I):
        terms.extend(["解析集", "analytic"])
    if re.search(r"拟凸|pseudoconvex", value, re.I):
        terms.extend(["拟凸", "pseudoconvex", "levi"])
    if "hartogs" in lower:
        terms.append("hartogs")
        if "延拓" in value:
            terms.append("hartogs延拓")
    if re.search(r"topos|拓扑斯", value, re.I):
        terms.extend(["topos", "拓扑斯"])
    if "grothendieck" in lower:
        terms.append("grothendieck")
    if re.search(r"层|sheaf", value, re.I):
        terms.extend(["层", "sheaf"])
    if "heyting" in lower:
        terms.append("heyting")
    if re.search(r"locale|位象|frame", value, re.I):
        terms.extend(["locale", "位象", "frame"])
    if re.search(r"模型范畴|model category", value, re.I):
        terms.extend(["模型范畴", "model", "category"])
    if re.search(r"谱序列|spectral sequence", value, re.I):
        terms.extend(["谱序列", "spectral", "sequence"])
    if "galois" in lower:
        terms.append("galois")
    if re.search(r"\bnip\b", value, re.I):
        terms.append("nip")
    if "banach" in lower:
        terms.append("banach")
    if "hilbert" in lower:
        terms.append("hilbert")
    if "yoneda" in lower:
        terms.append("yoneda")
    return terms


def is_generic_focus_term(term: str):
    compact = term.lower().strip()
    if "hartogs" in compact and "延拓" in compact:
        return False
    if not compact or compact in FOCUS_STOP:
        return True
    if len(compact) <= 1:
        return True
    generic_parts = [
        "定义",
        "定理",
        "命题",
        "性质",
        "基本",
        "重要",
        "应用",
        "关系",
        "整理",
        "总结",
        "证明",
        "直观",
        "意义",
        "延拓",
        "理论",
        "例子",
        "代数",
        "函数",
        "空间",
        "什么",
        "观意",
    ]
    if any(part in compact for part in generic_parts):
        return True
    if re.search(r"[\u3400-\u9fff]", compact) and any(ch in compact for ch in ["的", "和", "与", "有", "么"]):
        return True
    if compact in {"algebra", "operator", "space", "function", "category", "theory"}:
        return True
    return False


def strip_focus_noise(query: str):
    value = str(query or "")
    for phrase in [
        "基本定义",
        "重要定理",
        "定义",
        "定理",
        "命题",
        "性质",
        "基本",
        "重要",
        "应用",
        "关系",
        "整理",
        "总结",
        "证明",
        "直观",
        "意义",
        "例子",
        "有什么",
        "是什么",
        "怎么",
        "如何",
        "的",
        "和",
        "与",
    ]:
        value = value.replace(phrase, " ")
    return value


def line_score(text, terms):
    lower = str(text or "").lower()
    score = 0
    for term in terms:
        if term and term.lower() in lower:
            score += 10
    return score


def focus_terms(query):
    terms = tokenize_plain(strip_focus_noise(query)) + entity_alias_terms(query)
    selected = []
    for term in terms:
        compact = term.lower().strip()
        if is_generic_focus_term(compact):
            continue
        selected.append(compact)
    return list(dict.fromkeys(selected))[:10]


def focus_score(text, query):
    return line_score(text, focus_terms(query))


def requested_types(query):
    value = str(query or "").lower()
    result = set()
    if re.search(r"定义|概念|是什么|definition|def\b", value):
        result.update(["definition", "def"])
    if re.search(r"命题|proposition|prop\b", value):
        result.update(["proposition", "prop"])
    if re.search(r"定理|theorem|thm\b", value):
        result.update(["theorem", "thm"])
    if re.search(r"引理|lemma", value):
        result.add("lemma")
    if re.search(r"推论|corollary", value):
        result.add("corollary")
    if re.search(r"例子|例|example", value):
        result.add("example")
    if re.search(r"应用|application|直观|意义", value):
        result.update(["example", "remark", "proposition", "theorem", "thm"])
    if re.search(r"记号|符号|notation", value):
        result.add("notation")
    if re.search(r"证明|proof", value):
        result.add("proof")
    return result


def parse_callouts(path: str, text: str):
    lines = text.splitlines()
    blocks = []
    current = None
    start_re = re.compile(r"^\s*>\s*\[!([A-Za-z][\w-]*)\]([+-])?\s*(.*)$")

    def finish(end_line):
        nonlocal current
        if not current:
            return
        body = "\n".join(current["body"]).strip()
        hpath = heading_path(lines, max(0, current["line"] - 1))
        title = current["title"]
        first = clean(re.sub(r"\$\$[\s\S]*?\$\$", " ", body).split("。")[0] or body, 180)
        inferred = title or clean(f"{hpath.split(' > ')[-1] if hpath else Path(path).stem}: {first}", 140)
        ctype = current["type"].lower()
        role = "auxiliary" if ctype in AUX_TYPES else "core" if ctype in CORE_TYPES else "context"
        block = {
            "path": path,
            "type": ctype,
            "role": role,
            "title": title,
            "inferredTitle": inferred,
            "line": current["line"] + 1,
            "endLine": end_line + 1,
            "headingPath": hpath,
            "links": wikilinks(body),
            "formulas": formulas(body),
            "body": body[:2600],
            "summary": clean(body, 650),
            "sourceLink": source_link(path, title or inferred, current.get("blockId", "")),
        }
        block["search"] = "\n".join(
            [
                path,
                ctype,
                role,
                title,
                inferred,
                hpath,
                body,
                " ".join(block["links"]),
                " ".join(block["formulas"]),
            ]
        )
        blocks.append(block)
        current = None

    for i, line in enumerate(lines):
        m = start_re.match(line)
        if m:
            finish(i - 1)
            current = {"type": m.group(1), "title": m.group(3).strip(), "line": i, "body": [], "blockId": ""}
            continue
        if not current:
            continue
        block_id = re.match(r"^\s*\^([A-Za-z0-9-]{3,})\s*$", line)
        if block_id:
            current["blockId"] = block_id.group(1)
            finish(i)
        elif re.match(r"^\s*>", line):
            current["body"].append(re.sub(r"^\s*>\s?", "", line))
        elif not line.strip():
            current["body"].append("")
        else:
            finish(i - 1)
    finish(len(lines) - 1)
    return blocks


def note_profile(path: Path):
    rel = path.relative_to(VAULT).as_posix()
    text = read_text(path)
    hs = headings(text.splitlines())
    calls = parse_callouts(rel, text)
    links = wikilinks(text)
    return {
        "path": rel,
        "title": path.stem,
        "folder": str(path.relative_to(VAULT).parent).replace("\\", "/"),
        "headings": hs,
        "links": links,
        "callouts": calls,
        "text": text,
    }


def build_index():
    files = [p for p in VAULT.rglob("*.md") if should_use(p)]
    profiles = [note_profile(path) for path in files]
    by_title = {}
    for profile in profiles:
        rel_no_ext = re.sub(r"\.md$", "", profile["path"])
        by_title[profile["title"].lower()] = profile["path"]
        by_title[rel_no_ext.lower()] = profile["path"]
    backlinks = defaultdict(set)
    for profile in profiles:
        for link in profile["links"]:
            target = by_title.get(link.lower())
            if target:
                backlinks[target].add(profile["path"])
    for profile in profiles:
        profile["backlinks"] = sorted(backlinks.get(profile["path"], set()))
        profile["resolvedLinks"] = sorted({by_title.get(link.lower()) for link in profile["links"] if by_title.get(link.lower())})
    callouts = []
    for profile in profiles:
        for callout in profile["callouts"]:
            callout["noteTitle"] = profile["title"]
            callout["backlinkCount"] = len(profile["backlinks"])
            callouts.append(callout)
    return profiles, callouts


def score_callout(callout, query):
    terms = tokenize(query)
    focus = focus_terms(query)
    req = requested_types(query)
    ctype = callout["type"]
    anchor_text = "\n".join(
        [
            callout["path"],
            callout["noteTitle"],
            callout["title"],
            callout["headingPath"],
        ]
    )
    body_text = "\n".join(
        [
            " ".join(callout["links"]),
            callout["body"],
        ]
    )
    focus_text = "\n".join([anchor_text, body_text])
    score = 0
    score += line_score(f"{callout['title']}", terms) * 5
    score += line_score(f"{callout['inferredTitle']}", terms) * 1.2
    score += line_score(f"{callout['path']} {callout['noteTitle']} {callout['headingPath']}", terms) * 3
    score += line_score(f"{callout['summary']} {callout['body']}", terms) * 0.75
    score += line_score(" ".join(callout["links"] + callout["formulas"]), terms) * 1.4
    anchor_focus = focus_score(anchor_text, query)
    body_focus = focus_score(body_text, query)
    fscore = anchor_focus + body_focus
    score += anchor_focus * 12
    score += body_focus * 2.5
    if focus and fscore == 0:
        score -= 260
    elif focus and anchor_focus == 0:
        score -= 85
    elif focus and anchor_focus >= 2:
        score += 90
    if req:
        if ctype in req:
            score += 150
        elif ctype in AUX_TYPES and "proof" not in req:
            score -= 45
        elif ctype not in CORE_TYPES:
            score -= 8
        elif {"definition", "def"} & req:
            score -= 120
    if callout["role"] == "core":
        score += 14
    if callout["role"] == "auxiliary" and "proof" not in req:
        score -= 28
    if re.search(r"应用|application|直观|意义", query, re.I):
        if ctype in {"example", "remark"}:
            score += 42
        if callout["links"]:
            score += 18
    score += min(12, callout.get("backlinkCount", 0) * 0.4)
    return score


def score_profile(profile, query):
    terms = tokenize(query)
    focus = focus_terms(query)
    text = "\n".join(
        [
            profile["path"],
            profile["title"],
            profile["folder"],
            " ".join(h[2] for h in profile["headings"]),
            " ".join(profile["links"]),
            " ".join(c["title"] + " " + c["summary"] for c in profile["callouts"]),
        ]
    )
    score = line_score(text, terms)
    fscore = focus_score(text, query)
    score += fscore * 4.5
    if focus and fscore == 0:
        score -= 120
    elif focus and fscore >= 2:
        score += 55
    score += min(30, len(profile["backlinks"]) * 1.5)
    score += min(18, len(profile["callouts"]) * 0.4)
    return score


def callout_has_focus(callout, query):
    focus = focus_terms(query)
    if not focus:
        return True
    anchor_text = "\n".join(
        [
            callout["path"],
            callout["noteTitle"],
            callout["title"],
            callout["headingPath"],
        ]
    )
    body_text = "\n".join([" ".join(callout["links"]), callout["body"]])
    return focus_score(anchor_text, query) > 0 or focus_score(body_text, query) >= 20


def profile_has_focus(profile, query):
    focus = focus_terms(query)
    if not focus:
        return True
    text = "\n".join(
        [
            profile["path"],
            profile["title"],
            profile["folder"],
            " ".join(h[2] for h in profile["headings"]),
            " ".join(profile["links"]),
        ]
    )
    return focus_score(text, query) > 0


def evidence_pack(profiles, callouts, query):
    profile_map = {p["path"]: p for p in profiles}
    scored_callouts = sorted(
        [(score_callout(c, query), c) for c in callouts], key=lambda x: x[0], reverse=True
    )
    core_candidates = [(s, c) for s, c in scored_callouts if s > 0 and c["role"] == "core"]
    focused_core = [(s, c) for s, c in core_candidates if callout_has_focus(c, query)]
    core = (focused_core if focused_core else core_candidates)[:16]
    auxiliary = [(s, c) for s, c in scored_callouts if s > 0 and c["role"] != "core"][:6]
    seed_paths = {c["path"] for _, c in core[:8]}
    for _, c in core[:8]:
        for link in c["links"]:
            for p in profiles:
                if link.lower() in {p["title"].lower(), re.sub(r"\.md$", "", p["path"]).lower()}:
                    seed_paths.add(p["path"])
    for p in list(seed_paths):
        seed_paths.update(profile_map[p].get("resolvedLinks", [])[:8])
        seed_paths.update(profile_map[p].get("backlinks", [])[:8])
    profile_candidates = [(score_profile(p, query) + (60 if p["path"] in seed_paths else 0), p) for p in profiles]
    focused_profiles = [(s, p) for s, p in profile_candidates if profile_has_focus(p, query) or p["path"] in seed_paths]
    scored_profiles = sorted(focused_profiles if focused_profiles else profile_candidates, key=lambda x: x[0], reverse=True)
    return core, auxiliary, scored_profiles[:12]


def evaluate(profiles, callouts):
    lines = ["# Knowledge Block v2 Vault Experiment", ""]
    type_counts = Counter(c["type"] for c in callouts)
    role_counts = Counter(c["role"] for c in callouts)
    lines.append(f"Vault: `{VAULT}`")
    lines.append(f"Searchable notes: `{len(profiles)}`")
    lines.append(f"Callout blocks: `{len(callouts)}`")
    lines.append(f"Role counts: `{dict(role_counts)}`")
    lines.append(f"Top callout types: `{dict(type_counts.most_common(16))}`")
    lines.append("")

    passed = 0
    total = 0
    for query in QUERIES:
        core, aux, profs = evidence_pack(profiles, callouts, query)
        total += 1
        proof_ratio = sum(1 for _, c in core[:10] if c["type"] == "proof") / max(1, len(core[:10]))
        ok = bool(core or profs) and proof_ratio <= (0.35 if re.search(r"证明|proof", query, re.I) else 0.15)
        passed += int(ok)
        lines.append(f"## {'PASS' if ok else 'FAIL'} {query}")
        lines.append(f"- core blocks: `{len(core)}`; auxiliary blocks: `{len(aux)}`; proof ratio top10: `{proof_ratio:.2f}`")
        lines.append("- Top core blocks:")
        for score, c in core[:5]:
            lines.append(f"  - `{score:.1f}` {c['sourceLink']} `{c['type']}` {clean(c['summary'], 120)}")
        lines.append("- Related notes:")
        for score, p in profs[:5]:
            lines.append(f"  - `{score:.1f}` [[{re.sub(r'.md$', '', p['path'])}]] links={len(p['resolvedLinks'])} back={len(p['backlinks'])} callouts={len(p['callouts'])}")
        lines.append("")
    lines.insert(2, f"Query checks: `{passed}/{total}` passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} query checks passed")
    print(REPORT)
    return 0 if passed == total else 1


def main():
    profiles, callouts = build_index()
    return evaluate(profiles, callouts)


if __name__ == "__main__":
    raise SystemExit(main())
