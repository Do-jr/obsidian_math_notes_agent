from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


VAULT = Path(r"C:\Users\ddjr\Desktop\obsidian notes.valut")
REPORT = Path("tools/knowledge_citation_eval_report.md")

CALLOUT_START = re.compile(r"^\s*>\s*\[!([A-Za-z][\w-]*)\]([+-])?\s*(.*)$")
HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
BLOCK_ID = re.compile(r"^\s*\^([A-Za-z0-9-]{3,})\s*$")
INLINE_MATH = re.compile(r"\$([^$\n]{1,160})\$")
WIKI = re.compile(r"\[\[([^\]\n]+)\]\]")
TAG = re.compile(r"(^|[\s([{:])#([A-Za-z0-9_\-/\u0080-\uffff]+)")

INTENT_WORDS = re.compile(
    r"(请|帮我|解释|说明|整理|总结|相关|内容|主要|给我|一下|是什么|什么是|定义|基本定义|概念|定理|命题|证明|应用|如何|怎么|why|what|how|definition|theorem|proposition|proof)",
    re.I,
)


def clean_snippet(text: str, limit: int = 320) -> str:
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    return value if len(value) <= limit else value[: limit - 3].strip() + "..."


def limit_text(text: str, limit: int = 2600) -> str:
    value = str(text or "")
    return value if len(value) <= limit else value[: max(0, limit - 80)].strip() + "\n\n[section shortened]"


@lru_cache(maxsize=100000)
def normalize_math_canonical(text: str) -> str:
    value = str(text or "")
    value = re.sub(r"\\(?:operatorname|text)\{([^{}]+)\}", r"\1", value)
    value = re.sub(r"\\mathbb\{C\}", " C ", value)
    value = re.sub(r"\\mathbb\{R\}", " R ", value)
    value = re.sub(r"\\mathbb\{Z\}", " Z ", value)
    value = re.sub(r"\\mathbb\{Q\}", " Q ", value)
    value = re.sub(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", " C星 ", value, flags=re.I)
    value = value.replace("\\ast", "星")
    value = value.replace("\\infty", "无穷")
    value = value.replace("\\text", " text ")
    value = value.replace("\\operatorname", " operatorname ")
    return value


@lru_cache(maxsize=100000)
def normalize_math_aliases(text: str) -> str:
    value = str(text or "")
    value = re.sub(r"\\(?:operatorname|text)\{([^{}]+)\}", r"\1", value)
    value = re.sub(r"\\mathbb\{C\}", " C 复数 complex ", value)
    value = re.sub(r"\\mathbb\{R\}", " R 实数 real ", value)
    value = re.sub(r"\\mathbb\{Z\}", " Z 整数 integer ", value)
    value = re.sub(r"\\mathbb\{Q\}", " Q 有理数 rational ", value)
    value = re.sub(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", " C星 C星代数 Cstar C* ", value, flags=re.I)
    value = re.sub(r"\\bar\s*\{?\s*\\partial\s*\}?", " dbar barpartial Cauchy-Riemann CR 方程 ", value)
    value = value.replace("\\infty", "无穷 infinity")
    value = value.replace("\\ast", "星 ast")
    value = value.replace("\\Delta", "Delta Δ")
    value = value.replace("\\text", " text ")
    value = value.replace("\\operatorname", " operatorname ")
    return value


@lru_cache(maxsize=100000)
def add_search_aliases(text: str) -> str:
    value = normalize_math_aliases(str(text or ""))
    compact = re.sub(r"\s+", "", value)
    aliases: list[str] = []
    checks = [
        (r"c星|cstar|c\*", "C星 C星代数 Cstar C* C*-代数 C*代数"),
        (r"topos|拓扑斯", "topos 拓扑斯 初等拓扑斯 Grothendieck拓扑斯"),
        (r"sheaf|层\b|层范畴", "sheaf 层 层范畴 Sh"),
        (r"presheaf|预层", "presheaf 预层 预层范畴"),
        (r"grothendieck\s*topology|grothendieck拓扑|覆盖筛|景", "Grothendieck拓扑 覆盖筛 site 景"),
        (r"geometric\s*morphism|几何态射", "geometric morphism 几何态射 direct-image inverse-image"),
        (r"subobject\s*classifier|子对象分类子", "subobject classifier 子对象分类子 真值对象"),
        (r"locale|位象", "locale 位象 frame 帧"),
        (r"banach", "Banach 巴拿赫 Banach空间"),
        (r"hilbert", "Hilbert 希尔伯特 Hilbert空间"),
        (r"hahn[-\s]?banach", "Hahn-Banach 延拓 分离"),
        (r"拓扑向量|topological\s*vector|tvs", "拓扑向量空间 TVS topological vector space"),
        (r"模型范畴|model\s*category", "模型范畴 model category cofibration fibration weak equivalence"),
        (r"quillen", "Quillen Quillen伴随 Quillen等价 导出函子"),
        (r"reedy", "Reedy Reedy范畴 Reedy模型结构"),
        (r"bousfield", "Bousfield 局部化"),
        (r"谱序列|spectral\s*sequence", "谱序列 spectral sequence 滤过 正合对"),
        (r"galois", "Galois 伽罗瓦 Galois扩张 Galois对应"),
        (r"hilbert\s*90", "Hilbert90 Hilbert 90 上同调"),
        (r"多复变|several\s*complex", "多复变函数 多复变 复分析 SCV"),
        (r"解析集|analytic\s*set", "解析集 analytic set 正则点 奇异点"),
        (r"多重次调和|plurisubharmonic|psh", "多重次调和函数 plurisubharmonic psh Levi形式"),
        (r"拟凸|pseudoconvex", "拟凸域 pseudoconvex Levi拟凸 全纯凸"),
        (r"hartogs", "Hartogs 延拓 Hartogs引理"),
        (r"riemann", "Riemann 可去奇性"),
        (r"weierstrass", "Weierstrass 预备定理 Weierstrass映射"),
        (r"abel", "Abel范畴 abelian category 阿贝尔范畴"),
        (r"yoneda", "Yoneda 米田 可表"),
        (r"kan", "Kan扩张 Kan extension"),
        (r"nip", "NIP 稳定性理论 交错数"),
        (r"morley", "Morley 稳定性 型"),
        (r"definition|定义|定義|是什么|基本定义|概念", "定义 基本定义 概念 是什么"),
        (r"proposition|命题|命題", "命题 proposition"),
        (r"theorem|定理", "定理 theorem"),
        (r"proof|证明|證明", "证明 proof"),
        (r"morphism|态射|同态|homomorphism", "态射 同态 morphism homomorphism"),
        (r"representation|表示论|表示", "表示 表示论 representation"),
    ]
    lower = value.lower()
    for pattern, alias in checks:
        if re.search(pattern, lower, re.I):
            aliases.append(alias)
    return " ".join([value, compact, *aliases])


def tokenize(text: str) -> list[str]:
    value = add_search_aliases(text).lower()
    terms: list[str] = []
    for word in re.findall(r"[a-z0-9_\\\-]+", value):
        cleaned = word.strip("-")
        if len(cleaned) > 1 or cleaned.startswith("\\"):
            terms.append(cleaned)
    for seq in re.findall(r"[\u3400-\u9fff]+", value):
        if len(seq) <= 10:
            terms.append(seq)
        for size in (2, 3, 4, 5):
            if len(seq) < size:
                continue
            for index in range(0, len(seq) - size + 1):
                terms.append(seq[index : index + size])
    return list(dict.fromkeys(terms))[:220]


@lru_cache(maxsize=300000)
def _line_score_cached(text: str, terms_key: tuple[str, ...]) -> float:
    lower = add_search_aliases(text).lower()
    score = 0.0
    for term in terms_key:
        if term in lower:
            score += 10 + min(8, lower.count(term))
    return score


def line_score(text: str, terms: list[str] | tuple[str, ...]) -> float:
    return _line_score_cached(str(text or ""), tuple(terms))


def plain_compact(value: str) -> str:
    return re.sub(r"\s+", "", normalize_math_canonical(str(value or "")).lower())


def alias_compact(value: str) -> str:
    return re.sub(r"\s+", "", add_search_aliases(str(value or "")).lower())


def compact_equal(left: str, right: str) -> bool:
    left_plain = plain_compact(left)
    return bool(left_plain and left_plain == plain_compact(right)) or bool(alias_compact(left) and alias_compact(left) == alias_compact(right))


def exactish_contains(haystack: str, needle: str) -> bool:
    target = plain_compact(needle)
    if target and target in plain_compact(haystack):
        return True
    alias_target = alias_compact(needle)
    return bool(alias_target and alias_target in alias_compact(haystack))


def query_focus(query: str) -> str:
    value = normalize_math_canonical(query)
    value = INTENT_WORDS.sub(" ", value)
    value = re.sub(r"[\s,，。:：；;?？!！]+", " ", value).strip()
    return value or query.strip()


def focus_parts(query: str) -> list[str]:
    focus = query_focus(query)
    result: list[str] = []
    for piece in re.split(r"[\s,，。:：；;?？!！/]+", focus):
        cleaned = piece.strip()
        if len(cleaned) >= 2 and not INTENT_WORDS.fullmatch(cleaned):
            result.append(cleaned)
    for match in re.finditer(r"[A-Za-z][A-Za-z0-9\-]{1,}|[\u3400-\u9fff]{2,}", focus):
        item = match.group(0)
        if not INTENT_WORDS.fullmatch(item):
            result.append(item)
    seen = set()
    unique = []
    for item in result:
        key = plain_compact(item)
        if key and key not in seen:
            seen.add(key)
            unique.append(item)
    return unique[:12]


def extract_wiki_links(text: str) -> list[str]:
    links = []
    for match in WIKI.finditer(str(text or "")):
        raw = match.group(1).split("|")[0].split("#")[0].removesuffix(".md").strip()
        if raw:
            links.append(raw)
    return list(dict.fromkeys(links))


def extract_tags(text: str) -> list[str]:
    tags = []
    for match in TAG.finditer(str(text or "")):
        tag = match.group(2).strip()
        if tag and not tag.isdigit():
            tags.append("#" + tag)
    return list(dict.fromkeys(tags))


def get_heading_path(lines: list[str], line_index: int) -> str:
    stack: list[str] = []
    for index in range(0, min(line_index + 1, len(lines))):
        match = HEADING.match(lines[index])
        if not match:
            continue
        level = len(match.group(1))
        while len(stack) < level:
            stack.append("")
        stack[level - 1] = match.group(2).strip()
        del stack[level:]
    return " > ".join(item for item in stack if item) or "(no heading)"


def obsidian_path(path: str) -> str:
    return str(path or "").replace("\\", "/").removesuffix(".md")


def make_source_link(path: str, label: str, block_id: str = "", heading: str = "") -> str:
    clean_path = obsidian_path(path)
    clean_label = clean_snippet(label or clean_path, 80).replace("|", " ")
    if block_id:
        return f"[[{clean_path}#^{block_id}|{clean_label}]]"
    if heading and heading != "(no heading)":
        return f"[[{clean_path}#{heading}|{clean_label}]]"
    return f"[[{clean_path}|{clean_label}]]"


@dataclass
class Callout:
    path: str
    note_title: str
    type: str
    title: str
    inferred_title: str
    line: int
    heading_path: str
    block_id: str
    links: list[str]
    tags: list[str]
    formulas: list[str]
    first_sentence: str
    body: str
    summary: str
    source_link: str
    synthetic: bool = False

    @property
    def label(self) -> str:
        return self.title or self.inferred_title or f"{self.type} line {self.line}"


def extract_callouts(path: Path, text: str) -> list[Callout]:
    lines = text.splitlines()
    callouts: list[Callout] = []
    current = None

    def finish(block_id: str = ""):
        nonlocal current
        if not current:
            return
        body = "\n".join(current["body_lines"]).strip()
        heading_path = get_heading_path(lines, max(0, current["line"] - 1))
        formulas = [clean_snippet(match.group(1), 100) for match in INLINE_MATH.finditer(body)][:16]
        first_sentence = clean_snippet(
            re.split(r"(?<=[。！？.!?])\s+", re.sub(r"\$\$[\s\S]*?\$\$", " ", body))[0] or body,
            260,
        )
        title = current["title"]
        heading_tail = heading_path.split(" > ")[-1] if heading_path else ""
        inferred = title or clean_snippet(f"{heading_tail}: {first_sentence}", 140)
        relative = str(path).replace("/", "\\")
        source_link = make_source_link(relative, title or inferred or path.stem, block_id, heading_tail)
        callouts.append(
            Callout(
                path=relative,
                note_title=path.stem,
                type=current["type"],
                title=title,
                inferred_title=inferred,
                line=current["line"],
                heading_path=heading_path,
                block_id=block_id,
                links=extract_wiki_links(body)[:24],
                tags=extract_tags(body)[:16],
                formulas=formulas,
                first_sentence=first_sentence,
                body=limit_text(body, 3000),
                summary=clean_snippet(body, 850),
                source_link=source_link,
            )
        )
        current = None

    for index, line in enumerate(lines):
        match = CALLOUT_START.match(line)
        if match:
            finish()
            current = {
                "type": match.group(1).lower(),
                "title": match.group(3).strip(),
                "line": index + 1,
                "body_lines": [],
                "in_fence": False,
            }
            continue
        if not current:
            continue
        block_match = BLOCK_ID.match(line)
        if block_match and not current.get("in_fence"):
            finish(block_match.group(1))
        elif re.match(r"^\s*>", line):
            stripped = re.sub(r"^\s*>\s?", "", line)
            current["body_lines"].append(stripped)
            if stripped.strip().startswith("```"):
                current["in_fence"] = not current.get("in_fence")
        elif current.get("in_fence"):
            current["body_lines"].append(line)
            if line.strip().startswith("```"):
                current["in_fence"] = False
        elif not line.strip():
            current["body_lines"].append("")
        else:
            finish()
    finish()
    return callouts


def should_use_file(path: Path, vault: Path) -> bool:
    relative = path.relative_to(vault)
    if ".obsidian" in relative.parts:
        return False
    if relative.parts and relative.parts[0] == "AI Drafts":
        return False
    return path.suffix.lower() == ".md"


def load_callouts(vault: Path) -> tuple[list[Path], list[Callout], dict[str, str]]:
    files = [path for path in vault.rglob("*.md") if should_use_file(path, vault)]
    contents: dict[str, str] = {}
    callouts: list[Callout] = []
    for path in files:
        text = path.read_text(encoding="utf-8-sig", errors="ignore")
        relative = path.relative_to(vault)
        contents[str(relative).replace("/", "\\")] = text
        callouts.extend(extract_callouts(relative, text))
    return files, callouts, contents


def requested_types(query: str) -> set[str]:
    value = query.lower()
    result = set()
    if re.search(r"definition|定义|定義|概念|是什么|基本", value):
        result.update(["definition", "def"])
    if re.search(r"proposition|命题|命題", value):
        result.update(["proposition", "prop"])
    if re.search(r"theorem|定理", value):
        result.update(["theorem", "thm"])
    if re.search(r"lemma|引理", value):
        result.add("lemma")
    if re.search(r"proof|证明|證明", value):
        result.add("proof")
    if re.search(r"example|例子|例", value):
        result.add("example")
    if re.search(r"notation|记号|符号|記號|符號", value):
        result.add("notation")
    return result


def score_callout(item: Callout, query: str, terms: list[str]) -> float:
    focus = query_focus(query)
    parts = focus_parts(query)
    req = requested_types(query)
    title_text = f"{item.title} {item.inferred_title} {item.label}"
    locator = f"{item.path} {item.note_title} {item.heading_path} {item.block_id}"
    body_text = f"{item.first_sentence} {item.summary} {item.body}"
    score = 0.0
    score += line_score(title_text, terms) * 4.0
    score += line_score(locator, terms) * 2.2
    score += line_score(" ".join(item.links + item.formulas), terms) * 1.5
    score += line_score(body_text, terms) * 0.75
    if req:
        score += 42 if item.type in req else -12
    if item.block_id:
        score += 18
    if compact_equal(item.title, focus) or compact_equal(item.label, focus):
        score += 3200
    elif exactish_contains(title_text, focus):
        score += 1800
    if compact_equal(item.note_title, focus):
        score += 850
    elif exactish_contains(item.note_title, focus):
        score += 260
    if exactish_contains(item.heading_path, focus):
        score += 70
    if exactish_contains(item.path, focus):
        score += 55
    for part in parts:
        if compact_equal(item.title, part) or compact_equal(item.label, part):
            score += 1200
        elif exactish_contains(title_text, part):
            score += 420
        if compact_equal(item.note_title, part):
            score += 520
        elif exactish_contains(item.note_title, part):
            score += 150
        if re.search(r"[A-Za-z]", part) and exactish_contains(title_text, part):
            score += 700
    if len(parts) >= 2:
        title_or_locator_matches = [
            part for part in parts if exactish_contains(title_text, part) or exactish_contains(locator, part)
        ]
        title_matches = [part for part in parts if exactish_contains(title_text, part)]
        if len(title_or_locator_matches) >= 2:
            score += 360 + 120 * len(title_matches)
        else:
            score -= 220
        if all(exactish_contains(f"{title_text} {locator}", part) for part in parts):
            score += 1500
        if title_matches and any(exactish_contains(locator, part) for part in parts if part not in title_matches):
            score += 4500
    if item.type in {"definition", "def", "theorem", "thm", "proposition", "prop", "lemma", "corollary"}:
        score += 8
    if item.title:
        score += 6
    if item.line <= 25 and exactish_contains(item.note_title, focus):
        score += 55
    if re.search(r"定义|definition|是什么|基本|概念", query, re.I):
        if item.type in {"definition", "def"}:
            score += 25
            if compact_equal(item.title, focus) or compact_equal(item.note_title, focus):
                score += 3000
            if compact_equal(item.title, focus) or compact_equal(item.label, focus):
                score += 2200
            if item.line <= 25 and any(compact_equal(item.title, part) or compact_equal(item.note_title, part) for part in parts):
                score += 1250
        else:
            score -= 650
        if item.line <= 25 and (
            compact_equal(item.note_title, focus)
            or compact_equal(item.title, focus)
            or any(compact_equal(item.title, part) or compact_equal(item.note_title, part) for part in parts)
        ):
            score += 900
        if item.line > 220 and not any(exactish_contains(title_text, part) for part in parts):
            score -= 45
    if re.search(r"定理|theorem", query, re.I):
        if item.type in {"theorem", "thm"}:
            score += 35
        elif item.type in {"definition", "def"}:
            score -= 20
    if item.synthetic:
        score -= 550
    return score


def rank_callouts(callouts: list[Callout], query: str) -> list[tuple[float, Callout]]:
    terms = tokenize(query)
    return sorted(((score_callout(item, query, terms), item) for item in callouts), key=lambda pair: pair[0], reverse=True)


def resolve_source_link(item: Callout, contents: dict[str, str]) -> tuple[bool, str]:
    if item.synthetic:
        return False, "synthetic source should not be cited"
    text = contents.get(item.path)
    if text is None:
        return False, "file missing"
    if item.block_id:
        return (bool(re.search(rf"(?m)^\s*\^{re.escape(item.block_id)}\s*$", text)), f"block ^{item.block_id}")
    heading_tail = item.heading_path.split(" > ")[-1] if item.heading_path else ""
    if heading_tail and heading_tail != "(no heading)":
        return (bool(re.search(rf"(?m)^#{{1,6}}\s+{re.escape(heading_tail)}\s*$", text)), f"heading {heading_tail}")
    return True, "note-level fallback"


TESTS = [
    ("C星代数 是什么", "泛函分析\\C星代数\\C星代数.md", 4, 2),
    ("C*代数的表示是什么", "泛函分析\\C星代数\\C星代数的表示.md", 3, 3),
    ("C星代数表示间的态射", "泛函分析\\C星代数\\C星代数的表示.md", 15, 3),
    ("拓扑向量空间 基本定义", "泛函分析\\拓扑向量空间\\拓扑向量空间的理论部分.md", 3, 2),
    ("拓扑向量空间 度量化定理", "泛函分析\\拓扑向量空间\\拓扑向量空间的理论部分.md", 174, 2),
    ("解析集 定义 多复变函数", "多复变函数\\解析集.md", 3, 2),
    ("多重次调和函数 Hartogs引理", "多复变函数\\多重次调和函数.md", 160, 3),
    ("Levi拟凸域 Narasimhan", "多复变函数\\凸性理论\\Levi拟凸域.md", 155, 3),
    ("解析分歧覆盖 局部典则表示", "多复变函数\\解析分歧覆盖\\解析分歧覆盖.md", 63, 3),
    ("Grothendieck拓扑 定义", "拓扑斯理论\\Grothendieck拓扑.md", 23, 3),
    ("子对象分类子 定义", "拓扑斯理论\\子对象分类子.md", 32, 3),
    ("几何态射 定义", "拓扑斯理论\\几何态射.md", 5, 2),
    ("Quillen伴随 定义", "模型范畴\\Quillen伴随.md", 3, 2),
    ("谱序列 定义", "同调代数\\谱序列\\谱序列.md", 4, 2),
    ("Galois基本定理", "Galois理论\\理论部分\\Galois对应.md", 23, 2),
    ("Hahn-Banach定理", "泛函分析\\Hahn-Banach定理.md", 16, 3),
    ("Abel范畴 定义", "范畴论\\Abel范畴\\Abel范畴.md", 290, 5),
    ("NIP 定义", "模型论\\稳定性理论\\NIP.md", 4, 3),
    ("光滑态射 Jacobian判别法", "代数几何\\光滑态射.md", 244, 3),
    ("局部小的纤维范畴 定义", "范畴论\\纤维范畴\\局部小的纤维范畴.md", 8, 3),
]


def synthetic_callout(path: str, title: str, body: str, type_: str = "definition") -> Callout:
    label = title or clean_snippet(body, 80)
    return Callout(
        path=path,
        note_title=Path(path).stem,
        type=type_,
        title=title,
        inferred_title=label,
        line=1,
        heading_path="Synthetic",
        block_id="",
        links=[],
        tags=[],
        formulas=[],
        first_sentence=clean_snippet(body, 220),
        body=body,
        summary=clean_snippet(body, 850),
        source_link=make_source_link(path, label),
        synthetic=True,
    )


def round_callouts(base: list[Callout], round_name: str) -> list[Callout]:
    if round_name == "round-1-base":
        return base
    generic = [
        synthetic_callout("__synthetic__\\泛函分析摘录.md", "C星代数和表示的应用", "C星代数 表示 态射 Gelfand Naimark 正锥 连续函数演算 " * 8),
        synthetic_callout("__synthetic__\\多复变函数摘录.md", "多复变函数常用定理", "解析集 多重次调和函数 Hartogs Levi拟凸域 Narasimhan 全纯映射 " * 8, "theorem"),
        synthetic_callout("__synthetic__\\拓扑斯导读.md", "拓扑斯相关概念", "Grothendieck拓扑 子对象分类子 几何态射 层范畴 预层范畴 " * 8),
        synthetic_callout("__synthetic__\\代数几何导读.md", "光滑态射与Jacobian", "光滑态射 Jacobian判别法 有限表示 纤维 正则序列 " * 8, "theorem"),
        synthetic_callout("__synthetic__\\范畴论导读.md", "Abel范畴若干概念", "预加性范畴 加性范畴 Abel范畴 正合列 核 余核 " * 8),
    ]
    if round_name == "round-2-generic-new-notes":
        return [*base, *generic]
    adversarial = [
        synthetic_callout("__synthetic__\\泛函分析\\C星代数应用速记.md", "矩阵C星代数的表示例子", "C星代数的表示是什么 C星代数 表示 表示间态射 " * 10),
        synthetic_callout("__synthetic__\\多复变函数\\Levi拟凸域应用.md", "Levi强拟凸域的应用", "Levi拟凸域 Narasimhan theorem 拟凸 强拟凸 穷竭 " * 10, "proposition"),
        synthetic_callout("__synthetic__\\Galois理论\\Galois基本定理应用.md", "无限Galois基本定理的应用", "Galois基本定理 Galois对应 无限Galois扩张 子群 子域 " * 10, "proposition"),
        synthetic_callout("__synthetic__\\模型范畴\\Quillen应用.md", "Quillen伴随应用", "Quillen伴随 定义 Quillen等价 模型范畴 导出函子 " * 10, "remark"),
        synthetic_callout("__synthetic__\\模型论\\NIP应用.md", "NIP例子", "NIP 定义 稳定性理论 交错数 诚实定义 " * 10, "example"),
    ]
    return [*base, *generic, *adversarial]


def main() -> int:
    files, callouts, contents = load_callouts(VAULT)
    rounds = ["round-1-base", "round-2-generic-new-notes", "round-3-adversarial-new-notes"]
    total = 0
    passed = 0
    lines = [
        "# Knowledge Citation Evaluation",
        "",
        f"- Vault: `{VAULT}`",
        f"- Formal Markdown files used: `{len(files)}`",
        f"- Real callout units: `{len(callouts)}`",
        f"- Tests per round: `{len(TESTS)}`",
        f"- Rounds: `{len(rounds)}`",
        "- Pass criteria: expected callout appears within required rank and its generated Obsidian source link resolves to the real file anchor.",
        "",
    ]
    for round_name in rounds:
        units = round_callouts(callouts, round_name)
        round_passed = 0
        lines.append(f"## {round_name}")
        lines.append("")
        for query, must_path, must_line, top in TESTS:
            total += 1
            ranked = rank_callouts(units, query)
            hit_position = None
            hit_item = None
            for index, (_score, item) in enumerate(ranked[:top], start=1):
                if item.path == must_path and item.line == must_line:
                    hit_position = index
                    hit_item = item
                    break
            link_ok = False
            link_reason = "no hit"
            if hit_item:
                link_ok, link_reason = resolve_source_link(hit_item, contents)
            precise_enough = bool(hit_item and hit_item.block_id) or link_reason.startswith("heading ")
            ok = hit_position is not None and link_ok and precise_enough
            if ok:
                passed += 1
                round_passed += 1
            lines.append(f"### {'PASS' if ok else 'FAIL'} `{query}`")
            lines.append(f"- Expected: `{must_path}:{must_line}` in top {top}")
            lines.append(f"- Actual: {f'hit #{hit_position}' if hit_position else 'not found in required range'}")
            lines.append(f"- Source link: `{hit_item.source_link if hit_item else '(none)'}`")
            lines.append(f"- Link validation: `{link_reason}`")
            lines.append("- Top candidates:")
            for index, (score, item) in enumerate(ranked[: max(5, top)], start=1):
                marker = " <= expected" if item.path == must_path and item.line == must_line else ""
                synth = " synthetic" if item.synthetic else ""
                lines.append(
                    f"  {index}. `{score:.1f}` `{item.path}:{item.line}` [{item.type}{synth}] {item.label} -> `{item.source_link}`{marker}"
                )
            lines.append("")
        lines.append(f"Round summary: `{round_passed}/{len(TESTS)}` passed.")
        lines.append("")
    lines.insert(1, f"\nSummary: `{passed}/{total}` citation tests passed.\n")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} citation tests passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
