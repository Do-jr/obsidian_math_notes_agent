import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN_MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
PLUGIN_CSS = ROOT / "local-note-assistant-stage3" / "styles.css"
PLUGIN_MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
REPORT = ROOT / "tools" / "chatgpt_handoff_eval_report.md"


def file_contains(path, text):
    return text in path.read_text(encoding="utf-8")


def parse_file_blocks(output):
    text = str(output or "").strip()
    pattern = re.compile(r"^FILE:\s*(.+?\.md)\s*$", re.I | re.M)
    matches = list(pattern.finditer(text))
    if not matches:
        return [("Imported.md", text)] if text else []
    files = []
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        body = text[start:end].strip()
        if body:
            files.append((match.group(1), body))
    return files[:20]


def prompt_has_required_contract(prompt):
    required = [
        "# ChatGPT Handoff Prompt",
        "## Task",
        "## Prompt Mode",
        "## Output Contract",
        "## Source Boundary Rules",
        "## Retrieved Note Evidence",
        "## Final Instruction",
    ]
    return all(item in prompt for item in required)


SIMULATED_PROMPT = """# ChatGPT Handoff Prompt

## Task
整理 C星代数的表示。

## Prompt Mode
Mode: note completion. Use the provided note evidence first. You may add model-supplied background, examples, or missing steps, but every such addition must be explicitly labeled as 模型补充.

## Output Contract
Return one concise Obsidian Markdown file.

## Source Boundary Rules
- The numbered excerpts below are the only note evidence.
- Copy Obsidian links exactly when citing sources.
- Never invent headings, block anchors, note names, or source links.
- Use the exact label 模型补充 for model additions.

## Required Working Method
Do this silently before writing the final Markdown.

## Final Quality Checklist
- The final output is importable Markdown.

## Retrieved Note Evidence
[1] [[C星代数#表示]]
Excerpt...

## Final Instruction
Now produce the requested output.
"""


SIMULATED_MULTI_FILE = """FILE: C星代数/Overview.md
# C星代数
内容

FILE: C星代数/GNS表示.md
# GNS表示
内容
"""


STATIC_CHECKS = [
    ("manifest 0.4.85", PLUGIN_MANIFEST, '"version": "0.4.85"'),
    ("handoff default folder", PLUGIN_MAIN, 'handoffFolder: "AI Handoffs"'),
    ("handoff prompt limit setting", PLUGIN_MAIN, "maxHandoffPromptChars"),
    ("six handoff modes method", PLUGIN_MAIN, "getChatGptHandoffModes"),
    ("notes only mode", PLUGIN_MAIN, '"notes_only"'),
    ("note completion mode", PLUGIN_MAIN, '"note_completion"'),
    ("proof completion mode", PLUGIN_MAIN, '"proof_completion"'),
    ("topic synthesis mode", PLUGIN_MAIN, '"topic_synthesis"'),
    ("multi file mode", PLUGIN_MAIN, '"multi_file"'),
    ("check mode", PLUGIN_MAIN, '"check"'),
    ("handoff prompt builder", PLUGIN_MAIN, "buildChatGptHandoffPrompt"),
    ("handoff quality checker", PLUGIN_MAIN, "checkChatGptHandoffPrompt"),
    ("handoff package writer", PLUGIN_MAIN, "PROMPT.md"),
    ("handoff output importer", PLUGIN_MAIN, "importChatGptHandoffOutput"),
    ("handoff clipboard output reader", PLUGIN_MAIN, "readClipboardOutput"),
    ("handoff markdown file reader", PLUGIN_MAIN, "readMarkdownOutputFiles"),
    ("handoff prompt working method", PLUGIN_MAIN, "Required Working Method"),
    ("handoff prompt quality checklist", PLUGIN_MAIN, "Final Quality Checklist"),
    ("handoff prompt exact model label", PLUGIN_MAIN, "Use the exact label"),
    ("handoff protocol v2", PLUGIN_MAIN, "Local Note Assistant GPT Protocol v2"),
    ("handoff file contract", PLUGIN_MAIN, "Return exactly one importable Obsidian Markdown file"),
    ("handoff no commentary outside file block", PLUGIN_MAIN, "no commentary outside the required FILE block"),
    ("safe relative markdown path", PLUGIN_MAIN, "sanitizeRelativeMarkdownPath"),
    ("toolbar button", PLUGIN_MAIN, 'text("chatGptHandoffButton")'),
    ("handoff modal css", PLUGIN_CSS, "lna-handoff-modal"),
]


RUNTIME_CHECKS = [
    ("prompt contract sections", lambda: prompt_has_required_contract(SIMULATED_PROMPT), True),
    ("prompt labels model additions", lambda: "模型补充" in SIMULATED_PROMPT, True),
    ("prompt forbids invented links", lambda: "Never invent headings" in SIMULATED_PROMPT, True),
    ("multi-file parser count", lambda: len(parse_file_blocks(SIMULATED_MULTI_FILE)), 2),
    ("multi-file parser first path", lambda: parse_file_blocks(SIMULATED_MULTI_FILE)[0][0], "C星代数/Overview.md"),
    ("single-file parser fallback", lambda: len(parse_file_blocks("# Single file")), 1),
]


def main():
    total = 0
    passed = 0
    lines = ["# ChatGPT Handoff Evaluation", ""]

    lines.append("## Static Checks")
    for name, path, needle in STATIC_CHECKS:
        total += 1
        ok = file_contains(path, needle)
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        if not ok:
            lines.append(f"  - missing: `{needle}`")

    lines.append("")
    lines.append("## Simulated Prompt / Import Checks")
    for name, fn, expected in RUNTIME_CHECKS:
        total += 1
        try:
            actual = fn()
            ok = actual == expected
        except Exception as error:
            actual = f"ERROR: {error}"
            ok = False
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        lines.append(f"  - actual: `{actual}`")
        lines.append(f"  - expected: `{expected}`")

    lines.insert(2, f"Overall: `{passed}/{total}` checks passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} checks passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
