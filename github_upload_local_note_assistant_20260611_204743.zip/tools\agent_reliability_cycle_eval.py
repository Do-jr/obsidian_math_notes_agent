import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
CSS = ROOT / "local-note-assistant-stage3" / "styles.css"
MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
REPORT = ROOT / "tools" / "agent_reliability_cycle_eval_report.md"


def read(path):
    return path.read_text(encoding="utf-8")


MAIN_TEXT = read(MAIN)
CSS_TEXT = read(CSS)


def contains(text):
    return text in MAIN_TEXT


def css_contains(text):
    return text in CSS_TEXT


def manifest_version():
    return json.loads(read(MANIFEST)).get("version")


def route_expectation(text):
    value = str(text or "")
    if re.search(r"正式笔记|formal note", value, re.I) and re.search(r"修改|删除|替换|改掉|modify|delete|replace", value, re.I):
        return "formal_note_proposal"
    if re.search(r"记忆|历史对话|memory", value, re.I) and re.search(r"打开|查看|管理|删除|回到|open|show|manage", value, re.I):
        return "memory"
    if re.search(r"知识索引|knowledge", value, re.I):
        return "knowledge"
    if re.search(r"迁移审阅|review", value, re.I):
        return "migration_review"
    if re.search(r"迁移工具|migration", value, re.I):
        return "migration_tool"
    if re.search(r"ChatGPT|GPT|handoff|交接", value, re.I):
        return "chatgpt_handoff"
    if re.search(r"检查.*索引|索引.*变化|check.*index", value, re.I):
        return "check_index_changes"
    if re.search(r"更新.*索引|update.*index", value, re.I):
        return "update_changed_index"
    if re.search(r"重建.*索引|rebuild.*index", value, re.I):
        return "build_index"
    if re.search(r"截图|图片|image|ocr|pdf", value, re.I):
        return "image_to_markdown"
    if re.search(r"空白|新建|创建", value, re.I) and re.search(r"草稿|文档|笔记", value, re.I):
        return "create_blank_draft"
    if re.search(r"选中|selection|selected", value, re.I) and re.search(r"改写|润色|修改", value, re.I):
        return "edit_selection"
    if re.search(r"当前草稿|全文|整篇", value, re.I) and re.search(r"改写|整理|优化|补全", value, re.I):
        return "edit_current_draft"
    if re.search(r"刚才|之前|上一轮|previous|earlier", value, re.I) and re.search(r"插入|加入|放到|insert|append", value, re.I):
        return "agent_task"
    if re.search(r"插入|加入|放到|insert|append", value, re.I):
        return "insert_into_draft"
    if re.search(r"整理|总结|综述|生成", value, re.I) and re.search(r"文件|笔记|资料|页面|draft", value, re.I):
        return "generate_draft"
    return "search_answer"


def insertion_candidate(lines, target):
    target = str(target or "").lstrip("#").strip().lower()
    best = None
    for index, line in enumerate(lines):
      candidates = []
      heading = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
      if heading:
          candidates.append(("heading", heading.group(2), 6))
      comment = re.search(r"<!--\s*([^>]{1,100}?)\s*-->", line)
      if comment:
          candidates.append(("marker", comment.group(1), 8))
      tag = re.match(r"^#([A-Za-z0-9_\-\u4e00-\u9fff]{1,100})$", line.strip())
      if tag:
          candidates.append(("tag", "#" + tag.group(1), 8))
      for kind, label, bonus in candidates:
          clean = label.lower().lstrip("#")
          score = (10 if target and target in clean else 0) + bonus
          if score > 0 and (best is None or score > best["score"]):
              best = {"kind": kind, "text": label, "line": index, "score": score}
    return best


ROUND_1 = [
    ("formal note direct modification routes to proposal", lambda: route_expectation("请直接修改正式笔记A里的旧记号"), "formal_note_proposal"),
    ("open memory natural language", lambda: route_expectation("打开历史对话记忆"), "memory"),
    ("open knowledge natural language", lambda: route_expectation("查看知识索引"), "knowledge"),
    ("open migration tool", lambda: route_expectation("呼出迁移工具"), "migration_tool"),
    ("open migration review", lambda: route_expectation("打开迁移审阅表格"), "migration_review"),
    ("open handoff", lambda: route_expectation("打开 ChatGPT 交接模式"), "chatgpt_handoff"),
    ("check index", lambda: route_expectation("检查索引有没有变化"), "check_index_changes"),
    ("update index", lambda: route_expectation("更新变更索引"), "update_changed_index"),
    ("rebuild index", lambda: route_expectation("完整重建索引"), "build_index"),
    ("image route", lambda: route_expectation("把截图里的证明转成 markdown"), "image_to_markdown"),
    ("blank draft route", lambda: route_expectation("创建一个空白草稿，主题是层"), "create_blank_draft"),
    ("selected rewrite route", lambda: route_expectation("把选中段落润色一下"), "edit_selection"),
    ("current draft route", lambda: route_expectation("改写当前草稿全文"), "edit_current_draft"),
    ("prior insertion route", lambda: route_expectation("把刚才那个证明放到 #tag2 后面"), "agent_task"),
    ("plain insertion route", lambda: route_expectation("在 #pp 后面插入一个定义"), "insert_into_draft"),
    ("topic file route", lambda: route_expectation("整理 C 星代数和表示，生成一个文件"), "generate_draft"),
    ("plain question route", lambda: route_expectation("C 星代数的表示有什么应用"), "search_answer"),
]


ROUND_2 = [
    ("agent plan summary method exists", lambda: contains("summarizeAgentPlan(prompt, state, steps)"), True),
    ("agent step formatter exists", lambda: contains("formatAgentPlanStep(step, index)"), True),
    ("plan summary UI key exists", lambda: contains("agentPlanSummary"), True),
    ("plan summary CSS exists", lambda: css_contains("lna-agent-plan-summary"), True),
    ("formal proposal in tool catalog", lambda: contains('action: "formal_note_proposal"'), True),
    ("formal proposal route handled", lambda: contains("route && route.action === \"formal_note_proposal\""), True),
    ("formal proposal generator exists", lambda: contains("generateFormalNoteProposal(instruction)"), True),
    ("formal proposal no-write message exists", lambda: contains("formalProposalNoWrite"), True),
    ("normalize steps allows formal proposal", lambda: contains("\"formal_note_proposal\","), True),
    ("relevant memory summaries exist", lambda: contains("getRelevantMemorySummaries(query = \"\""), True),
    ("memory stats exist", lambda: contains("getMemoryStats()"), True),
    ("agent state carries relevant memory", lambda: contains("relevantMemory: this.plugin.getRelevantMemorySummaries"), True),
    ("agent state carries memory stats", lambda: contains("memoryStats: this.plugin.getMemoryStats"), True),
    ("artifact fallback can use memory", lambda: contains("memoryText &&") and contains("bestScore === 0"), True),
    ("insertion candidate helper exists", lambda: contains("getDraftInsertionCandidatesFromLines"), True),
    ("insertion fuzzy summary exists", lambda: contains("fuzzy target="), True),
    ("insertion marker fallback summary exists", lambda: contains("created marker="), True),
    ("candidate simulation finds heading", lambda: insertion_candidate(["# 预备", "## tag2 证明"], "tag2")["kind"], "heading"),
    ("candidate simulation finds marker", lambda: insertion_candidate(["<!-- theorem-slot -->"], "theorem")["kind"], "marker"),
]


ROUND_3 = [
    ("topic coverage report method exists", lambda: contains("buildTopicSynthesisCoverageReport"), True),
    ("topic coverage source count exists", lambda: contains("Retrieved excerpts"), True),
    ("topic coverage candidate count exists", lambda: contains("Knowledge coverage candidates"), True),
    ("topic coverage callout count exists", lambda: contains("Callout evidence blocks considered"), True),
    ("source heading is clean", lambda: contains("## 检索来源索引"), True),
    ("generated file includes coverage report", lambda: contains("${coverageReport}${sources}"), True),
    ("AI generated remains excluded from index", lambda: contains("AI generated") and contains("shouldUseFileForSearch"), True),
    ("self-check clean Chinese result label", lambda: contains("结果：一句话说明是否完成"), True),
    ("self-check clean Chinese position label", lambda: contains("位置：一句话说明内容大概放在哪里"), True),
    ("self-check clean Chinese attention label", lambda: contains("注意：如果发现重复"), True),
    ("router prompt knows formal proposal", lambda: contains("formal_note_proposal: read formal notes"), True),
    ("router rejects formal direct write", lambda: contains("choose formal_note_proposal unless"), True),
    ("local formal direct write proposal", lambda: contains("formal note safety proposal"), True),
    ("plan summary shows read-only", lambda: contains("agentPlanReadOnly"), True),
    ("plan summary shows draft-only", lambda: contains("agentPlanDraftOnly"), True),
    ("manifest version", manifest_version, "0.4.85"),
]


ROUNDS = [
    ("Round 1: natural-language routing", ROUND_1),
    ("Round 2: context, memory, insertion, and plan confirmation", ROUND_2),
    ("Round 3: topic synthesis, safety, and self-check", ROUND_3),
]


def main():
    passed = 0
    total = 0
    lines = ["# Agent Reliability Cycle Evaluation", ""]
    for round_name, tests in ROUNDS:
        round_passed = 0
        lines.append(f"## {round_name}")
        lines.append(f"Checks: `{len(tests)}`")
        lines.append("")
        for name, fn, expected in tests:
            total += 1
            try:
                actual = fn()
                ok = actual == expected
            except Exception as error:
                actual = f"ERROR: {error}"
                ok = False
            passed += int(ok)
            round_passed += int(ok)
            lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
            lines.append(f"  - actual: `{actual}`")
            lines.append(f"  - expected: `{expected}`")
        lines.append("")
        lines.append(f"Round result: `{round_passed}/{len(tests)}` passed.")
        lines.append("")
    lines.insert(2, f"Summary: `{passed}/{total}` checks passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} checks passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
