import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN_MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
PLUGIN_MANIFEST = ROOT / "local-note-assistant-stage3" / "manifest.json"
REPORT = ROOT / "tools" / "agent_multiround_sim_eval_report.md"


def normalize(value):
    return str(value or "").lower()


def extract_target(text):
    value = str(text or "")
    wiki = re.search(r"\[\[([^\]\n]+)\]\]", value)
    if wiki:
        return wiki.group(1).strip()
    html = re.search(r"<!--\s*([^>]+?)\s*-->", value)
    if html:
        return html.group(1).strip()
    tag = re.search(r"(^|[\s,，。；;:：()（）])#([A-Za-z0-9_\-/\u0080-\uffff]+)", value)
    if tag:
        return "#" + tag.group(2)
    named = re.search(r"\b(tag[0-9A-Za-z_-]+)\b", value, re.I)
    return named.group(1) if named else ""


def parse_keyword(text):
    value = str(text or "")
    match = re.match(r"\s*(?:\[([^\]\n]{1,32})\]|【([^】\n]{1,32})】)\s*", value)
    if not match:
        return "", value.strip()
    raw = re.sub(r"[\s_\-:：]+", "", match.group(1) or match.group(2) or "").lower()
    actions = {
        "问答": "search_answer",
        "搜索": "search_answer",
        "查找": "search_answer",
        "主题整理": "topic_synthesis",
        "主题笔记": "topic_synthesis",
        "生成草稿": "generate_draft",
        "草稿": "generate_draft",
        "空白草稿": "create_blank_draft",
        "新建草稿": "create_blank_draft",
        "插入草稿": "insert_into_draft",
        "追加草稿": "insert_into_draft",
        "改写草稿": "edit_current_draft",
        "修改草稿": "edit_current_draft",
        "改写选中": "edit_selection",
        "修改选中": "edit_selection",
        "图片转写": "image_to_markdown",
        "截图转写": "image_to_markdown",
        "迁移工具": "migration_tool",
        "迁移": "migration_tool",
        "迁移审阅": "migration_review",
        "迁移表格": "migration_review",
        "知识索引": "knowledge",
        "知识": "knowledge",
        "记忆": "memory",
        "对话记忆": "memory",
        "暂停ai": "pause_ai",
        "暂停": "pause_ai",
        "恢复ai": "resume_ai",
        "继续ai": "resume_ai",
    }
    return actions.get(raw, ""), value[match.end() :].strip()


def infer_action(text, state):
    forced, stripped = parse_keyword(text)
    if forced:
        return forced
    value = stripped
    lower = normalize(value)
    target = extract_target(value)
    has_image = bool(state.get("hasImage"))
    has_draft = bool(state.get("hasCurrentDraft"))
    has_selection = bool(state.get("hasDraftSelection"))
    prior = re.search(r"刚才|刚刚|刚生成|上面|之前|上一条|上一轮|这个回答|这个证明|这段回答|那段|前述|last|previous|above|earlier", value, re.I)
    transform_prior = prior and re.search(r"改写|重写|润色|整理|总结|摘要|压缩|扩写|补全|改成|变成|转成|格式|rewrite|summarize|polish|convert", lower)

    if re.search(r"不满意|不好|不对|错了|有问题|失败|编造|幻觉|引用错|来源错|bad answer|unsatisfied|wrong response", value, re.I) and re.search(
        r"这次|刚才|刚刚|上次|上一轮|回答|答案|结果|你|answer|response|previous|last", value, re.I
    ):
        return "negative_feedback"
    if re.search(r"暂停\s*ai|暂停模型|关闭\s*ai|先不要调用模型|不要调用模型|pause", lower):
        return "pause_ai"
    if re.search(r"恢复\s*ai|继续\s*ai|开启\s*ai|启用\s*ai|resume", lower):
        return "resume_ai"
    if re.search(r"记忆|对话记录|历史对话|memory", lower) and re.search(r"打开|查看|进入|展开|管理|删除|回到|继续|open|show|view|manage", lower):
        return "memory"
    if re.search(r"知识索引|概念索引|知识图谱|knowledge", lower) and re.search(r"打开|查看|进入|刷新|构建|建立|重建|open|show|view|build|refresh", lower):
        return "knowledge"
    if re.search(r"迁移|链接替换|符号替换|migration", lower) and re.search(r"审阅|审核|表格|review", lower) and re.search(r"打开|查看|进入|open|show|view", lower):
        return "migration_review"
    if re.search(r"迁移|链接替换|符号替换|migration", lower) and re.search(r"工具|页面|面板|打开|进入|呼出|使用|open|tool|panel", lower):
        return "migration_tool"
    if re.search(r"chatgpt|gpt|prompt\s*包|prompt\s*package|handoff|交接", value, re.I) and re.search(
        r"打开|生成|创建|导入|粘贴|复制|模式|包|文件|open|generate|create|import|paste|copy", value, re.I
    ):
        return "chatgpt_handoff"
    if re.search(r"迁移|替代|取代|更新|改成|改为|链接|migrate|replace", lower) and re.search(r"\[\[[^\]]+\]\].*?\[\[[^\]]+\]\]", value):
        return "note_migration_scan"
    if has_image and re.search(r"图片|截图|图像|图里|照片|识别|转\s*markdown|转成\s*md|pdf|证明|公式|image|screenshot|ocr", lower):
        return "image_to_markdown"
    if re.search(r"空白|新建|创建|建立|打开|开一页|开个|blank", lower) and re.search(r"草稿|文档|笔记|draft|note|页面", lower):
        return "create_blank_draft"
    if has_selection and re.search(r"选中|这段|当前段落|所选|selected|selection", lower) and re.search(r"改写|修改|润色|优化|替换|扩写|整理|证明|补齐|rewrite|edit|replace", lower):
        return "edit_selection"
    if has_draft and re.search(r"当前草稿|当前文档|这篇草稿|整个草稿|这篇|本文|整篇|current draft|whole draft|draft", lower) and re.search(r"改写|修改|重写|整理|优化|扩写|补全|润色|rewrite|edit|improve|polish", lower):
        return "edit_current_draft"
    if re.search(r"正式笔记|正式文档|原笔记|formal note|formal notes", lower) and re.search(r"改掉|修改|删除|替换|直接改|覆写|remove|delete|replace|modify", lower):
        return "search_answer"
    if re.search(r"整理|梳理|总结|综述|汇总|生成|写一篇|做一个|做成|整理成|形成", lower) and re.search(r"文件|文档|笔记|草稿|ai generated|draft|note|页面|资料", lower):
        return "generate_draft"
    if re.search(r"插入|加入|添加|放到|放进|写到|写进|追加|塞到|置于|append|insert|add", lower) and (target or re.search(r"草稿|draft|后面|前面|之前|之后|下面|上面|末尾|开头", lower)):
        return "agent_task" if prior or transform_prior else "insert_into_draft"
    return "search_answer"


def infer_steps(text):
    value = str(text or "")
    prior = re.search(r"刚才|刚刚|刚生成|上面|之前|上一条|上一轮|这个回答|这个证明|这段回答|那段|前述|last|previous|above|earlier", value, re.I)
    if not prior:
        return []
    steps = ["use_artifact"]
    if re.search(r"改写|重写|润色|整理|总结|摘要|压缩|扩写|补全|改成|变成|转成|格式|rewrite|summarize|polish|convert", value, re.I):
        steps.append("generate_markdown")
    steps.append("insert_into_draft")
    return steps


ROUNDS = [
    {
        "name": "Round 1 - Chinese note Q&A and synthesis",
        "initial": {},
        "turns": [
            ("我有点忘了 C星代数的表示 是怎么定义的，帮我回忆一下", "search_answer"),
            ("这次回答不满意，因为引用错了并且编造了不存在的定义", "negative_feedback"),
            ("这有什么应用？", "search_answer"),
            ("以多复变函数为主题整理一份可放进 AI generated 的笔记", "generate_draft"),
            ("开一页新的空白草稿，标题叫 多复变复习", "create_blank_draft", {"hasCurrentDraft": True}),
            ("把刚才生成的那段放进 #tag2 下面", "agent_task", None, ["use_artifact", "insert_into_draft"]),
            ("将上一轮关于 NIP 的回答改成命题-证明格式，然后放到 tag1", "agent_task", None, ["use_artifact", "generate_markdown", "insert_into_draft"]),
        ],
    },
    {
        "name": "Round 2 - screenshot, draft editing, and voice-like commands",
        "initial": {"hasCurrentDraft": True},
        "turns": [
            ("把图里这段证明识别成 md", "image_to_markdown", {"hasImage": True}),
            ("当前草稿整体润色，保留公式和引用", "edit_current_draft"),
            ("把选中的证明补齐，缺失步骤用 TODO 标注", "edit_selection", {"hasDraftSelection": True}),
            ("[主题整理] Grothendieck 拓扑与层", "topic_synthesis"),
            ("[图片转写] 这个截图里的公式转成 Obsidian Markdown", "image_to_markdown", {"hasImage": True}),
            ("暂停 AI，先只做本地搜索", "pause_ai", {"aiPaused": True}),
            ("恢复 AI", "resume_ai", {"aiPaused": False}),
        ],
    },
    {
        "name": "Round 3 - panels, migration, safety boundaries",
        "initial": {"hasCurrentDraft": True},
        "turns": [
            ("打开知识索引让我看看", "knowledge"),
            ("打开记忆面板，回到之前那个 C星代数对话", "memory"),
            ("生成一个 ChatGPT 交接 prompt 包，用来整理 C星代数的表示", "chatgpt_handoff"),
            ("我要处理链接迁移，打开迁移工具", "migration_tool"),
            ("打开迁移审阅表格", "migration_review"),
            ("我想迁移 [[旧A]] 到 [[新B]]，先扫描不要修改", "note_migration_scan"),
            ("把正式笔记A直接改掉", "search_answer"),
            ("检查当前草稿的来源引用有没有错", "search_answer"),
        ],
    },
]


STATIC_CHECKS = [
    ("natural pause route", 'reason: "pause ai"'),
    ("natural memory route", 'reason: "open memory panel"'),
    ("natural knowledge route", 'reason: "open knowledge panel"'),
    ("natural migration tool route", 'reason: "open migration tool"'),
    ("natural migration review route", 'reason: "open migration review"'),
    ("route handler opens memory", 'route && route.action === "memory"'),
    ("route handler opens knowledge", 'route && route.action === "knowledge"'),
    ("route handler opens migration tool", 'route && route.action === "migration_tool"'),
    ("route handler pauses AI", 'route && route.action === "pause_ai"'),
    ("bilingual migration labels", 'text("migrationOriginal")'),
    ("bilingual provider labels", 'text("providerUseChat")'),
    ("voice command normalizer", "normalizeVoiceCommandText"),
    ("unsatisfied feedback handler", "handleUnsatisfiedFeedbackPrompt"),
    ("unsatisfied feedback modal", "class NegativeFeedbackModal extends Modal"),
    ("unsatisfied feedback prompt block", "Unsatisfied-answer feedback to avoid repeating"),
    ("unsatisfied feedback in agent state", "negativeFeedback: this.plugin.getNegativeFeedbackSummaries"),
    ("ChatGPT handoff route", 'reason: "open ChatGPT handoff"'),
    ("ChatGPT handoff modal", "class ChatGptHandoffModal extends Modal"),
    ("ChatGPT handoff import parser", "parseChatGptHandoffFiles"),
]


def run_round(round_spec):
    state = dict(round_spec.get("initial") or {})
    rows = []
    passed = 0
    for index, item in enumerate(round_spec["turns"], 1):
        prompt, expected = item[0], item[1]
        overrides = item[2] if len(item) > 2 and isinstance(item[2], dict) else {}
        expected_steps = item[3] if len(item) > 3 else None
        effective_state = {**state, **overrides}
        actual = infer_action(prompt, effective_state)
        actual_steps = infer_steps(prompt) if actual == "agent_task" else []
        ok = actual == expected and (expected_steps is None or actual_steps == expected_steps)
        passed += int(ok)
        rows.append((index, ok, prompt, actual, expected, actual_steps, expected_steps, dict(effective_state)))
        if ok:
            if expected in {"create_blank_draft", "generate_draft", "topic_synthesis"}:
                state["hasCurrentDraft"] = True
            if expected == "image_to_markdown":
                state["hasImage"] = False
            if expected == "pause_ai":
                state["aiPaused"] = True
            if expected == "resume_ai":
                state["aiPaused"] = False
    return passed, rows


def main():
    source = PLUGIN_MAIN.read_text(encoding="utf-8")
    total = 0
    passed = 0
    lines = ["# Agent Multi-Round Simulation Evaluation", ""]

    for name, needle in STATIC_CHECKS:
        total += 1
        ok = needle in source
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} static: {name}")
        if not ok:
            lines.append(f"  - missing: `{needle}`")

    lines.append("")
    lines.append("## Simulated Conversations")
    for round_spec in ROUNDS:
        round_passed, rows = run_round(round_spec)
        passed += round_passed
        total += len(rows)
        lines.append("")
        lines.append(f"### {round_spec['name']}")
        lines.append(f"Summary: `{round_passed}/{len(rows)}` turns passed.")
        for index, ok, prompt, actual, expected, actual_steps, expected_steps, state in rows:
            lines.append(f"- {'PASS' if ok else 'FAIL'} turn {index}: `{prompt}`")
            lines.append(f"  - state: `{state}`")
            lines.append(f"  - actual: `{actual}`, expected: `{expected}`")
            if expected_steps is not None:
                lines.append(f"  - steps: `{actual_steps}`, expected: `{expected_steps}`")

    lines.insert(2, f"Overall: `{passed}/{total}` checks passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} checks passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
