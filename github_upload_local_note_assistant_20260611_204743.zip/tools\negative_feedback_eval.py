import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN_MAIN = ROOT / "local-note-assistant-stage3" / "main.js"
PLUGIN_CSS = ROOT / "local-note-assistant-stage3" / "styles.css"
REPORT = ROOT / "tools" / "negative_feedback_eval_report.md"


def classify(question="", reason="", answer=""):
    value = f"{question}\n{reason}\n{answer}".lower()
    checks = [
        ("citation-error", r"引用|来源|出处|链接|锚点|source|citation|anchor|link"),
        ("hallucination", r"编造|胡说|不存在|笔记里没有|没有证据|invent|hallucinat|unsupported"),
        ("missing-context", r"漏|遗漏|没找到|未找到|不完整|缺少|截断|context|missing|truncated"),
        ("wrong-tool", r"工具|功能|没有插入|没有修改|只回答|草稿|迁移|页面|wrong tool|insert|draft|migration"),
        ("math-render", r"公式|latex|渲染|格式|markdown|\$ | \$|render|format"),
        ("knowledge-index", r"知识索引|索引|概念|callout|concept|knowledge"),
    ]
    tags = [tag for tag, pattern in checks if re.search(pattern, value, re.I)]
    return tags or ["answer-quality"]


def avoidance_rules(tags):
    rules = []
    if "citation-error" in tags:
        rules.append("copy source links exactly")
    if "hallucination" in tags:
        rules.append("do not present unsupported content as notes")
    if "missing-context" in tags:
        rules.append("search broadly before saying notes are insufficient")
    if "wrong-tool" in tags:
        rules.append("choose the plugin action instead of plain chat")
    if "math-render" in tags:
        rules.append("use Obsidian-renderable LaTeX")
    if "knowledge-index" in tags:
        rules.append("verify knowledge-index hints with evidence")
    return rules


SCENARIOS = [
    {
        "name": "citation hallucination",
        "question": "C星代数的表示是什么？",
        "reason": "这次回答不满意，因为引用错了并且编造了不存在的定义",
        "expected": {"citation-error", "hallucination"},
    },
    {
        "name": "missing knowledge context",
        "question": "整理 C星代数的表示",
        "reason": "明显笔记里有相关内容，但它说缺少核心笔记，遗漏了知识索引里的 callout",
        "expected": {"missing-context", "knowledge-index"},
    },
    {
        "name": "wrong draft tool and math render",
        "question": "把刚才证明插入 #tag2 后面",
        "reason": "它只在聊天框回答，没有插入草稿，而且公式 $ x $ 无法正常渲染",
        "expected": {"wrong-tool", "math-render"},
    },
]


STATIC_CHECKS = [
    ("default setting", PLUGIN_MAIN, "useNegativeFeedbackMemory: true"),
    ("storage field", PLUGIN_MAIN, "negativeFeedbackItems: this.negativeFeedbackItems || []"),
    ("button label", PLUGIN_MAIN, 'text("markUnsatisfied")'),
    ("natural-language handler", PLUGIN_MAIN, "handleUnsatisfiedFeedbackPrompt"),
    ("prompt feedback block", PLUGIN_MAIN, "Unsatisfied-answer feedback to avoid repeating"),
    ("memory modal management", PLUGIN_MAIN, "renderNegativeFeedbackSection"),
    ("delete feedback method", PLUGIN_MAIN, "deleteNegativeFeedback"),
    ("feedback styling", PLUGIN_CSS, "lna-negative-feedback-section"),
]


def main():
    source_cache = {}
    total = 0
    passed = 0
    lines = ["# Negative Feedback Evaluation", ""]

    lines.append("## Static Checks")
    for name, path, needle in STATIC_CHECKS:
        total += 1
        if path not in source_cache:
            source_cache[path] = path.read_text(encoding="utf-8")
        ok = needle in source_cache[path]
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {name}")
        if not ok:
            lines.append(f"  - missing: `{needle}`")

    lines.append("")
    lines.append("## Simulated Feedback Tags")
    for scenario in SCENARIOS:
        total += 1
        tags = set(classify(scenario["question"], scenario["reason"]))
        rules = avoidance_rules(tags)
        ok = scenario["expected"].issubset(tags) and bool(rules)
        passed += int(ok)
        lines.append(f"- {'PASS' if ok else 'FAIL'} {scenario['name']}")
        lines.append(f"  - tags: `{sorted(tags)}`")
        lines.append(f"  - expected subset: `{sorted(scenario['expected'])}`")
        lines.append(f"  - avoidance rules: `{rules}`")

    lines.insert(2, f"Overall: `{passed}/{total}` checks passed.")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} checks passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
