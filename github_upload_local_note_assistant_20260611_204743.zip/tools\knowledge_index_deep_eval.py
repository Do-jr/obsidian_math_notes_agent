from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path


VAULT = Path(r"C:\Users\ddjr\Desktop\obsidian notes.valut")
REPORT = Path("tools/knowledge_index_deep_eval_report.md")

CALLOUT_START = re.compile(r"^\s*>\s*\[!([A-Za-z][\w-]*)\]([+-])?\s*(.*)$")
HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
WIKI = re.compile(r"\[\[([^\]\n]+)\]\]")
TAG = re.compile(r"(^|[\s([{:])#([A-Za-z0-9_\-/\u0080-\uffff]+)")
INLINE_MATH = re.compile(r"\$([^$\n]{1,160})\$")


def clean_snippet(text: str, limit: int = 320) -> str:
    compact = re.sub(r"\s+", " ", str(text or "")).strip()
    return compact if len(compact) <= limit else compact[: limit - 3].strip() + "..."


def limit_text(text: str, limit: int = 2600) -> str:
    value = str(text or "")
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 80)].strip() + "\n\n[section shortened by experiment]"


def normalize_math_aliases(text: str) -> str:
    value = str(text or "")
    value = re.sub(r"\\(?:operatorname|text)\{([^{}]+)\}", r"\1", value)
    value = re.sub(r"\\mathbb\{C\}", " C 复数 complex ", value)
    value = re.sub(r"\\mathbb\{R\}", " R 实数 real ", value)
    value = re.sub(r"\\mathbb\{Z\}", " Z 整数 integer ", value)
    value = re.sub(r"\\mathbb\{Q\}", " Q 有理数 rational ", value)
    value = re.sub(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", " C星 C星代数 Cstar C* ", value, flags=re.I)
    value = re.sub(r"\\bar\s*\{?\s*\\partial\s*\}?", " dbar barpartial Cauchy-Riemann CR 方程 ", value)
    value = value.replace("\\infty", "无穷 infinity")
    value = value.replace("\\ast", "星 ast")
    value = value.replace("\\Delta", "Delta Δ")
    value = value.replace("\\text", " text ")
    value = value.replace("\\operatorname", " operatorname ")
    return value


def normalize_math_canonical(text: str) -> str:
    value = str(text or "")
    value = re.sub(r"\\(?:operatorname|text)\{([^{}]+)\}", r"\1", value)
    value = re.sub(r"\\mathbb\{C\}", " C ", value)
    value = re.sub(r"\\mathbb\{R\}", " R ", value)
    value = re.sub(r"\\mathbb\{Z\}", " Z ", value)
    value = re.sub(r"\\mathbb\{Q\}", " Q ", value)
    value = re.sub(r"c\s*(\^\s*\{?\s*\\?ast\s*\}?|\*)", " C星 ", value, flags=re.I)
    value = value.replace("\\ast", "星")
    value = value.replace("\\infty", "无穷")
    value = value.replace("\\text", " text ")
    value = value.replace("\\operatorname", " operatorname ")
    return value


def add_search_aliases(text: str) -> str:
    value = normalize_math_aliases(str(text or ""))
    compact = re.sub(r"\s+", "", value)
    aliases: list[str] = []
    checks = [
        (r"c星|cstar|c\*", "C星 C星代数 Cstar C* C*-代数 C*代数"),
        (r"topos|拓扑斯", "topos 拓扑斯 初等拓扑斯 Grothendieck拓扑斯"),
        (r"sheaf|层\b|层范畴", "sheaf 层 层范畴 Sh"),
        (r"presheaf|预层", "presheaf 预层 预层范畴"),
        (r"grothendieck\s*topology|grothendieck拓扑|覆盖筛|景", "Grothendieck拓扑 覆盖筛 site 景"),
        (r"geometric\s*morphism|几何态射", "geometric morphism 几何态射 direct-image inverse-image"),
        (r"subobject\s*classifier|子对象分类子", "subobject classifier 子对象分类子 真值对象"),
        (r"locale|位象", "locale 位象 frame 帧"),
        (r"heyting", "Heyting 海廷 Heyting代数"),
        (r"banach", "Banach 巴拿赫 Banach空间"),
        (r"hilbert", "Hilbert 希尔伯特 Hilbert空间"),
        (r"hahn[-\s]?banach", "Hahn-Banach 延拓 分离"),
        (r"拓扑向量|topological\s*vector|tvs", "拓扑向量空间 TVS topological vector space"),
        (r"模型范畴|model\s*category", "模型范畴 model category cofibration fibration weak equivalence"),
        (r"quillen", "Quillen Quillen伴随 Quillen等价 导出函子"),
        (r"reedy", "Reedy Reedy范畴 Reedy模型结构"),
        (r"bousfield", "Bousfield 局部化"),
        (r"谱序列|spectral\s*sequence", "谱序列 spectral sequence 滤过 正合对"),
        (r"galois", "Galois 伽罗瓦 Galois扩张 Galois对应"),
        (r"hilbert\s*90", "Hilbert90 Hilbert 90 上同调"),
        (r"多复变|several\s*complex", "多复变函数 多复变 复分析 SCV"),
        (r"解析集|analytic\s*set", "解析集 analytic set 正则点 奇异点"),
        (r"多重次调和|plurisubharmonic|psh", "多重次调和函数 plurisubharmonic psh Levi形式"),
        (r"拟凸|pseudoconvex", "拟凸域 pseudoconvex Levi拟凸 全纯凸"),
        (r"hartogs", "Hartogs 延拓 Hartogs引理"),
        (r"riemann", "Riemann 可去奇性"),
        (r"weierstrass", "Weierstrass 预备定理 Weierstrass映射"),
        (r"abel", "Abel范畴 abelian category 阿贝尔范畴"),
        (r"yoneda", "Yoneda 米田 可表"),
        (r"kan", "Kan扩张 Kan extension"),
        (r"nip", "NIP 稳定性理论 交错数"),
        (r"morley", "Morley 稳定性 型"),
        (r"definition|定义|定義|是什么|基本定义|概念", "定义 基本定义 概念 是什么"),
        (r"proposition|命题|命題", "命题 proposition"),
        (r"theorem|定理", "定理 theorem"),
        (r"proof|证明|證明", "证明 proof"),
        (r"morphism|态射|同态|homomorphism", "态射 同态 morphism homomorphism"),
        (r"representation|表示论|表示", "表示 表示论 representation"),
    ]
    lower = value.lower()
    for pattern, alias in checks:
        if re.search(pattern, lower, re.I):
            aliases.append(alias)
    return " ".join([value, compact, *aliases])


def tokenize(text: str) -> list[str]:
    value = add_search_aliases(text).lower()
    terms: list[str] = []
    for word in re.findall(r"[a-z0-9_\\\-]+", value):
        cleaned = word.strip("-")
        if len(cleaned) > 1 or cleaned.startswith("\\"):
            terms.append(cleaned)
    for seq in re.findall(r"[\u3400-\u9fff]+", value):
        if len(seq) <= 10:
            terms.append(seq)
        for size in (2, 3, 4, 5):
            if len(seq) < size:
                continue
            for index in range(0, len(seq) - size + 1):
                terms.append(seq[index : index + size])
    seen = set()
    result = []
    for term in terms:
        if term and term not in seen:
            seen.add(term)
            result.append(term)
    return result[:220]


def line_score(text: str, terms: list[str]) -> float:
    lower = add_search_aliases(text).lower()
    score = 0.0
    for term in terms:
        if term in lower:
            score += 10 + min(8, lower.count(term))
    return score


INTENT_WORDS = re.compile(
    r"(请|帮我|解释|说明|整理|总结|相关|内容|主要|给我|一下|是什么|什么是|定义|基本定义|概念|定理|命题|证明|应用|如何|怎么|why|what|how|definition|theorem|proposition|proof)",
    re.I,
)


def query_focus(query: str) -> str:
    value = normalize_math_canonical(query)
    value = INTENT_WORDS.sub(" ", value)
    value = re.sub(r"[\s,，。:：；;?？!！]+", " ", value).strip()
    return value or query.strip()


def compact(value: str) -> str:
    return re.sub(r"\s+", "", add_search_aliases(value).lower())


def plain_compact(value: str) -> str:
    return re.sub(r"\s+", "", normalize_math_canonical(str(value or "")).lower())


def plain_equal(left: str, right: str) -> bool:
    normalized = plain_compact(left)
    return bool(normalized and normalized == plain_compact(right))


def plain_contains(haystack: str, needle: str) -> bool:
    target = plain_compact(needle)
    return bool(target and target in plain_compact(haystack))


def compact_equal(left: str, right: str) -> bool:
    return plain_equal(left, right) or bool(compact(left) and compact(left) == compact(right))


def exactish_contains(haystack: str, needle: str) -> bool:
    if plain_contains(haystack, needle):
        return True
    target = compact(needle)
    return bool(target and target in compact(haystack))


def focus_parts(query: str) -> list[str]:
    focus = query_focus(query)
    pieces = re.split(r"[\s,，。:：；;?？!！/]+", focus)
    result = []
    for piece in pieces:
        cleaned = piece.strip()
        if len(cleaned) >= 2 and not INTENT_WORDS.fullmatch(cleaned):
            result.append(cleaned)
    for match in re.finditer(r"[A-Za-z][A-Za-z0-9\-]{1,}|[\u3400-\u9fff]{2,}", focus):
        item = match.group(0)
        if not INTENT_WORDS.fullmatch(item):
            result.append(item)
    seen = set()
    unique = []
    for item in result:
        key = plain_compact(item)
        if key and key not in seen:
            seen.add(key)
            unique.append(item)
    return unique[:12]


def extract_wiki_links(text: str) -> list[str]:
    links = []
    for match in WIKI.finditer(str(text or "")):
        raw = match.group(1).split("|")[0].split("#")[0].removesuffix(".md").strip()
        if raw:
            links.append(raw)
    return list(dict.fromkeys(links))


def extract_tags(text: str) -> list[str]:
    tags = []
    for match in TAG.finditer(str(text or "")):
        tag = match.group(2).strip()
        if tag and not tag.isdigit():
            tags.append("#" + tag)
    return list(dict.fromkeys(tags))


def get_heading_path(lines: list[str], line_index: int) -> str:
    stack: list[str] = []
    for index in range(0, min(line_index + 1, len(lines))):
        match = HEADING.match(lines[index])
        if not match:
            continue
        level = len(match.group(1))
        while len(stack) < level:
            stack.append("")
        stack[level - 1] = match.group(2).strip()
        del stack[level:]
    return " > ".join(item for item in stack if item) or "(no heading)"


@dataclass
class Callout:
    path: str
    note_title: str
    type: str
    title: str
    line: int
    heading_path: str
    links: list[str]
    tags: list[str]
    formulas: list[str]
    first_sentence: str
    body: str
    summary: str

    @property
    def label(self) -> str:
        if self.title:
            return self.title
        heading = self.heading_path.split(" > ")[-1] if self.heading_path else ""
        return clean_snippet(f"{heading}: {self.first_sentence}", 120)


@dataclass
class Section:
    path: str
    note_title: str
    heading: str
    heading_path: str
    line: int
    body: str
    summary: str
    links: list[str]
    formulas: list[str]


@dataclass
class Profile:
    path: str
    title: str
    folders: list[str]
    folder: str
    links: list[str]
    callouts: list[Callout]
    sections: list[Section]
    text: str
    inbound: int = 0
    score: float = 0.0
    reasons: list[str] = field(default_factory=list)


def extract_callouts(path: Path, text: str) -> list[Callout]:
    lines = text.splitlines()
    callouts: list[Callout] = []
    current = None

    def finish():
        nonlocal current
        if not current:
            return
        body = "\n".join(current["body_lines"]).strip()
        heading_path = get_heading_path(lines, max(0, current["line"] - 1))
        formulas = [clean_snippet(match.group(1), 100) for match in INLINE_MATH.finditer(body)][:16]
        first_sentence = clean_snippet(
            re.split(r"(?<=[。！？.!?])\s+", re.sub(r"\$\$[\s\S]*?\$\$", " ", body))[0] or body,
            260,
        )
        callouts.append(
            Callout(
                path=str(path),
                note_title=path.stem,
                type=current["type"],
                title=current["title"],
                line=current["line"],
                heading_path=heading_path,
                links=extract_wiki_links(body)[:24],
                tags=extract_tags(body)[:16],
                formulas=formulas,
                first_sentence=first_sentence,
                body=limit_text(body, 3000),
                summary=clean_snippet(body, 850),
            )
        )
        current = None

    for index, line in enumerate(lines):
        match = CALLOUT_START.match(line)
        if match:
            finish()
            current = {
                "type": match.group(1).lower(),
                "title": match.group(3).strip(),
                "line": index + 1,
                "body_lines": [],
            }
            continue
        if not current:
            continue
        if re.match(r"^\s*>", line):
            current["body_lines"].append(re.sub(r"^\s*>\s?", "", line))
        elif not line.strip():
            current["body_lines"].append("")
        else:
            finish()
    finish()
    return callouts


def extract_sections(path: Path, text: str) -> list[Section]:
    lines = text.splitlines()
    headings = []
    for index, line in enumerate(lines):
        match = HEADING.match(line)
        if match:
            headings.append((index, len(match.group(1)), match.group(2).strip()))
    sections: list[Section] = []
    for index, (line_index, _level, heading) in enumerate(headings):
        next_line = headings[index + 1][0] if index + 1 < len(headings) else len(lines)
        body = "\n".join(lines[line_index:next_line]).strip()
        if len(body) < 30:
            continue
        formulas = [clean_snippet(match.group(1), 100) for match in INLINE_MATH.finditer(body)][:12]
        sections.append(
            Section(
                path=str(path),
                note_title=path.stem,
                heading=heading,
                heading_path=get_heading_path(lines, line_index),
                line=line_index + 1,
                body=limit_text(body, 2200),
                summary=clean_snippet(body, 650),
                links=extract_wiki_links(body)[:20],
                formulas=formulas,
            )
        )
    return sections


def should_use_file(path: Path, vault: Path) -> bool:
    relative = path.relative_to(vault)
    if ".obsidian" in relative.parts:
        return False
    if relative.parts and relative.parts[0] == "AI Drafts":
        return False
    return path.suffix.lower() == ".md"


def load_profiles(vault: Path) -> tuple[list[Path], list[Callout], list[Section], list[Profile]]:
    files = [path for path in vault.rglob("*.md") if should_use_file(path, vault)]
    callouts: list[Callout] = []
    sections: list[Section] = []
    profiles: list[Profile] = []
    inbound = Counter()
    raw_profiles = []
    for path in files:
        text = path.read_text(encoding="utf-8-sig", errors="ignore")
        relative = path.relative_to(vault)
        links = extract_wiki_links(text)
        for link in links:
            inbound[normalize_ref(link)] += 1
        raw_profiles.append((path, relative, text, links))
    for path, relative, text, links in raw_profiles:
        extracted_callouts = extract_callouts(relative, text)
        extracted_sections = extract_sections(relative, text)
        callouts.extend(extracted_callouts)
        sections.extend(extracted_sections)
        rel_parts = relative.parts
        folders = list(rel_parts[:-1])
        folder = str(Path(*rel_parts[:-1])) if len(rel_parts) > 1 else ""
        profile = Profile(
            path=str(relative),
            title=path.stem,
            folders=folders,
            folder=folder,
            links=links,
            callouts=extracted_callouts,
            sections=extracted_sections,
            text="\n".join(
                [
                    str(relative),
                    path.stem,
                    " ".join(folders),
                    " ".join(c.title or c.label for c in extracted_callouts),
                    " ".join(s.heading for s in extracted_sections[:40]),
                    clean_snippet(text, 8000),
                ]
            ),
            inbound=max(inbound[normalize_ref(path.stem)], inbound[normalize_ref(str(relative).removesuffix(".md"))]),
        )
        profiles.append(profile)
    return files, callouts, sections, profiles


def normalize_ref(value: str) -> str:
    return str(value or "").split("|")[0].split("#")[0].removesuffix(".md").replace("/", "\\").strip().lower()


def requested_types(query: str) -> set[str]:
    value = query.lower()
    result = set()
    if re.search(r"definition|定义|定義|概念|是什么|基本", value):
        result.update(["definition", "def"])
    if re.search(r"proposition|命题|命題", value):
        result.update(["proposition", "prop"])
    if re.search(r"theorem|定理", value):
        result.update(["theorem", "thm"])
    if re.search(r"lemma|引理", value):
        result.add("lemma")
    if re.search(r"proof|证明|證明", value):
        result.add("proof")
    if re.search(r"example|例子|例", value):
        result.add("example")
    if re.search(r"notation|记号|符号|記號|符號", value):
        result.add("notation")
    return result


def score_callout(item: Callout, query: str, terms: list[str]) -> float:
    focus = query_focus(query)
    parts = focus_parts(query)
    req = requested_types(query)
    title_text = f"{item.title} {item.label}"
    locator = f"{item.path} {item.note_title} {item.heading_path}"
    body_text = f"{item.first_sentence} {item.summary} {item.body}"
    score = 0.0
    score += line_score(title_text, terms) * 4.0
    score += line_score(locator, terms) * 2.2
    score += line_score(" ".join(item.links + item.formulas), terms) * 1.5
    score += line_score(body_text, terms) * 0.75
    if req:
        score += 42 if item.type in req else -12
    if compact_equal(item.title, focus) or compact_equal(item.label, focus):
        score += 3200
    elif exactish_contains(title_text, focus):
        score += 1800
    if compact_equal(item.note_title, focus):
        score += 850
    elif exactish_contains(item.note_title, focus):
        score += 260
    if exactish_contains(item.heading_path, focus):
        score += 70
    if exactish_contains(item.path, focus):
        score += 55
    for part in parts:
        if compact_equal(item.title, part) or compact_equal(item.label, part):
            score += 1200
        elif exactish_contains(title_text, part):
            score += 420
        if compact_equal(item.note_title, part):
            score += 520
        elif exactish_contains(item.note_title, part):
            score += 150
        if re.search(r"[A-Za-z]", part) and exactish_contains(title_text, part):
            score += 700
    if len(parts) >= 2:
        title_or_locator_matches = [
            part for part in parts if exactish_contains(title_text, part) or exactish_contains(locator, part)
        ]
        title_matches = [part for part in parts if exactish_contains(title_text, part)]
        if len(title_or_locator_matches) >= 2:
            score += 360 + 120 * len(title_matches)
        else:
            score -= 220
        if all(exactish_contains(f"{title_text} {locator}", part) for part in parts):
            score += 1500
        if title_matches and any(exactish_contains(locator, part) for part in parts if part not in title_matches):
            score += 4500
    if item.type in {"definition", "def", "theorem", "thm", "proposition", "prop", "lemma", "corollary"}:
        score += 8
    if item.title:
        score += 6
    if item.line <= 25 and exactish_contains(item.note_title, focus):
        score += 55
    if re.search(r"定义|definition|是什么|基本|概念", query, re.I):
        if item.type in {"definition", "def"}:
            score += 25
            if compact_equal(item.title, focus) or compact_equal(item.note_title, focus):
                score += 900
            if item.line <= 25 and any(
                compact_equal(item.title, part) or compact_equal(item.note_title, part) for part in parts
            ):
                score += 550
        if item.line <= 25 and (
            compact_equal(item.note_title, focus)
            or compact_equal(item.title, focus)
            or any(compact_equal(item.title, part) or compact_equal(item.note_title, part) for part in parts)
        ):
            score += 420
        if item.type not in {"definition", "def"}:
            score -= 120
        if item.line > 220 and not any(exactish_contains(title_text, part) for part in parts):
            score -= 45
    if re.search(r"定理|theorem", query, re.I):
        if item.type in {"theorem", "thm"}:
            score += 35
        elif item.type in {"definition", "def"}:
            score -= 20
    return score


def rank_callouts(callouts: list[Callout], query: str) -> list[tuple[float, Callout]]:
    terms = tokenize(query)
    return sorted(
        ((score_callout(item, query, terms), item) for item in callouts),
        key=lambda pair: pair[0],
        reverse=True,
    )


def score_profile(profile: Profile, query: str, terms: list[str]) -> float:
    focus = query_focus(query)
    parts = focus_parts(query)
    score = 0.0
    score += line_score(profile.title, terms) * 5.0
    score += line_score(profile.path, terms) * 3.0
    score += line_score(" ".join(profile.folders), terms) * 2.5
    score += line_score(profile.text, terms) * 0.45
    if compact_equal(profile.title, focus):
        score += 180
    elif exactish_contains(profile.title, focus):
        score += 55
    if exactish_contains(profile.path, focus):
        score += 90
    for part in parts:
        if compact_equal(profile.title, part):
            score += 150
        elif exactish_contains(profile.title, part):
            score += 45
        if exactish_contains(profile.path, part):
            score += 45
    score += min(28, profile.inbound * 0.6)
    score += min(30, len(profile.callouts) * 0.45)
    return score


TOPIC_CORE_HINTS = {
    "c星代数": ["C星代数", "表示", "范畴性质", "正锥", "连续函数演算", "von Neumann"],
    "多复变函数": ["解析集", "全纯映射", "多重次调和", "拟凸", "全纯凸", "解析分歧覆盖", "Hartogs"],
    "拓扑斯": ["拓扑斯", "几何态射", "Grothendieck拓扑", "Grothendieck拓扑上的层范畴", "预层范畴", "子对象分类子", "位象"],
    "模型范畴": ["模型范畴", "Quillen伴随", "Quillen等价", "Reedy模型结构", "Bousfield局部化", "单纯集的模型结构"],
    "谱序列": ["谱序列", "Grothendieck谱序列", "滤过对象"],
    "galois理论": ["Galois对应", "Galois扩张", "Hilbert 90", "Kummer理论", "正规基定理"],
}


def topic_core_hints(query: str) -> list[str]:
    q = compact(query_focus(query))
    hints: list[str] = []
    for key, values in TOPIC_CORE_HINTS.items():
        if compact(key) in q or q in compact(key):
            hints.extend(values)
    return hints


def profile_matches(profile: Profile, ref: str) -> bool:
    target = normalize_ref(ref)
    title = normalize_ref(profile.title)
    path = normalize_ref(profile.path)
    return bool(target and (target == title or target == path or path.endswith("\\" + target) or target.endswith("\\" + title)))


def topic_bundle(profiles: list[Profile], callouts: list[Callout], query: str, limit: int = 14) -> list[Profile]:
    terms = tokenize(query)
    focus = query_focus(query)
    hints = topic_core_hints(query)
    ranked_callouts = rank_callouts(callouts, query)
    seed_paths = {item.path for _score, item in ranked_callouts[:16]}
    direct_profiles = sorted(((score_profile(p, query, terms), p) for p in profiles), key=lambda pair: pair[0], reverse=True)
    for _score, profile in direct_profiles[:8]:
        seed_paths.add(profile.path)
    seed_profiles = [profile for profile in profiles if profile.path in seed_paths]
    seed_refs = set()
    seed_links: list[str] = []
    seed_folders = set()
    for profile in seed_profiles:
        seed_refs.add(normalize_ref(profile.title))
        seed_refs.add(normalize_ref(profile.path))
        if profile.folder:
            seed_folders.add(profile.folder)
        seed_links.extend(profile.links)
    scored: list[Profile] = []
    for profile in profiles:
        reasons: list[str] = []
        score = score_profile(profile, query, terms)
        if profile.path in seed_paths:
            score += 120
            reasons.append("direct match")
        if profile.folder and profile.folder in seed_folders:
            score += 75
            reasons.append("same topic folder")
        if any(normalize_ref(link) in seed_refs for link in profile.links):
            score += 70
            reasons.append("links to seed")
        if any(profile_matches(profile, link) for link in seed_links):
            score += 70
            reasons.append("linked from seed")
        if compact_equal(profile.title, focus):
            score += 160
            reasons.append("exact topic title")
        elif exactish_contains(profile.title, focus):
            score += 45
            reasons.append("title contains topic")
        elif exactish_contains(profile.path, focus):
            score += 55
            reasons.append("path contains topic")
        for hint in hints:
            if compact_equal(profile.title, hint):
                score += 260
                reasons.append(f"core hint: {hint}")
            elif exactish_contains(f"{profile.title} {profile.path}", hint):
                score += 170
                reasons.append(f"core hint: {hint}")
        if score > 0:
            scored_profile = Profile(**{**profile.__dict__, "score": score, "reasons": reasons or ["semantic"]})
            scored.append(scored_profile)
    return sorted(scored, key=lambda item: item.score, reverse=True)[:limit]


CALLOUT_TESTS = [
    ("C星代数 是什么", "泛函分析\\C星代数\\C星代数.md", 4, 2, "basic C*-algebra definition"),
    ("C*代数的表示是什么", "泛函分析\\C星代数\\C星代数的表示.md", 3, 3, "C* notation should map to C星 representation note"),
    ("C星代数表示间的态射", "泛函分析\\C星代数\\C星代数的表示.md", 15, 3, "representation morphism should not be lost"),
    ("拓扑向量空间 基本定义", "泛函分析\\拓扑向量空间\\拓扑向量空间的理论部分.md", 3, 2, "basic TVS definition"),
    ("拓扑向量空间 度量化定理", "泛函分析\\拓扑向量空间\\拓扑向量空间的理论部分.md", 174, 2, "specific theorem in a long note"),
    ("解析集 定义 多复变函数", "多复变函数\\解析集.md", 3, 2, "SCV analytic set definition"),
    ("多重次调和函数 Hartogs引理", "多复变函数\\多重次调和函数.md", 160, 3, "named lemma/theorem inside a long SCV note"),
    ("Levi拟凸域 Narasimhan", "多复变函数\\凸性理论\\Levi拟凸域.md", 155, 3, "named Narasimhan theorem"),
    ("解析分歧覆盖 局部典则表示", "多复变函数\\解析分歧覆盖\\解析分歧覆盖.md", 63, 3, "specific theorem in nested folder"),
    ("Grothendieck拓扑 定义", "拓扑斯理论\\Grothendieck拓扑.md", 23, 3, "Grothendieck topology definition"),
    ("子对象分类子 定义", "拓扑斯理论\\子对象分类子.md", 32, 3, "subobject classifier definition"),
    ("几何态射 定义", "拓扑斯理论\\几何态射.md", 5, 2, "geometric morphism definition"),
    ("局部小的纤维范畴 定义", "范畴论\\纤维范畴\\局部小的纤维范畴.md", 8, 3, "fibered category subtopic"),
    ("Quillen伴随 定义", "模型范畴\\Quillen伴随.md", 3, 2, "Quillen adjunction definition"),
    ("谱序列 定义", "同调代数\\谱序列\\谱序列.md", 4, 2, "spectral sequence definition"),
    ("Galois基本定理", "Galois理论\\理论部分\\Galois对应.md", 23, 2, "named theorem"),
    ("Hahn-Banach定理", "泛函分析\\Hahn-Banach定理.md", 16, 3, "named functional analysis theorem"),
    ("Abel范畴 定义", "范畴论\\Abel范畴\\Abel范畴.md", 290, 5, "avoid stopping at preadditive/additive definitions"),
    ("NIP 定义", "模型论\\稳定性理论\\NIP.md", 4, 3, "Latin abbreviation with Chinese notes"),
    ("光滑态射 Jacobian判别法", "代数几何\\光滑态射.md", 244, 3, "algebraic geometry named criterion"),
]


TOPIC_TESTS = [
    ("C星代数", "泛函分析\\C星代数\\C星代数.md", 4, "core C*-algebra note"),
    ("C星代数", "泛函分析\\C星代数\\C星代数的表示.md", 8, "representation should be covered"),
    ("C星代数", "泛函分析\\C星代数\\C星代数的范畴性质.md", 8, "category properties should be covered"),
    ("多复变函数", "多复变函数\\解析集.md", 12, "analytic sets are a major SCV branch"),
    ("多复变函数", "多复变函数\\多重次调和函数.md", 12, "plurisubharmonic functions are a major SCV branch"),
    ("多复变函数", "多复变函数\\全纯理论\\全纯映射的定义和基本性质.md", 12, "holomorphic maps are core SCV"),
    ("多复变函数", "多复变函数\\凸性理论\\拟凸域.md", 14, "pseudoconvexity branch"),
    ("拓扑斯", "拓扑斯理论\\拓扑斯.md", 5, "core topos note"),
    ("拓扑斯", "拓扑斯理论\\几何态射.md", 10, "geometric morphisms are central"),
    ("拓扑斯", "拓扑斯理论\\Grothendieck拓扑.md", 12, "Grothendieck topology should be covered"),
    ("模型范畴", "模型范畴\\模型范畴.md", 5, "core model category note"),
    ("模型范畴", "模型范畴\\Quillen伴随.md", 12, "Quillen adjunction should be covered"),
    ("谱序列", "同调代数\\谱序列\\谱序列.md", 5, "core spectral sequence note"),
    ("Galois理论", "Galois理论\\理论部分\\Galois对应.md", 10, "Galois correspondence should be covered"),
]


def main() -> int:
    files, callouts, sections, profiles = load_profiles(VAULT)
    lines = [
        "# Deep Knowledge Index Evaluation",
        "",
        f"- Vault: `{VAULT}`",
        f"- Markdown files used: `{len(files)}`",
        f"- Excluded folder: `AI Drafts`",
        f"- Callouts: `{len(callouts)}`",
        f"- Sections: `{len(sections)}`",
        "",
    ]
    passed = 0
    total = len(CALLOUT_TESTS) + len(TOPIC_TESTS)
    for query, must_path, must_line, top, why in CALLOUT_TESTS:
        ranked = rank_callouts(callouts, query)
        hit = None
        for index, (_score, item) in enumerate(ranked[:top], start=1):
            if item.path == must_path and item.line == must_line:
                hit = index
                break
        ok = hit is not None
        passed += 1 if ok else 0
        lines.append(f"## {'PASS' if ok else 'FAIL'} precise: {query}")
        lines.append("")
        lines.append(f"- Ideal: `{must_path}:{must_line}` in top {top}")
        lines.append(f"- Reason: {why}")
        lines.append(f"- Actual: {'hit position `' + str(hit) + '`' if ok else 'not found in required range'}")
        lines.append("")
        lines.append("Top candidates:")
        for index, (score, item) in enumerate(ranked[: max(top, 8)], start=1):
            lines.append(f"{index}. `{score:.1f}` `{item.path}:{item.line}` [{item.type}] {item.title or item.label}")
        lines.append("")
    for query, must_path, top, why in TOPIC_TESTS:
        bundle = topic_bundle(profiles, callouts, query, max(14, top))
        hit = None
        for index, profile in enumerate(bundle[:top], start=1):
            if profile.path == must_path:
                hit = index
                break
        ok = hit is not None
        passed += 1 if ok else 0
        lines.append(f"## {'PASS' if ok else 'FAIL'} topic bundle: {query}")
        lines.append("")
        lines.append(f"- Ideal: `{must_path}` in topic bundle top {top}")
        lines.append(f"- Reason: {why}")
        lines.append(f"- Actual: {'hit position `' + str(hit) + '`' if ok else 'not found in required range'}")
        lines.append("")
        lines.append("Top topic notes:")
        for index, profile in enumerate(bundle[: max(top, 10)], start=1):
            reason = ", ".join(profile.reasons)
            lines.append(f"{index}. `{profile.score:.1f}` `{profile.path}` ({reason})")
        lines.append("")
    lines.insert(1, f"\nSummary: `{passed}/{total}` tests passed.\n")
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} tests passed")
    print(REPORT)
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
